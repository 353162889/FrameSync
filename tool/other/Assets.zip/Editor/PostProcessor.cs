﻿#if UNITY_IPHONE
using UnityEngine;
using UnityEditor;
using UnityEditor.Callbacks;
using UnityEditor.iOS.Xcode;
using System.IO;

public static class PostProcessor
{
    [PostProcessBuild]
	public static void OnPostProcessBuild (BuildTarget eTarget, string strPath)
	{
		if (eTarget != BuildTarget.iOS)
        {
            return;
		}

        PBXProject pbxProject = new PBXProject();
        string pbxProjPath = PBXProject.GetPBXProjectPath(strPath);
        string strGuidName = PBXProject.GetUnityTargetName();

        // 读取
        pbxProject.ReadFromString(File.ReadAllText(pbxProjPath));
        string targetGuid = pbxProject.TargetGuidByName(strGuidName);

        pbxProject.SetBuildProperty(targetGuid, "CODE_SIGN_STYLE", "Manual");
        pbxProject.SetBuildProperty(targetGuid, "ENABLE_BITCODE", "NO");

        //TalkingData
        pbxProject.AddFrameworkToProject(targetGuid, "AdSupport.framework", false);
        pbxProject.AddFrameworkToProject(targetGuid, "CoreTelephony.framework", false);
        pbxProject.AddFrameworkToProject(targetGuid, "CoreMotion.framework", false);
        pbxProject.AddFrameworkToProject(targetGuid, "Security.framework", false);
        pbxProject.AddFrameworkToProject(targetGuid, "SystemConfiguration.framework", false);

        //Bugly
        pbxProject.AddFrameworkToProject(targetGuid, "JavaScriptCore.framework", true);

        //CloudVoice
        pbxProject.AddFrameworkToProject(targetGuid, "Accelerate.framework", false);
        pbxProject.AddFrameworkToProject(targetGuid, "ImageIO.framework", false);
        pbxProject.AddFrameworkToProject(targetGuid, "CoreImage.framework", false);
        pbxProject.AddFrameworkToProject(targetGuid, "SafariServices.framework", false);

        //ShareSDK
        pbxProject.AddFileToBuild(targetGuid, pbxProject.AddFile("usr/lib/" + "libicucore.tbd", "Frameworks/libicucore.tbd", PBXSourceTree.Sdk));
        pbxProject.AddFileToBuild(targetGuid, pbxProject.AddFile("usr/lib/" + "libstdc++.tbd", "Frameworks/libstdc++.tbd", PBXSourceTree.Sdk));

        //微信
        pbxProject.AddFrameworkToProject(targetGuid, "CFNetwork.framework", false);
        pbxProject.AddFileToBuild(targetGuid, pbxProject.AddFile("usr/lib/" + "libsqlite3.tbd", "Frameworks/libsqlite3.tbd", PBXSourceTree.Sdk));
        pbxProject.AddBuildProperty(targetGuid, "OTHER_LDFLAGS", "-ObjC");

        //舜飞SDK
        //pbxProject.AddBuildProperty(targetGuid, "OTHER_LDFLAGS", "-all_load");


        pbxProject.AddFileToBuild(targetGuid, pbxProject.AddFile("usr/lib/" + "libc++.tbd", "Frameworks/libc++.tbd", PBXSourceTree.Sdk));
        pbxProject.AddFileToBuild(targetGuid, pbxProject.AddFile("usr/lib/" + "libz.tbd", "Frameworks/libz.tbd", PBXSourceTree.Sdk));

        File.WriteAllText(pbxProjPath, pbxProject.WriteToString());


        string plistPath = strPath + "/Info.plist";
        PlistDocument plist = new PlistDocument();
        plist.ReadFromString(File.ReadAllText(plistPath));
        PlistElementDict rootDict = plist.root;

        rootDict.SetString("NSMicrophoneUsageDescription", "Use Microphone");
        rootDict.SetString("NSAllowsArbitraryLoads", "YES");

        //舜飞微信相关
        PlistElementArray loginChannelsArr;
        loginChannelsArr = rootDict.CreateArray("LSApplicationQueriesSchemes");
        loginChannelsArr.AddString("weixin");
        loginChannelsArr.AddString("wechat");

        PlistElementDict itemDict = rootDict.CreateDict("STThird-PartyPlatformAppIDs");
        itemDict.SetString("WeChatOpenSDK", "wx266fcee02c24e009");

        PlistElementArray urlTypes = rootDict.CreateArray("CFBundleURLTypes");
        itemDict = urlTypes.AddDict();
        itemDict.SetString("CFBundleTypeRole", "Editor");
        itemDict.SetString("CFBundleURLName", "weixin");
        PlistElementArray schemesArray1 = itemDict.CreateArray("CFBundleURLSchemes");
        schemesArray1.AddString("wx266fcee02c24e009");

        File.WriteAllText(plistPath, plist.WriteToString());
	}
}
#endif