﻿using System.Collections.Generic;
using System.IO;
using UnityEditor;
using UnityEngine;

public class AutoSetPackingTag : EditorWindow
{
    [MenuItem("Tools/UI资源管理/自动检测和设置 UI的[PackingTag]")]
    static void ShowWindow()
    {
        GetWindow<AutoSetPackingTag>("设置PackingTag").Show();
    }

    List<string> picList = new List<string>();
    Vector2 scrollPos = Vector2.zero;
    string folderPath;

    private void SearchAllUIFile()
    {
        string[] files = Directory.GetFiles(folderPath, "*.*", SearchOption.AllDirectories);
        foreach (string file in files)
        {
            if (EditorConst.IsPicAsset(file) == false) continue;

            string strFile = file.Substring(file.IndexOf("Asset")).Replace('\\', '/');
            
            if (EditorConst.IsSizeOver256(strFile) == true) continue;  //尺寸过大  不打包图集

            picList.Add(strFile);
        }
    }

    void ChangePicPackingTag(TextureImporter ti, string folderStr)
    {
        if (ti.spritePackingTag != folderStr)
        {
            ti.spritePackingTag = folderStr;
            ti.SaveAndReimport();
        }
    }

    /// <summary>
    /// 修改列表所有设置
    /// </summary>
    void ChangeAllUISetting()
    {
        float count = 0;
        foreach (string t in picList)
        {
            count++;
            EditorUtility.DisplayProgressBar("Processing...", "替换中... (" + count + " / " + picList.Count + ")", count / picList.Count);
            TextureImporter ti = AssetImporter.GetAtPath(t) as TextureImporter;

            string dirName = Path.GetDirectoryName(t);
            string folderStr = Path.GetFileName(dirName);
            ChangePicPackingTag(ti, folderStr);
        }

        EditorUtility.ClearProgressBar();
    }

    void OnGUI()
    {
        EditorGUILayout.BeginHorizontal();
        foreach (string folderName in EditorConst.atlasPathArr)
        {
            if (GUILayout.Button("搜索 : "+ folderName , GUILayout.Width(200), GUILayout.Height(50)))
            {
                folderPath = Application.dataPath + folderName;
                picList.Clear();
                SearchAllUIFile();
            }
        }

        if (GUILayout.Button("修改所有PackingTag", GUILayout.Width(200), GUILayout.Height(50)))
        {
            ChangeAllUISetting();
        }

        EditorGUILayout.EndHorizontal();

        scrollPos = EditorGUILayout.BeginScrollView(scrollPos);
        foreach (string file in picList)
        {
            EditorGUILayout.BeginHorizontal();
            string showFilePath = file.Substring(file.IndexOf("ResourcesEx"));
            EditorGUILayout.LabelField("文件路径 : " + showFilePath, GUILayout.Width(400));

            string dirName = Path.GetDirectoryName(file);
            string folderStr = Path.GetFileName(dirName);

            Texture2D texture = (Texture2D)AssetDatabase.LoadAssetAtPath(file, typeof(Texture2D));
            EditorGUILayout.ObjectField(texture, typeof(Texture2D), false);

            TextureImporter ti = AssetImporter.GetAtPath(file) as TextureImporter;
            EditorGUILayout.LabelField("当前PackingTag :   [" + ti.spritePackingTag + "]");

            EditorGUILayout.Space();
            if (ti.spritePackingTag != folderStr)
            {
                EditorGUILayout.LabelField("✖ | PackingTag应为 : [" + folderStr + "]");
            }
            else
            {
                EditorGUILayout.LabelField("✔");
            }

            if (GUILayout.Button("修改PackingTag", GUILayout.Width(150)))
            {
                ChangePicPackingTag(ti, folderStr);
            }

            EditorGUILayout.EndHorizontal();
            EditorGUILayout.Space();
        }
        EditorGUILayout.EndScrollView();
    }

}
