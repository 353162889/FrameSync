﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEditor;

public class AffectFieldBase
{
    protected EEventAffectType m_eAffectType = EEventAffectType.ENone;
    public EEventAffectType affectType { get { return m_eAffectType; } }

    public AffectFieldBase(EventAffectData cAffectData)
    {
        m_eAffectType = cAffectData.mType;
    }

    public virtual string GetDescribe1()
    {
        return "参数1";
    }
    public virtual string GetDescribe2()
    {
        return "参数2";
    }
    public virtual string GetDescribe3()
    {
        return "参数3";
    }
    public virtual string GetDescribe4()
    {
        return "参数4";
    }
}

public class AffectFieldFactory
{
    public static AffectFieldBase CreateField(EventAffectData cAffectData)
    {
        if (EEventAffectType.ENone == cAffectData.mType)
        {
            return null;
        }

        AffectFieldBase cAffectField = null;
        switch (cAffectData.mType)
        {
            case EEventAffectType.EHp:
                cAffectField = new HpAffectField(cAffectData);
                break;

            case EEventAffectType.EAddBuff:
                cAffectField = new AddBuffAffectField(cAffectData);
                break;

            case EEventAffectType.ERemoveBuff:
                cAffectField = new RemoveBuffAffectField(cAffectData);
                break;
            case EEventAffectType.EAddHalo:
                cAffectField = new AddHaloAffectField(cAffectData);
                break;

            case EEventAffectType.ERemoveHalo:
                cAffectField = new RemoveHaloAffectField(cAffectData);
                break;
            case EEventAffectType.EEffect:
                cAffectField = new EffectAffectField(cAffectData);
                break;
            case EEventAffectType.EDispelBuff:
                cAffectField = new DispelBuffField(cAffectData);
                break;
            case EEventAffectType.EAudio:
                cAffectField = new AudioAffectField(cAffectData);
                break;
            case EEventAffectType.EResetTarget:
                cAffectField = new ResetTargetAffectField(cAffectData);
                break;
            case EEventAffectType.EResetTargetPosition:
                cAffectField = new ResetTargetPositionAffectField(cAffectData);
                break;
            case EEventAffectType.EResetTargetDirect:
                cAffectField = new ResetTargetDirectAffectField(cAffectData);
                break;
            case EEventAffectType.EBreakPhase:
                cAffectField = new BreakPhaseAffectField(cAffectData);
                break;
            case EEventAffectType.EAnimation:
                cAffectField = new AnimationAffectField(cAffectData);
                break;
            case EEventAffectType.EShakeCamera:
                cAffectField = new ShakeCameraAffectField(cAffectData);
                break;
        }
        return cAffectField;
    }
}

public class HpAffectField : AffectFieldBase
{
    public HpAffectField(EventAffectData cAffectData) : base(cAffectData)
    {
        if (null == cAffectData.mParamer1)
        {
            cAffectData.mParamer1 = "";
        }
    }

    public override string GetDescribe1()
    {
        return "Hp";
    }
}

public class AddBuffAffectField : AffectFieldBase
{
    public AddBuffAffectField(EventAffectData cAffectData) : base(cAffectData)
    {
        if (null == cAffectData.mParamer1)
        {
            cAffectData.mParamer1 = 0;
        }
        if (null == cAffectData.mParamer2)
        {
            cAffectData.mParamer2 = 0;
        }
        if (null == cAffectData.mParamer3)
        {
            cAffectData.mParamer3 = 0;
        }
        if (null == cAffectData.mParamer4)
        {
            cAffectData.mParamer4 = 0;
        }
    }

    public override string GetDescribe1()
    {
        return "BuffId";
    }
    public override string GetDescribe2()
    {
        return "BuffId";
    }
    public override string GetDescribe3()
    {
        return "BuffId";
    }
    public override string GetDescribe4()
    {
        return "BuffId";
    }
}

public class RemoveBuffAffectField : AffectFieldBase
{
    public RemoveBuffAffectField(EventAffectData cAffectData) : base(cAffectData)
    {
        if (null == cAffectData.mParamer1)
        {
            cAffectData.mParamer1 = 0;
        }
        if (null == cAffectData.mParamer2)
        {
            cAffectData.mParamer2 = 0;
        }
        if (null == cAffectData.mParamer3)
        {
            cAffectData.mParamer3 = 0;
        }
        if (null == cAffectData.mParamer4)
        {
            cAffectData.mParamer4 = 0;
        }
    }

    public override string GetDescribe1()
    {
        return "BuffId";
    }
    public override string GetDescribe2()
    {
        return "BuffId";
    }
    public override string GetDescribe3()
    {
        return "BuffId";
    }
    public override string GetDescribe4()
    {
        return "BuffId";
    }
}

public class AddHaloAffectField : AffectFieldBase
{
    public AddHaloAffectField(EventAffectData cAffectData) : base(cAffectData)
    {
        if (null == cAffectData.mParamer1)
        {
            cAffectData.mParamer1 = 0;
        }
        if (null == cAffectData.mParamer2)
        {
            cAffectData.mParamer2 = 0;
        }
        if (null == cAffectData.mParamer3)
        {
            cAffectData.mParamer3 = 0;
        }
        if (null == cAffectData.mParamer4)
        {
            cAffectData.mParamer4 = 0;
        }
    }

    public override string GetDescribe1()
    {
        return "HaloId";
    }
    public override string GetDescribe2()
    {
        return "HaloId";
    }
    public override string GetDescribe3()
    {
        return "HaloId";
    }
    public override string GetDescribe4()
    {
        return "HaloId";
    }
}

public class RemoveHaloAffectField : AffectFieldBase
{
    public RemoveHaloAffectField(EventAffectData cAffectData) : base(cAffectData)
    {
        if (null == cAffectData.mParamer1)
        {
            cAffectData.mParamer1 = 0;
        }
        if (null == cAffectData.mParamer2)
        {
            cAffectData.mParamer2 = 0;
        }
        if (null == cAffectData.mParamer3)
        {
            cAffectData.mParamer3 = 0;
        }
        if (null == cAffectData.mParamer4)
        {
            cAffectData.mParamer4 = 0;
        }
    }

    public override string GetDescribe1()
    {
        return "HaloId";
    }
    public override string GetDescribe2()
    {
        return "HaloId";
    }
    public override string GetDescribe3()
    {
        return "HaloId";
    }
    public override string GetDescribe4()
    {
        return "HaloId";
    }
}

public class EffectAffectField : AffectFieldBase
{
    public EffectAffectField(EventAffectData cAffectData) : base(cAffectData)
    {
        if (null == cAffectData.mParamer1)
        {
            cAffectData.mParamer1 = "";
        }
        if (null == cAffectData.mParamer2)
        {
            cAffectData.mParamer2 = "";
        }
        if(null == cAffectData.mParamer3)
        {
            cAffectData.mParamer3 = false;
        }
        if (null == cAffectData.mParamer4)
        {
            cAffectData.mParamer4 = false;
        }
    }

    public override string GetDescribe1()
    {
        return "特效名";
    }
    public override string GetDescribe2()
    {
        return "挂点";
    }

    public override string GetDescribe3()
    {
        return "使用受击位置";
    }
    public override string GetDescribe4()
    {
        return "使用受击方向";
    }
}

public class DispelBuffField : AffectFieldBase
{
    public DispelBuffField(EventAffectData cAffectData) : base(cAffectData)
    {
        if (null == cAffectData.mParamer1)
        {
            cAffectData.mParamer1 = "";
        }
        if (null == cAffectData.mParamer2)
        {
            cAffectData.mParamer2 = "";
        }
        if (null == cAffectData.mParamer3)
        {
            cAffectData.mParamer3 = "";
        }
        if (null == cAffectData.mParamer4)
        {
            cAffectData.mParamer4 = "";
        }
    }

    public override string GetDescribe1()
    {
        return "BuffAffect";
    }
    public override string GetDescribe2()
    {
        return "BuffAffect";
    }
    public override string GetDescribe3()
    {
        return "BuffAffect";
    }
    public override string GetDescribe4()
    {
        return "BuffAffect";
    }
}

public class AudioAffectField : AffectFieldBase
{
    public AudioAffectField(EventAffectData cAffectData) : base(cAffectData)
    {
        if (null == cAffectData.mParamer1)
        {
            cAffectData.mParamer1 = 0;
        }
        if (null == cAffectData.mParamer2)
        {
            cAffectData.mParamer2 = 0;
        }
        if (null == cAffectData.mParamer3)
        {
            cAffectData.mParamer3 = 0;
        }
        if (null == cAffectData.mParamer4)
        {
            cAffectData.mParamer4 = 0;
        }
    }

    public override string GetDescribe1()
    {
        return "音效ID";
    }
    public override string GetDescribe2()
    {
        return "音效ID";
    }
    public override string GetDescribe3()
    {
        return "音效ID";
    }
    public override string GetDescribe4()
    {
        return "音效ID";
    }
}

public class ResetTargetAffectField : AffectFieldBase
{
    public ResetTargetAffectField(EventAffectData cAffectData) : base(cAffectData)
    {
        
    }
}

public class ResetTargetPositionAffectField : AffectFieldBase
{
    public ResetTargetPositionAffectField(EventAffectData cAffectData) : base(cAffectData)
    {

    }
}

public class ResetTargetDirectAffectField : AffectFieldBase
{
    public ResetTargetDirectAffectField(EventAffectData cAffectData) : base(cAffectData)
    {

    }
}

public class BreakPhaseAffectField : AffectFieldBase
{
    public BreakPhaseAffectField(EventAffectData cAffectData) : base(cAffectData)
    {

    }
}

public class AnimationAffectField : AffectFieldBase
{
    public AnimationAffectField(EventAffectData cAffectData) : base(cAffectData)
    {
        if (null == cAffectData.mParamer1)
        {
            cAffectData.mParamer1 = "";
        }
    }

    public override string GetDescribe1()
    {
        return "动画名称";
    }
}

public class ShakeCameraAffectField : AffectFieldBase
{
    public ShakeCameraAffectField(EventAffectData cAffectData) : base(cAffectData)
    {
        if (null == cAffectData.mParamer1)
        {
            cAffectData.mParamer1 = 30;
        }
        if (null == cAffectData.mParamer2)
        {
            cAffectData.mParamer2 = 200;
        }
        if (null == cAffectData.mParamer3)
        {
            cAffectData.mParamer3 = 20000;
        }
    }

    public override string GetDescribe1()
    {
        return "时长";
    }
    public override string GetDescribe2()
    {
        return "幅度";
    }
    public override string GetDescribe3()
    {
        return "速度";
    }
}


