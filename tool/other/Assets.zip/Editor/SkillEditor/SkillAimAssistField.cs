﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

public class AimAssistFieldFactory
{
    public static AimAssistFieldBase CreateField(SkillAimAssistData cAimAssistData)
    {
        AimAssistFieldBase cAimAssistField = null;
        switch (cAimAssistData.mType)
        {
            case EAimAssistType.Adsorb:
                cAimAssistField = new AdsorbAimAssistField(cAimAssistData);
                break;
            case EAimAssistType.Lock:
                cAimAssistField = new LockAimAssistField(cAimAssistData);
                break;
        }
        return cAimAssistField;
    }
}

public class AimAssistFieldBase
{
    protected EAimAssistType m_eAimAssistType = EAimAssistType.Adsorb;
    public EAimAssistType aimAssistType { get { return m_eAimAssistType; } }

    public AimAssistFieldBase(SkillAimAssistData cAimAssistData)
    {
        m_eAimAssistType = cAimAssistData.mType;
    }

    public virtual string GetDescribe1()
    {
        return "参数1";
    }
    public virtual string GetDescribe2()
    {
        return "参数2";
    }
    public virtual string GetDescribe3()
    {
        return "参数3";
    }
    public virtual string GetDescribe4()
    {
        return "参数4";
    }
    public virtual string GetDescribe5()
    {
        return "参数5";
    }
    public virtual string GetDescribe6()
    {
        return "参数6";
    }
}

public class AdsorbAimAssistField : AimAssistFieldBase
{
    public AdsorbAimAssistField(SkillAimAssistData cAimAssistData) : base(cAimAssistData)
    {
        if (null == cAimAssistData.mParamer1)
        {
            cAimAssistData.mParamer1 = 0;
        }
        if (null == cAimAssistData.mParamer2)
        {
            cAimAssistData.mParamer2 = 0;
        }
        if (null == cAimAssistData.mParamer3)
        {
            cAimAssistData.mParamer3 = 0;
        }
        cAimAssistData.mParamer4 = null;
        cAimAssistData.mParamer5 = null;
        cAimAssistData.mParamer6 = null;
    }

    public override string GetDescribe1()
    {
        return "吸附范围角度";
    }
    public override string GetDescribe2()
    {
        return "吸附范围距离";
    }
    public override string GetDescribe3()
    {
        return "吸附角度";
    }
}

public class LockAimAssistField : AimAssistFieldBase
{
    public LockAimAssistField(SkillAimAssistData cAimAssistData) : base(cAimAssistData)
    {
        if (null == cAimAssistData.mParamer1)
        {
            cAimAssistData.mParamer1 = 0;
        }
        if (null == cAimAssistData.mParamer2)
        {
            cAimAssistData.mParamer2 = 0;
        }
        if (null == cAimAssistData.mParamer3 || cAimAssistData.mParamer3.GetType() != typeof(EAimAssistSelectType))
        {
            cAimAssistData.mParamer3 = EAimAssistSelectType.MinHP;
        }
        cAimAssistData.mParamer4 = null;
        cAimAssistData.mParamer5 = null;
        cAimAssistData.mParamer6 = null;
    }

    public override string GetDescribe1()
    {
        return "锁定范围角度";
    }
    public override string GetDescribe2()
    {
        return "锁定范围距离";
    }

    public override string GetDescribe3()
    {
        return "锁定优先级";
    }
}
