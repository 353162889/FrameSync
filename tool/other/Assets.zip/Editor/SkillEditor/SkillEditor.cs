﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEditor;

public class SkillEditor : EditorWindow
{
    public const float CHAR_WIDTH = 13.5f;
    public const float INTERVAL_WIDTH = 15.0f;
    public const float BUTTON_HEIGHT = 25;

    private GameObject m_objEditor;
    private Vector2 m_sScrollPos = Vector2.zero;

    private SkillData m_cSkillData = null;
    private Dictionary<SkillEventData, EventFieldBase> m_dicEventToField = null;
    private Dictionary<SkillConditionData, ConditionFieldBase> m_dicConditionToField = null;
    private Dictionary<EventAffectData, AffectFieldBase> m_dicAffectToField = null;
    private Dictionary<SkillAimAssistData, AimAssistFieldBase> m_dicAimAssistField = null;

    [MenuItem("Tools/SkillEditor")]
    public static void StartSkillEditor()
    {
        if (EditorApplication.isCompiling)
        {
            EditorUtility.DisplayDialog("提示", "正在编译，请编译完成后再启用", "确定");
            return;
        }

        SkillEditor cEditor = EditorWindow.GetWindow<SkillEditor>();
        cEditor.Init();
        cEditor.Show();
    }

    private void Init()
    {
        m_objEditor = new GameObject();
        m_objEditor.transform.position = Vector3.zero;
        m_objEditor.name = "SkillEditor";

        m_cSkillData = new SkillData();
        m_cSkillData.mLstPhaseData = new List<SkillPhaseData>();
        m_cSkillData.mLstAimAssistData = new List<SkillAimAssistData>();

        m_dicEventToField = new Dictionary<SkillEventData, EventFieldBase>();
        m_dicConditionToField = new Dictionary<SkillConditionData, ConditionFieldBase>();
        m_dicAffectToField = new Dictionary<EventAffectData, AffectFieldBase>();
        m_dicAimAssistField = new Dictionary<SkillAimAssistData, AimAssistFieldBase>();

        SkillDataMgr.instance.Clear();
    }

    private void OnDisable()
    {
        if (null != m_objEditor)
        {
            GameObject.DestroyImmediate(m_objEditor);
            m_objEditor = null;
        }
    }

    private void OnGUI()
    {
        using (var scope = new EditorGUILayout.ScrollViewScope(m_sScrollPos))
        {
            m_sScrollPos = scope.scrollPosition;
            //m_sScrollPos = GUI.BeginScrollView(new Rect(0, 0, position.width, position.height), m_sScrollPos, new Rect(0, 0, 500, 5000));

            EditorGUILayout.BeginHorizontal();
            if (GUILayout.Button("创建技能", GUILayout.Width(6 * CHAR_WIDTH), GUILayout.Height(BUTTON_HEIGHT)))
            {
                m_cSkillData = new SkillData();
                m_cSkillData.mLstPhaseData = new List<SkillPhaseData>();
                m_cSkillData.mLstAimAssistData = new List<SkillAimAssistData>();
            }
            EditorGUILayout.LabelField("", GUILayout.Width(INTERVAL_WIDTH));

            string defaultDictionary = Application.dataPath + "/ResourcesEx/Config/SkillConfig/";
            if (GUILayout.Button("读取技能", GUILayout.Width(6 * CHAR_WIDTH), GUILayout.Height(BUTTON_HEIGHT)))
            {
                string strPath = EditorUtility.OpenFilePanel("加载技能数据", defaultDictionary, "bytes");
                if (!string.IsNullOrEmpty(strPath))
                {
                    m_cSkillData = (SkillData)CUility.DeSerializerObject(strPath, typeof(SkillData), SkillDataMgr.arrExtTypes);
                    if (null == m_cSkillData.mLstPhaseData)
                    {
                        m_cSkillData.mLstPhaseData = new List<SkillPhaseData>();
                    }
                    if(null == m_cSkillData.mLstAimAssistData)
                    {
                        m_cSkillData.mLstAimAssistData = new List<SkillAimAssistData>();
                    }
                }
                Repaint();
            }
            EditorGUILayout.LabelField("", GUILayout.Width(INTERVAL_WIDTH));

            if (GUILayout.Button("保存技能", GUILayout.Width(6 * CHAR_WIDTH), GUILayout.Height(BUTTON_HEIGHT)))
            {
                string path = EditorUtility.SaveFilePanel("保存技能数据", defaultDictionary, m_cSkillData.mId.ToString(), "bytes");
                if (!string.IsNullOrEmpty(path))
                {
                    for (int i = 0; i != m_cSkillData.mLstPhaseData.Count; ++i)
                    {
                        SkillPhaseData cPhaseData = m_cSkillData.mLstPhaseData[i];
                        SortEvent(cPhaseData.mLstEventData);
                    }
                    SortAimAssist(m_cSkillData.mLstAimAssistData);
                    CUility.SerializerObject(Application.dataPath + "/ResourcesEx/Config/SkillConfig/" + m_cSkillData.mId + ".bytes", m_cSkillData, SkillDataMgr.arrExtTypes);
                    AssetDatabase.Refresh();
                }
            }
            EditorGUILayout.EndHorizontal();

            EditorGUILayout.BeginHorizontal();
            if (GUILayout.Button("添加阶段", GUILayout.Width(6 * CHAR_WIDTH), GUILayout.Height(BUTTON_HEIGHT)))
            {
                SkillPhaseData cPhaseData = new SkillPhaseData();
                cPhaseData.mLstEventData = new List<SkillEventData>();
                cPhaseData.mLstEndEventData = new List<SkillEventData>();
                cPhaseData.mLstCastCondition = new List<SkillConditionData>();
                cPhaseData.mLstEarlyEndCondition = new List<SkillConditionData>();

                m_cSkillData.mLstPhaseData.Add(cPhaseData);
            }
            EditorGUILayout.LabelField("", GUILayout.Width(INTERVAL_WIDTH));

            if (GUILayout.Button("添加瞄准辅助", GUILayout.Width(6 * CHAR_WIDTH), GUILayout.Height(BUTTON_HEIGHT)))
            {
                SkillAimAssistData cAimAssistData = new SkillAimAssistData();
                m_cSkillData.mLstAimAssistData.Add(cAimAssistData);
            }
            EditorGUILayout.LabelField("", GUILayout.Width(INTERVAL_WIDTH));
            if (GUILayout.Button("预览", GUILayout.Width(6 * CHAR_WIDTH), GUILayout.Height(BUTTON_HEIGHT)))
            {
                if (!Application.isPlaying)
                {
                    Debug.LogError("请进入SkillTest里面预览");
                    return;
                }
                if (m_cSkillData.mId <= 0)
                {
                    Debug.LogError("当前技能Id为0");
                    return;
                }

                SkillDataMgr.instance.Remove(m_cSkillData);
                SkillDataMgr.instance.Add(m_cSkillData);

                Hero cMainHero = BattleScene.instance.mainHero;
                cMainHero.unitAttack.RemoveSkill(m_cSkillData.mId);
                cMainHero.unitAttack.AddSkill(new Skill(cMainHero, m_cSkillData.mId, false));

                cMainHero.ReqCastSpell(m_cSkillData.mId, 0, cMainHero.curPosition, cMainHero.curForward);
            }
            EditorGUILayout.EndHorizontal();

            FieldSkillData();

            //GUI.EndScrollView();
        }
    }

    private void SortEvent(List<SkillEventData> lstEventData)
    {
        lstEventData.Sort(delegate (SkillEventData x, SkillEventData y) { return x.mStartTime.CompareTo(y.mStartTime); });
    }

    private void SortAimAssist(List<SkillAimAssistData> lstAimAssistData)
    {
        lstAimAssistData.Sort(delegate(SkillAimAssistData x,SkillAimAssistData y) { return -x.mPriority.CompareTo(y.mPriority); });
    }

    private void FieldAffectData(EventAffectData cCurAffectData)
    {
        if (EEventAffectType.ENone == cCurAffectData.mType)
        {
            return;
        }

        AffectFieldBase cAffectField = null;
        if (!m_dicAffectToField.TryGetValue(cCurAffectData, out cAffectField))
        {
            cAffectField = AffectFieldFactory.CreateField(cCurAffectData);
            m_dicAffectToField.Add(cCurAffectData, cAffectField);
        }
        else if (cAffectField.affectType != cCurAffectData.mType)
        {
            cAffectField = AffectFieldFactory.CreateField(cCurAffectData);
            m_dicAffectToField[cCurAffectData] = cAffectField;
        }
        EditorGUILayout.BeginHorizontal();
        EditorGUILayout.LabelField("目标类型", GUILayout.Width(6 * CHAR_WIDTH));
        cCurAffectData.mTargetType = (EAffectTargetType)EditorGUILayout.EnumPopup(cCurAffectData.mTargetType, GUILayout.Width(8 * CHAR_WIDTH));
        EditorGUILayout.EndHorizontal();

        if (null != cCurAffectData.mParamer1)
        {
            EditorGUILayout.BeginHorizontal();
            EditorGUILayout.LabelField(cAffectField.GetDescribe1(), GUILayout.Width(6 * CHAR_WIDTH));
            if (cCurAffectData.mParamer1.GetType() == typeof(int))
            {
                cCurAffectData.mParamer1 = EditorGUILayout.IntField((int)cCurAffectData.mParamer1, GUILayout.Width(8 * CHAR_WIDTH));
            }
            else if (cCurAffectData.mParamer1.GetType() == typeof(string))
            {
                cCurAffectData.mParamer1 = EditorGUILayout.TextField((string)cCurAffectData.mParamer1, GUILayout.Width(8 * CHAR_WIDTH));
            }
            else if (cCurAffectData.mParamer1.GetType() == typeof(bool))
            {
                cCurAffectData.mParamer1 = EditorGUILayout.Toggle((bool)cCurAffectData.mParamer1, GUILayout.Width(8 * CHAR_WIDTH));
            }
            else if (cCurAffectData.mParamer1 != null && cCurAffectData.mParamer1.GetType().IsEnum)
            {
                cCurAffectData.mParamer1 = EditorGUILayout.EnumPopup((Enum)cCurAffectData.mParamer1, GUILayout.Width(8 * CHAR_WIDTH));
            }
            EditorGUILayout.EndHorizontal();
        }

        if (null != cCurAffectData.mParamer2)
        {
            EditorGUILayout.BeginHorizontal();
            EditorGUILayout.LabelField(cAffectField.GetDescribe2(), GUILayout.Width(6 * CHAR_WIDTH));
            if (cCurAffectData.mParamer2.GetType() == typeof(int))
            {
                cCurAffectData.mParamer2 = EditorGUILayout.IntField((int)cCurAffectData.mParamer2, GUILayout.Width(8 * CHAR_WIDTH));
            }
            else if (cCurAffectData.mParamer2.GetType() == typeof(string))
            {
                cCurAffectData.mParamer2 = EditorGUILayout.TextField((string)cCurAffectData.mParamer2, GUILayout.Width(8 * CHAR_WIDTH));
            }
            else if (cCurAffectData.mParamer2.GetType() == typeof(bool))
            {
                cCurAffectData.mParamer2 = EditorGUILayout.Toggle((bool)cCurAffectData.mParamer2, GUILayout.Width(8 * CHAR_WIDTH));
            }
            else if (cCurAffectData.mParamer2 != null && cCurAffectData.mParamer2.GetType().IsEnum)
            {
                cCurAffectData.mParamer2 = EditorGUILayout.EnumPopup((Enum)cCurAffectData.mParamer2, GUILayout.Width(8 * CHAR_WIDTH));
            }
            EditorGUILayout.EndHorizontal();
        }

        if (null != cCurAffectData.mParamer3)
        {
            EditorGUILayout.BeginHorizontal();
            EditorGUILayout.LabelField(cAffectField.GetDescribe3(), GUILayout.Width(6 * CHAR_WIDTH));
            if (cCurAffectData.mParamer3.GetType() == typeof(int))
            {
                cCurAffectData.mParamer3 = EditorGUILayout.IntField((int)cCurAffectData.mParamer3, GUILayout.Width(8 * CHAR_WIDTH));
            }
            else if (cCurAffectData.mParamer3.GetType() == typeof(string))
            {
                cCurAffectData.mParamer3 = EditorGUILayout.TextField((string)cCurAffectData.mParamer3, GUILayout.Width(8 * CHAR_WIDTH));
            }
            else if (cCurAffectData.mParamer3.GetType() == typeof(bool))
            {
                cCurAffectData.mParamer3 = EditorGUILayout.Toggle((bool)cCurAffectData.mParamer3, GUILayout.Width(8 * CHAR_WIDTH));
            }
            else if (cCurAffectData.mParamer3 != null && cCurAffectData.mParamer3.GetType().IsEnum)
            {
                cCurAffectData.mParamer3 = EditorGUILayout.EnumPopup((Enum)cCurAffectData.mParamer3, GUILayout.Width(8 * CHAR_WIDTH));
            }
            EditorGUILayout.EndHorizontal();
        }

        if (null != cCurAffectData.mParamer4)
        {
            EditorGUILayout.BeginHorizontal();
            EditorGUILayout.LabelField(cAffectField.GetDescribe4(), GUILayout.Width(6 * CHAR_WIDTH));
            if (cCurAffectData.mParamer4.GetType() == typeof(int))
            {
                cCurAffectData.mParamer4 = EditorGUILayout.IntField((int)cCurAffectData.mParamer4, GUILayout.Width(8 * CHAR_WIDTH));
            }
            else if (cCurAffectData.mParamer4.GetType() == typeof(string))
            {
                cCurAffectData.mParamer4 = EditorGUILayout.TextField((string)cCurAffectData.mParamer4, GUILayout.Width(8 * CHAR_WIDTH));
            }
            else if (cCurAffectData.mParamer4.GetType() == typeof(bool))
            {
                cCurAffectData.mParamer4 = EditorGUILayout.Toggle((bool)cCurAffectData.mParamer4, GUILayout.Width(8 * CHAR_WIDTH));
            }
            else if (cCurAffectData.mParamer4 != null && cCurAffectData.mParamer4.GetType().IsEnum)
            {
                cCurAffectData.mParamer4 = EditorGUILayout.EnumPopup((Enum)cCurAffectData.mParamer4, GUILayout.Width(8 * CHAR_WIDTH));
            }
            EditorGUILayout.EndHorizontal();
        }
    }

    private void FieldSingleEventData(SkillEventData cCurEventData)
    {
        if (ESkillEventType.ENone == cCurEventData.mType)
        {
            EditorGUILayout.LabelField("----------------------------------");
            return;
        }

        EventFieldBase cEventField = null;
        if (!m_dicEventToField.TryGetValue(cCurEventData, out cEventField))
        {
            cEventField = EventFieldFactory.CreateField(cCurEventData);
            m_dicEventToField.Add(cCurEventData, cEventField);
        }
        else if (cEventField.eventType != cCurEventData.mType)
        {
            cEventField = EventFieldFactory.CreateField(cCurEventData);
            m_dicEventToField[cCurEventData] = cEventField;
        }

        if (null != cCurEventData.mParamer1)
        {
            EditorGUILayout.BeginHorizontal();
            EditorGUILayout.LabelField(cEventField.GetDescribe1(), GUILayout.Width(6 * CHAR_WIDTH));
            if (cCurEventData.mParamer1.GetType() == typeof(int))
            {
                cCurEventData.mParamer1 = EditorGUILayout.IntField((int)cCurEventData.mParamer1, GUILayout.Width(8 * CHAR_WIDTH));
            }
            else if (cCurEventData.mParamer1.GetType() == typeof(string))
            {
                cCurEventData.mParamer1 = EditorGUILayout.TextField((string)cCurEventData.mParamer1, GUILayout.Width(8 * CHAR_WIDTH));
            }
            else if (cCurEventData.mParamer1.GetType() == typeof(bool))
            {
                cCurEventData.mParamer1 = EditorGUILayout.Toggle((bool)cCurEventData.mParamer1, GUILayout.Width(8 * CHAR_WIDTH));
            }
            else if (cCurEventData.mParamer1 != null && cCurEventData.mParamer1.GetType().IsEnum)
            {
                cCurEventData.mParamer1 = EditorGUILayout.EnumPopup((Enum)cCurEventData.mParamer1, GUILayout.Width(8 * CHAR_WIDTH));
            }
            EditorGUILayout.EndHorizontal();
        }

        if (null != cCurEventData.mParamer2)
        {
            EditorGUILayout.BeginHorizontal();
            EditorGUILayout.LabelField(cEventField.GetDescribe2(), GUILayout.Width(6 * CHAR_WIDTH));
            if (cCurEventData.mParamer2.GetType() == typeof(int))
            {
                cCurEventData.mParamer2 = EditorGUILayout.IntField((int)cCurEventData.mParamer2, GUILayout.Width(8 * CHAR_WIDTH));
            }
            else if (cCurEventData.mParamer2.GetType() == typeof(string))
            {
                cCurEventData.mParamer2 = EditorGUILayout.TextField((string)cCurEventData.mParamer2, GUILayout.Width(8 * CHAR_WIDTH));
            }
            else if (cCurEventData.mParamer2.GetType() == typeof(bool))
            {
                cCurEventData.mParamer2 = EditorGUILayout.Toggle((bool)cCurEventData.mParamer2, GUILayout.Width(8 * CHAR_WIDTH));
            }
            else if (cCurEventData.mParamer2 != null && cCurEventData.mParamer2.GetType().IsEnum)
            {
                cCurEventData.mParamer2 = EditorGUILayout.EnumPopup((Enum)cCurEventData.mParamer2, GUILayout.Width(8 * CHAR_WIDTH));
            }
            EditorGUILayout.EndHorizontal();
        }

        if (null != cCurEventData.mParamer3)
        {
            EditorGUILayout.BeginHorizontal();
            EditorGUILayout.LabelField(cEventField.GetDescribe3(), GUILayout.Width(6 * CHAR_WIDTH));
            if (cCurEventData.mParamer3.GetType() == typeof(int))
            {
                cCurEventData.mParamer3 = EditorGUILayout.IntField((int)cCurEventData.mParamer3, GUILayout.Width(8 * CHAR_WIDTH));
            }
            else if (cCurEventData.mParamer3.GetType() == typeof(string))
            {
                cCurEventData.mParamer3 = EditorGUILayout.TextField((string)cCurEventData.mParamer3, GUILayout.Width(8 * CHAR_WIDTH));
            }
            else if (cCurEventData.mParamer3.GetType() == typeof(bool))
            {
                cCurEventData.mParamer3 = EditorGUILayout.Toggle((bool)cCurEventData.mParamer3, GUILayout.Width(8 * CHAR_WIDTH));
            }
            else if (cCurEventData.mParamer3 != null && cCurEventData.mParamer3.GetType().IsEnum)
            {
                cCurEventData.mParamer3 = EditorGUILayout.EnumPopup((Enum)cCurEventData.mParamer3, GUILayout.Width(8 * CHAR_WIDTH));
            }
            EditorGUILayout.EndHorizontal();
        }

        if (null != cCurEventData.mParamer4)
        {
            EditorGUILayout.BeginHorizontal();
            EditorGUILayout.LabelField(cEventField.GetDescribe4(), GUILayout.Width(6 * CHAR_WIDTH));
            if (cCurEventData.mParamer4.GetType() == typeof(int))
            {
                cCurEventData.mParamer4 = EditorGUILayout.IntField((int)cCurEventData.mParamer4, GUILayout.Width(8 * CHAR_WIDTH));
            }
            else if (cCurEventData.mParamer4.GetType() == typeof(string))
            {
                cCurEventData.mParamer4 = EditorGUILayout.TextField((string)cCurEventData.mParamer4, GUILayout.Width(8 * CHAR_WIDTH));
            }
            else if (cCurEventData.mParamer4.GetType() == typeof(bool))
            {
                cCurEventData.mParamer4 = EditorGUILayout.Toggle((bool)cCurEventData.mParamer4, GUILayout.Width(8 * CHAR_WIDTH));
            }
            else if (cCurEventData.mParamer4 != null && cCurEventData.mParamer4.GetType().IsEnum)
            {
                cCurEventData.mParamer4 = EditorGUILayout.EnumPopup((Enum)cCurEventData.mParamer4, GUILayout.Width(8 * CHAR_WIDTH));
            }
            EditorGUILayout.EndHorizontal();
        }

        if (null != cCurEventData.mParamer5)
        {
            EditorGUILayout.BeginHorizontal();
            EditorGUILayout.LabelField(cEventField.GetDescribe5(), GUILayout.Width(6 * CHAR_WIDTH));
            if (cCurEventData.mParamer5.GetType() == typeof(int))
            {
                cCurEventData.mParamer5 = EditorGUILayout.IntField((int)cCurEventData.mParamer5, GUILayout.Width(8 * CHAR_WIDTH));
            }
            else if (cCurEventData.mParamer5.GetType() == typeof(string))
            {
                cCurEventData.mParamer5 = EditorGUILayout.TextField((string)cCurEventData.mParamer5, GUILayout.Width(8 * CHAR_WIDTH));
            }
            else if (cCurEventData.mParamer5.GetType() == typeof(bool))
            {
                cCurEventData.mParamer5 = EditorGUILayout.Toggle((bool)cCurEventData.mParamer5, GUILayout.Width(8 * CHAR_WIDTH));
            }
            else if (cCurEventData.mParamer5 != null && cCurEventData.mParamer5.GetType().IsEnum)
            {
                cCurEventData.mParamer5 = EditorGUILayout.EnumPopup((Enum)cCurEventData.mParamer5, GUILayout.Width(8 * CHAR_WIDTH));
            }
            EditorGUILayout.EndHorizontal();
        }

        if (null != cCurEventData.mParamer6)
        {
            EditorGUILayout.BeginHorizontal();
            EditorGUILayout.LabelField(cEventField.GetDescribe6(), GUILayout.Width(6 * CHAR_WIDTH));
            if (cCurEventData.mParamer6.GetType() == typeof(int))
            {
                cCurEventData.mParamer6 = EditorGUILayout.IntField((int)cCurEventData.mParamer6, GUILayout.Width(8 * CHAR_WIDTH));
            }
            else if (cCurEventData.mParamer6.GetType() == typeof(string))
            {
                cCurEventData.mParamer6 = EditorGUILayout.TextField((string)cCurEventData.mParamer6, GUILayout.Width(8 * CHAR_WIDTH));
            }
            else if (cCurEventData.mParamer6.GetType() == typeof(bool))
            {
                cCurEventData.mParamer6 = EditorGUILayout.Toggle((bool)cCurEventData.mParamer6, GUILayout.Width(8 * CHAR_WIDTH));
            }
            else if (cCurEventData.mParamer6 != null && cCurEventData.mParamer6.GetType().IsEnum)
            {
                cCurEventData.mParamer6 = EditorGUILayout.EnumPopup((Enum)cCurEventData.mParamer6, GUILayout.Width(8 * CHAR_WIDTH));
            }
            EditorGUILayout.EndHorizontal();
        }

        if (null != cCurEventData.mParamer7)
        {
            EditorGUILayout.BeginHorizontal();
            EditorGUILayout.LabelField(cEventField.GetDescribe7(), GUILayout.Width(6 * CHAR_WIDTH));
            if (cCurEventData.mParamer7.GetType() == typeof(int))
            {
                cCurEventData.mParamer7 = EditorGUILayout.IntField((int)cCurEventData.mParamer7, GUILayout.Width(8 * CHAR_WIDTH));
            }
            else if (cCurEventData.mParamer7.GetType() == typeof(string))
            {
                cCurEventData.mParamer7 = EditorGUILayout.TextField((string)cCurEventData.mParamer7, GUILayout.Width(8 * CHAR_WIDTH));
            }
            else if (cCurEventData.mParamer7.GetType() == typeof(bool))
            {
                cCurEventData.mParamer7 = EditorGUILayout.Toggle((bool)cCurEventData.mParamer7, GUILayout.Width(8 * CHAR_WIDTH));
            }
            else if (cCurEventData.mParamer7 != null && cCurEventData.mParamer7.GetType().IsEnum)
            {
                cCurEventData.mParamer7 = EditorGUILayout.EnumPopup((Enum)cCurEventData.mParamer7, GUILayout.Width(8 * CHAR_WIDTH));
            }
            EditorGUILayout.EndHorizontal();
        }

        if (null != cCurEventData.mParamer8)
        {
            EditorGUILayout.BeginHorizontal();
            EditorGUILayout.LabelField(cEventField.GetDescribe8(), GUILayout.Width(6 * CHAR_WIDTH));
            if (cCurEventData.mParamer8.GetType() == typeof(int))
            {
                cCurEventData.mParamer8 = EditorGUILayout.IntField((int)cCurEventData.mParamer8, GUILayout.Width(8 * CHAR_WIDTH));
            }
            else if (cCurEventData.mParamer8.GetType() == typeof(string))
            {
                cCurEventData.mParamer8 = EditorGUILayout.TextField((string)cCurEventData.mParamer8, GUILayout.Width(8 * CHAR_WIDTH));
            }
            else if (cCurEventData.mParamer8.GetType() == typeof(bool))
            {
                cCurEventData.mParamer8 = EditorGUILayout.Toggle((bool)cCurEventData.mParamer8, GUILayout.Width(8 * CHAR_WIDTH));
            }
            else if (cCurEventData.mParamer8 != null && cCurEventData.mParamer8.GetType().IsEnum)
            {
                cCurEventData.mParamer8 = EditorGUILayout.EnumPopup((Enum)cCurEventData.mParamer8, GUILayout.Width(8 * CHAR_WIDTH));
            }
            EditorGUILayout.EndHorizontal();
        }

        if (null != cCurEventData.mParamer9)
        {
            EditorGUILayout.BeginHorizontal();
            EditorGUILayout.LabelField(cEventField.GetDescribe9(), GUILayout.Width(6 * CHAR_WIDTH));
            if (cCurEventData.mParamer9.GetType() == typeof(int))
            {
                cCurEventData.mParamer9 = EditorGUILayout.IntField((int)cCurEventData.mParamer9, GUILayout.Width(8 * CHAR_WIDTH));
            }
            else if (cCurEventData.mParamer9.GetType() == typeof(string))
            {
                cCurEventData.mParamer9 = EditorGUILayout.TextField((string)cCurEventData.mParamer9, GUILayout.Width(8 * CHAR_WIDTH));
            }
            else if (cCurEventData.mParamer9.GetType() == typeof(bool))
            {
                cCurEventData.mParamer9 = EditorGUILayout.Toggle((bool)cCurEventData.mParamer9, GUILayout.Width(8 * CHAR_WIDTH));
            }
            else if (cCurEventData.mParamer9 != null && cCurEventData.mParamer9.GetType().IsEnum)
            {
                cCurEventData.mParamer9 = EditorGUILayout.EnumPopup((Enum)cCurEventData.mParamer9, GUILayout.Width(8 * CHAR_WIDTH));
            }
            EditorGUILayout.EndHorizontal();
        }

        if (null != cCurEventData.mParamer10)
        {
            EditorGUILayout.BeginHorizontal();
            EditorGUILayout.LabelField(cEventField.GetDescribe10(), GUILayout.Width(6 * CHAR_WIDTH));
            if (cCurEventData.mParamer10.GetType() == typeof(int))
            {
                cCurEventData.mParamer10 = EditorGUILayout.IntField((int)cCurEventData.mParamer10, GUILayout.Width(8 * CHAR_WIDTH));
            }
            else if (cCurEventData.mParamer10.GetType() == typeof(string))
            {
                cCurEventData.mParamer10 = EditorGUILayout.TextField((string)cCurEventData.mParamer10, GUILayout.Width(8 * CHAR_WIDTH));
            }
            else if (cCurEventData.mParamer10.GetType() == typeof(bool))
            {
                cCurEventData.mParamer10 = EditorGUILayout.Toggle((bool)cCurEventData.mParamer10, GUILayout.Width(8 * CHAR_WIDTH));
            }
            else if (cCurEventData.mParamer10 != null && cCurEventData.mParamer10.GetType().IsEnum)
            {
                cCurEventData.mParamer10 = EditorGUILayout.EnumPopup((Enum)cCurEventData.mParamer10, GUILayout.Width(8 * CHAR_WIDTH));
            }
            EditorGUILayout.EndHorizontal();
        }

        for (int i = 0; i != cCurEventData.mLstAffectData.Count; ++i)
        {
            EventAffectData cCurAffectData = cCurEventData.mLstAffectData[i];

            EditorGUILayout.LabelField("");
            EditorGUILayout.LabelField("效果" + (i + 1).ToString());

            if (GUILayout.Button("删除效果", GUILayout.Width(6 * CHAR_WIDTH), GUILayout.Height(BUTTON_HEIGHT)))
            {
                cCurEventData.mLstAffectData.Remove(cCurAffectData);
                return;
            }

            EditorGUILayout.BeginHorizontal();
            EditorGUILayout.LabelField("效果类型", GUILayout.Width(6 * CHAR_WIDTH));
            cCurAffectData.mType = (EEventAffectType)EditorGUILayout.EnumPopup(cCurAffectData.mType, GUILayout.Width(8 * CHAR_WIDTH));
            EditorGUILayout.EndHorizontal();

            FieldAffectData(cCurAffectData);
        }
        EditorGUILayout.LabelField("-----------------------------------");
    }

    private void FieldEventData(SkillPhaseData cCurPhaseData)
    {
        EditorGUILayout.LabelField("_________________________");

        for (int i = 0; i != cCurPhaseData.mLstEventData.Count; ++i)
        {
            SkillEventData cCurEventData = cCurPhaseData.mLstEventData[i];
            EditorGUILayout.BeginHorizontal();
            EditorGUILayout.LabelField("事件" + (i + 1).ToString(), GUILayout.Width(8 * CHAR_WIDTH));
            cCurEventData.mDesc = EditorGUILayout.TextField(cCurEventData.mDesc, GUILayout.Width(30 * CHAR_WIDTH));
            EditorGUILayout.EndHorizontal();
            EditorGUILayout.BeginHorizontal();
            if (ESkillEventType.ENone != cCurEventData.mType)
            {
                if (GUILayout.Button("添加效果", GUILayout.Width(6 * CHAR_WIDTH), GUILayout.Height(BUTTON_HEIGHT)))
                {
                    cCurEventData.mLstAffectData.Add(new EventAffectData());
                    return;
                }
                EditorGUILayout.LabelField("", GUILayout.Width(INTERVAL_WIDTH));
            }
            else
            {
                if (cCurEventData.mLstAffectData.Count > 0)
                {
                    cCurEventData.mLstAffectData.Clear();
                }
            }
            if (GUILayout.Button("删除事件", GUILayout.Width(6 * CHAR_WIDTH), GUILayout.Height(BUTTON_HEIGHT)))
            {
                cCurPhaseData.mLstEventData.Remove(cCurEventData);
                return;
            }
            EditorGUILayout.EndHorizontal();

            EditorGUILayout.BeginHorizontal();
            EditorGUILayout.LabelField("事件类型", GUILayout.Width(6 * CHAR_WIDTH));
            cCurEventData.mType = (ESkillEventType)EditorGUILayout.EnumPopup(cCurEventData.mType, GUILayout.Width(8 * CHAR_WIDTH));
            EditorGUILayout.LabelField(string.Format("({0})",GetEventCount(cCurPhaseData,cCurEventData.mType,i)), GUILayout.Width(6 * CHAR_WIDTH));
            EditorGUILayout.EndHorizontal();

            EditorGUILayout.BeginHorizontal();
            EditorGUILayout.LabelField("触发时间", GUILayout.Width(6 * CHAR_WIDTH));
            cCurEventData.mStartTime = EditorGUILayout.IntField(cCurEventData.mStartTime, GUILayout.Width(8 * CHAR_WIDTH));
            EditorGUILayout.EndHorizontal();

            FieldSingleEventData(cCurEventData);
            EditorGUILayout.LabelField("");
        }
    }

    private void FieldEndEventData(SkillPhaseData cCurPhaseData)
    {
        EditorGUILayout.LabelField("_________________________");

        for (int i = 0; i != cCurPhaseData.mLstEndEventData.Count; ++i)
        {
            SkillEventData cCurEventData = cCurPhaseData.mLstEndEventData[i];

            EditorGUILayout.LabelField("结束事件" + (i + 1).ToString());

            EditorGUILayout.BeginHorizontal();
            if (ESkillEventType.ENone != cCurEventData.mType)
            {
                if (GUILayout.Button("添加效果", GUILayout.Width(6 * CHAR_WIDTH), GUILayout.Height(BUTTON_HEIGHT)))
                {
                    cCurEventData.mLstAffectData.Add(new EventAffectData());
                    return;
                }
                EditorGUILayout.LabelField("", GUILayout.Width(INTERVAL_WIDTH));
            }
            else
            {
                if (cCurEventData.mLstAffectData.Count > 0)
                {
                    cCurEventData.mLstAffectData.Clear();
                }
            }
            if (GUILayout.Button("删除事件", GUILayout.Width(6 * CHAR_WIDTH), GUILayout.Height(BUTTON_HEIGHT)))
            {
                cCurPhaseData.mLstEndEventData.Remove(cCurEventData);
                return;
            }
            EditorGUILayout.EndHorizontal();

            EditorGUILayout.BeginHorizontal();
            EditorGUILayout.LabelField("事件类型", GUILayout.Width(6 * CHAR_WIDTH));
            cCurEventData.mType = (ESkillEventType)EditorGUILayout.EnumPopup(cCurEventData.mType, GUILayout.Width(8 * CHAR_WIDTH));
            EditorGUILayout.EndHorizontal();

            FieldSingleEventData(cCurEventData);

            EditorGUILayout.LabelField("");
        }
    }

    private void FieldSingleConditionData(SkillConditionData cCurConditionData)
    {
        if (ESkillConditionType.ENone == cCurConditionData.mType)
        {
            return;
        }

        ConditionFieldBase cConditionField = null;
        if (!m_dicConditionToField.TryGetValue(cCurConditionData, out cConditionField))
        {
            cConditionField = ConditionFieldFactory.CreateField(cCurConditionData);
            m_dicConditionToField.Add(cCurConditionData, cConditionField);
        }
        else if (cConditionField.conditionType != cCurConditionData.mType)
        {
            cConditionField = ConditionFieldFactory.CreateField(cCurConditionData);
            m_dicConditionToField[cCurConditionData] = cConditionField;
        }

        if (null != cCurConditionData.mParamer1)
        {
            EditorGUILayout.BeginHorizontal();
            EditorGUILayout.LabelField(cConditionField.GetDescribe1(), GUILayout.Width(6 * CHAR_WIDTH));
            if (cCurConditionData.mParamer1.GetType() == typeof(int))
            {
                cCurConditionData.mParamer1 = EditorGUILayout.IntField((int)cCurConditionData.mParamer1, GUILayout.Width(8 * CHAR_WIDTH));
            }
            else if (cCurConditionData.mParamer1.GetType() == typeof(string))
            {
                cCurConditionData.mParamer1 = EditorGUILayout.TextField((string)cCurConditionData.mParamer1, GUILayout.Width(8 * CHAR_WIDTH));
            }
            else if (cCurConditionData.mParamer1.GetType() == typeof(bool))
            {
                cCurConditionData.mParamer1 = EditorGUILayout.Toggle((bool)cCurConditionData.mParamer1, GUILayout.Width(8 * CHAR_WIDTH));
            }
            else if (cCurConditionData.mParamer1 != null && cCurConditionData.mParamer1.GetType().IsEnum)
            {
                cCurConditionData.mParamer1 = EditorGUILayout.EnumPopup((Enum)cCurConditionData.mParamer1, GUILayout.Width(8 * CHAR_WIDTH));
            }
            EditorGUILayout.EndHorizontal();
        }

        if (null != cCurConditionData.mParamer2)
        {
            EditorGUILayout.BeginHorizontal();
            EditorGUILayout.LabelField(cConditionField.GetDescribe2(), GUILayout.Width(6 * CHAR_WIDTH));
            if (cCurConditionData.mParamer2.GetType() == typeof(int))
            {
                cCurConditionData.mParamer2 = EditorGUILayout.IntField((int)cCurConditionData.mParamer2, GUILayout.Width(8 * CHAR_WIDTH));
            }
            else if (cCurConditionData.mParamer2.GetType() == typeof(string))
            {
                cCurConditionData.mParamer2 = EditorGUILayout.TextField((string)cCurConditionData.mParamer2, GUILayout.Width(8 * CHAR_WIDTH));
            }
            else if (cCurConditionData.mParamer2.GetType() == typeof(bool))
            {
                cCurConditionData.mParamer2 = EditorGUILayout.Toggle((bool)cCurConditionData.mParamer2, GUILayout.Width(8 * CHAR_WIDTH));
            }
            else if (cCurConditionData.mParamer2 != null && cCurConditionData.mParamer2.GetType().IsEnum)
            {
                cCurConditionData.mParamer2 = EditorGUILayout.EnumPopup((Enum)cCurConditionData.mParamer2, GUILayout.Width(8 * CHAR_WIDTH));
            }
            EditorGUILayout.EndHorizontal();
        }

        if (null != cCurConditionData.mParamer3)
        {
            EditorGUILayout.BeginHorizontal();
            EditorGUILayout.LabelField(cConditionField.GetDescribe3(), GUILayout.Width(6 * CHAR_WIDTH));
            if (cCurConditionData.mParamer3.GetType() == typeof(int))
            {
                cCurConditionData.mParamer3 = EditorGUILayout.IntField((int)cCurConditionData.mParamer3, GUILayout.Width(8 * CHAR_WIDTH));
            }
            else if (cCurConditionData.mParamer3.GetType() == typeof(string))
            {
                cCurConditionData.mParamer3 = EditorGUILayout.TextField((string)cCurConditionData.mParamer3, GUILayout.Width(8 * CHAR_WIDTH));
            }
            else if (cCurConditionData.mParamer3.GetType() == typeof(bool))
            {
                cCurConditionData.mParamer3 = EditorGUILayout.Toggle((bool)cCurConditionData.mParamer3, GUILayout.Width(8 * CHAR_WIDTH));
            }
            else if (cCurConditionData.mParamer3 != null && cCurConditionData.mParamer3.GetType().IsEnum)
            {
                cCurConditionData.mParamer3 = EditorGUILayout.EnumPopup((Enum)cCurConditionData.mParamer3, GUILayout.Width(8 * CHAR_WIDTH));
            }
            EditorGUILayout.EndHorizontal();
        }

        if (null != cCurConditionData.mParamer4)
        {
            EditorGUILayout.BeginHorizontal();
            EditorGUILayout.LabelField(cConditionField.GetDescribe4(), GUILayout.Width(6 * CHAR_WIDTH));
            if (cCurConditionData.mParamer4.GetType() == typeof(int))
            {
                cCurConditionData.mParamer4 = EditorGUILayout.IntField((int)cCurConditionData.mParamer4, GUILayout.Width(8 * CHAR_WIDTH));
            }
            else if (cCurConditionData.mParamer4.GetType() == typeof(string))
            {
                cCurConditionData.mParamer4 = EditorGUILayout.TextField((string)cCurConditionData.mParamer4, GUILayout.Width(8 * CHAR_WIDTH));
            }
            else if (cCurConditionData.mParamer4.GetType() == typeof(bool))
            {
                cCurConditionData.mParamer4 = EditorGUILayout.Toggle((bool)cCurConditionData.mParamer4, GUILayout.Width(8 * CHAR_WIDTH));
            }
            else if (cCurConditionData.mParamer4 != null && cCurConditionData.mParamer4.GetType().IsEnum)
            {
                cCurConditionData.mParamer4 = EditorGUILayout.EnumPopup((Enum)cCurConditionData.mParamer4, GUILayout.Width(8 * CHAR_WIDTH));
            }
            EditorGUILayout.EndHorizontal();
        }
    }

    private void FieldConditionData(List<SkillConditionData> lstCondition)
    {
        EditorGUILayout.LabelField("_________________________");

        for (int i = 0; i != lstCondition.Count; ++i)
        {
            SkillConditionData cCurConditionData = lstCondition[i];

            EditorGUILayout.LabelField("条件" + (i + 1).ToString());

            if (GUILayout.Button("删除条件", GUILayout.Width(6 * CHAR_WIDTH), GUILayout.Height(BUTTON_HEIGHT)))
            {
                lstCondition.Remove(cCurConditionData);
                return;
            }

            EditorGUILayout.BeginHorizontal();
            EditorGUILayout.LabelField("条件类型", GUILayout.Width(6 * CHAR_WIDTH));
            cCurConditionData.mType = (ESkillConditionType)EditorGUILayout.EnumPopup(cCurConditionData.mType, GUILayout.Width(8 * CHAR_WIDTH));
            EditorGUILayout.EndHorizontal();

            EditorGUILayout.BeginHorizontal();
            EditorGUILayout.LabelField("取反", GUILayout.Width(6 * CHAR_WIDTH));
            cCurConditionData.mInvert = EditorGUILayout.Toggle(cCurConditionData.mInvert, GUILayout.Width(8 * CHAR_WIDTH));
            EditorGUILayout.EndHorizontal();

            FieldSingleConditionData(cCurConditionData);

            EditorGUILayout.LabelField("");
        }
    }

    private bool FieldPhaseData(SkillPhaseData cCurPhaseData)
    {
        EditorGUILayout.BeginHorizontal();
        if (GUILayout.Button("添加释放条件", GUILayout.Width(6 * CHAR_WIDTH), GUILayout.Height(BUTTON_HEIGHT)))
        {
            cCurPhaseData.mLstCastCondition.Add(new SkillConditionData());
        }
        EditorGUILayout.LabelField("", GUILayout.Width(INTERVAL_WIDTH));
        if (GUILayout.Button("添加事件", GUILayout.Width(4 * CHAR_WIDTH), GUILayout.Height(BUTTON_HEIGHT)))
        {
            SkillEventData cEventData = new SkillEventData();
            cEventData.mLstAffectData = new List<EventAffectData>();
            cCurPhaseData.mLstEventData.Add(cEventData);
        }
        if (GUILayout.Button("刷新事件", GUILayout.Width(4 * CHAR_WIDTH), GUILayout.Height(BUTTON_HEIGHT)))
        {
            SortEvent(cCurPhaseData.mLstEventData);
        }
        EditorGUILayout.LabelField("", GUILayout.Width(INTERVAL_WIDTH));
        if (GUILayout.Button("添加提前结束条件", GUILayout.Width(8 * CHAR_WIDTH), GUILayout.Height(BUTTON_HEIGHT)))
        {
            cCurPhaseData.mLstEarlyEndCondition.Add(new SkillConditionData());
        }
        EditorGUILayout.LabelField("", GUILayout.Width(INTERVAL_WIDTH));
        if (GUILayout.Button("添加结束事件", GUILayout.Width(8 * CHAR_WIDTH), GUILayout.Height(BUTTON_HEIGHT)))
        {
            SkillEventData cEventData = new SkillEventData();
            cEventData.mLstAffectData = new List<EventAffectData>();
            cCurPhaseData.mLstEndEventData.Add(cEventData);
        }
        EditorGUILayout.EndHorizontal();
        if (GUILayout.Button("删除阶段", GUILayout.Width(4 * CHAR_WIDTH), GUILayout.Height(BUTTON_HEIGHT)))
        {
            m_cSkillData.mLstPhaseData.Remove(cCurPhaseData);
            return false;
        }

        EditorGUILayout.LabelField("_______________________________________________________________________________");
        EditorGUILayout.BeginHorizontal();
        EditorGUILayout.LabelField("支持施法移动", GUILayout.Width(6 * CHAR_WIDTH));
        cCurPhaseData.mCanMove = EditorGUILayout.Toggle(cCurPhaseData.mCanMove, GUILayout.Width(8 * CHAR_WIDTH));
        EditorGUILayout.EndHorizontal();

        EditorGUILayout.BeginHorizontal();
        EditorGUILayout.LabelField("支持施法面向", GUILayout.Width(6 * CHAR_WIDTH));
        cCurPhaseData.mCanForward = EditorGUILayout.Toggle(cCurPhaseData.mCanForward, GUILayout.Width(8 * CHAR_WIDTH));
        EditorGUILayout.EndHorizontal();

        //阶段施法条件
        EditorGUILayout.LabelField("");
        EditorGUILayout.LabelField("释放条件");
        FieldConditionData(cCurPhaseData.mLstCastCondition);

        //阶段事件
        EditorGUILayout.LabelField("");
        EditorGUILayout.LabelField("事件");
        FieldEventData(cCurPhaseData);

        //阶段提前结束条件
        EditorGUILayout.LabelField("");
        EditorGUILayout.LabelField("提前结束条件");

        FieldConditionData(cCurPhaseData.mLstEarlyEndCondition);

        //阶段结束事件
        EditorGUILayout.LabelField("");
        EditorGUILayout.LabelField("结束事件");
        FieldEndEventData(cCurPhaseData);
        EditorGUILayout.LabelField("", GUILayout.Width(0.0f), GUILayout.Height(45.0f));

        return true;
    }

    private void FieldSkillData()
    {
        EditorGUILayout.LabelField("");

        EditorGUILayout.BeginHorizontal();
        EditorGUILayout.LabelField("技能Id", GUILayout.Width(6 * CHAR_WIDTH));
        m_cSkillData.mId = EditorGUILayout.IntField(m_cSkillData.mId, GUILayout.Width(8 * CHAR_WIDTH));
        EditorGUILayout.EndHorizontal();

        EditorGUILayout.BeginHorizontal();
        EditorGUILayout.LabelField("技能名", GUILayout.Width(6 * CHAR_WIDTH));
        m_cSkillData.mName = EditorGUILayout.TextField(m_cSkillData.mName, GUILayout.Width(8 * CHAR_WIDTH));
        EditorGUILayout.EndHorizontal();

        EditorGUILayout.BeginHorizontal();
        EditorGUILayout.LabelField("前摇时间", GUILayout.Width(6 * CHAR_WIDTH));
        m_cSkillData.mBeforeAtkTime = EditorGUILayout.IntField(m_cSkillData.mBeforeAtkTime, GUILayout.Width(8 * CHAR_WIDTH));
        EditorGUILayout.EndHorizontal();

        EditorGUILayout.BeginHorizontal();
        EditorGUILayout.LabelField("进入后摇时间", GUILayout.Width(6 * CHAR_WIDTH));
        m_cSkillData.mBackswingAtkTime = EditorGUILayout.IntField(m_cSkillData.mBackswingAtkTime, GUILayout.Width(8 * CHAR_WIDTH));
        EditorGUILayout.EndHorizontal();

        EditorGUILayout.BeginHorizontal();
        EditorGUILayout.LabelField("攻击距离", GUILayout.Width(6 * CHAR_WIDTH));
        m_cSkillData.mAttackDistance = EditorGUILayout.IntField(m_cSkillData.mAttackDistance, GUILayout.Width(8 * CHAR_WIDTH));
        EditorGUILayout.EndHorizontal();

        EditorGUILayout.BeginHorizontal();
        EditorGUILayout.LabelField("优先级", GUILayout.Width(6 * CHAR_WIDTH));
        m_cSkillData.mPriority = EditorGUILayout.IntField(m_cSkillData.mPriority, GUILayout.Width(8 * CHAR_WIDTH));
        EditorGUILayout.EndHorizontal();

        EditorGUILayout.BeginHorizontal();
        EditorGUILayout.LabelField("受高优先级打断", GUILayout.Width(6 * CHAR_WIDTH));
        m_cSkillData.mBreakByPriority = EditorGUILayout.Toggle(m_cSkillData.mBreakByPriority, GUILayout.Width(8 * CHAR_WIDTH));
        EditorGUILayout.EndHorizontal();

        EditorGUILayout.BeginHorizontal();
        EditorGUILayout.LabelField("消耗单位属性类型", GUILayout.Width(6 * CHAR_WIDTH));
        m_cSkillData.mUnitConsumeType = (ESkillUnitConsumeType)EditorGUILayout.EnumPopup(m_cSkillData.mUnitConsumeType, GUILayout.Width(8 * CHAR_WIDTH));
        EditorGUILayout.EndHorizontal();

        EditorGUILayout.BeginHorizontal();
        EditorGUILayout.LabelField("消耗单位属性值(公式)", GUILayout.Width(6 * CHAR_WIDTH));
        m_cSkillData.mUnitConsume = EditorGUILayout.TextField(m_cSkillData.mUnitConsume, GUILayout.Width(8 * CHAR_WIDTH));
        EditorGUILayout.EndHorizontal();

        EditorGUILayout.BeginHorizontal();
        EditorGUILayout.LabelField("消耗类型(停用)", GUILayout.Width(6 * CHAR_WIDTH));
        m_cSkillData.mConsumeType = (EConsumeType)EditorGUILayout.EnumPopup(m_cSkillData.mConsumeType, GUILayout.Width(8 * CHAR_WIDTH));
        EditorGUILayout.EndHorizontal();

        EditorGUILayout.BeginHorizontal();
        EditorGUILayout.LabelField("升级能量(停用)", GUILayout.Width(6 * CHAR_WIDTH));
        m_cSkillData.mConsume = EditorGUILayout.TextField(m_cSkillData.mConsume, GUILayout.Width(8 * CHAR_WIDTH));
        EditorGUILayout.EndHorizontal();

        EditorGUILayout.BeginHorizontal();
        EditorGUILayout.LabelField("最高等级", GUILayout.Width(6 * CHAR_WIDTH));
        m_cSkillData.mMaxLevel = EditorGUILayout.IntField(m_cSkillData.mMaxLevel, GUILayout.Width(8 * CHAR_WIDTH));
        EditorGUILayout.EndHorizontal();

        EditorGUILayout.BeginHorizontal();
        EditorGUILayout.LabelField("Cd", GUILayout.Width(6 * CHAR_WIDTH));
        m_cSkillData.mCd = EditorGUILayout.TextField(m_cSkillData.mCd, GUILayout.Width(8 * CHAR_WIDTH));
        EditorGUILayout.EndHorizontal();

        EditorGUILayout.BeginHorizontal();
        EditorGUILayout.LabelField("是否是后置CD", GUILayout.Width(6 * CHAR_WIDTH));
        m_cSkillData.mIsEndCD = EditorGUILayout.Toggle(m_cSkillData.mIsEndCD, GUILayout.Width(8 * CHAR_WIDTH));
        EditorGUILayout.EndHorizontal();

        EditorGUILayout.BeginHorizontal();
        EditorGUILayout.LabelField("技能参数类型", GUILayout.Width(6 * CHAR_WIDTH));
        m_cSkillData.mParamType = (ESkillParamType)EditorGUILayout.EnumPopup(m_cSkillData.mParamType, GUILayout.Width(8 * CHAR_WIDTH));
        EditorGUILayout.EndHorizontal();

        EditorGUILayout.BeginHorizontal();
        EditorGUILayout.LabelField("技能施法类型", GUILayout.Width(6 * CHAR_WIDTH));
        m_cSkillData.mCastType = (ECastType)EditorGUILayout.EnumPopup(m_cSkillData.mCastType, GUILayout.Width(8 * CHAR_WIDTH));
        EditorGUILayout.EndHorizontal();

        EditorGUILayout.BeginHorizontal();
        EditorGUILayout.LabelField("是否具有指示器", GUILayout.Width(6 * CHAR_WIDTH));
        m_cSkillData.mNeedIndicator = EditorGUILayout.Toggle(m_cSkillData.mNeedIndicator, GUILayout.Width(8 * CHAR_WIDTH));
        EditorGUILayout.EndHorizontal();

        EditorGUILayout.BeginHorizontal();
        EditorGUILayout.LabelField("指示器特效", GUILayout.Width(6 * CHAR_WIDTH));
        m_cSkillData.mIndicatorEffect = EditorGUILayout.TextField(m_cSkillData.mIndicatorEffect, GUILayout.Width(8 * CHAR_WIDTH));
        EditorGUILayout.EndHorizontal();

        EditorGUILayout.BeginHorizontal();
        EditorGUILayout.LabelField("指示器范围半径", GUILayout.Width(6 * CHAR_WIDTH));
        m_cSkillData.mIndicatorRadius = EditorGUILayout.IntField(m_cSkillData.mIndicatorRadius, GUILayout.Width(8 * CHAR_WIDTH));
        EditorGUILayout.EndHorizontal();

        EditorGUILayout.BeginHorizontal();
        EditorGUILayout.LabelField("指示器攻击半径", GUILayout.Width(6 * CHAR_WIDTH));
        m_cSkillData.mIndicatorDamageRadius = EditorGUILayout.IntField(m_cSkillData.mIndicatorDamageRadius, GUILayout.Width(8 * CHAR_WIDTH));
        EditorGUILayout.EndHorizontal();

        EditorGUILayout.BeginHorizontal();
        EditorGUILayout.LabelField("指示器宽度缩放", GUILayout.Width(6 * CHAR_WIDTH));
        m_cSkillData.mIndicatorWidthScale = EditorGUILayout.IntField(m_cSkillData.mIndicatorWidthScale, GUILayout.Width(8 * CHAR_WIDTH));
        EditorGUILayout.EndHorizontal();

        EditorGUILayout.BeginHorizontal();
        EditorGUILayout.LabelField("是否立即改变面向", GUILayout.Width(6 * CHAR_WIDTH));
        m_cSkillData.mForwardImmediately = EditorGUILayout.Toggle(m_cSkillData.mForwardImmediately, GUILayout.Width(8 * CHAR_WIDTH));
        EditorGUILayout.EndHorizontal();

        for (int i = 0; i != m_cSkillData.mLstAimAssistData.Count; ++i)
        {
            SkillAimAssistData cCurAimAssistData = m_cSkillData.mLstAimAssistData[i];
            if(!AimAssistData(cCurAimAssistData))
            {
                return;
            }
        }
        

        EditorGUILayout.LabelField("");

        for (int i = 0; i != m_cSkillData.mLstPhaseData.Count; ++i)
        {
            EditorGUILayout.BeginHorizontal();
            EditorGUILayout.LabelField("阶段" + (i + 1).ToString(), GUILayout.Width(8 * CHAR_WIDTH));
            if(GUILayout.Button("↑", GUILayout.Width(4 * CHAR_WIDTH)))
            {
                SwitchLst(m_cSkillData.mLstPhaseData, i - 1, i);
                return;
            }
            if (GUILayout.Button("↓", GUILayout.Width(4 * CHAR_WIDTH)))
            {
                SwitchLst(m_cSkillData.mLstPhaseData, i, i+1);
                return;
            }
            EditorGUILayout.EndHorizontal();
            SkillPhaseData cCurPhaseData = m_cSkillData.mLstPhaseData[i];
            if (!FieldPhaseData(cCurPhaseData))
            {
                return;
            }
        }
    }
    private void SwitchLst(IList lst,int indexA,int indexB)
    {
        if (indexA < 0 || indexA >= lst.Count || indexB < 0 || indexB >= lst.Count) return;
        var temp = lst[indexA];
        lst[indexA] = lst[indexB];
        lst[indexB] = temp;
    }

    private int GetEventCount(SkillPhaseData cCurPhaseData, ESkillEventType eventType,int curIndex)
    {
        int count = 0;
        for (int i = 0; i != cCurPhaseData.mLstEventData.Count && i <= curIndex; ++i)
        {
            if(cCurPhaseData.mLstEventData[i].mType == eventType)
            {
                count++;
            }
        }
        return count;
    }

    private bool AimAssistData(SkillAimAssistData aimAssistData)
    {
        EditorGUILayout.BeginHorizontal();
        EditorGUILayout.LabelField("_______________________________________________________________________________");
        EditorGUILayout.EndHorizontal();
        EditorGUILayout.BeginHorizontal();
        EditorGUILayout.LabelField("技能辅助瞄准类型", GUILayout.Width(6 * CHAR_WIDTH));
        aimAssistData.mType = (EAimAssistType)EditorGUILayout.EnumPopup(aimAssistData.mType, GUILayout.Width(8 * CHAR_WIDTH));
        if (GUILayout.Button("删除", GUILayout.Width(6 * CHAR_WIDTH), GUILayout.Height(BUTTON_HEIGHT)))
        {
            m_cSkillData.mLstAimAssistData.Remove(aimAssistData);
            return false;
        }
        EditorGUILayout.EndHorizontal();
        
        EditorGUILayout.BeginHorizontal();
        EditorGUILayout.LabelField("优先级", GUILayout.Width(6 * CHAR_WIDTH));
        aimAssistData.mPriority = EditorGUILayout.IntField(aimAssistData.mPriority, GUILayout.Width(8 * CHAR_WIDTH));
        EditorGUILayout.EndHorizontal();

        AimAssistFieldBase cAimAssistField = null;
        if (!m_dicAimAssistField.TryGetValue(aimAssistData, out cAimAssistField))
        {
            cAimAssistField = AimAssistFieldFactory.CreateField(aimAssistData);
            m_dicAimAssistField.Add(aimAssistData, cAimAssistField);
        }
        else if (cAimAssistField.aimAssistType != aimAssistData.mType)
        {
            cAimAssistField = AimAssistFieldFactory.CreateField(aimAssistData);
            m_dicAimAssistField[aimAssistData] = cAimAssistField;
        }

        if (null != aimAssistData.mParamer1)
        {
            EditorGUILayout.BeginHorizontal();
            EditorGUILayout.LabelField(cAimAssistField.GetDescribe1(), GUILayout.Width(6 * CHAR_WIDTH));
            if (aimAssistData.mParamer1.GetType() == typeof(int))
            {
                aimAssistData.mParamer1 = EditorGUILayout.IntField((int)aimAssistData.mParamer1, GUILayout.Width(8 * CHAR_WIDTH));
            }
            else if (aimAssistData.mParamer1.GetType() == typeof(string))
            {
                aimAssistData.mParamer1 = EditorGUILayout.TextField((string)aimAssistData.mParamer1, GUILayout.Width(8 * CHAR_WIDTH));
            }
            else if (aimAssistData.mParamer1.GetType() == typeof(bool))
            {
                aimAssistData.mParamer1 = EditorGUILayout.Toggle((bool)aimAssistData.mParamer1, GUILayout.Width(8 * CHAR_WIDTH));
            }
            else if (aimAssistData.mParamer1 != null && aimAssistData.mParamer1.GetType().IsEnum)
            {
                aimAssistData.mParamer1 = EditorGUILayout.EnumPopup((Enum)aimAssistData.mParamer1, GUILayout.Width(8 * CHAR_WIDTH));
            }
            EditorGUILayout.EndHorizontal();
        }

        if (null != aimAssistData.mParamer2)
        {
            EditorGUILayout.BeginHorizontal();
            EditorGUILayout.LabelField(cAimAssistField.GetDescribe2(), GUILayout.Width(6 * CHAR_WIDTH));
            if (aimAssistData.mParamer2.GetType() == typeof(int))
            {
                aimAssistData.mParamer2 = EditorGUILayout.IntField((int)aimAssistData.mParamer2, GUILayout.Width(8 * CHAR_WIDTH));
            }
            else if (aimAssistData.mParamer2.GetType() == typeof(string))
            {
                aimAssistData.mParamer2 = EditorGUILayout.TextField((string)aimAssistData.mParamer2, GUILayout.Width(8 * CHAR_WIDTH));
            }
            else if (aimAssistData.mParamer2.GetType() == typeof(bool))
            {
                aimAssistData.mParamer2 = EditorGUILayout.Toggle((bool)aimAssistData.mParamer2, GUILayout.Width(8 * CHAR_WIDTH));
            }
            else if (aimAssistData.mParamer2 != null && aimAssistData.mParamer2.GetType().IsEnum)
            {
                aimAssistData.mParamer2 = EditorGUILayout.EnumPopup((Enum)aimAssistData.mParamer2, GUILayout.Width(8 * CHAR_WIDTH));
            }
            EditorGUILayout.EndHorizontal();
        }

        if (null != aimAssistData.mParamer3)
        {
            EditorGUILayout.BeginHorizontal();
            EditorGUILayout.LabelField(cAimAssistField.GetDescribe3(), GUILayout.Width(6 * CHAR_WIDTH));
            if (aimAssistData.mParamer3.GetType() == typeof(int))
            {
                aimAssistData.mParamer3 = EditorGUILayout.IntField((int)aimAssistData.mParamer3, GUILayout.Width(8 * CHAR_WIDTH));
            }
            else if (aimAssistData.mParamer3.GetType() == typeof(string))
            {
                aimAssistData.mParamer3 = EditorGUILayout.TextField((string)aimAssistData.mParamer3, GUILayout.Width(8 * CHAR_WIDTH));
            }
            else if (aimAssistData.mParamer3.GetType() == typeof(bool))
            {
                aimAssistData.mParamer3 = EditorGUILayout.Toggle((bool)aimAssistData.mParamer3, GUILayout.Width(8 * CHAR_WIDTH));
            }
            else if (aimAssistData.mParamer3 != null && aimAssistData.mParamer3.GetType().IsEnum)
            {
                aimAssistData.mParamer3 = EditorGUILayout.EnumPopup((Enum)aimAssistData.mParamer3, GUILayout.Width(8 * CHAR_WIDTH));
            }
            EditorGUILayout.EndHorizontal();
        }

        if (null != aimAssistData.mParamer4)
        {
            EditorGUILayout.BeginHorizontal();
            EditorGUILayout.LabelField(cAimAssistField.GetDescribe4(), GUILayout.Width(6 * CHAR_WIDTH));
            if (aimAssistData.mParamer4.GetType() == typeof(int))
            {
                aimAssistData.mParamer4 = EditorGUILayout.IntField((int)aimAssistData.mParamer4, GUILayout.Width(8 * CHAR_WIDTH));
            }
            else if (aimAssistData.mParamer4.GetType() == typeof(string))
            {
                aimAssistData.mParamer4 = EditorGUILayout.TextField((string)aimAssistData.mParamer4, GUILayout.Width(8 * CHAR_WIDTH));
            }
            else if (aimAssistData.mParamer4.GetType() == typeof(bool))
            {
                aimAssistData.mParamer4 = EditorGUILayout.Toggle((bool)aimAssistData.mParamer4, GUILayout.Width(8 * CHAR_WIDTH));
            }
            else if (aimAssistData.mParamer4 != null && aimAssistData.mParamer4.GetType().IsEnum)
            {
                aimAssistData.mParamer4 = EditorGUILayout.EnumPopup((Enum)aimAssistData.mParamer4, GUILayout.Width(8 * CHAR_WIDTH));
            }
            EditorGUILayout.EndHorizontal();
        }

        if (null != aimAssistData.mParamer5)
        {
            EditorGUILayout.BeginHorizontal();
            EditorGUILayout.LabelField(cAimAssistField.GetDescribe5(), GUILayout.Width(6 * CHAR_WIDTH));
            if (aimAssistData.mParamer5.GetType() == typeof(int))
            {
                aimAssistData.mParamer5 = EditorGUILayout.IntField((int)aimAssistData.mParamer5, GUILayout.Width(8 * CHAR_WIDTH));
            }
            else if (aimAssistData.mParamer5.GetType() == typeof(string))
            {
                aimAssistData.mParamer5 = EditorGUILayout.TextField((string)aimAssistData.mParamer5, GUILayout.Width(8 * CHAR_WIDTH));
            }
            else if (aimAssistData.mParamer5.GetType() == typeof(bool))
            {
                aimAssistData.mParamer5 = EditorGUILayout.Toggle((bool)aimAssistData.mParamer5, GUILayout.Width(8 * CHAR_WIDTH));
            }
            else if (aimAssistData.mParamer5 != null && aimAssistData.mParamer5.GetType().IsEnum)
            {
                aimAssistData.mParamer5 = EditorGUILayout.EnumPopup((Enum)aimAssistData.mParamer5, GUILayout.Width(8 * CHAR_WIDTH));
            }
            EditorGUILayout.EndHorizontal();
        }

        if (null != aimAssistData.mParamer6)
        {
            EditorGUILayout.BeginHorizontal();
            EditorGUILayout.LabelField(cAimAssistField.GetDescribe6(), GUILayout.Width(6 * CHAR_WIDTH));
            if (aimAssistData.mParamer6.GetType() == typeof(int))
            {
                aimAssistData.mParamer6 = EditorGUILayout.IntField((int)aimAssistData.mParamer6, GUILayout.Width(8 * CHAR_WIDTH));
            }
            else if (aimAssistData.mParamer6.GetType() == typeof(string))
            {
                aimAssistData.mParamer6 = EditorGUILayout.TextField((string)aimAssistData.mParamer6, GUILayout.Width(8 * CHAR_WIDTH));
            }
            else if (aimAssistData.mParamer6.GetType() == typeof(bool))
            {
                aimAssistData.mParamer6 = EditorGUILayout.Toggle((bool)aimAssistData.mParamer6, GUILayout.Width(8 * CHAR_WIDTH));
            }
            else if (aimAssistData.mParamer6 != null && aimAssistData.mParamer6.GetType().IsEnum)
            {
                aimAssistData.mParamer6 = EditorGUILayout.EnumPopup((Enum)aimAssistData.mParamer6, GUILayout.Width(8 * CHAR_WIDTH));
            }
            EditorGUILayout.EndHorizontal();
        }
        return true;
    }
}