﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEditor;

public class EventFieldBase
{
    protected ESkillEventType m_eEventType = ESkillEventType.ENone;
    public ESkillEventType eventType { get { return m_eEventType; } }

    public EventFieldBase(SkillEventData cEventData)
    {
        m_eEventType = cEventData.mType;
    }

    public virtual string GetDescribe1()
    {
        return "参数1";
    }
    public virtual string GetDescribe2()
    {
        return "参数2";
    }
    public virtual string GetDescribe3()
    {
        return "参数3";
    }
    public virtual string GetDescribe4()
    {
        return "参数4";
    }
    public virtual string GetDescribe5()
    {
        return "参数5";
    }
    public virtual string GetDescribe6()
    {
        return "参数6";
    }
    public virtual string GetDescribe7()
    {
        return "参数7";
    }
    public virtual string GetDescribe8()
    {
        return "参数8";
    }
    public virtual string GetDescribe9()
    {
        return "参数9";
    }
    public virtual string GetDescribe10()
    {
        return "参数10";
    }
}

public class EventFieldFactory
{
    public static EventFieldBase CreateField(SkillEventData cEventData)
    {
        if (ESkillEventType.ENone == cEventData.mType)
        {
            return null;
        }

        EventFieldBase cEventField = null;
        switch (cEventData.mType)
        {
            case ESkillEventType.EAnimation:
                cEventField = new AnimationEventField(cEventData);
                break;

            case ESkillEventType.EEffect:
                cEventField = new EffectEventField(cEventData);
                break;

            case ESkillEventType.ECircleSelect:
                cEventField = new CircleSelectEventField(cEventData);
                break;

            case ESkillEventType.EHitCountCircleSelect:
                cEventField = new HitCountCircleSelectEventField(cEventData);
                break;

            case ESkillEventType.ESectorSelect:
                cEventField = new SectorSelectEventField(cEventData);
                break;

            case ESkillEventType.ELineSelect:
                cEventField = new LineSelectEventField(cEventData);
                break;
            case ESkillEventType.ERectSelect:
                cEventField = new RectSelectEventField(cEventData);
                break;

            case ESkillEventType.ECreateFlyTarget:
                cEventField = new CreateFlyTargetEventField(cEventData);
                break;
            case ESkillEventType.ECreateFlyForward:
                cEventField = new CreateFlyForwardEventField(cEventData);
                break;
            case ESkillEventType.ECreateFlyForwardExplode:
                cEventField = new CreateFlyForwardExplodeEventField(cEventData);
                break;
            case ESkillEventType.ECreateFlyForwardBack:
                cEventField = new CreateFlyForwardBackEventField(cEventData);
                break;
            case ESkillEventType.ECreateFlyPosition:
                cEventField = new CreateFlyPositionEventField(cEventData);
                break;
            case ESkillEventType.EFlushForward:
                cEventField = new FlushForwardEventField(cEventData);
                break;
            case ESkillEventType.EShakeCamera:
                cEventField = new ShakeCameraEventField(cEventData);
                break;
            case ESkillEventType.EInputCast:
                cEventField = new InputCastEventField(cEventData);
                break;
            case ESkillEventType.EAudio:
                cEventField = new AudioEventField(cEventData);
                break;
            case ESkillEventType.EEmpty:
                cEventField = new EmptyEventField(cEventData);
                break;
            case ESkillEventType.EFlashTarget:
                cEventField = new FlashTargetEventField(cEventData);
                break;
            case ESkillEventType.ESetTargetDir:
                cEventField = new SetTargetDirEventField(cEventData);
                break;
            case ESkillEventType.EChangeForward:
                cEventField = new ChangeForwardEventField(cEventData);
                break;
            case ESkillEventType.EUnitLock:
                cEventField = new UnitLockEventField(cEventData);
                break;
            case ESkillEventType.ESwapActiveSkillPosition:
                cEventField = new SwapActiveSkillPositionEventField(cEventData);
                break;
            case ESkillEventType.ESkillLeaveTime:
                cEventField = new SkillLeaveTimeEventField(cEventData);
                break;
            case ESkillEventType.EResetAllCD:
                cEventField = new ResetAllCDEventField(cEventData);
                break;
            case ESkillEventType.EReflectDamage:
                cEventField = new ReflectDamageEventField(cEventData);
                break;  
        }
        return cEventField;
    }
}

public class AnimationEventField : EventFieldBase
{
    public AnimationEventField(SkillEventData cEventData) : base(cEventData)
    {
        if (null == cEventData.mParamer1)
        {
            cEventData.mParamer1 = "";
        }
        if (null == cEventData.mParamer2)
        {
            cEventData.mParamer2 = 0;
        }
    }

    public override string GetDescribe1()
    {
        return "动作名";
    }
    public override string GetDescribe2()
    {
        return "动作时间";
    }
}

public class EffectEventField : EventFieldBase
{
    public EffectEventField(SkillEventData cEventData) : base(cEventData)
    {
        if (null == cEventData.mParamer1)
        {
            cEventData.mParamer1 = "";
        }
        if (null == cEventData.mParamer2)
        {
            cEventData.mParamer2 = "";
        }
        if (null == cEventData.mParamer3)
        {
            cEventData.mParamer3 = 0;
        }
    }

    public override string GetDescribe1()
    {
        return "特效名";
    }
    public override string GetDescribe2()
    {
        return "挂点";
    }
    public override string GetDescribe3()
    {
        return "循环时间";
    }
}

public class CircleSelectEventField : EventFieldBase
{
    public CircleSelectEventField(SkillEventData cEventData) : base(cEventData)
    {
        if (null == cEventData.mParamer1)
        {
            cEventData.mParamer1 = ETargetType.EEnemyAll;
        }
        else if(cEventData.mParamer1.GetType() == typeof(int))
        {
            cEventData.mParamer1 = (ETargetType)cEventData.mParamer1;
        }

        if (null == cEventData.mParamer2)
        {
            cEventData.mParamer2 = "";
        }

        if (null == cEventData.mParamer3)
        {
            cEventData.mParamer3 = 9999;
        }

        if (null == cEventData.mParamer4)
        {
            cEventData.mParamer4 = 0;
        }

        if (null == cEventData.mParamer5)
        {
            cEventData.mParamer5 = 0;
        }

        if (null == cEventData.mParamer6)
        {
            cEventData.mParamer6 = 0;
        }

        if (null == cEventData.mParamer7)
        {
            cEventData.mParamer7 = 1;
        }
    }

    public override string GetDescribe1()
    {
        return "目标类型";
    }
    public override string GetDescribe2()
    {
        return "挂点";
    }
    public override string GetDescribe3()
    {
        return "数量限制";
    }
    public override string GetDescribe4()
    {
        return "半径";
    }

    public override string GetDescribe5()
    {
        return "持续时间";
    }

    public override string GetDescribe6()
    {
        return "选择间隔";
    }

    public override string GetDescribe7()
    {
        return "单个单位数量限制";
    }
}

public class HitCountCircleSelectEventField : EventFieldBase
{
    public HitCountCircleSelectEventField(SkillEventData cEventData) : base(cEventData)
    {
        if (null == cEventData.mParamer1)
        {
            cEventData.mParamer1 = ETargetType.EEnemyAll;
        }

        if (null == cEventData.mParamer2)
        {
            cEventData.mParamer2 = "";
        }

        if (null == cEventData.mParamer3)
        {
            cEventData.mParamer3 = 9999;
        }

        if (null == cEventData.mParamer4)
        {
            cEventData.mParamer4 = 0;
        }

        if (null == cEventData.mParamer5)
        {
            cEventData.mParamer5 = 0;
        }

        if (null == cEventData.mParamer6)
        {
            cEventData.mParamer6 = 0;
        }

        if (null == cEventData.mParamer7)
        {
            cEventData.mParamer7 = 1;
        }

        if (null == cEventData.mParamer8)
        {
            cEventData.mParamer8 = HitCountSelectType.EMinCount;
        }
        if(null == cEventData.mParamer9)
        {
            cEventData.mParamer9 = false;
        }
    }

    public override string GetDescribe1()
    {
        return "目标类型";
    }
    public override string GetDescribe2()
    {
        return "挂点";
    }
    public override string GetDescribe3()
    {
        return "数量限制";
    }
    public override string GetDescribe4()
    {
        return "半径";
    }

    public override string GetDescribe5()
    {
        return "持续时间";
    }

    public override string GetDescribe6()
    {
        return "选择间隔";
    }

    public override string GetDescribe7()
    {
        return "单个单位数量限制";
    }

    public override string GetDescribe8()
    {
        return "次数选择类型";
    }

    public override string GetDescribe9()
    {
        return "随机选择";
    }
}

public class SectorSelectEventField : EventFieldBase
{
    public SectorSelectEventField(SkillEventData cEventData) : base(cEventData)
    {
        if (null == cEventData.mParamer1)
        {
            cEventData.mParamer1 = ETargetType.EEnemyAll;
        }
        else if (cEventData.mParamer1.GetType() == typeof(int))
        {
            cEventData.mParamer1 = (ETargetType)cEventData.mParamer1;
        }

        if (null == cEventData.mParamer2)
        {
            cEventData.mParamer2 = "";
        }

        if (null == cEventData.mParamer3)
        {
            cEventData.mParamer3 = 9999;
        }

        if (null == cEventData.mParamer4)
        {
            cEventData.mParamer4 = 0;
        }

        if (null == cEventData.mParamer5)
        {
            cEventData.mParamer5 = 0;
        }

        if (null == cEventData.mParamer6)
        {
            cEventData.mParamer6 = 0;
        }

        if (null == cEventData.mParamer7)
        {
            cEventData.mParamer7 = 1;
        }

        if (null == cEventData.mParamer8)
        {
            cEventData.mParamer8 = 0;
        }

    }

    public override string GetDescribe1()
    {
        return "目标类型";
    }
    public override string GetDescribe2()
    {
        return "挂点";
    }
    public override string GetDescribe3()
    {
        return "数量限制";
    }
    public override string GetDescribe4()
    {
        return "半径";
    }
    public override string GetDescribe5()
    {
        return "持续时间";
    }

    public override string GetDescribe6()
    {
        return "选择间隔";
    }

    public override string GetDescribe7()
    {
        return "单个单位数量限制";
    }

    public override string GetDescribe8()
    {
        return "角度";
    }

}

public class LineSelectEventField : EventFieldBase
{
    public LineSelectEventField(SkillEventData cEventData) : base(cEventData)
    {
        if (null == cEventData.mParamer1)
        {
            cEventData.mParamer1 = ETargetType.EEnemyAll;
        }
        else if (cEventData.mParamer1.GetType() == typeof(int))
        {
            cEventData.mParamer1 = (ETargetType)cEventData.mParamer1;
        }

        if (null == cEventData.mParamer2)
        {
            cEventData.mParamer2 = "";
        }

        if (null == cEventData.mParamer3)
        {
            cEventData.mParamer3 = 9999;
        }
        if (null == cEventData.mParamer4)
        {
            cEventData.mParamer4 = 0;
        }
        if (null == cEventData.mParamer5)
        {
            cEventData.mParamer5 = 0;
        }
        if (null == cEventData.mParamer6)
        {
            cEventData.mParamer6 = 0;
        }

        if (null == cEventData.mParamer7)
        {
            cEventData.mParamer7 = 1;
        }
    }

    public override string GetDescribe1()
    {
        return "目标类型";
    }
    public override string GetDescribe2()
    {
        return "挂点";
    }
    public override string GetDescribe3()
    {
        return "数量限制";
    }

    public override string GetDescribe4()
    {
        return "距离";
    }

    public override string GetDescribe5()
    {
        return "持续时间";
    }

    public override string GetDescribe6()
    {
        return "选择间隔";
    }

    public override string GetDescribe7()
    {
        return "单个单位数量限制";
    }
}

public class RectSelectEventField : EventFieldBase
{
    public RectSelectEventField(SkillEventData cEventData) : base(cEventData)
    {
        if (null == cEventData.mParamer1)
        {
            cEventData.mParamer1 = ETargetType.EEnemyAll;
        }
        else if (cEventData.mParamer1.GetType() == typeof(int))
        {
            cEventData.mParamer1 = (ETargetType)cEventData.mParamer1;
        }

        if (null == cEventData.mParamer2)
        {
            cEventData.mParamer2 = "";
        }

        if (null == cEventData.mParamer3)
        {
            cEventData.mParamer3 = 9999;
        }

        if (null == cEventData.mParamer4)
        {
            cEventData.mParamer4 = 0;
        }

        if (null == cEventData.mParamer5)
        {
            cEventData.mParamer5 = 0;
        }

        if (null == cEventData.mParamer6)
        {
            cEventData.mParamer6 = 0;
        }

        if (null == cEventData.mParamer7)
        {
            cEventData.mParamer7 = 1;
        }

        if (null == cEventData.mParamer8)
        {
            cEventData.mParamer8 = 0;
        }

    }

    public override string GetDescribe1()
    {
        return "目标类型";
    }
    public override string GetDescribe2()
    {
        return "挂点";
    }
    public override string GetDescribe3()
    {
        return "数量限制";
    }
    public override string GetDescribe4()
    {
        return "半宽(宽/2)";
    }
    public override string GetDescribe5()
    {
        return "持续时间";
    }

    public override string GetDescribe6()
    {
        return "选择间隔";
    }

    public override string GetDescribe7()
    {
        return "单个单位数量限制";
    }

    public override string GetDescribe8()
    {
        return "半高(高/2)";
    }

}

public class CreateFlyTargetEventField : EventFieldBase
{
    public CreateFlyTargetEventField(SkillEventData cEventData) : base(cEventData)
    {
        if (null == cEventData.mParamer1)
        {
            cEventData.mParamer1 = "";
        }
        if (null == cEventData.mParamer2)
        {
            cEventData.mParamer2 = "";
        }
        if (null == cEventData.mParamer3)
        {
            cEventData.mParamer3 = ETargetType.EEnemyAll;
        }
        else if (cEventData.mParamer3.GetType() == typeof(int))
        {
            cEventData.mParamer3 = (ETargetType)cEventData.mParamer3;
        }

        if (null == cEventData.mParamer4)
        {
            cEventData.mParamer4 = 1;
        }
        if (null == cEventData.mParamer5)
        {
            cEventData.mParamer5 = 10000;
        }
        if (null == cEventData.mParamer6)
        {
            cEventData.mParamer6 = "";
        }
    }

    public override string GetDescribe1()
    {
        return "特效名";
    }
    public override string GetDescribe2()
    {
        return "挂点";
    }
    public override string GetDescribe3()
    {
        return "目标类型";
    }
    public override string GetDescribe4()
    {
        return "数量限制";
    }
    public override string GetDescribe5()
    {
        return "飞行速度";
    }
    public override string GetDescribe6()
    {
        return "结束特效名";
    }
}

public class CreateFlyForwardEventField : EventFieldBase
{
    public CreateFlyForwardEventField(SkillEventData cEventData) : base(cEventData)
    {
        if (null == cEventData.mParamer1)
        {
            cEventData.mParamer1 = "";
        }
        if (null == cEventData.mParamer2)
        {
            cEventData.mParamer2 = "";
        }
        if (null == cEventData.mParamer3)
        {
            cEventData.mParamer3 = ETargetType.EEnemyAll;
        }
        else if (cEventData.mParamer3.GetType() == typeof(int))
        {
            cEventData.mParamer3 = (ETargetType)cEventData.mParamer3;
        }

        if (null == cEventData.mParamer4)
        {
            cEventData.mParamer4 = 1;
        }
        if (null == cEventData.mParamer5)
        {
            cEventData.mParamer5 = 10000;
        }
        if (null == cEventData.mParamer6)
        {
            cEventData.mParamer6 = "";
        }
        if(null == cEventData.mParamer7)
        {
            cEventData.mParamer7 = 0;
        }
        if (null == cEventData.mParamer8)
        {
            cEventData.mParamer8 = 0;
        }
        if (null == cEventData.mParamer9)
        {
            cEventData.mParamer9 = false;
        }
    }

    public override string GetDescribe1()
    {
        return "特效名";
    }
    public override string GetDescribe2()
    {
        return "挂点";
    }
    public override string GetDescribe3()
    {
        return "目标类型";
    }
    public override string GetDescribe4()
    {
        return "数量限制";
    }
    public override string GetDescribe5()
    {
        return "飞行速度";
    }
    public override string GetDescribe6()
    {
        return "结束特效名";
    }

    public override string GetDescribe7()
    {
        return "宽度";
    }
    public override string GetDescribe8()
    {
        return "偏移角度(0-180)";
    }

    public override string GetDescribe9()
    {
        return "使用挂点方向";
    }
}

public class CreateFlyForwardExplodeEventField : EventFieldBase
{
    public CreateFlyForwardExplodeEventField(SkillEventData cEventData) : base(cEventData)
    {
        if (null == cEventData.mParamer1)
        {
            cEventData.mParamer1 = "";
        }
        if (null == cEventData.mParamer2)
        {
            cEventData.mParamer2 = "";
        }
        if (null == cEventData.mParamer3)
        {
            cEventData.mParamer3 = ETargetType.EEnemyAll;
        }
        else if (cEventData.mParamer3.GetType() == typeof(int))
        {
            cEventData.mParamer3 = (ETargetType)cEventData.mParamer3;
        }

        if (null == cEventData.mParamer4)
        {
            cEventData.mParamer4 = 1;
        }
        if (null == cEventData.mParamer5)
        {
            cEventData.mParamer5 = 10000;
        }
        if (null == cEventData.mParamer6)
        {
            cEventData.mParamer6 = "";
        }
        if (null == cEventData.mParamer7)
        {
            cEventData.mParamer7 = 0;
        }
        if (null == cEventData.mParamer8)
        {
            cEventData.mParamer8 = 0;
        }
        if (null == cEventData.mParamer9)
        {
            cEventData.mParamer9 = 0;
        }

        if (null == cEventData.mParamer10)
        {
            cEventData.mParamer10 = 0;
        }
    }

    public override string GetDescribe1()
    {
        return "特效名";
    }
    public override string GetDescribe2()
    {
        return "挂点";
    }
    public override string GetDescribe3()
    {
        return "目标类型";
    }
    public override string GetDescribe4()
    {
        return "数量限制";
    }
    public override string GetDescribe5()
    {
        return "飞行速度";
    }
    public override string GetDescribe6()
    {
        return "结束特效名";
    }

    public override string GetDescribe7()
    {
        return "宽度";
    }
    public override string GetDescribe8()
    {
        return "偏移角度(0-180)";
    }

    public override string GetDescribe9()
    {
        return "爆炸半径";
    }

    public override string GetDescribe10()
    {
        return "延时检测时间";
    }
}

public class CreateFlyForwardBackEventField : EventFieldBase
{
    public CreateFlyForwardBackEventField(SkillEventData cEventData) : base(cEventData)
    {
        if (null == cEventData.mParamer1)
        {
            cEventData.mParamer1 = "";
        }
        if (null == cEventData.mParamer2)
        {
            cEventData.mParamer2 = "";
        }
        if (null == cEventData.mParamer3)
        {
            cEventData.mParamer3 = ETargetType.EEnemyAll;
        }
        else if (cEventData.mParamer3.GetType() == typeof(int))
        {
            cEventData.mParamer3 = (ETargetType)cEventData.mParamer3;
        }

        if (null == cEventData.mParamer4)
        {
            cEventData.mParamer4 = 1;
        }
        if (null == cEventData.mParamer5)
        {
            cEventData.mParamer5 = 10000;
        }
        if (null == cEventData.mParamer6)
        {
            cEventData.mParamer6 = "";
        }
        if (null == cEventData.mParamer7)
        {
            cEventData.mParamer7 = 0;
        }
        if (null == cEventData.mParamer8)
        {
            cEventData.mParamer8 = 0;
        }
        if (null == cEventData.mParamer9)
        {
            cEventData.mParamer9 = false;
        }
        if (null == cEventData.mParamer10)
        {
            cEventData.mParamer10 = false;
        }
    }

    public override string GetDescribe1()
    {
        return "特效名";
    }
    public override string GetDescribe2()
    {
        return "挂点";
    }
    public override string GetDescribe3()
    {
        return "目标类型";
    }
    public override string GetDescribe4()
    {
        return "数量限制";
    }
    public override string GetDescribe5()
    {
        return "飞行速度";
    }
    public override string GetDescribe6()
    {
        return "结束特效名";
    }

    public override string GetDescribe7()
    {
        return "宽度";
    }
    public override string GetDescribe8()
    {
        return "偏移角度(0-180)";
    }

    public override string GetDescribe9()
    {
        return "使用挂点方向";
    }

    public override string GetDescribe10()
    {
        return "返回时检测";
    }
}

public class CreateFlyPositionEventField : EventFieldBase
{
    public CreateFlyPositionEventField(SkillEventData cEventData) : base(cEventData)
    {
        if (null == cEventData.mParamer1)
        {
            cEventData.mParamer1 = "";
        }
        if (null == cEventData.mParamer2)
        {
            cEventData.mParamer2 = "";
        }
        if (null == cEventData.mParamer3)
        {
            cEventData.mParamer3 = ETargetType.EEnemyAll;
        }
        else if (cEventData.mParamer3.GetType() == typeof(int))
        {
            cEventData.mParamer3 = (ETargetType)cEventData.mParamer3;
        }
        if (null == cEventData.mParamer4)
        {
            cEventData.mParamer4 = 1;
        }
        if (null == cEventData.mParamer5)
        {
            cEventData.mParamer5 = 10000;
        }
        if (null == cEventData.mParamer6)
        {
            cEventData.mParamer6 = "";
        }
        if (null == cEventData.mParamer7)
        {
            cEventData.mParamer7 = 0;
        }
        if (null == cEventData.mParamer8)
        {
            cEventData.mParamer8 = false;
        }
    }

    public override string GetDescribe1()
    {
        return "特效名";
    }
    public override string GetDescribe2()
    {
        return "挂点";
    }
    public override string GetDescribe3()
    {
        return "目标类型";
    }
    public override string GetDescribe4()
    {
        return "数量限制";
    }
    public override string GetDescribe5()
    {
        return "飞行速度";
    }
    public override string GetDescribe6()
    {
        return "结束特效名";
    }

    public override string GetDescribe7()
    {
        return "爆炸半径";
    }

    public override string GetDescribe8()
    {
        return "使用面向落点";
    }
}

public class FlushForwardEventField : EventFieldBase
{
    public FlushForwardEventField(SkillEventData cEventData) : base(cEventData)
    {
        if (null == cEventData.mParamer1)
        {
            cEventData.mParamer1 = ETargetType.EEnemyAll;
        }
        else if (cEventData.mParamer1.GetType() == typeof(int))
        {
            cEventData.mParamer1 = (ETargetType)cEventData.mParamer1;
        }
        if (null == cEventData.mParamer2)
        {
            cEventData.mParamer2 = 1;
        }
        if (null == cEventData.mParamer3)
        {
            cEventData.mParamer3 = 20000;
        }
        if (null == cEventData.mParamer4)
        {
            cEventData.mParamer4 = 1000;
        }
        if (null == cEventData.mParamer5)
        {
            cEventData.mParamer5 = true;
        }
        if (null == cEventData.mParamer6)
        {
            cEventData.mParamer6 = true;
        }
        if (null == cEventData.mParamer7)
        {
            cEventData.mParamer7 = false;
        }
        if(null == cEventData.mParamer8)
        {
            cEventData.mParamer8 = EFlushPosType.ETargetDir;
        }
        if (null == cEventData.mParamer9)
        {
            cEventData.mParamer9 = 0;
        }
    }

    public override string GetDescribe1()
    {
        return "目标类型";
    }
    public override string GetDescribe2()
    {
        return "数量限制";
    }
    public override string GetDescribe3()
    {
        return "位移速度";
    }
    public override string GetDescribe4()
    {
        return "伤害宽度";
    }

    public override string GetDescribe5()
    {
        return "改变面向";
    }

    public override string GetDescribe6()
    {
        return "忽略阻挡";
    }

    public override string GetDescribe7()
    {
        return "忽略单位";
    }

    public override string GetDescribe8()
    {
        return "目标位置类型";
    }

    public override string GetDescribe9()
    {
        return "闪现距离";
    }
}

public class ShakeCameraEventField : EventFieldBase
{
    public ShakeCameraEventField(SkillEventData cEventData) : base(cEventData)
    {
        if (null == cEventData.mParamer1)
        {
            cEventData.mParamer1 = 30;
        }
        if (null == cEventData.mParamer2)
        {
            cEventData.mParamer2 = 200;
        }
        if (null == cEventData.mParamer3)
        {
            cEventData.mParamer3 = 20000;
        }
    }

    public override string GetDescribe1()
    {
        return "时长";
    }
    public override string GetDescribe2()
    {
        return "幅度";
    }
    public override string GetDescribe3()
    {
        return "速度";
    }
}

public class InputCastEventField : EventFieldBase
{
    public InputCastEventField(SkillEventData cEventData) : base(cEventData)
    {
        if (null == cEventData.mParamer1)
        {
            cEventData.mParamer1 = ECastType.EClick;
        }
        else if (cEventData.mParamer1.GetType() == typeof(int))
        {
            cEventData.mParamer1 = (ECastType)cEventData.mParamer1;
        }
        if (null == cEventData.mParamer2)
        {
            cEventData.mParamer2 = 0;
        }
    }

    public override string GetDescribe1()
    {
        return "施法类型";
    }
    public override string GetDescribe2()
    {
        return "持续等待时间";
    }
    public override string GetDescribe3()
    {
        return "速度";
    }
}

public class AudioEventField : EventFieldBase
{
    public AudioEventField(SkillEventData cEventData) : base(cEventData)
    {
        if (null == cEventData.mParamer1)
        {
            cEventData.mParamer1 = 0;
        }

        if (null == cEventData.mParamer2)
        {
            cEventData.mParamer2 = 0;
        }
    }

    public override string GetDescribe1()
    {
        return "音效ID";
    }

    public override string GetDescribe2()
    {
        return "持续时间";
    }
}

public class EmptyEventField : EventFieldBase
{
    public EmptyEventField(SkillEventData cEventData) : base(cEventData)
    {
    }
}

public class FlashTargetEventField : EventFieldBase
{
    public FlashTargetEventField(SkillEventData cEventData) : base(cEventData)
    {
    }
}

public class SetTargetDirEventField : EventFieldBase
{
    public SetTargetDirEventField(SkillEventData cEventData) : base(cEventData)
    {
        if (null == cEventData.mParamer1)
        {
            cEventData.mParamer1 = true;
        }
    }

    public override string GetDescribe1()
    {
        return "立即转向";
    }
}

public class ChangeForwardEventField : EventFieldBase
{
    public ChangeForwardEventField(SkillEventData cEventData) : base(cEventData)
    {
        if (null == cEventData.mParamer1)
        {
            cEventData.mParamer1 = true;
        }
        if (null == cEventData.mParamer2)
        {
            cEventData.mParamer2 = true;
        }
    }

    public override string GetDescribe1()
    {
        return "立即转向";
    }

    public override string GetDescribe2()
    {
        return "忽略转向时间";
    }
}

public class UnitLockEventField : EventFieldBase
{
    public UnitLockEventField(SkillEventData cEventData) : base(cEventData)
    {
        if (null == cEventData.mParamer1)
        {
            cEventData.mParamer1 = UnitLockType.None;
        }
        if (null == cEventData.mParamer2)
        {
            cEventData.mParamer2 = 0;
        }
        if (null == cEventData.mParamer3)
        {
            cEventData.mParamer3 = 0;
        }
    }

    public override string GetDescribe1()
    {
        return "锁定类型";
    }

    public override string GetDescribe2()
    {
        return "锁定距离";
    }

    public override string GetDescribe3()
    {
        return "锁定时间";
    }
}

public class SwapActiveSkillPositionEventField : EventFieldBase
{
    public SwapActiveSkillPositionEventField(SkillEventData cEventData) : base(cEventData)
    {
        if (null == cEventData.mParamer1)
        {
            cEventData.mParamer1 = "";
        }
        if (null == cEventData.mParamer2)
        {
            cEventData.mParamer2 = 0;
        }
        if (null == cEventData.mParamer3)
        {
            cEventData.mParamer3 = true;
        }
    }

    public override string GetDescribe1()
    {
        return "技能ID列表(id,id...)";
    }

    public override string GetDescribe2()
    {
        return "持续时间";
    }

    public override string GetDescribe3()
    {
        return "还原技能位置";
    }

}

public class SkillLeaveTimeEventField : EventFieldBase
{
    public SkillLeaveTimeEventField(SkillEventData cEventData) : base(cEventData)
    {
        if (null == cEventData.mParamer1)
        {
            cEventData.mParamer1 = 0;
        }
        if (null == cEventData.mParamer2)
        {
            cEventData.mParamer2 = "";
        }
    }

    public override string GetDescribe1()
    {
        return "持续时间";
    }

    public override string GetDescribe2()
    {
        return "UI特效";
    }
}

public class ResetAllCDEventField : EventFieldBase
{
    public ResetAllCDEventField(SkillEventData cEventData) : base(cEventData)
    {
    }
}

public class ReflectDamageEventField : EventFieldBase
{
    public ReflectDamageEventField(SkillEventData cEventData) : base(cEventData)
    {
        if (null == cEventData.mParamer1)
        {
            cEventData.mParamer1 = 0;
        }
        if (null == cEventData.mParamer2)
        {
            cEventData.mParamer2 = 10000;
        }
    }

    public override string GetDescribe1()
    {
        return "持续时间";
    }

    public override string GetDescribe2()
    {
        return "万分比概率";
    }
}