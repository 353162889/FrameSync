﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ConditionFieldBase
{
    protected ESkillConditionType m_eConditionType = ESkillConditionType.ENone;
    public ESkillConditionType conditionType { get { return m_eConditionType; } }

    public ConditionFieldBase(SkillConditionData cConditionData)
    {
        m_eConditionType = cConditionData.mType;
    }

    public virtual string GetDescribe1()
    {
        return "参数1";
    }
    public virtual string GetDescribe2()
    {
        return "参数2";
    }
    public virtual string GetDescribe3()
    {
        return "参数3";
    }
    public virtual string GetDescribe4()
    {
        return "参数4";
    }
}

public class ConditionFieldFactory
{
    public static ConditionFieldBase CreateField(SkillConditionData cConditionData)
    {
        if (ESkillConditionType.ENone == cConditionData.mType)
        {
            return null;
        }

        ConditionFieldBase cConditionField = null;
        switch (cConditionData.mType)
        {
            case ESkillConditionType.EHaveBuff:
                cConditionField = new HaveBuffConditionField(cConditionData);
                break;
            case ESkillConditionType.ECircleHaveTarget:
                cConditionField = new CircleHaveTargetConditionField(cConditionData);
                break;
            case ESkillConditionType.EInputCast:
                cConditionField = new InputCastConditionField(cConditionData);
                break;
            case ESkillConditionType.ESkillCastTimes:
                cConditionField = new SkillCastTimesConditionField(cConditionData);
                break;
            case ESkillConditionType.ECurrentTargetDie:
                cConditionField = new CurrentTargetDieConditionField(cConditionData);
                break;
            case ESkillConditionType.EFlyBackObjEnd:
                cConditionField = new FlyBackObjEndConditionField(cConditionData);
                break;
            case ESkillConditionType.ELaskSkillPhaseBreak:
                cConditionField = new LastSkillPhaseBreakConditionField(cConditionData);
                break;
            case ESkillConditionType.EBuffAffect:
                cConditionField = new BuffAffectConditionField(cConditionData);
                break;
        }
        return cConditionField;
    }
}

public class HaveBuffConditionField : ConditionFieldBase
{
    public HaveBuffConditionField(SkillConditionData cConditionData) : base(cConditionData)
    {
        if (null == cConditionData.mParamer1)
        {
            cConditionData.mParamer1 = 0;
        }
        if (null == cConditionData.mParamer2)
        {
            cConditionData.mParamer2 = 0;
        }
        if (null == cConditionData.mParamer3)
        {
            cConditionData.mParamer3 = 0;
        }
        if (null == cConditionData.mParamer4)
        {
            cConditionData.mParamer4 = 0;
        }
    }

    public override string GetDescribe1()
    {
        return "BuffId";
    }
    public override string GetDescribe2()
    {
        return "BuffId";
    }
    public override string GetDescribe3()
    {
        return "BuffId";
    }
    public override string GetDescribe4()
    {
        return "BuffId";
    }
}

public class CircleHaveTargetConditionField : ConditionFieldBase
{
    public CircleHaveTargetConditionField(SkillConditionData cConditionData) : base(cConditionData)
    {
        if (null == cConditionData.mParamer1)
        {
            cConditionData.mParamer1 = ETargetType.EEnemyAll;
        }
        if (null == cConditionData.mParamer2)
        {
            cConditionData.mParamer2 = "";
        }
        if (null == cConditionData.mParamer3)
        {
            cConditionData.mParamer3 = 0;
        }
    }

    public override string GetDescribe1()
    {
        return "目标类型";
    }
    public override string GetDescribe2()
    {
        return "挂点（尽量不填）";
    }
    public override string GetDescribe3()
    {
        return "半径";
    }
}

public class InputCastConditionField : ConditionFieldBase
{
    public InputCastConditionField(SkillConditionData cConditionData) : base(cConditionData)
    {
        if (null == cConditionData.mParamer1)
        {
            cConditionData.mParamer1 = ECastType.EClick;
        }
       
    }

    public override string GetDescribe1()
    {
        return "上阶段输入类型";
    }
}

public class SkillCastTimesConditionField : ConditionFieldBase
{
    public SkillCastTimesConditionField(SkillConditionData cConditionData) : base(cConditionData)
    {
        if (null == cConditionData.mParamer1)
        {
            cConditionData.mParamer1 = EConditionCompareType.Great;
        }
        if (null == cConditionData.mParamer2)
        {
            cConditionData.mParamer2 = 0;
        }
        if (null == cConditionData.mParamer3)
        {
            cConditionData.mParamer3 = 0;
        }
    }

    public override string GetDescribe1()
    {
        return "比较类型";
    }

    public override string GetDescribe2()
    {
        return "技能ID";
    }

    public override string GetDescribe3()
    {
        return "使用次数";
    }
}

public class CurrentTargetDieConditionField : ConditionFieldBase
{
    public CurrentTargetDieConditionField(SkillConditionData cConditionData) : base(cConditionData)
    {
       
    }
}

public class FlyBackObjEndConditionField : ConditionFieldBase
{
    public FlyBackObjEndConditionField(SkillConditionData cConditionData) : base(cConditionData)
    {

    }
}

public class LastSkillPhaseBreakConditionField : ConditionFieldBase
{
    public LastSkillPhaseBreakConditionField(SkillConditionData cConditionData) : base(cConditionData)
    {

    }
}

public class BuffAffectConditionField : ConditionFieldBase
{
    public BuffAffectConditionField(SkillConditionData cConditionData) : base(cConditionData)
    {
        if (null == cConditionData.mParamer1)
        {
            cConditionData.mParamer1 = EBuffAffectType.ENone;
        }
    }

    public override string GetDescribe1()
    {
        return "拥有buff效果类型";
    }
}