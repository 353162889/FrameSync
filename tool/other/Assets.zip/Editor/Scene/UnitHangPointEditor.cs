﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using UnityEditor;
using UnityEngine;


[CustomEditor(typeof(UnitHangPoint))]
public class UnitHangPointEditor : Editor
{
    public override void OnInspectorGUI()
    {
        var transNameProperty = serializedObject.FindProperty("m_lstTransName");
        var transProperty = serializedObject.FindProperty("m_lstTrans");
        var posNameProperty = serializedObject.FindProperty("m_lstPosName");
        var posProperty = serializedObject.FindProperty("m_lstPos");
        var forwardProperty = serializedObject.FindProperty("m_lstForward");
        EditorGUILayout.LabelField("HangPoint_Transform:");
        int count = transNameProperty.arraySize;
        for (int i = 0; i < count; i++)
        {
            var prop = transNameProperty.GetArrayElementAtIndex(i);
            var objProp = transProperty.GetArrayElementAtIndex(i);
            EditorGUILayout.ObjectField(objProp, new GUIContent(prop.stringValue));
        }
        EditorGUILayout.LabelField("HangPoint_Position:");
        count = posNameProperty.arraySize;
        for (int i = 0; i < count; i++)
        {

            var prop = posNameProperty.GetArrayElementAtIndex(i);
            var objProp = posProperty.GetArrayElementAtIndex(i);
            var forwardPorp = forwardProperty.GetArrayElementAtIndex(i);
            int x = objProp.FindPropertyRelative("x").intValue;
            int y = objProp.FindPropertyRelative("y").intValue;
            int z = objProp.FindPropertyRelative("z").intValue;

            int fx = forwardPorp.FindPropertyRelative("x").intValue;
            int fy = forwardPorp.FindPropertyRelative("y").intValue;
            int fz = forwardPorp.FindPropertyRelative("z").intValue;
            EditorGUILayout.BeginHorizontal();
            EditorGUILayout.LabelField("    " + prop.stringValue);
            EditorGUILayout.EndHorizontal();
            EditorGUILayout.BeginHorizontal();
            EditorGUILayout.Vector3Field("\tposition", new Vector3(x, y, z));
            EditorGUILayout.EndHorizontal();
            EditorGUILayout.BeginHorizontal();
            EditorGUILayout.Vector3Field("\tforward", new Vector3(fx, fy, fz));
            EditorGUILayout.EndHorizontal();
        }
        UnitHangPoint hangPoint = (UnitHangPoint)target;
        if (GUILayout.Button("查找所有挂点"))
        {
            transNameProperty.ClearArray();
            transProperty.ClearArray();
            posNameProperty.ClearArray();
            posProperty.ClearArray();
            forwardProperty.ClearArray();
            Transform trans = hangPoint.transform;
            FindHangPoint(trans, trans, transNameProperty, transProperty, posNameProperty, posProperty, forwardProperty);
            if (GUI.changed)
                EditorUtility.SetDirty(hangPoint.gameObject);
            serializedObject.ApplyModifiedProperties();
            AssetDatabase.SaveAssets();
            AssetDatabase.Refresh();
        }
    }

    private void FindHangPoint(Transform root, Transform trans, SerializedProperty transNameProperty, SerializedProperty transProperty, SerializedProperty posNameProperty, SerializedProperty posProperty, SerializedProperty forwardProperty)
    {
        int count = trans.childCount;
        for (int i = 0; i < count; i++)
        {
            var child = trans.GetChild(i);
            if (child.tag == "HangPoint_Transform")
            {
                transNameProperty.InsertArrayElementAtIndex(transNameProperty.arraySize);
                transProperty.InsertArrayElementAtIndex(transProperty.arraySize);
                var prop = transNameProperty.GetArrayElementAtIndex(transNameProperty.arraySize - 1);
                var objPorp = transProperty.GetArrayElementAtIndex(transProperty.arraySize - 1);
                prop.stringValue = child.name;
                objPorp.objectReferenceValue = child;
            }
            else if (child.tag == "HangPoint_Position")
            {
                posNameProperty.InsertArrayElementAtIndex(posNameProperty.arraySize);
                posProperty.InsertArrayElementAtIndex(posProperty.arraySize);
                forwardProperty.InsertArrayElementAtIndex(forwardProperty.arraySize);
                var prop = posNameProperty.GetArrayElementAtIndex(posNameProperty.arraySize - 1);
                var objProp = posProperty.GetArrayElementAtIndex(posProperty.arraySize - 1);
                var forwardProp = forwardProperty.GetArrayElementAtIndex(forwardProperty.arraySize - 1);
                prop.stringValue = child.name;
                var pos = child.position;
                var localPos = root.InverseTransformPoint(pos);
                objProp.FindPropertyRelative("x").intValue = (int)(localPos.x * 1000);
                objProp.FindPropertyRelative("y").intValue = (int)(localPos.y * 1000);
                objProp.FindPropertyRelative("z").intValue = (int)(localPos.z * 1000);

                var forward = child.forward;
                var localForward = root.InverseTransformDirection(forward);
                forwardProp.FindPropertyRelative("x").intValue = (int)(localForward.x * 1000);
                forwardProp.FindPropertyRelative("y").intValue = (int)(localForward.y * 1000);
                forwardProp.FindPropertyRelative("z").intValue = (int)(localForward.z * 1000);

            }
            FindHangPoint(root, child, transNameProperty, transProperty, posNameProperty, posProperty, forwardProperty);
        }
    }
}