﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEditor;
using UnityEditor.SceneManagement;

public class ColliderCreater
{
    [MenuItem("Tools/生成自定义碰撞器")]
    public static void GenerateCollider()
    {
        GameObject objRoot = GameObject.Find("SceneRoot");
        Collider[] arrCollider = objRoot.GetComponentsInChildren<Collider>();
        for (int i = 0; i != arrCollider.Length; ++i)
        {
            Collider cCollider = arrCollider[i];
            bool bIsBox = cCollider is BoxCollider;
            bool bIsSphere = cCollider is SphereCollider;

            if (bIsBox || bIsSphere)
            {
                GameObject cCurObj = cCollider.gameObject;
                CCollider cCustomCollider = cCurObj.GetComponent<CCollider>();
                if (null == cCustomCollider)
                {
                    if (bIsBox)
                    {
                        cCustomCollider = cCurObj.AddComponent<CBox>();
                    }
                    else
                    {
                        cCustomCollider = cCurObj.AddComponent<CSphere>();
                    }  
                }
                cCustomCollider.UpdateCollider();
                //cCollider.enabled = false;
            }
        }

        EditorSceneManager.MarkSceneDirty(EditorSceneManager.GetActiveScene());
    }
}
