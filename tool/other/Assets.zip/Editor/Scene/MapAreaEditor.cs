﻿using ResTable;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;

public class MapAreaEditor
{
    private int m_nSceneIndex;
    private string[] m_arrSceneName;
    private List<ResScene> m_lstResScene;

    private int m_nAreaIndex;
    private string[] m_arrAreaName;
    private List<ResArea> m_lstArea;
    private List<GameObject> m_lstAreaView;
    private Color[] m_arrAreaColor = new Color[256];

    private CellAreaLayerType m_eCurSelectLayer;
    private bool[] m_arrShowLayer;
    private bool[] m_arrShowLayerView;
    private bool m_bShowCurrent;

    private GameObject m_cRoot;

    public void Init()
    {
        DataEditorReader<ResScene>.Clear();
        DataEditorReader<ResArea>.Clear();
        m_nSceneIndex = 0;
        m_lstArea = new List<ResArea>();
        m_lstAreaView = new List<GameObject>();
        m_lstResScene = DataEditorReader<ResScene>.DataList;
        if(m_lstResScene == null || m_lstResScene.Count == 0)
        {
            Debug.LogError("找不到场景配置");
            return;
        }
        m_cRoot = new GameObject();
        m_cRoot.name = "MapAreaEditorRoot";
        m_cRoot.transform.position = Vector3.zero;
        int count = m_lstResScene.Count;
        m_arrSceneName = new string[count];
        for (int i = 0; i < count; i++)
        {
            m_arrSceneName[i] = m_lstResScene[i].id + "|" + m_lstResScene[i].name;
            if(m_lstResScene[i].name == EditorSceneManager.GetActiveScene().name)
            {
                m_nSceneIndex = i;
            }
        }

        m_eCurSelectLayer = CellAreaLayerType.Layer1;
        m_arrShowLayer = new bool[(int)CellAreaLayerType.LayerMax];
        for (int i = 0; i < m_arrShowLayer.Length; i++)
        {
            m_arrShowLayer[i] = i == (int)m_eCurSelectLayer;
        }
        m_arrShowLayerView = new bool[(int)CellAreaLayerType.LayerMax];
        for (int i = 0; i < m_arrShowLayerView.Length; i++)
        {
            m_arrShowLayerView[i] = i == (int)m_eCurSelectLayer;
        }
        m_bShowCurrent = false;
        RefreshData();
    }

    public void Clear()
    {
        DataEditorReader<ResScene>.Clear();
        DataEditorReader<ResArea>.Clear();
        m_lstAreaView.Clear();
        if(null != m_cRoot)
        {
            GameObject.DestroyImmediate(m_cRoot);
            m_cRoot = null;
        }
    }

    private void RefreshData()
    {
        if (m_nSceneIndex < 0) return;
        m_lstArea.Clear();
        for (int i = 0; i < m_lstAreaView.Count; i++)
        {
            GameObject.DestroyImmediate(m_lstAreaView[i]);
        }
        m_lstAreaView.Clear();
        var resScene = m_lstResScene[m_nSceneIndex];
        int sceneId = resScene.id;
        var lst = DataEditorReader<ResArea>.DataList;
        for (int i = 0; i < lst.Count; i++)
        {
            if(lst[i].scene_id == sceneId)
            {
                m_lstArea.Add(lst[i]);
            }
        }
        m_nAreaIndex = 0;
        m_arrAreaName = new string[m_lstArea.Count];
        for (int i = 0; i < m_arrAreaColor.Length; i++)
        {
            m_arrAreaColor[i] = NoneColor;
        }
        for (int i = 0; i < m_lstArea.Count; i++)
        {
            m_arrAreaName[i] = m_lstArea[i].key +"|" + m_lstArea[i].desc;
            Color color;
            ColorUtility.TryParseHtmlString(m_lstArea[i].editor_color,out color);
            m_arrAreaColor[m_lstArea[i].key] = color;
            var path = m_lstArea[i].prefab;
            GameObject go;
            if (string.IsNullOrEmpty(path))
            {
                go = new GameObject();
            }
            else
            {
               GameObject prefab = AssetDatabase.LoadAssetAtPath<GameObject>("Assets/ResourcesEx/Prefab/Effect/" + path + ".prefab");
               go = GameObject.Instantiate<GameObject>(prefab);
            }
            go.name = m_arrAreaName[i];
            m_cRoot.AddChild(go);
            go.transform.position = new Vector3(m_lstArea[i].pos_x_z[0] / 1000.0f,0, m_lstArea[i].pos_x_z[1]/1000.0f);
            m_lstAreaView.Add(go);
        }
        UpdateLayerView();
    }

    public bool OnGUI()
    {
        EditorGUILayout.BeginHorizontal();
        EditorGUILayout.LabelField("场景选择:", GUILayout.Width(80));
        EditorGUILayout.EndHorizontal();
        EditorGUILayout.BeginHorizontal();
        int oldSceneIndex = m_nSceneIndex;
        m_nSceneIndex = EditorGUILayout.Popup(m_nSceneIndex, m_arrSceneName,GUILayout.Width(150));
        EditorGUILayout.LabelField(m_lstResScene[m_nSceneIndex].desc);
        if(oldSceneIndex != m_nSceneIndex)
        {
            RefreshData();
        }
        EditorGUILayout.EndHorizontal();

        EditorGUILayout.BeginHorizontal();
        EditorGUILayout.LabelField("-----------------------------------------------------------");
        EditorGUILayout.EndHorizontal();

        EditorGUILayout.BeginHorizontal();
        EditorGUILayout.LabelField("当前编辑层次:", GUILayout.Width(80));
        EditorGUILayout.EndHorizontal();

        EditorGUILayout.BeginHorizontal();
        var oldLayer = m_eCurSelectLayer;
        m_eCurSelectLayer = (CellAreaLayerType)EditorGUILayout.EnumPopup(m_eCurSelectLayer, GUILayout.Width(150));
        if (m_eCurSelectLayer == CellAreaLayerType.LayerMax)//排除max层
        {
            m_eCurSelectLayer = oldLayer;
        }
        if(oldLayer != m_eCurSelectLayer)
        {
            for (int i = 0; i < m_arrShowLayer.Length; i++)
            {
                m_arrShowLayer[i] = i == (int)m_eCurSelectLayer;
            }
            return true;
        }
        EditorGUILayout.EndHorizontal();

        EditorGUILayout.BeginHorizontal();
        EditorGUILayout.LabelField("显示层次:", GUILayout.Width(80));
        float oldWidth = EditorGUIUtility.labelWidth;
        EditorGUIUtility.labelWidth = 30;
        for (int i = 0; i < m_arrShowLayer.Length; i++)
        {
            bool oldShowLayer = m_arrShowLayer[i];
            m_arrShowLayer[i] = EditorGUILayout.Toggle("层" + i, m_arrShowLayer[i]);
            if (i == (int)m_eCurSelectLayer)
            {
                m_arrShowLayer[i] = true;
            }
            if(oldShowLayer != m_arrShowLayer[i])
            {
                return true;
            }
        }
        EditorGUIUtility.labelWidth = oldWidth;
        EditorGUILayout.EndHorizontal();

        EditorGUILayout.BeginHorizontal();
        EditorGUILayout.LabelField("显示层次表现:", GUILayout.Width(80));
        oldWidth = EditorGUIUtility.labelWidth;
        EditorGUIUtility.labelWidth = 30;
        for (int i = 0; i < m_arrShowLayerView.Length; i++)
        {
            bool oldShowLayerView = m_arrShowLayerView[i];
            m_arrShowLayerView[i] = EditorGUILayout.Toggle("层" + i, m_arrShowLayerView[i]);
            if (oldShowLayerView != m_arrShowLayerView[i])
            {
                UpdateLayerView();
                return true;
            }
        }
        EditorGUIUtility.labelWidth = oldWidth;
        EditorGUILayout.EndHorizontal();

        EditorGUILayout.BeginHorizontal();
        EditorGUILayout.LabelField("-----------------------------------------------------------");
        EditorGUILayout.EndHorizontal();

        EditorGUILayout.BeginHorizontal();
        EditorGUILayout.LabelField("区域选择:",GUILayout.Width(80));
        EditorGUILayout.EndHorizontal();
        if (m_lstArea.Count > 0)
        {
            EditorGUILayout.BeginHorizontal();
            int oldAreaIndex = m_nAreaIndex;
            m_nAreaIndex = EditorGUILayout.Popup(m_nAreaIndex, m_arrAreaName, GUILayout.Width(150));
            if (oldAreaIndex != m_nAreaIndex)
            {
                return true;
            }
            EditorGUILayout.ObjectField(m_lstAreaView[m_nAreaIndex], typeof(GameObject), true);

            oldWidth = EditorGUIUtility.labelWidth;
            EditorGUIUtility.labelWidth = 80;
            bool oldShowCurrent = m_bShowCurrent;
            m_bShowCurrent = EditorGUILayout.Toggle("仅显示当前", m_bShowCurrent);
            EditorGUIUtility.labelWidth = oldWidth;
            if (oldShowCurrent != m_bShowCurrent) return true;

            EditorGUILayout.EndHorizontal();
        }
        else
        {
            EditorGUILayout.BeginHorizontal();
            EditorGUILayout.LabelField("当前场景没有配置区域");
            EditorGUILayout.EndHorizontal();
        }
        return false;
    }

    private void UpdateLayerView()
    {
        for (int i = 0; i < m_arrShowLayerView.Length; i++)
        {
            for (int j = 0; j < m_lstArea.Count; j++)
            {
                if (m_bShowCurrent)
                {
                    m_lstAreaView[j].SetActive(m_lstArea[j].key == m_lstArea[m_nAreaIndex].key);
                }
                else
                {
                    if (m_lstArea[j].layer == i)
                    {
                        m_lstAreaView[j].SetActive(m_arrShowLayerView[i]);
                    }
                }
            }
        }
    }

    public bool IsCurrentPaint(Cell cCell)
    {
        return cCell.mArrAreaId[(int)m_eCurSelectLayer] != 0; 
    }

    public void PaintCurrent(Cell cCell)
    {
        if (m_lstArea.Count > 0)
        {
            cCell.mArrAreaId[(int)m_eCurSelectLayer] = (byte)m_lstArea[m_nAreaIndex].key;
        }
    }

    public void ClearCurrentPaint(Cell cCell)
    {
        cCell.mArrAreaId[(int)m_eCurSelectLayer] = 0;
    }

    private static Color NoneColor = new Color(0, 0, 0, 0);
    public Color GetCellColor(Cell cCell)
    {
        for (int i = m_arrShowLayer.Length - 1; i > -1 ; i--)
        {
            if (m_bShowCurrent)
            {
                if(cCell.mArrAreaId[i] == m_lstArea[m_nAreaIndex].key)
                {
                    return m_arrAreaColor[cCell.mArrAreaId[i]];
                }
            }
            else
            {
                if (m_arrShowLayer[i])
                {
                    byte key = cCell.mArrAreaId[i];
                    if (key != 0)
                    {
                        return m_arrAreaColor[key];
                    }
                }
            }
        }
        return NoneColor;
    }
}
