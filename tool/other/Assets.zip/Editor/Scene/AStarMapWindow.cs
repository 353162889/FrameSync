﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEditor;
using System.IO;

public class AStarMapWindow : EditorWindow
{
    private int m_nRowCount = 50;
    private int m_nColumnCount = 50;
    private int m_nCellSize = 1000;
    private SVector3 m_sMapCenter;
    private int m_nPaintSize = 4;
    private bool m_bEditGrass;
    private int m_nEditorIndex;
    private string[] m_arrEditorDesc = new string[] { "编辑阻挡","编辑草丛","编辑功能区域"};
    private ECamp m_eCamp;

    private Map m_cMap = null;

    private GameObject m_objEditor;

    private bool m_bShowRevivePoint;
    private List<GameObject> m_lstRevivePointGO = new List<GameObject>();
    private Vector2 m_sReviveScrollViewPos;

    private MapAreaEditor m_cAreaEditor = null;

    [MenuItem("Tools/SceneMap/EditorAStarMap")]
    public static void StartSceneMapEditor()
    {
        if (EditorApplication.isCompiling)
        {
            EditorUtility.DisplayDialog("提示", "正在编译，请编译完成后再启用", "确定");
            return;
        }

        AStarMapWindow window = EditorWindow.GetWindow<AStarMapWindow>();
        window.CreateEditorObject();
        window.Init();
        window.Show();
        SceneView.onSceneGUIDelegate += window.OnSceneGUI;
    }

    private void CreateEditorObject()
    {
        m_objEditor = new GameObject();
        Vector3 sPos = Vector3.zero;
        sPos.y = 0.3f;
        m_objEditor.transform.position = sPos;
        m_objEditor.layer = CLayerDefine.Editor;
        m_objEditor.name = "AStarMapEditor";
    }

    void OnEnable()
    {
        m_bShowRevivePoint = true;
        m_eCamp = ECamp.EBlue;
        m_lstRevivePointGO.Clear();
        m_cAreaEditor = new MapAreaEditor();
        m_cAreaEditor.Init();
    }

    private void OnDisable()
    {
        if (null != m_objEditor)
        {
            GameObject.DestroyImmediate(m_objEditor);
            m_objEditor = null;
        }
        SceneView.onSceneGUIDelegate -= OnSceneGUI;
        m_lstRevivePointGO.Clear();
        m_cAreaEditor.Clear();
        m_cAreaEditor = null;
    }

    private void Init()
    {
        if (Application.isPlaying && null != BattleScene.instance.map)
        {
            m_cMap = BattleScene.instance.map;
            m_nCellSize = m_cMap.cellSize;
            m_nRowCount = m_cMap.rowCount;
            m_nColumnCount = m_cMap.columnCount;
            m_sMapCenter = m_cMap.centerPos;
            UpdateMesh();
        }
    }

    private void OnGUI()
    {
        if (EditorApplication.isCompiling)
        {
            return;
        }

        GUILayout.BeginHorizontal();
        m_nCellSize = EditorGUILayout.IntField("格子大小", m_nCellSize);
        GUILayout.EndHorizontal();

        GUILayout.BeginHorizontal();
        m_nRowCount = EditorGUILayout.IntField("格子行数", m_nRowCount);
        m_nColumnCount = EditorGUILayout.IntField("格子列数", m_nColumnCount);
        GUILayout.EndHorizontal();

        GUILayout.BeginHorizontal();
        m_sMapCenter.x = EditorGUILayout.IntField("地图中心X", m_sMapCenter.x);
        m_sMapCenter.y = EditorGUILayout.IntField("地图中心Z", m_sMapCenter.y);
        GUILayout.EndHorizontal();

        GUILayout.BeginHorizontal();
        if (GUILayout.Button("创建新的地图数据"))
        {
            CreateMap();
        }
        if (GUILayout.Button("加载地图数据"))
        {
            LoadMap();
        }
        if (GUILayout.Button("保存地图数据"))
        {
            SaveMap();
        }
        GUILayout.EndHorizontal();
        GUILayout.BeginHorizontal();
        ECamp oldCamp = m_eCamp;
        float oldLabelWidth = EditorGUIUtility.labelWidth;
        EditorGUIUtility.labelWidth = 60;
        m_eCamp = (ECamp)EditorGUILayout.EnumPopup("当前阵营", m_eCamp,GUILayout.Width(140));
        EditorGUIUtility.labelWidth = oldLabelWidth;
        if ((int)m_eCamp >= (int)ECamp.ECount) m_eCamp = oldCamp;
        if (GUILayout.Button(m_arrEditorDesc[m_nEditorIndex]))
        {
            m_nEditorIndex++;
            m_nEditorIndex = m_nEditorIndex % m_arrEditorDesc.Length;
            UpdateMesh();
        }
        GUILayout.EndHorizontal();
        if(m_nEditorIndex == m_arrEditorDesc.Length - 1 && null != m_cAreaEditor)
        {
            if(m_cAreaEditor.OnGUI())
            {
                UpdateMesh();
            }
        }
        ShowRevivePoint();
        if (null != m_cMap)
        {
            if (m_cMap.rowCount != m_nRowCount || m_cMap.columnCount != m_nColumnCount || m_cMap.cellSize != m_nCellSize || m_cMap.centerPos != m_sMapCenter)
            {
                CreateMap();
            }
        }
    }

    private void ShowRevivePoint()
    {
        EditorGUILayout.BeginVertical();
        EditorGUILayout.BeginHorizontal();
        m_bShowRevivePoint = EditorGUILayout.Foldout(m_bShowRevivePoint, "查看出生节点");
        if(GUILayout.Button("添加出生节点"))
        {
            if(m_cMap != null)
            {
                m_cMap.mLstRevivePoint.Add(new MapRevivePoint());
            }
        }
        EditorGUILayout.EndHorizontal();

        if (m_bShowRevivePoint)
        {
            if (m_cMap != null)
            {
                int deleteIndex = -1;
                m_sReviveScrollViewPos = EditorGUILayout.BeginScrollView(m_sReviveScrollViewPos);
                for (int i = 0; i < m_cMap.mLstRevivePoint.Count; i++)
                {
                    EditorGUILayout.BeginHorizontal();
                    MapRevivePoint revivePoint = m_cMap.mLstRevivePoint[i];
                    if (m_lstRevivePointGO.Count <= i)
                    {
                        GameObject go = GameObject.CreatePrimitive(PrimitiveType.Cube);
                        go.transform.parent = m_objEditor.transform;
                        go.transform.position = new Vector3(revivePoint.x / 1000f, 0, revivePoint.z / 1000f);
                        m_lstRevivePointGO.Add(go);
                    }
                    m_lstRevivePointGO[i].name = "RevivePoint_" + i;
                    m_lstRevivePointGO[i] = (GameObject)EditorGUILayout.ObjectField("index:" + i, m_lstRevivePointGO[i], typeof(GameObject), true);
                    if (GUILayout.Button("删除"))
                    {
                        deleteIndex = i;
                        break;
                    }
                    EditorGUILayout.EndHorizontal();
                }
                EditorGUILayout.EndScrollView();
                if (deleteIndex > 0)
                {
                    m_cMap.mLstRevivePoint.RemoveAt(deleteIndex);
                    GameObject.DestroyImmediate(m_lstRevivePointGO[deleteIndex]);
                    m_lstRevivePointGO.RemoveAt(deleteIndex);
                }
            }
            for (int i = 0; i < m_lstRevivePointGO.Count; i++)
            {
                if (!m_lstRevivePointGO[i].activeSelf)
                    m_lstRevivePointGO[i].SetActive(true);
            }
        }
        else
        {
            for (int i = 0; i < m_lstRevivePointGO.Count; i++)
            {
                if (m_lstRevivePointGO[i].activeSelf)
                    m_lstRevivePointGO[i].SetActive(false);
            }
        }
        EditorGUILayout.EndVertical();
    }

    private void CreateMap()
    {
        int nStartZ = m_sMapCenter.z + (m_nRowCount * m_nCellSize / 2 - m_nCellSize / 2);
        int nStartX = m_sMapCenter.x + (-m_nColumnCount * m_nCellSize / 2 + m_nCellSize / 2);

        Cell[,] arrCell = new Cell[m_nRowCount, m_nColumnCount];
        for (short i = 0; i != m_nRowCount; ++i)
        {
            int nPosZ = nStartZ - i * m_nCellSize;
            for (short j = 0; j != m_nColumnCount; ++j)
            {
                int nPosX = nStartX + j * m_nCellSize;
                SVector3 sPos = new SVector3(nPosX, 0, nPosZ);
                Cell cCell = new Cell(sPos, 0);
                cCell.rowIndex = i;
                cCell.columnIndex = j;
                arrCell[i, j] = cCell;
            }
        }

        m_cMap = new Map(m_nRowCount * m_nCellSize, m_nColumnCount * m_nCellSize, arrCell, m_nCellSize, m_nColumnCount, m_nRowCount, m_sMapCenter);
        UpdateMesh();
    }

    private void LoadMap()
    {
        string defaultDictionary = Application.dataPath + "/ResourcesEx/Config/MapConfig/";
        string strPath = EditorUtility.OpenFilePanel("加载地图数据", defaultDictionary, "txt");
        if (!string.IsNullOrEmpty(strPath))
        {
            byte[] buffSrc = null;
            using (FileStream fs = new FileStream(strPath, FileMode.Open))
            {
                buffSrc = new byte[fs.Length];
                fs.Read(buffSrc, 0, (int)fs.Length);
            }
            m_cMap = new Map();
            m_cMap.LoadMapFile(buffSrc);

            m_nCellSize = m_cMap.cellSize;
            m_nRowCount = m_cMap.rowCount;
            m_nColumnCount = m_cMap.columnCount;
            m_sMapCenter = m_cMap.centerPos;
        }
        UpdateMesh();
    }

    private void SaveMap()
    {
        if (null != m_cMap)
        {
            string defaultName = UnityEngine.SceneManagement.SceneManager.GetActiveScene().name + "_AStarData";
            string defaultDictionary = Application.dataPath + "/ResourcesEx/Config/MapConfig/";
            string path = EditorUtility.SaveFilePanel("保存地图数据", defaultDictionary, defaultName, "txt");
            if (!string.IsNullOrEmpty(path))
            {
                m_cMap.cellSize = m_nCellSize;
                m_cMap.rowCount = m_nRowCount;
                m_cMap.columnCount = m_nColumnCount;
                m_cMap.centerPos = m_sMapCenter;

                m_objEditor.SetActive(false);
                m_cMap.mLstRevivePoint.Clear();
                for (int i = 0; i < m_lstRevivePointGO.Count; i++)
                {
                    MapRevivePoint revivePoint = new MapRevivePoint();
                    revivePoint.x = Mathf.CeilToInt(m_lstRevivePointGO[i].transform.position.x * 1000);
                    revivePoint.z = Mathf.CeilToInt(m_lstRevivePointGO[i].transform.position.z * 1000);
                    m_cMap.mLstRevivePoint.Add(revivePoint);
                }
                for (int i = 0; i != m_nRowCount; ++i)
                {
                    for (int j = 0; j != m_nColumnCount; ++j)
                    {
                        Cell cCell = m_cMap.mCellsArry[i, j];
                        Vector3 sOrg = cCell.centerPos.ToUnity();
                        sOrg.y += 100.0f;
                        RaycastHit cHitInfo;
                        if (Physics.Raycast(sOrg, Vector3.down, out cHitInfo,float.MaxValue,CLayerDefine.GroundMask))
                        {
                            m_cMap.mCellsArry[i, j].centerPos.y = (int)(1000 * cHitInfo.point.y);
                        }
                    }
                }
                m_objEditor.SetActive(true);

                m_cMap.SaveMapToFile(path);
                AssetDatabase.Refresh();
                Debug.Log("保存成功！");
            }
        }
        else
        {
            EditorUtility.DisplayDialog("提示", "缺少地图数据", "确定");
        }
    }

    private void OnSceneGUI(SceneView sceneView)
    {
        if (null == m_cMap)
        {
            return;
        }
        var e = UnityEngine.Event.current;
        if (e.type == EventType.keyDown && e.keyCode > KeyCode.Alpha0 && e.keyCode <= KeyCode.Alpha9)
        {
            m_nPaintSize = e.keyCode - KeyCode.Alpha0;
        }
        if (e.type == EventType.keyDown && (e.keyCode == KeyCode.LeftControl || e.keyCode == KeyCode.Space))
        {
            Ray ray = HandleUtility.GUIPointToWorldRay(e.mousePosition);
            RaycastHit hitInfo;
            if (Physics.Raycast(ray, out hitInfo, int.MaxValue, CLayerDefine.EditorMask))
            {
                Vector3 pos = hitInfo.point;
                float fCellSize = m_nCellSize / 1000.0f;
                Vector2 cur = new Vector2(pos.x + fCellSize * m_nPaintSize / 2, pos.z - fCellSize * m_nPaintSize / 2);
                float lenX = m_cMap.width / 1000f;
                float lenZ = m_cMap.height / 1000f;
                int nStartZ = m_sMapCenter.y + (m_nRowCount * m_nCellSize / 2 - m_nCellSize / 2);
                int nStartX = m_sMapCenter.x + (-m_nColumnCount * m_nCellSize / 2 + m_nCellSize / 2);
                bool bNeedUpdate = false;
                for (int i = 0; i != m_nPaintSize; ++i)
                {
                    cur.y = pos.z - fCellSize * m_nPaintSize / 2;
                    for (int j = 0; j != m_nPaintSize; ++j)
                    {
                        Vector2 offset = new Vector2(cur.x - nStartX / 1000f, nStartZ / 1000f - cur.y);
                        if (offset.x >= 0 && offset.x < lenX && offset.y >= 0 && offset.y < lenZ)
                        {
                            int xIndex = Mathf.FloorToInt(offset.y * 1000 / m_nCellSize);
                            int zIndex = Mathf.FloorToInt(offset.x * 1000 / m_nCellSize);
                            var cell = m_cMap.mCellsArry[xIndex, zIndex];
                            bool isPaint = IsPaint(m_nEditorIndex, cell);
                            if (e.keyCode == KeyCode.Space)
                            {
                                if (!isPaint)
                                {
                                    switch (m_nEditorIndex)
                                    {
                                        case 0:
                                            cell.mFlagValue = 1;
                                            break;
                                        case 1:
                                            cell.mGrassId = 1;
                                            break;
                                        case 2:
                                            if(null != m_cAreaEditor)
                                            {
                                                m_cAreaEditor.PaintCurrent(cell);
                                            }
                                            break;
                                    }
                                    bNeedUpdate = true;
                                }
                            }
                            else
                            {
                                if (isPaint)
                                {
                                    switch (m_nEditorIndex)
                                    {
                                        case 0:
                                            cell.mFlagValue = 0;
                                            break;
                                        case 1:
                                            cell.mGrassId = 0;
                                            break;
                                        case 2:
                                            if (null != m_cAreaEditor)
                                            {
                                                m_cAreaEditor.ClearCurrentPaint(cell);
                                            }
                                            break;
                                    }
                                    bNeedUpdate = true;
                                }
                            }
                        }
                        cur.y += fCellSize;
                    }
                    cur.x -= fCellSize;
                }
                if (bNeedUpdate)
                {
                    UpdateMesh();
                }
            }
        }
    }

    private bool IsPaint(int editorIndex,Cell cCell)
    {
        switch (editorIndex)
        {
            case 0:
                return cCell.mFlagValue != 0;
            case 1:
                return cCell.mGrassId != 0;
            case 2:
                if(null != m_cAreaEditor)
                {
                    return m_cAreaEditor.IsCurrentPaint(cCell);
                }
                break;
        }
        return false;
    }

    private static Color BLUE = new Color(0.0f, 0.0f, 1.0f, 0.5f);
    private static Color RED = new Color(0.5f, 0.0f, 0.0f, 0.5f);
    private static Color Green = new Color(0.0f, 0.8f, 0.0f, 0.5f);
    private static Color NoneColor = new Color(0,0,0,0);
    private Color GetCellColor(Cell cCell)
    {
        switch (m_nEditorIndex)
        {
            case 0:
                switch (cCell.mFlagValue)
                {
                    case 0:
                        return BLUE;

                    case (byte)ObstacleType.StaticObstacle:
                        return RED;

                    case (byte)ObstacleType.DynamicObstacleUnit:
                        return Color.yellow;

                    case (byte)ObstacleType.DynamicObstacleSide:
                        return Color.gray;
                }
                return Color.white;
            case 1:
                if (0 != cCell.mGrassId)
                {
                    return Green;
                }
                break;
            case 2:
                if(null != m_cAreaEditor)
                {
                    return m_cAreaEditor.GetCellColor(cCell);
                }
                break;
        }
        return NoneColor;
    }

    public void UpdateMesh()
    {
        if (null == m_cMap)
        {
            return;
        }
        int originZ = m_sMapCenter.y + m_nRowCount * m_nCellSize / 2;
        int originX = m_sMapCenter.x - m_nColumnCount * m_nCellSize / 2;
        int originY = 100;

        float fUnitLen = m_nCellSize / 1000f;
        float fOriginX = originX / 1000f;
        float fOriginZ = originZ / 1000f;
        float fOriginY = originY / 1000f;
        int xLen = m_cMap.mCellsArry.GetLength(0);
        int zLen = m_cMap.mCellsArry.GetLength(1);
        List<Vector3> listVertice = new List<Vector3>();
        List<Color> listColor = new List<Color>();
        List<int> listTriangle = new List<int>();
        int curChildIndex = 0;
        for (int x = 0; x < xLen; x++)
        {
            for (int z = 0; z < zLen; z++)
            {
                Vector3 t1, t2, t3, t4;
                t4 = new Vector3(fOriginX + z * fUnitLen, fOriginY, fOriginZ - x * fUnitLen);
                t3 = new Vector3(fOriginX + (z + 1) * fUnitLen, fOriginY, fOriginZ - x * fUnitLen);
                t2 = new Vector3(fOriginX + (z + 1) * fUnitLen, fOriginY, fOriginZ - (x + 1) * fUnitLen);
                t1 = new Vector3(fOriginX + z * fUnitLen, fOriginY, fOriginZ - (x + 1) * fUnitLen);

                listVertice.Add(t1);
                listVertice.Add(t2);
                listVertice.Add(t3);
                listVertice.Add(t4);
                listTriangle.Add(listVertice.Count - 2);
                listTriangle.Add(listVertice.Count - 3);
                listTriangle.Add(listVertice.Count - 4);

                listTriangle.Add(listVertice.Count - 4);
                listTriangle.Add(listVertice.Count - 1);
                listTriangle.Add(listVertice.Count - 2);

                Color c = GetCellColor(m_cMap.mCellsArry[x, z]);
                listColor.Add(c);
                listColor.Add(c);
                listColor.Add(c);
                listColor.Add(c);

                if (listVertice.Count >= 40000)
                {
                    Vector3[] tempVertices = listVertice.ToArray();
                    int[] tempTriangles = listTriangle.ToArray();
                    Color[] tempColors = listColor.ToArray();
                    UpdateChildMesh(m_objEditor.transform, curChildIndex, tempVertices, tempTriangles, tempColors);
                    listVertice.Clear();
                    listTriangle.Clear();
                    listColor.Clear();
                    curChildIndex++;
                }
            }
        }
        Vector3[] vertices = listVertice.ToArray();
        int[] triangles = listTriangle.ToArray();
        Color[] colors = listColor.ToArray();
        UpdateChildMesh(m_objEditor.transform, curChildIndex, vertices, triangles, colors);
    }

    private void UpdateChildMesh(Transform parent, int childIndex, Vector3[] vertices, int[] triangles, Color[] colors)
    {
        if (childIndex >= parent.childCount)
        {
            int count = childIndex - parent.childCount + 1;
            for (int i = 0; i < count; i++)
            {
                GameObject go = new GameObject();
                go.name = childIndex.ToString();
                go.layer = CLayerDefine.Editor;
                go.transform.parent = parent;
                go.transform.SetAsLastSibling();
            }
        }
        GameObject child = parent.GetChild(childIndex).gameObject;

        MeshFilter filter = child.GetComponent<MeshFilter>();
        if (filter == null) filter = child.AddComponent<MeshFilter>();
        if (filter.sharedMesh == null) filter.sharedMesh = new Mesh();

        MeshRenderer renderer = child.GetComponent<MeshRenderer>();
        if (renderer == null)
        {
            renderer = child.AddComponent<MeshRenderer>();
            Material material = new Material(Shader.Find("Unlit/EditorColor"));
            renderer.material = material;
        }
        MeshCollider collider = child.GetComponent<MeshCollider>();
        if (collider == null)
        {
            collider = child.AddComponent<MeshCollider>();
            collider.sharedMesh = filter.sharedMesh;
        }

        Mesh mesh = filter.sharedMesh;
        mesh.vertices = vertices;
        mesh.triangles = triangles;
        mesh.colors = colors;
        collider.sharedMesh = mesh;
    }
}
