﻿using System.Collections;
using System.Collections.Generic;
using UnityEditor;
using UnityEngine;

[CustomEditor(typeof(CommonPageView))]
public class CommonPageViewEditor : Editor
{
    public override void OnInspectorGUI()
    {
        CommonPageView controller = (CommonPageView)target;

        EditorGUILayout.LabelField("通用翻页组件属性 : ");
        controller.triggerValue = EditorGUILayout.IntField("翻页阀值 : ", controller.triggerValue);
        //controller.pageType = (CommonPageView.PageType)EditorGUILayout.EnumPopup("Index计算处理方式 (默认 or 自定义) : ", controller.pageType);
        //if (controller.pageType == CommonPageView.PageType.Custom)
        //{
        //    controller._minIndex = EditorGUILayout.IntField("最小Index : ", controller._minIndex);
        //    controller._maxIndex = EditorGUILayout.IntField("最大Index : ", controller._maxIndex);
        //}


        EditorGUILayout.LabelField("---------------------------------------------------");
        EditorGUILayout.Space();
        EditorGUILayout.LabelField("Unity Scroll Rect 属性 : ");
        base.OnInspectorGUI();
    }
}
