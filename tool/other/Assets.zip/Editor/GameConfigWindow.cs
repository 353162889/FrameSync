﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEditor;
using System;

public class GameConfigWindow : EditorWindow {
    [MenuItem("Tools/GameConfig")]
    static void ShowWindow()
    {
        var window = EditorWindow.GetWindow<GameConfigWindow>();
        window.Show();
    }

    private GameConfig m_cGameConfig;
    private string[] m_arrServerIp = new string[] {
        "192.168.18.20",
        "192.168.19.89",
        "120.77.232.234",
        "47.74.237.24",
        "192.168.237.128"
    };
    private string[] m_arrServerResUrl = new string[] {
        "192.168.18.20",
        "192.168.19.89",
        "cdn.resource.imbaworld.com",
        "47.74.237.24",
        "192.168.237.128"
    };
    private string[] m_arrServerIpDesc = new string[] {
        "内网服务器",
        "龚平的服务器",
        "外网服务器",
        "海外服务器",
        "测试服务器"
    };

    private int m_nServerIndex;
    private int m_nMajorVersion;
    private int m_nMinorVersion;

    void OnEnable()
    {
        TextAsset asset = AssetDatabase.LoadAssetAtPath<TextAsset>("Assets/Resources/GameConfig/GameConfig.xml");
        if (asset == null) return;
        m_cGameConfig = (GameConfig)CUility.DeSerializerObjectFromBuff(asset.bytes, typeof(GameConfig));
        m_nServerIndex = Array.IndexOf(m_arrServerIp, m_cGameConfig.mLoginSvrUrl);
        if (m_nServerIndex < 0) m_nServerIndex = 0;
        m_nMajorVersion = m_cGameConfig.mMajorVersion;
        m_nMinorVersion = m_cGameConfig.mMinorVersion;
    }

    void OnDisable()
    {
        m_cGameConfig = null;
    }

    void OnGUI()
    {
        if (m_cGameConfig == null) return;
        EditorGUILayout.BeginHorizontal();
        int oldIndex = m_nServerIndex;
        m_nServerIndex = EditorGUILayout.Popup("登录服务器地址",m_nServerIndex, m_arrServerIpDesc,GUILayout.Width(300));
        EditorGUILayout.LabelField(m_arrServerIp[m_nServerIndex]);
        EditorGUILayout.EndHorizontal();

        EditorGUILayout.BeginHorizontal();
        int oldMajorVersion = m_nMajorVersion;
        m_nMajorVersion = EditorGUILayout.IntField("MajorVersion", m_nMajorVersion);
        EditorGUILayout.EndHorizontal();

        EditorGUILayout.BeginHorizontal();
        int oldMinorVersion = m_nMinorVersion;
        m_nMinorVersion = EditorGUILayout.IntField("MinorVersion", m_nMinorVersion);
        EditorGUILayout.EndHorizontal();

        if (oldIndex != m_nServerIndex || oldMajorVersion != m_nMajorVersion || oldMinorVersion != m_nMinorVersion)
        {
            m_cGameConfig.mLoginSvrUrl = m_arrServerIp[m_nServerIndex];
            m_cGameConfig.mResSvrUrl = m_arrServerResUrl[m_nServerIndex];
            m_cGameConfig.mMajorVersion = m_nMajorVersion;
            m_cGameConfig.mMinorVersion = m_nMinorVersion;
            CUility.SerializerObject(Application.dataPath + "/Resources/GameConfig/GameConfig.xml", m_cGameConfig);
            AssetDatabase.Refresh();
        }
    }
}
