﻿using System.IO;
using UnityEditor;
using UnityEngine;

/// <summary>
/// 导入UI资源 自动设置默认属性
/// </summary>
public class ImportUIAutoSetting : AssetPostprocessor
{
    void OnPreprocessTexture()
    {
        if (EditorConst.IsAtlasFolder(assetPath) == true)
        {
            TextureImporter textureImporter = (TextureImporter)assetImporter;
            
            string dirName = Path.GetDirectoryName(assetPath);
            string folderStr = Path.GetFileName(dirName);

            //自动设置
            textureImporter.textureType = TextureImporterType.Sprite;
            textureImporter.spriteImportMode = SpriteImportMode.Single;
            textureImporter.mipmapEnabled = false;
            textureImporter.alphaIsTransparency = true;
            textureImporter.anisoLevel = 1;

            textureImporter.wrapModeU = TextureWrapMode.Clamp;
            textureImporter.wrapModeV = TextureWrapMode.Repeat;

            textureImporter.filterMode = FilterMode.Bilinear;

            if (EditorConst.IsSizeOver256(assetPath) == false)
            {
                textureImporter.spritePackingTag = folderStr;
            }

        }

    }
}
