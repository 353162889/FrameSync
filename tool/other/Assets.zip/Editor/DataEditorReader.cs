﻿using ProtoBuf;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using UnityEditor;
using UnityEngine;

//editor下配置数据读取，使用前调用Clear,不使用时请调用Clear(如果不调用，会导致重新导入的数据获取不到最新的)
public sealed class DataEditorReader<T>
where T : class, new()
{
    #region 变量

    private static List<T> m_dataList;
    public static List<T> DataList
    {
        get
        {
            Init();
            return m_dataList;
        }
    }

    private static Dictionary<int, T> m_intDataMap = new Dictionary<int, T>();
    private static Dictionary<string, T> m_strDataMap = new Dictionary<string, T>();

    #endregion

    #region INIT

    /// <summary>
    /// 初始化加载指定配置表
    /// </summary>
    public static void Init()
    {
        if (m_dataList != null)
            return;//表示已经初始化, 直接返回

        var data = LoadData();
        if (data != null)
        {
            InitData(data);
            UnloadAsset();
        }
    }

    public static void Clear()
    {
        m_dataList = null;
        m_intDataMap.Clear();
        m_strDataMap.Clear();
    }

    private static string GetFileName()
    {
        var dataType = typeof(T);
        var arr = dataType.ToString().Split('.');
        var fileName = arr[arr.Length - 1];
        return fileName;
    }

    private static string GetFilePath(string fileName)
    {
        return string.Format("Assets/ResourcesEx/Table/cc_{0}.bytes", fileName);
    }

    public static byte[] LoadData()
    {
        if (m_dataList != null)
            return null;//表示已经初始化, 直接返回

        var fileName = GetFileName();

        var data = AssetDatabase.LoadAssetAtPath<TextAsset>(GetFilePath(fileName));
        if (data == null)
        {
            Debug.LogError("加载 " + fileName + " 失败");
        }

        return data.bytes;
    }

    public static void UnloadAsset()
    {
        //================Unload====================
        //==========================================
    }

    public static void InitData(byte[] data)
    {
        Type dataType = typeof(T);
        string fileName = GetFileName();

        if (data == null)
        {
            Debug.LogError("加载 " + fileName + " 失败");
            return;
        }
        try
        {
            using (MemoryStream memoryStream = new MemoryStream(data))
            {
                //需要消耗1.5MB的GC和90ms的开销
                m_dataList = Serializer.Deserialize<List<T>>(memoryStream);
            }
        }
        catch (ProtoException ex)
        {
            Debug.LogError("表格数据解析错误 " + fileName + ": " + ex);
            return;
        }

        PropertyInfo keyProp = dataType.GetProperties(BindingFlags.Instance | BindingFlags.Public)[0];
        if (keyProp.PropertyType == typeof(Int32) ||
            keyProp.PropertyType == typeof(UInt32) ||
            keyProp.PropertyType == typeof(String))
        {
            for (int i = 0; i < m_dataList.Count; ++i)
            {
                if (keyProp.PropertyType == typeof(Int32) ||
                    keyProp.PropertyType == typeof(UInt32))
                {
                    int dataKey = Convert.ToInt32(keyProp.GetValue(m_dataList[i], null));

                    if (!m_intDataMap.ContainsKey(dataKey))
                        m_intDataMap.Add(dataKey, m_dataList[i]);
                }
                else if (keyProp.PropertyType == typeof(String))
                {
                    string dataKey = Convert.ToString(keyProp.GetValue(m_dataList[i], null));
                    if (!m_strDataMap.ContainsKey(dataKey))
                        m_strDataMap.Add(dataKey, m_dataList[i]);
                }
            }
        }
    }

    #endregion

    #region Get

    public static T Get(int key)
    {
        Init();

        if (m_intDataMap.ContainsKey(key))
            return m_intDataMap[key];

        Debug.LogError("此表  " + typeof(T) + " 没有包含为  key  " + key + "  对应的数据");
        return null;
    }

    public static T Get(string key)
    {
        Init();

        if (m_strDataMap.ContainsKey(key))
            return m_strDataMap[key];

        Debug.LogError("此表  " + typeof(T) + " 没有包含为  key  " + key + "  对应的数据");
        return null;
    }

    #endregion

    #region Contains

    public static bool Contains(int key)
    {
        Init();
        return m_intDataMap.ContainsKey(key);
    }

    public static bool Contains(string key)
    {
        Init();
        return m_strDataMap.ContainsKey(key);
    }

    #endregion
}
