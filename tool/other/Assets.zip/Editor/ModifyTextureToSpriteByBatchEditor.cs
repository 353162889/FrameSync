﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using UnityEditor;
using UnityEngine;

namespace Assets.Editor
{
    public class ModifyTextureToSpriteByBatchEditor
    {
        [MenuItem("Tools/批量操作/修改贴图属性")]
        public static void ModifyTextureToSprite()
        {
            EditorWindow.GetWindow<ModifyTextureToSpriteWindow>().Show();
        }
    }

    public class ModifyTextureToSpriteWindow : EditorWindow
    {
        private string _atlasName = "atlasName";
        private string _abName = "";

        private void OnEnable()
        {
            EditorGUILayout.TextField("图集名字:", _atlasName);
            EditorGUILayout.TextField("ab资源的名字:", _abName);
        }

        private void OnGUI()
        {
            _atlasName = EditorGUILayout.TextField("图集名字:", _atlasName);
            _abName = EditorGUILayout.TextField("ab资源的名字:", _abName);
            var folderPath = AssetDatabase.GetAssetPath(Selection.activeObject);
            if ((File.GetAttributes(folderPath) & FileAttributes.Directory) != FileAttributes.Directory)
            {
                GUILayout.Label("请选择一个贴图文件夹");
                return;
            }

            if (GUILayout.Button("确定"))
            {
                var directories = new Stack<string>();
                directories.Push(folderPath);
                while (directories.Count != 0)
                {
                    var d = directories.Pop();
                    var subDir = Directory.GetDirectories(d);
                    foreach (var dir in subDir)
                    {
                        directories.Push(dir);
                    }
                    var allFiles = Directory.GetFiles(d);
                    modify(AssetImporter.GetAtPath(d) as TextureImporter);
                    foreach (var file in allFiles)
                    {
                        modify(AssetImporter.GetAtPath(file) as TextureImporter);
                    }
                }
            }
        }

        private void modify(TextureImporter item)
        {
            if (item != null)
            {
                item.textureType = TextureImporterType.Sprite;
                item.spriteImportMode = SpriteImportMode.Single;
                item.spritePackingTag = _atlasName;
                if (!string.IsNullOrEmpty(_abName))
                {
                    item.assetBundleName = _abName;
                }
            }
        }
    }
}
