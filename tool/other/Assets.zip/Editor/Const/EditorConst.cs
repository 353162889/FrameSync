﻿
using System.IO;
using UnityEditor;
using UnityEngine;

public static class EditorConst
{
    public static string[] atlasPathArr = new string[] { "/ResourcesEx/UI", "/ResourcesEx/Icon" };
    /// <summary>
    /// 资源是否在图集文件夹
    /// </summary>
    /// <param name="assetPath"></param>
    /// <returns></returns>
    public static bool IsAtlasFolder(string assetPath)
    {
        bool isAtlas = false;
        foreach (string path in atlasPathArr)
        {
            if (assetPath.Contains(path) == true)
            {
                isAtlas = true;
                break;
            }
        }
        return isAtlas;
    }

    static string[] picType = new string[] { "png", "jpg" };
    /// <summary>
    /// 判断是否为图片资源
    /// </summary>
    /// <param name="assetPath"></param>
    /// <returns></returns>
    public static bool IsPicAsset(string assetPath)
    {
        bool isPic = false;
        foreach (string type in picType)
        {
            if (assetPath.EndsWith(type) == true)
            {
                isPic = true;
                break;
            }
        }
        return isPic;
    }

    /// <summary>
    /// 检测UI资源 尺寸是否超过256
    /// </summary>
    /// <param name="assetPath"></param>
    /// <returns></returns>
    public static bool IsSizeOver256(string assetPath)
    {
        bool isOver = false;
        TextureImporter ti = AssetImporter.GetAtPath(assetPath) as TextureImporter;
        Texture2D texture = new Texture2D(1, 1);
        FileStream fs = new FileStream(ti.assetPath, FileMode.Open, FileAccess.Read);
        byte[] thebytes = new byte[fs.Length];
        fs.Read(thebytes, 0, (int)fs.Length);
        texture.LoadImage(thebytes);

        if (texture.width > 256 || texture.height > 256)
        {
            isOver = true;
        }

        return isOver;
    }

}
