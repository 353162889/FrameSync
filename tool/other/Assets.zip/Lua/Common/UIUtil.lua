﻿--From Lua Script Create
--ClassName: UIUtil
--Author:    hukiry
--CreateTime:2018-7-27

UIUtil = class(UIUtil)

--设置Image的sprite
function UIUtil.SetSpriteByPath(image, path, isNotNativeSize)
	if not image or not path then
		return
	end

	image.sprite = CResourceSys.instance:Load(EResType.EIcon, path)
	if not isNotNativeSize then
		image:SetNativeSize()
	end
end
