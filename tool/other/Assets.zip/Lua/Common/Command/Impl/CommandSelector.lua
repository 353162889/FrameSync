require "Common/Command/CommandContainerBase"
--选择执行器
CommandSelector = class("CommandSelector",CommandContainerBase)
function CommandSelector:ctor()
	CommandSelector.super.ctor(self);
end

function CommandSelector:AddCondition(select,success,fail)
	self.select = select
	self.success = success
	self.fail = fail
	self.executeChild = nil;
	self.select.parent = self
	if(self.success ~= nil) then
		self.success.parent = self
	end
	if(self.fail ~= nil) then
		self.fail.parent = self
	end
end

function CommandSelector:OnChildDone(cmd)
	if(cmd == self.select) then
		if(self.select.state == CmdExecuteState.Success) then
			if(self.success ~= nil) then
				self.executeChild = self.success;
				self.success:Execute(self.context)
			else
				self:OnExecuteDone(CmdExecuteState.Success)
			end
		else
			if(self.fail ~= nil) then
				self.executeChild = self.fail;
				self.fail:Execute(self.context)
			else
				self:OnExecuteDone(CmdExecuteState.Success)
			end
		end
	else
		self.executeChild = nil;
		CommandSelector.super.OnExecuteDone(self,cmd.state)
	end
end

function CommandSelector:Execute(context)
	CommandSelector.super.Execute(self,context)
	self.executeChild = self.select;
	self.select:Execute(self.context)
end

function CommandSelector:OnUpdate(deltaTime)
	CommandSelector.super.OnUpdate(self,deltaTime);
	if(self.executeChild ~= nil) then
		self.executeChild:OnUpdate(deltaTime);
	end
end


function CommandSelector:OnDestroy()
	CommandSelector.super.OnDestroy(self)
	if(self.success ~= nil) then
		self:OnChildDestroy(self.success)
	end
	if(self.fail ~= nil) then
		self:OnChildDestroy(self.fail)
	end
end