require "Common/Command/Impl/CommandSequence"

CommandDynamicSequence = class("CommandDynamicSequence",CommandSequence)

function CommandDynamicSequence:ctor(...)
	CommandDynamicSequence.super.ctor(self,...);
	self.children = {}
	self.executeChild = nil
	local autoDestroy = select(1,...)
	self.autoDestroy = true
	if(autoDestroy ~= nil) then
		self.autoDestroy = autoDestroy
	end
end

--添加子命令
function CommandDynamicSequence:AddSubCommand(cmd)
	CommandDynamicSequence.super.AddSubCommand(self,cmd)
	self:Execute()
end

--执行
function CommandDynamicSequence:Execute(context)
	if(not self:IsExecuting()) then
		CommandDynamicSequence.super.Execute(self,context)
	end
end

function CommandDynamicSequence:OnExecuteDone(state)
	self.state = state
	self:OnExecuteFinish()
	self:OnDoneInvoke()
	if(self.parent ~= nil) then
		self.parent:OnChildDone(self)
	elseif(self.autoDestroy) then
		self:OnDestroy()
	end
end

