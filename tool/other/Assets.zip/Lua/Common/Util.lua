Util = {}

function Util.Log( ... )
	CUility.Log(Util.GetStr(...));
end

function Util.LogError( ... )
	CUility.LogError(Util.GetStr(...));
end

function Util.LogColor(color, ... )
	CUility.LogColor(Util.GetStr(...),color)
end

function Util.GetStr( ... )
	local t = {...}
	local count = 0;
	for k,v in pairs(t) do
		count = count + 1;
	end
	local str = "";
	for i=1,count do
		str = str .. tostring(t[i]);
		if(i ~= count) then
			str = str .. ",";
		end
	end
	return str;
end

function Util.Split( str,reps )
    local resultStrList = {}
    string.gsub(str,'[^'..reps..']+',function ( w )
        table.insert(resultStrList,w)
    end)
    return resultStrList
end

function table.contains(table, element)
  for key, value in pairs(table) do
    if value == element then
      return true
    end
  end
  return false
end 

function Util.Trim(s) 
	return (string.gsub(s, "^%s*(.-)%s*$", "%1"))
end
