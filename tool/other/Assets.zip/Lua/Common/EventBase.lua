EventBase = class("EventBase", { event = EventDispatcher() });

function EventBase:AddEvent(id, handler, priorty)
    if nil == priorty then
        priorty = 1;
    end
    self.event:AddEvent(id, handler, priorty);
end

function EventBase:RemoveEvent(id, handler)
    self.event:RemoveEvent(id, handler);
end

function EventBase:DispatchByParam(id, ...)
    self.event:DispatchByParam(id, ...);
end

function EventBase:Dispatch(id, args)
    self.event:Dispatch(id, args);
end

function EventBase:HasEvent(id, handler)
    return self.event:HasEvent(id, handler);
end


function CustomEvent(table)
	local t = table;
	if nil == t then t = {} end
	t.event = EventDispatcher();

	t.AddEvent = function (id,handler,priorty)
		if nil == priorty then
	        priorty = 1;
	    end
	    t.event:AddEvent(id, handler, priorty);
	end

	t.RemoveEvent = function (id,handler)
		t.event:RemoveEvent(id,handler);
	end

	t.DispatchByParam = function (id,...)
		t.event:DispatchByParam(id,...);
	end

	t.Dispatch = function (id,args)
		t.event:Dispatch(id,args);
	end

	t.HasEvent = function (id,handler)
		return t.event:HasEvent(id,handler);
	end
	return t;
end