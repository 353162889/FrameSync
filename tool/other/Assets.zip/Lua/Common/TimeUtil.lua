﻿
--时间转化工具类
TimeUtil = class(TimeUtil)

--转化时间格式
--time 单位:毫秒
function TimeUtil.TranslateTimeFormat(time)
	local originalSecond = time / 1000
	local min = math.floor(originalSecond / 60);
	local second = math.ceil(originalSecond % 60);

	if second < 10 then
		second = "0"..second
	end
	
	return min,second
end
