function ViewInitEnd(viewName, obj)
	local viewPaths = ViewDefine[viewName];
	if nil == viewPaths then
		Util.Log("viewName="..viewName.." in ViewDefine cannot config!")
	    return;
	end

	for i, path in ipairs(viewPaths) do
		require(path);
	end
	
	local view = _G[viewName];
	print("Init",view,viewName);

	if nil ~= view then
	    view:InitView(obj);
	end
end

function ViewOpenEnd(viewName, obj)
	local viewPaths = ViewDefine[viewName];
	if nil == viewPaths then
	    return;
	end
	local view = _G[viewName];
	print("Open",view,viewName);

	if nil ~= view and nil ~= view.OpenView then
	    view:OpenView(obj);
	end
end

function ViewCloseEnd(viewName)
	local viewPaths = ViewDefine[viewName];
	if nil == viewPaths then
	    return;
	end
	local view = _G[viewName];
	print("Close",view,viewName);

	if nil ~= view and nil ~= view.CloseView then
	    view:CloseView();
	end
end

function ViewDestroyEnd(viewName)
	local viewPaths = ViewDefine[viewName];
	if nil == viewPaths then
	    return;
	end
	local view = _G[viewName];
	print("Destroy",view,viewName);

	if nil ~= view and nil ~= view.DestroyView then
	    view:DestroyView();
	end
end

--通过制定字符切割字符串
function split( str,reps )
    local resultStrList = {}
    string.gsub(str,'[^'..reps..']+',function ( w )
        table.insert(resultStrList,w)
    end)
    return resultStrList
end

function IsNil(uobj)
    return uobj == nil or uobj:Equals(nil)
end