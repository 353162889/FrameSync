--管理整个背包的逻辑
BagMgr = CustomEvent();

local this = BagMgr;

--初始化
function this.Init()
	BagModel.Init();
	BagType.InitMapTable();
end

function this.UpdateBagSize(bagType,size)
	BagModel.UpdateBagSize(bagType,size);
end

--初始化时使用
function this.AddItem(bagType,serverInfo)
	return BagModel.AddMO(bagType,serverInfo);
end

function this.UpdateItem(bagType,serverInfo)
	local mo = BagModel.UpdateMO(bagType,serverInfo)
	EventSys.instance:DispatchLua(GameEvent.OnBagUpdate,mo:GetID());
	return mo;
end

function this.UpdateBagSize(bagType,size)
	BagModel.UpdateBagSize(bagType,size);
end

--初始化时使用
function this.AddMO(bagType,serverInfo)
	return BagModel.AddMO(bagType,serverInfo);
end

function this.UpdateMO(bagType,serverInfo)
	return BagModel.UpdateMO(bagType,serverInfo);
end

--获取背包
function this.GetBag(bagType)
	return BagModel.GetBag(bagType);
end
--根据系统id获取物品
function this.GetItemBySystemId(systemId)
	return BagModel.GetItemBySystemId(systemId);
end
--更具配置id获取物品列表
function this.GetItemByConfigId(configId)
	return BagModel.GetItemByConfigId(configId);
end
