--单个背包的数据
BagMO = class("BagMO")

function BagMO:ctor(bagType)
	self.dicItem = {};
	self.bagSize = 0;
	self.bagType = bagType;
end
--设置背包大小
function BagMO:SetBagSize(bagSize)
	-- body
	self.bagSize = bagSize;
end
--添加物品
function BagMO:AddItemMO(mo)
	local systemId = mo:GetID();
	if self.dicItem[systemId] == nil then
		self.dicItem[systemId] = mo;
	else
		Util.LogError("已存在id为"..systemId.."的物品数据");
	end
	return mo;
end
--移除物品
function BagMO:RemoveItemMO(systemId)
	local mo = self.dicItem[systemId];
	self.dicItem[systemId] = nil;
	return mo;
end
--更新物品信息
function BagMO:UpdateItemMOByServerInfo( serverInfo )
	local systemId = serverInfo.system_id;	--获取系统物品id
	local count = serverInfo.count;		--获取系统物品数量
	local mo = nil;
	if count > 0 then
		if nil == self.dicItem[systemId] then
			local newMO = BagType.MapMO[self.bagType].new();
			newMO:Init(serverInfo,self.bagType);
			mo = self:AddItemMO(newMO);
		else
			mo = self.dicItem[systemId];
			mo:Update(serverInfo);
		end
	else
		mo = self:RemoveItemMO(systemId);
	end
	return mo;
end
--获取物品
function BagMO:GetItemMOBySystemId(systemId)
	return self.dicItem[systemId];
end
--是否有某个物品
function BagMO:HasItemMO(systemId)
	-- body
	return self.dicItem[systemId] ~= nil;
end
--根据配置获取物品列表
function BagMO:GetItemMOByConfigId(configId)
	local result = {};
	for k,v in pairs(self.dicItem) do
		if nil ~= v and v:GetConfigId() == configId then
			table.insert(result,v);
		end
	end
	return result;
end
--获取当前背包所有物品
function BagMO:GetListAll()
	local result = {};
	for k,v in pairs(self.dicItem) do
		if nil ~= v then
			table.insert(result,v);
		end
	end
	return result;
end
--获取当前背包字典
function BagMO:GetDicAll()
	return self.dicItem;
end