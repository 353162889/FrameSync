IconItem = class("IconItem")
IconItemSize = {}
IconItemSize.Big = 104;

function IconItem.Create(parent,size)
	local s = 104;
	if(size ~= nil) then s = size end;
	local prefab = CResourceSys.instance:Load(EResType.EView,"Item/IconItem"..s..".prefab");
	local iconItem = IconItem.new();
	iconItem.go = UnityEngine.GameObject.Instantiate(prefab);
	GameObjectUtil.AddChild(parent,iconItem.go);
	iconItem.icon = iconItem.go.transform:Find("icon"):GetComponent("Image");
	iconItem.icon.sprite = nil;
	iconItem.txt =  iconItem.go.transform:Find("txt"):GetComponent("Text");
	local OnUp = function (go)
		TipMgr.CloseItemTip()
	end
	EventTriggerListener.Get(iconItem.go).onUp = EventTriggerListener.Get(iconItem.go).onUp + OnUp;
	local OnDown = function (go)
		if(iconItem.itemCfg ~= nil) then
			TipMgr.ShowItemTip(iconItem.itemCfg.id,iconItem.go.transform.position)
		end
	end
	EventTriggerListener.Get(iconItem.go).onDown = EventTriggerListener.Get(iconItem.go).onDown + OnDown;
	return iconItem;
end

function IconItem:UpdateByCfg(itemCfg,count)
	self.itemCfg = itemCfg;
	if(self.itemCfg == nil) then return end
	self.icon.sprite = CResourceSys.instance:Load(EResType.EIcon,itemCfg.icon);
	self.txt.text = tostring(count);
end

function IconItem:UpdateByMO(itemMO)
	self:UpdateByCfg(itemMO:GetConfig());
end
--特殊面板使用（不需要做tips的情况下）
function IconItem:UpdateByIcon(icon,count)
	self.icon.sprite = CResourceSys.instance:Load(EResType.EIcon,icon);
	self.txt.text = tostring(count);
end

function IconItem:SetActive(active)
	if(self.go ~= nil) then
		self.go:SetActive(active)
	end
end

function IconItem:Destroy()
	self.itemCfg = nil;
	UnityEngine.GameObject.Destroy(self.go);
	self.go = nil;
end
