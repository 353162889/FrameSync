--基础物品数据
BaseItemMO = class("BaseItemMO")

function BaseItemMO:ctor( ... )
	self.serverInfo = nil;
	self.bagType = nil;
end

function BaseItemMO:Init(serverInfo,bagType)
	self.serverInfo = serverInfo;
	self.bagType = bagType;
	self:GetConfig();
end

function BaseItemMO:Update(serverInfo)
	self.serverInfo = serverInfo;
end

--获取后端分配的id
function BaseItemMO:GetID()
	return self.serverInfo.system_id;
end

--获取当前数量
function BaseItemMO:GetCount()
	return self.serverInfo.count;
end

--获取当前配置id
function BaseItemMO:GetConfigId()
	return self.serverInfo.config_id;
end
--获取到当前放入的背包类型
function BaseItemMO:GetBagType()
	return self.bagType;
end

function BaseItemMO:ToString()
	return "ID:"..self:GetID()..",Count:"..self:GetCount()..",ConfigID:"..self:GetConfigId()..",BagType:"..self:GetBagType();
end


--获取当前配置
function BaseItemMO:GetConfig()
	if nil == self.config then
		local id = self:GetConfigId();
		local bagType = self:GetBagType();
		local dataTable = BagType.MapTable[bagType];
		if nil ~= dataTable then
			self.config = dataTable[id];
			if self.config == nil then
				Util.LogError("找不到背包类型为"..bagType..",id为"..id.."的配置")
			end
		else
			Util.LogError("找不到背包类型为"..bagType.."的配置表")
		end
	end
	return self.config;
end