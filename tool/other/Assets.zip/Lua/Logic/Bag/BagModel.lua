--管理背包的数据
BagModel = {}
local this = BagModel;

function this.Init()
	this.dicBagTypeToBagMO = {};
	this.dicBagTypeToBagMO[BagType.Item] = BagMO.new(BagType.Item);
	this.dicSystemIdToItemMO = {}
end

function this.UpdateBagSize(bagType,size)
	this.dicBagTypeToBagMO[bagType]:SetBagSize(size);
end

--初始化时使用
function this.AddMO(bagType,serverInfo)
	local bagMO = this.dicBagTypeToBagMO[bagType];
	local mo = bagMO:UpdateItemMOByServerInfo(serverInfo);
	if mo ~= nil then
		local systemId = mo:GetID();
		this.dicSystemIdToItemMO[systemId] = mo;
	end
	return mo;
end
--更新物品
function this.UpdateMO(bagType,serverInfo)
	local bagMO = this.dicBagTypeToBagMO[bagType];
	local mo = bagMO:UpdateItemMOByServerInfo(serverInfo);
	local systemId = mo:GetID();
	if not bagMO:HasItemMO(systemId) then
		this.dicSystemIdToItemMO[systemId] = nil;
	else
		this.dicSystemIdToItemMO[systemId] = mo;
	end
	return mo;
end
--获取背包
function this.GetBag(bagType)
	return this.dicBagTypeToBagMO[bagType];
end
--根据系统id获取物品
function this.GetItemBySystemId(systemId)
	return this.dicSystemIdToItemMO[systemId];
end
--更具配置id获取物品列表
function this.GetItemByConfigId(configId)
	local result = {}
	for k,v in pairs(this.dicSystemIdToItemMO) do
		if nil ~= v then
			if v:GetConfigId() == configId then
				table.insert(result,v);
			end
		end
	end
	return result;
end
