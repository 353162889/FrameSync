BagType = {}

BagType.Item = 1;	--物品背包

BagType.MapTable = {}
BagType.MapMO = {}
--背包类型映射配置表
function BagType.InitMapTable()
	BagType.MapTable[BagType.Item] = ItemTable;

	BagType.MapMO[BagType.Item] = ItemMO;
end
