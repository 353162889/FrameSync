MatchMgr = {}

function MatchMgr.Init()
	NetSys.instance:AddMsgCallback(EChannelType.EWorldChannel, S2C_BatterServerAddr, MatchMgr.S2C_BatterServerAddrData, nil); 
    NetSys.instance:AddMsgCallback(EChannelType.EWorldChannel, S2C_MatchCancelResult, MatchMgr.S2C_MatchCancelResultData, nil); 
    NetSys.instance:AddMsgCallback(EChannelType.EWorldChannel, S2C_JoinMatchResult, MatchMgr.S2C_JoinMatchResultData, nil); 

    NetSys.instance:AddMsgCallback(EChannelType.EWorldChannel, S2C_NoCompletedGame, MatchMgr.S2C_NoCompletedGameData, nil); 

    MatchInfo.Clear();
end

function MatchMgr.S2C_NoCompletedGameData(obj, objMsg)
    -- body

    local msg = S2C_NoCompletedGameData(); 
    msg:ParseFromString(objMsg); 
    MatchInfo.Clear();
    Util.LogColor("#ff0000","S2C_NoCompletedGameData",msg.battleHost)
    MatchInfo.hasNoComplateGame = true; 
    MatchInfo.battleServerIP = msg.battleHost; 
    MatchInfo.battleServerTcpPort = msg.battleTcpPort; 
    MatchInfo.battleServerUdpPort = msg.battleUdpPort; 
    MatchInfo.battleAuthCode = msg.authCode; 
    MatchInfo.kcpId = msg.conv; 
    MatchInfo.sessionId = msg.match_type;
    print("重连当前游戏")
end

--开始匹配
function MatchMgr.ReqStartMatch(sessionId,selectHeroId,selectSkinID)--开始匹配
    -- body
    Util.LogColor("#ff0000","sessionId",sessionId,"selectHeroId",selectHeroId,"selectSkinID",selectSkinID)
    local data = C2S_JoinMatchReqData(); 
    data.match_type = sessionId; 
    data.select_hero_id = selectHeroId;
    data.appear_id = selectSkinID;
    NetSys.instance:SendWorldMsg(data:SerializeToString(), C2S_JoinMatchReq); 
end

--取消匹配
function MatchMgr.ReqCancelMatch()--取消匹配
    -- body
    local data = C2S_MatchCancelData(); 
    --print("取消匹配.................")
    NetSys.instance:SendWorldMsg(data:SerializeToString(), C2S_MatchCancel); 
end


function MatchMgr.S2C_BatterServerAddrData(obj, objMsg)--匹配成功结果
    -- body
    print("匹配成功")
    local msg = S2C_BatterServerAddrData(); 
    msg:ParseFromString(objMsg); 
    MatchInfo.Clear();
    MatchInfo.battleServerIP = msg.batterHost; 
    MatchInfo.battleServerTcpPort = msg.battleTcpPort; 
    MatchInfo.battleServerUdpPort = msg.battleUdpPort; 
    MatchInfo.battleAuthCode = msg.authCode; 
    MatchInfo.kcpId = msg.conv; 
    MatchInfo.sessionId = msg.match_type;
    --默认匹配成功
    EventSys.instance:DispatchLua(GameEvent.MatchResult,true);
end

function MatchMgr.S2C_MatchCancelResultData(obj, objMsg)--取消匹配
    print("接收到取消匹配的消息");
    -- body
    local msg = S2C_MatchCancelResultData(); 
    msg:ParseFromString(objMsg); 
    if msg.errorNum == Error_None then
        EventSys.instance:DispatchLua(GameEvent.CancelMatch);
    else
    	Util.LogError("取消匹配失败");
    end
end


function MatchMgr.S2C_JoinMatchResultData(obj, objMsg)--进入匹配
    -- body
    print("接收到进入匹配的消息");
    local msg = S2C_JoinMatchResultData(); 
    msg:ParseFromString(objMsg); 
    if msg.errorNum == Error_None then
        EventSys.instance:DispatchLua(GameEvent.StartMatch);
    elseif(msg.errorNum == Error_MoneyNotEnough) then
        TipMgr.ShowTipType2("进入匹配失败，金钱不足",nil);
    else
        TipMgr.ShowTipType2("进入匹配失败",nil);
    	Util.LogError("进入匹配失败",msg.errorNum);
    end
end