MatchInfo = {}

 MatchInfo.hasNoComplateGame = false;
--战斗服务器的ip
MatchInfo.battleServerIP = ""; 
--战斗服务器的tcp端口
MatchInfo.battleServerTcpPort = 0; 
--战斗服务器的udp端口
MatchInfo.battleServerUdpPort = 0; 
--战斗服务器的验证口令
MatchInfo.battleAuthCode = 0; 
--kcpId
MatchInfo.kcpId = 0; 
--游戏场次ID
MatchInfo.sessionId = 0;

function MatchInfo.Clear()
	MatchInfo.hasNoComplateGame = false;
	MatchInfo.battleServerIP = ""; 
	MatchInfo.battleServerTcpPort = 0; 
	MatchInfo.battleServerUdpPort = 0; 
	MatchInfo.battleAuthCode = 0; 
	MatchInfo.kcpId = 0; 
	MatchInfo.sessionId = 0;
end