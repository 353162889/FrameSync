﻿--From Lua Script Create
--ClassName: MatchingView_3V3
--Author:    hukiry
--CreateTime:2018-8-13

MatchingView_3V3 = {};

local _view;
local TeamItems = {};
local FriendItems = {};
local inviteTime = 10;
local b_friendClick = false;
local b_isMatch = false;

function MatchingView_3V3.Init(view)
	_view=view;
	MatchingView_3V3.RegeditEvent();
	MatchingView_3V3.InitView();
	MatchingView_3V3.CloseView();
	VoiceHelper:Init(_view.objVoice:GetComponent("VoiceCtrlUI"));
end

function MatchingView_3V3.InitView()
	MatchingView_3V3.InitTeamItem(_view.teamItem1,true);
	MatchingView_3V3.InitTeamItem(_view.teamItem2,false);
	MatchingView_3V3.InitTeamItem(_view.teamItem3,false);
	MatchingView_3V3.ToNormalState();
	_view.matchTimeShow:SetActive(false);
	_view.friendItem:SetActive(false);
end

function MatchingView_3V3.InitTeamItem(item,b_self)
	local teamp = {};
	teamp.Obj = item.gameObject;
	teamp.Img = item:Find("HeadBg/ImgHead"):GetComponent("Image");
	teamp.TxtName = item:Find("TxtName"):GetComponent("Text");
	teamp.ReadyObj = item:Find("HeadBg/eff_ui_ready").gameObject
	teamp.Obj:SetActive(false);
	teamp.OnSetHeadIcon = function()
		print("TODO:设置头像");
		
	end
	teamp.SetReady = function(b_isMatch)
		teamp.ReadyObj:SetActive(b_isMatch);
	end
	if(b_self==false)then 
		teamp.btnAdd = item:Find("BtnAddFriend").gameObject;
		teamp.btnAddNormal = item:Find("NoAddFriendIcon").gameObject;
		teamp.Open= function()
			teamp.Obj:SetActive(true);
			teamp.TxtName.text = "";
			teamp.btnAdd:SetActive(true);
		end
		teamp.id = nil;
		teamp.Init = function(data)
			teamp.Open();
			teamp.id = data.user_id;
			local ids = {};
			table.insert(ids,teamp.id);
			FriendManager.QueryUserInfoFromID(ids,
			function(datas)
				for i=1,#datas do
					if(MatchingManager_3V3.TeamListDatas[datas[i].user_id]~=nil)then 
						teamp.TxtName.text = datas[i].user_name;
					end
--[[ 					teamp.TxtName.text = datas[i].user_name; ]]
				end
			end)
			teamp.CheckIsFriend();
		end
		teamp.CheckIsFriend= function()
			local b_isFriend = FriendManager.CheckIsFriend(teamp.id);
			teamp.btnAdd:SetActive(not b_isFriend);
			teamp.btnAddNormal:SetActive(not b_isFriend);
		end
		teamp.OnAddFriendClick = function()
			print("添加好友");
			FriendManager.OnRequestAddFriendInvite(teamp.id)
			teamp.btnAdd:SetActive(false);
		end
		EventButtonListerer.Get(teamp.btnAdd,teamp.OnAddFriendClick);
	else
		teamp.TxtName.text= MainLobbyManager.playerBaseInfo.name;
	end

	table.insert(TeamItems,teamp);
end

function MatchingView_3V3.OpenView()
	_view.matchingPanel:SetActive(true);
	print("MatchingManager_3V3.isReady"..tostring(MatchingManager_3V3.isReady));
	if(MatchingManager_3V3.isBeInVited==false)then
		MatchingManager_3V3.OnRequsetCreatTeam()
	end
	MatchingManager_3V3.isBeInVited = false;
	MatchingView_3V3.OnFriendClick();
	VoiceHelper:Refresh(_view.objVoice:GetComponent("VoiceCtrlUI"));
	EventSys.instance:AddLuaEvent(GameEvent.UpdateFriendData,MatchingView_3V3.UpdateFriendData);
end

function MatchingView_3V3.Update()
	if(b_isMatch and MatchingManager_3V3.isReady)then 
		_view.txtMatchTime.text = LuaHelper.GetSpendTime(-1);
	end
end

function MatchingView_3V3.CloseView()
	_view.matchingPanel:SetActive(false);
	b_friendClick = false;
	EventSys.instance:RemoveLuaEvent(GameEvent.UpdateFriendData,MatchingView_3V3.UpdateFriendData);
end

function MatchingView_3V3.RegeditEvent()
	EventButtonListerer.Get(_view.btnReady, MatchingView_3V3.OnReadyClick)
	EventButtonListerer.Get(_view.btnCancelReady, MatchingView_3V3.OnCancelReadyClick)
	EventButtonListerer.Get(_view.btnFriend_3V3, MatchingView_3V3.OnFriendClick)
	EventButtonListerer.Get(_view.btnLately, MatchingView_3V3.OnLatelyClick)
	EventButtonListerer.Get(_view.btnMatchBack, MatchingView_3V3.OnBackClick)
	EventButtonListerer.Get(_view.btnExitMatching, MatchingView_3V3.OnCancelMatchingClick)
end

function MatchingView_3V3.UpdateFriendData()
	MatchingView_3V3.RefreshFriendItems(FriendManager.ListFriendDatas)
end

function MatchingView_3V3.RefreshTeamInfo(datas)
	TeamItems[1].Obj:SetActive(true);
	TeamItems[2].Obj:SetActive(false);
	TeamItems[3].Obj:SetActive(false);
	local j=2;
	for i=1,#datas do
		if(datas[i].user_id~=LoginInfo.userId)then 
			TeamItems[j].Init(datas[i]);
			TeamItems[j].SetReady(datas[i].statu==2);
			j=j+1;
		else
			TeamItems[1].SetReady(datas[i].statu==2);
			if(datas[i].statu==2)then 
				if(b_isMatch)then 
					MatchingView_3V3.ToReadyState();
				end
			else
				MatchingView_3V3.ToNormalState();
			end
		end
	end
end

function MatchingView_3V3.OnReadyClick()
	print("准备按钮点击");
	if(MatchingManager_3V3.isReady==false)then 
		MatchingManager_3V3.OnRequestTeamSetStatu();
	end
end

function MatchingView_3V3.OnCancelReadyClick()
	print("取消准备按钮点击");
	if(MatchingManager_3V3.isReady==true)then 
		MatchingManager_3V3.OnRequestTeamSetStatu();
	end
end

function MatchingView_3V3.OnFriendClick()
	print("好友按钮点击"..tostring(b_friendClick));
	if(b_friendClick ==false)then
		MatchingView_3V3.ClearFriendItem();
		FriendManager.UpdateFriendListData(function()
			MatchingView_3V3.RefreshFriendItems(FriendManager.ListFriendDatas);
		end);
		b_friendClick = true;
		_view.btnFriendNormal_3V3:SetActive(false);
		_view.btnLatelyNoraml:SetActive(true);
	end
end

function MatchingView_3V3.OnLatelyClick()
	print("最近按钮点击"..tostring(b_friendClick));
	if(b_friendClick)then
		MatchingView_3V3.ClearFriendItem();
		FriendManager.UpdateLatelyFriendList(function()
			MatchingView_3V3.RefreshFriendItems(FriendManager.LatelyFriendList);
		end);
		b_friendClick = false;
		_view.btnFriendNormal_3V3:SetActive(true);
		_view.btnLatelyNoraml:SetActive(false);
	end
end

function MatchingView_3V3.OnBackClick()
	print("返回按钮点击");
	MatchingManager_3V3.OnRequestTeamLeaveData();
end

function MatchingView_3V3.OnCancelMatchingClick()
	print("取消匹配按钮点击")
	MatchingManager_3V3.OnRequestTeamSetStatu()
	
end

function MatchingView_3V3.ToReadyState()
	print("切换到准备状态");
	_view.btnCancelReady:SetActive(true);
	_view.btnReady:SetActive(false);
	_view.matchTimeShow:SetActive(false);
	_view.btnMatchBack:SetActive(true);
end

function MatchingView_3V3.ToNormalState()
	print("切换到默认状态");
	b_isMatch = false;
	_view.btnReady:SetActive(true);
	_view.btnCancelReady:SetActive(false);
	_view.matchTimeShow:SetActive(false);
	_view.btnMatchBack:SetActive(true);
end

function MatchingView_3V3.ToMatchState()
	print("切换到匹配状态");
	b_isMatch = true;
	LuaHelper.SetMatchingTimer(-1);
	_view.btnCancelReady:SetActive(false);
	_view.btnReady:SetActive(false);
	_view.matchTimeShow:SetActive(true);
	_view.btnMatchBack:SetActive(false);
end

function MatchingView_3V3.RefreshFriendItems(datas)

	local i =1;
	for v,k in pairs(datas) do
	if(k~=nil)then 
		print(k.online_statu);
		if(k.online_statu==true)then
			if(i>#FriendItems)then 
				local item = {}
				item.obj = MatchingView_3V3.CreateFriendObj();
				item.data = k;
				item.txtName = item.obj.transform:Find("TxtName"):GetComponent("Text");
				item.btnInvite = item.obj.transform:Find("BtnInvite").gameObject
				item.inviteImg = item.btnInvite:GetComponent("Image");
				item.b_invite = false;
				item.txtName.text = item.data.user_name;
				item.Tween = nil;
				item.OnClickInvite = function()
					print(item.data);
					print("邀请组队。。。"..item.data.user_id);
					MatchingManager_3V3.OnRequestTeamInvite(item.data.user_id);
					item.b_invite = true;
					item.inviteImg.fillAmount = 0;
					item.inviteImg.raycastTarget = false;
					item.Tween = item.inviteImg:DOFillAmount(1,inviteTime);
					item.Tween:OnComplete(function()
						item.ClearInvite();
					end);
				end
				item.BeAgreeState = function()
					if(item.Tween~=nil)then 
						item.Tween:Pause();
						item.Tween = nil;
					end
					item.inviteImg.raycastTarget = false;
					item.inviteImg.fillAmount = 0;
				end 
				item.BeNormalState = function()
					if(item.Tween~=nil)then 
						item.Tween:Pause();
						item.Tween = nil;
					end
					item.inviteImg.raycastTarget = true;
					item.inviteImg.fillAmount = 1;
				end 
				item.ClearInvite = function()
					item.inviteImg.raycastTarget = true;
					item.inviteImg.fillAmount = 1;
					item.Tween = nil;
				end
				item.CheckInTeam = function()
					if(MatchingManager_3V3.TeamListDatas[item.data.user_id]~=nil)then 
						item.BeAgreeState();
					end 
				end
				item.CheckInTeam();
				item.RefreshItem = function(data)
					item.obj:SetActive(true);
					item.data = data;
					item.txtName.text = data.user_name;
					item.CheckInTeam();
				end
				item.Close = function()
					item.ClearInvite();
					item.obj:SetActive(false);
				end
				EventButtonListerer.Get(item.btnInvite,item.OnClickInvite);
				table.insert(FriendItems,item);
			else
				FriendItems[i].RefreshItem(k);
			end
			i=i+1;
		end
	end
	end
end

function MatchingView_3V3.FriendAddTeam(id)
	for v,k in pairs(FriendItems)do
		print(k.data.user_id);
		if(k.data.user_id==id)then 
			k.BeAgreeState();
		end
	end
end

function MatchingView_3V3.FriendLeave(id)
	for v,k in pairs(FriendItems)do
		print(k.data.user_id);
		if(k.data.user_id==id)then 
			k.BeNormalState();
		end
	end
end

function MatchingView_3V3.CreateFriendObj()
	local obj = UnityEngine.GameObject.Instantiate(_view.friendItem);
	obj.gameObject:SetActive(true);
	obj.transform:SetParent(_view.friendContent,false);
	return obj;
end

function MatchingView_3V3.ClearFriendItem()
	for i=1,#FriendItems do
		FriendItems[i].Close();
	end
end