﻿--From Lua Script Create
--ClassName: MatchingManager_3V3
--Author:    hukiry
--CreateTime:2018-8-14

MatchingManager_3V3 = class("MatchingManager_3V3")

MatchingManager_3V3.isBeInVited = false;
MatchingManager_3V3.MatchId = nil;
MatchingManager_3V3.isReady = false;
MatchingManager_3V3.mOtherTeammate={};
MatchingManager_3V3.MatchPlayerInfos={};--匹配到的玩家
MatchingManager_3V3.TeamListDatas={};

function MatchingManager_3V3.Init()
	MatchingManager_3V3.RegeditEvent();
end

function MatchingManager_3V3.RegeditEvent()
	NetSys.instance:AddMsgCallback(EChannelType.EWorldChannel, S2C_TeamInviteNotify,MatchingManager_3V3.OnReceiveTeamInviteNotify, nil);
	NetSys.instance:AddMsgCallback(EChannelType.EWorldChannel, S2C_TeamInfo,MatchingManager_3V3.OnReceiveTeamInfo, nil);
	NetSys.instance:AddMsgCallback(EChannelType.EWorldChannel, S2C_TeamInviteRefuseNotify,MatchingManager_3V3.OnReceiveTeamInviteRefuseNotify, nil);
	NetSys.instance:AddMsgCallback(EChannelType.EWorldChannel, S2C_TeamMemberJoin,MatchingManager_3V3.OnReceiveTeamMemberJoin, nil);
	NetSys.instance:AddMsgCallback(EChannelType.EWorldChannel, S2C_TeamMemberExit,MatchingManager_3V3.OnReceiveTeamMemberExit, nil);
	NetSys.instance:AddMsgCallback(EChannelType.EWorldChannel, S2C_TeamSetStatuCallBack,MatchingManager_3V3.OnReceiveTeamSetStatu, nil);
	NetSys.instance:AddMsgCallback(EChannelType.EWorldChannel, S2C_TeamLeaveCallBack,MatchingManager_3V3.OnReceiveTeamLeave, nil);
	NetSys.instance:AddMsgCallback(EChannelType.EWorldChannel, S2C_MatchPlayerList,MatchingManager_3V3.OnReceiveMatchInfo, nil);
	--NetSys.instance:AddMsgCallback(EChannelType.EWorldChannel, S2C_MatchReadyNotify,MatchingManager_3V3.OnReceiveMatchReadyNotify, nil);	
	NetSys.instance:AddMsgCallback(EChannelType.EWorldChannel, S2C_MatchTeamPushInTop,MatchingManager_3V3.OnReceiveCancelToPlay, nil);
	NetSys.instance:AddMsgCallback(EChannelType.EWorldChannel, S2C_MatchSelectHeroSetp,MatchingManager_3V3.OnReceiveToSelectHero, nil);
	EventSys.instance:AddLuaEvent(GameEvent.FightFinish,MatchingManager_3V3.OnReceiveFightFinish);
	EventSys.instance:AddLuaEvent(GameEvent.StartMatch,MatchingManager_3V3.StartMatch);
	EventSys.instance:AddLuaEvent(GameEvent.CancelMatch,MatchingManager_3V3.CancelMatch);
end

function MatchingManager_3V3.StartMatch(eventId,obj)
	print("开始匹配")
	MatchingView_3V3.ToMatchState();
end

--[[ function MatchingManager_3V3.UpdateFriendData(eventId,obj)
	MatchingView_3V3.RefreshFriendItems(FriendManager.ListFriendDatas)
end ]]

function MatchingManager_3V3.CancelMatch(eventId,obj)
	print("退出匹配")
	--MatchingView_3V3.ToNormalState();
end

function MatchingManager_3V3.OnReceiveFightFinish(eventId,obj)
	print("接收到战斗返回的消息")
	local number = MatchingManager_3V3.CheckTeamData();
	print("当前队伍数量"..tostring(number));
	if(number==0)then 
		return;
	end
	if(number>1)then 
	    VoiceHelper:ChangeToTeamChannel();
	else
		--MatchingManager_3V3.OnRequestTeamLeaveData();
	end
end

function MatchingManager_3V3.OnRequsetCreatTeam()
	print("主动创建队伍");
	local data = C2S_TeamCreateData()
	data.match_id =MatchingManager_3V3.MatchId;
	NetSys.instance:SendWorldMsg(data:SerializeToString(), C2S_TeamCreate);
end

function MatchingManager_3V3.OnReQuestMatchReady()
	print("发送匹配准备");
	local data = C2S_MatchReadyOperatData()
	data.operat = true;
	NetSys.instance:SendWorldMsg(data:SerializeToString(), C2S_MatchReadyOperat);
end

function MatchingManager_3V3.OnRequestTeamInvite(id)
	print("发送组队请求")
	local data = C2S_TeamInviteData()
	data.user_id = id;
	data.match_id = MatchingManager_3V3.MatchId;
	NetSys.instance:SendWorldMsg(data:SerializeToString(), C2S_TeamInvite);
end

function MatchingManager_3V3.OnRequestTeamInviteResult(isAgree)
	print("发送队伍邀请处理")
	local data = C2S_TeamInviteResponData()
	data.is_agree = isAgree;
	NetSys.instance:SendWorldMsg(data:SerializeToString(), C2S_TeamInviteRespon);
end

function  MatchingManager_3V3.OnRequestTeamLeaveData()
	print("发送离开队伍请求")
	local data = C2S_TeamLeaveData()
	NetSys.instance:SendWorldMsg(data:SerializeToString(), C2S_TeamLeave);
end

function  MatchingManager_3V3.OnRequestTeamSetStatu()
	print("发送组队准备或取消请求")
	local data = C2S_TeamSetStatuData()
	NetSys.instance:SendWorldMsg(data:SerializeToString(), C2S_TeamSetStatu);
end

function MatchingManager_3V3.OnReceiveTeamInviteRefuseNotify(this,objMsg)
	print("接收到拒绝组队邀请通知")
	local msg =S2C_TeamInviteRefuseNotifyData();
	msg:ParseFromString(objMsg);
	print("msg.id"..msg.user_id)
	MatchingManager_3V3.MatchId = msg.match_id;
	--print("接收到地图信息-->"..MatchingManager.MatchId);
	--MatchingView.RefuseInvite(msg.user_id)
end

function MatchingManager_3V3.OnReceiveTeamInfo(this,objMsg)
	local msg = S2C_TeamInfoData(); 
	msg:ParseFromString(objMsg); 
	print("接收到队伍信息-->"..#msg.team_member_list);
	MatchingManager_3V3.MatchId = msg.match_id;
	print("接收到地图信息-->"..MatchingManager_3V3.MatchId);
	MatchingManager_3V3.TeamListDatas={};
	for i=1,#msg.team_member_list do
		MatchingManager_3V3.TeamListDatas[msg.team_member_list[i].user_id] = msg.team_member_list[i];
		if(msg.team_member_list[i].user_id==LoginInfo.userId)then 
			MatchingManager_3V3.isReady = msg.team_member_list[i].statu==2;
			if #msg.team_member_list > 1 then
				VoiceHelper:LoginTeam(msg.team_member_list[i].user_id, msg.team_member_list[i].team_id);
			end
		end
	end
	if(#msg.team_member_list==1)then 
		VoiceHelper:Logout();
	end
	MatchingView_3V3.RefreshTeamInfo( msg.team_member_list);
end

function MatchingManager_3V3.OnReceiveTeamInviteNotify(this,objMsg)
	print("接收到组队请求");
	local msg = S2C_TeamInviteNotifyData(); 
	msg:ParseFromString(objMsg);
	local id = msg.user_id;
	MatchingManager_3V3.MatchId =msg.match_id;
	print("接收到地图信息-->"..MatchingManager_3V3.MatchId);
	print(id);
	if(FriendManager.ListFriendDatas[id]~=nil)then 
		MatchingManager_3V3.ShowTeamInvitePanel(FriendManager.ListFriendDatas[id].user_name);
	else
		local ids ={};
		table.insert(ids,id);
		FriendManager.QueryUserInfoFromID(ids,function(datas)
		MatchingManager_3V3.ShowTeamInvitePanel(datas[1].user_name)
				--[[ local data={};
				data.user_id=v.user_id;
				data.user_name=v.user_name;
				data.logoutTime=v.logoutTime;
				data.online_statu=v.online_statu;]]
		end)
	end
end

function MatchingManager_3V3.OnReceiveTeamMemberJoin(this,objMsg)
	print("接收到成员加入");
	local msg = S2C_TeamMemberJoinData();
	msg:ParseFromString(objMsg);
	local id = msg.user_id;
	MatchingView_3V3.FriendAddTeam(id);
end

function MatchingManager_3V3.OnReceiveTeamMemberExit(this,objMsg)
	print("接收到成员离开")
	local msg = S2C_TeamMemberExitData();
	msg:ParseFromString(objMsg);
	local id = msg.user_id;
	MatchingView_3V3.FriendLeave(id)
end

function MatchingManager_3V3.OnReceiveTeamLeave(this,objMsg)
	print("接收到自己离开的消息")
	local msg = S2C_TeamLeaveCallBackData();
	msg:ParseFromString(objMsg);
	MatchingView_3V3.CloseView()
	--MatchingManager.TeamListDatas={}
	VoiceHelper:Logout();
end

function MatchingManager_3V3.OnReceiveTeamSetStatu(this,objMsg)
	local msg = S2C_TeamSetStatuCallBackData();
	msg:ParseFromString(objMsg);
	local statu = msg.team_statu;
	print("接收到准备或取消"..statu);
--[[ 	TeamMemberStatuType_Idle = 1;			//空闲状态
	TeamMemberStatuType_Ready = 2;			//准备状态 ]]
	if(statu == TeamMemberStatuType_Idle) then
		MatchingManager_3V3.isReady = false;
		MatchingView_3V3.ToNormalState();
	end
    if(statu == TeamMemberStatuType_Ready) then
		MatchingManager_3V3.isReady=true;
		MatchingView_3V3.ToReadyState();
	end

	print("TODO:准备或取消")
	--[[ if(ViewSys.instance:IsOpen("MatchingView")) then
		MatchingView.ReceiveReadyOrCancel(MatchingManager.isReady);
	end ]]
end

function MatchingManager_3V3.OnReceiveMatchInfo(this,objMsg)
	print("接收到匹配到的玩家")
	local msg = S2C_MatchPlayerListData(); 
	msg:ParseFromString(objMsg);
	local lstTeam = nil;
	for i=1,#msg.team_1_player_list do
		if(LoginInfo.userId==msg.team_1_player_list[i])then 
			lstTeam = msg.team_1_player_list;
			MatchingManager_3V3.MatchPlayerInfos.selfTeamInfo = msg.team_1_player_list;
			MatchingManager_3V3.MatchPlayerInfos.otherTeamInfo =msg.team_2_player_list;
			MatchingManager_3V3.MatchPlayerInfos.selfRebootInfo = msg.team_1_robot_list;
			MatchingManager_3V3.MatchPlayerInfos.otherRebootInfo = msg.team_2_robot_list;
		end
	end
	for i=1,#msg.team_2_player_list do
		if(LoginInfo.userId==msg.team_2_player_list[i])then 
			lstTeam = msg.team_2_player_list;
			MatchingManager_3V3.MatchPlayerInfos.selfTeamInfo = msg.team_2_player_list;
			MatchingManager_3V3.MatchPlayerInfos.otherTeamInfo =msg.team_1_player_list;
			MatchingManager_3V3.MatchPlayerInfos.selfRebootInfo = msg.team_2_robot_list;
			MatchingManager_3V3.MatchPlayerInfos.otherRebootInfo = msg.team_1_robot_list;
		end
	end

	MatchingManager_3V3.mOtherTeammate = {};
	for i = 1, #lstTeam do
		table.insert(MatchingManager_3V3.mOtherTeammate, lstTeam[i]);
	end
	for i=1,#MatchingManager_3V3.MatchPlayerInfos.selfTeamInfo do
		if(LoginInfo.userId==MatchingManager_3V3.MatchPlayerInfos.selfTeamInfo[i])then 
			table.remove(MatchingManager_3V3.MatchPlayerInfos.selfTeamInfo,i);
			return;
		end
	end
end

function MatchingManager_3V3.OnReceiveCancelToPlay(this,objMsg)
	print("接收到进入游戏中断的消息");
	local msg = S2C_MatchTeamPushInTopData();
	msg:ParseFromString(objMsg);
	print("TODO")
	--MatchingView.ToMatchingState();
end

function MatchingManager_3V3.OnReceiveToSelectHero(this,objMsg)
	print("接收到进入选择英雄的消息");
	MatchingView_3V3.ToNormalState();
	local msg = S2C_MatchSelectHeroSetpData();
	msg:ParseFromString(objMsg);
	local MapData=ViewParam();
	MapData.objParam = {MatchId=1};
	MapData.objParam["MatchId"]=MatchingManager_3V3.MatchId;
	ViewSys.instance:Open("SelectHeroView",MapData);

	--切换到房间聊天频道
	VoiceHelper:LoginRoom(LoginInfo.userId, msg.chat_channel_id);
end

function MatchingManager_3V3.ShowTeamInvitePanel(name)
	local content =name.."想要与你组队";
	local confirmCallback =function()
		print("同意组队")
		MatchingManager_3V3.isBeInVited = true;
		MatchingManager_3V3.OnRequestTeamInviteResult(true);
		MatchingView_3V3.OpenView();
	end
	local cancelCallBack = function()
		print("拒绝组队")
		MatchingManager_3V3.OnRequestTeamInviteResult(false);
	end
	TipMgr.ShowTipType1(content,confirmCallback,cancelCallBack,cancelCallBack,cancelCallBack);
end

function MatchingManager_3V3.CheckTeamData()
	local number =0;
	for v,k in pairs(MatchingManager_3V3.TeamListDatas) do
		if(k~=nil)then 
			number=number+1;
		end
	end
	print("队伍成员数量"..number);
	return number;
end