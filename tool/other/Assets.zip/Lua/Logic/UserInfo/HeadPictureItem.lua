﻿--From Lua Script Create
--ClassName: HeadPictureItem
--Author:    Tzy
--CreateTime:2018-7-19

HeadPictureItem = class("HeadPictureItem")

function HeadPictureItem.Init(obj,id)
	local item = HeadPictureItem.new();
	item.obj = obj;
	item.id = id;
	item.normalBg =  obj.transform:Find("normalBg").gameObject;
	item.activeBg =  obj.transform:Find("activeBg").gameObject;
	item.headIcon =  obj.transform:Find("headIcon"):GetComponent("Image");
	item.headIcon.sprite = CResourceSys.instance:Load(EResType.EIcon,HeadPictureTable[id].head_file);
	item:SetActive(false);
	local click =function()
		UserInfoView.OnMarkChangeHead(item);
	end
	EventButtonListerer.Get(item.headIcon.gameObject,click)
	return item;
end

function HeadPictureItem:SetActive(isActive)
	self.activeBg:SetActive(isActive);
	self.normalBg:SetActive(not isActive);
end