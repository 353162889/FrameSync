﻿--From Lua Script Create
--ClassName: UserInfoView
--Author:    Tzy
--CreateTime:2018-7-18

require "Logic/UserInfo/HeadPictureItem"

UserInfoView = class("UserInfoView",UserInfoViewUI)

local _this;
local headPictureItemList={};
local currentActiveItem=nil;

function UserInfoView:Init()
	_this=self;
	_this.RegeditEvent();
	_this.InitUserInfoView();
end

function UserInfoView:OpenView()
	_this.ClearView()
end

function UserInfoView.RegeditEvent()
	EventSys.instance:AddLuaEvent(GameEvent.Rename,UserInfoView.OnReceiveRename);
	EventButtonListerer.Get(_this.btnRename, _this.OnBtnRenameClick);
	EventButtonListerer.Get(_this.btnClose, _this.OnCloseBtnClick);
	EventButtonListerer.Get(_this.btnCancel, _this.OnRenamePanelCancelClicl);
	EventButtonListerer.Get(_this.btnSure, _this.OnRenamePanelSureClicl);
	EventButtonListerer.Get(_this.btnRandomName, _this.OnRandomNameClick);
	EventButtonListerer.Get(_this.imgHead.gameObject, _this.OnImgHeadClick);
	EventButtonListerer.Get(_this.btnUpHeadSure, _this.OnBtnUpHeadSureClick);
	local sliderBgSoundOnUp = function()
		UserInfoView.OnSliderBgSoundValueChange();
	end
	EventTriggerListener.Get(_this.sliderBgSound).onUp = EventTriggerListener.Get(_this.sliderBgSound).onUp + sliderBgSoundOnUp;
	local sliderEffectSoundOnUp = function()
		UserInfoView.OnSliderEffectSoundValueChange();
	end
	EventTriggerListener.Get(_this.sliderEffectSound).onUp = EventTriggerListener.Get(_this.sliderEffectSound).onUp + sliderEffectSoundOnUp;
end

function UserInfoView.InitSoundView()
	local value = ConstTable["audio_volume"].p_int/1000;
	print(value);
	_this.sliderBgSound:GetComponent("Slider").value=value;
	_this.sliderEffectSound:GetComponent("Slider").value=value;
end

--[[ function UserInfoView.InitSoundVolume()
	local value = math.floor(ConstTable["audio_volume"].p_int/1000);
	AudioSys.instance:SetAllVol(value);
end ]]

function UserInfoView.OnRequsetRename()
	local name =_this.inputFieldRename.text;
	if(name=="")then 
		return;
	end
	print("向服务器发送改名消息"..name);
	local data = C2S_GiveNameData();
	data.name = name;
	NetSys.instance:SendWorldMsg(data:SerializeToString(), C2S_GiveName);
end

function UserInfoView.OnReceiveRename()
	print("接收到改名成功的消息"..MainLobbyManager.playerBaseInfo.name);
	UserInfoView.ClearView();
end

function UserInfoView.InitUserInfoView()
	_this.imgHead.sprite = CResourceSys.instance:Load(EResType.EIcon,HeadPictureTable[MainLobbyManager.HeadPictureId].head_file);
	_this.InitIdCard();
	_this.InitSoundView();
	_this.InitHeadListView()
end

function UserInfoView.InitIdCard()
	_this.txtId.text = "";
	--[[ local idStr = tostring(LoginInfo.userId);
	print("ID信息："..idStr);
	idStr = string.sub(idStr,#idStr-6,#idStr);
	_this.txtId.text = "ID:"..idStr; ]]
end


function UserInfoView.ClearView()
	_this.infoPanel:SetActive(true);
	_this.renamePanel:SetActive(false);
	_this.headListPanel:SetActive(false);
	print("修改名字的次数"..tostring(MainLobbyManager.playerBaseInfo.name_modify_times));
	if(MainLobbyManager.playerBaseInfo.name_modify_times==0)then 
		_this.renameTitle.text = "此次修改名字后，点击确定将扣除<color=#FF0000FF>0</color>金币";
	else
		local cost = ConstTable["name_charge"].p_int;
		_this.renameTitle.text = "此次修改名字后，点击确定将扣除<color=#FF0000FF>"..tostring(cost).."</color>金币";
	end
	_this.txtName.text = tostring(MainLobbyManager.playerBaseInfo.name);
end

function UserInfoView.OnBtnRenameClick()
	print("打开改名界面");
	_this.renamePanel:SetActive(true);
	_this.inputFieldRename.text="";
end

function UserInfoView.OnCloseBtnClick()
	print("关闭个人信息面板");
	ViewSys.instance:Close("UserInfoView");
end

function UserInfoView.OnRenamePanelCancelClicl()
	print("关闭改名界面");
	_this.renamePanel:SetActive(false);
end

function UserInfoView.OnRenamePanelSureClicl()
	print("向服务端发送改名请求");
	UserInfoView.OnRequsetRename();
end

function UserInfoView.OnSliderBgSoundValueChange()
	print("改变背景音量");
	AudioSys.instance:SetVol(AudioChannelType.BG,_this.sliderBgSound:GetComponent("Slider").value);
end

function UserInfoView.OnSliderEffectSoundValueChange()
	print("改变音效音量");
	AudioSys.instance:SetVol(AudioChannelType.SceneAudio,_this.sliderEffectSound:GetComponent("Slider").value);
	AudioSys.instance:SetVol(AudioChannelType.UIAudio,_this.sliderEffectSound:GetComponent("Slider").value);
end

function UserInfoView.OnRandomNameClick()
	print("随机名字")
	local length = math.random(3,7);
	print(tostring(length))
	local randomName=LuaHelper.GenerateRandomNumber(length);
	print("获取到的随机名字："..randomName);
	_this.inputFieldRename.text = randomName;
end

function UserInfoView.OnImgHeadClick()
	print("点击更换头像");
	_this.infoPanel:SetActive(false);
	_this.headListPanel:SetActive(true);
end

function UserInfoView.InitHeadListView()
	print("初始化头像列表"..#HeadPictureTable)
	_this.headPictureItem:SetActive(false);
	for i=1,#HeadPictureTable do
		if(i>#headPictureItemList)then 
			local obj = UserInfoView.CreatHeadItem();
			local item = HeadPictureItem.Init(obj,i);
			table.insert(headPictureItemList,item);
		end
		if(i==MainLobbyManager.HeadPictureId)then 
			_this.RefreshCurrentActiveItem(headPictureItemList[i]);
		end
	end
end

function UserInfoView.OnMarkChangeHead(item)
	print("记录当前选中的头像"..item.id);
	UserInfoView.RefreshCurrentActiveItem(item);
end

function UserInfoView.OnRequestChangeHead()
	print("TODO向服务端请求修改头像"..currentActiveItem.id)

end

function UserInfoView.OnReceiveHeadChanged()
	print("接收到头像改变的消息");
	--TODO:先改变Manager里面记录的头像ID;
	EventSys.instance:DispatchLua(GameEvent.HeadPictureChange);
end

function UserInfoView.RefreshCurrentActiveItem(current)
	if(currentActiveItem~=nil)then
		currentActiveItem:SetActive(false);
	end
	currentActiveItem = current;
	currentActiveItem:SetActive(true);
end

function UserInfoView.OnBtnUpHeadSureClick()
	print("确实选择头像并返回");
	_this.OnRequestChangeHead();
	_this.infoPanel:SetActive(true);
	_this.headListPanel:SetActive(false);
end

function UserInfoView.CreatHeadItem()
	local obj = UnityEngine.GameObject.Instantiate(_this.headPictureItem);
	obj.gameObject:SetActive(true);
	obj.transform:SetParent(_this.headPictureContent,false);
	return obj;
end
