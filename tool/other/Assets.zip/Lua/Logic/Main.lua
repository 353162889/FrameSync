require "Logic/Load/SceneLoad"
require "Logic/Load/BattleSceneLoad"
require "Logic/Fight/FightManager"
require "Logic/Friend/FriendManager"
require "Logic/Shop/ShopManager"
require "Logic/3V3MatchingView/MatchingManager_3V3"
require "Logic/ActiveSystem/ActiveSystemManager"
require "Logic/PlayerRank/PlayerRankManager"

Main = class("Main"); 
Main.funUpdate = {}

function Main.Init()
    print("--------------------Main.Init"); 
    MainLobbyManager.Init();
    FightManager.Init();
    BagMgr.Init();
    ItemMgr.Init();
    LoginMgr.Init();
    MatchMgr.Init();
    MediaMgr.Init();
    TimeRewardMgr.Init();
    NameMgr.Init();
    Main.BeginGame(); 
    FriendManager.Init();
    ShopManager.Init();
    MatchingManager_3V3.Init();
    ActiveSystemManager.Init();
    PlayerRankManager.Init();
end

function Main.Update(deltaTime)
    for i, v in ipairs(Main.funUpdate) do
        if v.interval then
            v.accumulateTime = v.accumulateTime + deltaTime
            if v.accumulateTime >= v.interval then
                v.accumulateTime = v.accumulateTime - v.interval
                v.fun(v.obj, deltaTime)
            end
        else
            v.fun(v.obj, deltaTime)
        end
        
    end
end

--fun 调用方法
--obj 传对应作用域self
--params 补充参数 (可以不传,不传按原Update调用 | 类型:table) 
--  interval 间隔时间 (单位:秒 | 类型:int)
--  callAtOnce 立即调用一次,传true立即调用一次 (类型:bool)
function Main.AddUpdateFun(fun, obj, params)
    for i, v in ipairs(Main.funUpdate) do
        if v == fun then
            return;
        end
    end 

    local tb = {}
    tb.fun = fun
    tb.obj = obj
    if params then
        tb.interval = params.interval
        if params.callAtOnce == true then
            tb.accumulateTime = params.interval
        else
            tb.accumulateTime = 0
        end
    end
    table.insert(Main.funUpdate, tb); 
end

function Main.RemoveUpdateFun(fun)
    for i, v in ipairs(Main.funUpdate) do
        if v.fun == fun then
            table.remove(Main.funUpdate, i); 
            return; 
        end
    end 
end

function Main.BeginGame()
     ViewSys.instance:Open("LoginView");
end
