--From Lua Script Create
--ClassName: FriendItem
--Author:    hukiry
--CreateTime:2018-7-5

FriendItem = class("FriendItem")

local _this;

function FriendItem.Init(obj,data)
	local item = FriendItem.new();
	item.data= data;
	item.obj = obj;
	item.head = obj.transform:Find("HeadBg/HeadIcon"):GetComponent("Image");
	item.name = obj.transform:Find("NameText"):GetComponent("Text");
	item.state = obj.transform:Find("StateText"):GetComponent("Text");
	local btn = obj.transform:Find("AddFriendBtn");
	local OnClick =nil;
	if(btn~=nil)then 
		item.btnObj = btn.gameObject;
		item.isAddItem = true;
		OnClick = function()
			item:OnAddFriend();
		end
		item:UpdateView(data,true);
	else
		item.btnObj = obj.transform:Find("DeleteFriendBtn").gameObject;
		item.isAddItem = false;
		OnClick = function()
			item:OnDeleteFriend();
		end
		item:UpdateView(data,false);
	end
	EventButtonListerer.Get(item.btnObj, OnClick);
	return item;
end

function FriendItem:OnDeleteFriend()
	local content ="您确定要移除"..self.data.user_name.."吗？"
	local confirmCallback =function()
		FriendManager.OnRequestDeleteFriend(self.data.user_id);
	end
	TipMgr.ShowTipType1(content,confirmCallback,nil,nil,nil);
	
end

function FriendItem:OnAddFriend()
	local content ="您确定要添加"..self.data.user_name.."为好友吗？"
	local confirmCallback =function()
		print("item添加好友"..tostring(self.data.user_id));
		FriendManager.OnRequestAddFriendInvite(self.data.user_id);
	end
	TipMgr.ShowTipType1(content,confirmCallback,nil,nil,nil);
end

function FriendItem:UpdateView(data,isAddItem)
	self.data = data;
	self.name.text = data.user_name;
	self:UpdateState(isAddItem);
end

function FriendItem:UpdateState(isAddItem)
	if(isAddItem==true)then 
		local state;
		if(self.data.online_statu==true)then 
			state ="<color=#32b43b>在线</color>";
		else
			state="<color=#67655b>离线</color>";
		end 
		self.state.text = state;
		if(FriendManager.ListFriendDatas[self.data.user_id]==nil)then 
			self.btnObj:SetActive(true);
		else
			self.btnObj:SetActive(false);
		end
	else
		local state;
		if(self.data.online_statu==true)then 
			state ="<color=#32b43b>在线</color>";
		else
			--[[ print("self.data.logoutTime"..self.data.logoutTime); ]]
			local loginOut = self.data.logoutTime;
			if(loginOut==nil)then 
				self.state.text = "<color=#67655b>离线</color>";
				return;
			end
			local minutes= math.floor(loginOut / 60)
			--[[ print("minutes"..minutes); ]]
			local hours =math.floor(minutes / 60);
			local days = math.floor(hours / 24);
			minutes = minutes - (hours * 60)
			local seconds=loginOut % 60
			--[[ print("loginOut"..loginOut);
			print("minutes"..minutes);
			print("seconds"..seconds);
			print("hours"..hours);
			print("days"..days); ]]
			local str="";
			if(days>0)then 
				str = tostring(days).."天前";
			else 
				if(hours>0) then
					str = tostring(hours).."小时前";
				else 
					if(minutes>0) then 
						str = tostring(minutes).."分前"
					else
						str = tostring(seconds).."秒前"
					end
				end
			end

			state = "<color=#67655b>".."上次登入时间:"..str.."</color>"
		end 
		self.state.text = state;
	end
end