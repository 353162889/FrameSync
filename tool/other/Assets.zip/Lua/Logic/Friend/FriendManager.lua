--From Lua Script Create
--ClassName: FriendManager
--Author:    hukiry
--CreateTime:2018-7-5
--[[ required uint64 user_id = 1;
required string user_name = 2;
required uint32 logoutTime = 3;
required bool online_statu = 4; ]]
FriendManager = class(FriendManager)

local OnReceiveQueryCallBack ={};
local AddFriendDatas={};
FriendManager.ListFriendDatas ={};
FriendManager.LatelyFriendList={};
FriendManager.RecommendFriendList={};
local LatelyFriendIdList ={};
local isReceiveLatelyFriendList = false;
local idSumNameDatas = {};
--[[ Error_FriendRequestBusy = 1070;                     //对方太忙了
Error_FriendRequestRepeat = 1071;                   //重复申请
Error_FriendRequestAlreadyFriend = 1072;            //已经是好友了
Error_FriendNotRequest = 1073;                      //对方没有添加你为好友
Error_FriendFull = 1074;                            //好友满了
Error_FriendAnotherFull = 1075;                     //对方好友满了
Error_FriendNotBuildFriend = 1076;                  //你们不是好友 ]]
function FriendManager.Init()
	NetSys.instance:AddMsgCallback(EChannelType.EWorldChannel, S2C_FriendList, FriendManager.OnReceiveFriendList, nil);
	NetSys.instance:AddMsgCallback(EChannelType.EWorldChannel, S2C_QueryUserResult, FriendManager.OnReceiveQueryUserResult, nil);
	NetSys.instance:AddMsgCallback(EChannelType.EWorldChannel, S2C_FriendInviteNotice, FriendManager.OnReceiveAddFriendNotice, nil);--//好友添加申请通知
	NetSys.instance:AddMsgCallback(EChannelType.EWorldChannel, S2C_FriendRequestList, FriendManager.OnReceiveAddList, nil);--查询好友申请列表
	NetSys.instance:AddMsgCallback(EChannelType.EWorldChannel, S2C_FriendSync, FriendManager.OnReceiveFriendSync, nil);--好友同步
	NetSys.instance:AddMsgCallback(EChannelType.EWorldChannel, S2C_FriendRemove, FriendManager.OnReceiveFriendRemove, nil);--好友移除
	NetSys.instance:AddMsgCallback(EChannelType.EWorldChannel, S2C_RecentPlayerList,FriendManager.OnReceiveLatelyFriendList,nil);--最近一起玩游戏的
	EventSys.instance:AddLuaEvent(GameEvent.LoginSuccess,FriendManager.OnLoginSuccess);
	EventSys.instance:AddLuaEvent(GameEvent.FightFinish,FriendManager.OnShowAddFriendTip);
end

function FriendManager.OnLoginSuccess(eventId,obj)
	FriendManager.OnRequestAddFriendList();
	FriendManager.OnRequestFriendList();
end

function FriendManager.OnRequestAddFriendList()
	print("查询好友申请列表")
	local data = S2C_FriendRequestListData();
	NetSys.instance:SendWorldMsg(data:SerializeToString(), C2S_FriendRequestList);
end 

function FriendManager.OnRequestDeleteFriend(id)
	print("请求删除好友")
	local data = C2S_DeleteFriendData()
	data.actid = id;
	NetSys.instance:SendWorldMsg(data:SerializeToString(), C2S_DeleteFriend);
end

function FriendManager.OnRequestFriendList()
	print("查询好友列表")
	local data = C2S_SecertShopRefreshData();
	NetSys.instance:SendWorldMsg(data:SerializeToString(), C2S_FriendList);
end

function FriendManager.QueryUserInfoFromID(ids,OnCallBack)
	print("通过好友Id查询列表--》"..#ids);
	if(#ids==0)then 
		return
	end
	local data = C2S_QueryUserInfoData();
	table.insert(OnReceiveQueryCallBack,OnCallBack);
	for i=1,#ids do
		print(ids[i]);
		data.user_id_list:append(ids[i]);
	end
	NetSys.instance:SendWorldMsg(data:SerializeToString(), C2S_QueryUserInfo);
end

--[[ function FriendManager.QueryUserNameFromID(id,OnCallBack)
	if(idSumNameDatas[id]~=nil)then 
		OnCallBack(idSumNameDatas[id]);
	else
		local callBack = function(datas)
			idSumNameDatas[id]=datas[1].user_name;
			OnCallBack(datas[1].user_name);
		end
		local data = C2S_QueryUserInfoData();
		data.user_id_list:append(id);
		NetSys.instance:SendWorldMsg(data:SerializeToString(), C2S_QueryUserInfo);
	end
end ]]

function FriendManager.QueryUserInfoFromName(name,OnCallBack)
	local data = C2S_QueryUserInfoData();
	table.insert(OnReceiveQueryCallBack,OnCallBack);
	data.user_name = name;
	NetSys.instance:SendWorldMsg(data:SerializeToString(), C2S_QueryUserInfo);
end

function FriendManager.OnRequestAddFriendInvite(id)
	local data = C2S_FriendInviteData();
	data.actid = id;
	print("发送申请好友请求"..data.actid);
	NetSys.instance:SendWorldMsg(data:SerializeToString(), C2S_FriendInvite);
end

function FriendManager.OnRequestAgreeFriend(id)--同意添加好友
	local data = C2S_FriendAgreeData();
	data.actid = id;
	print("同意添加好友"..data.actid);
	NetSys.instance:SendWorldMsg(data:SerializeToString(), C2S_FriendAgree);
end

function FriendManager.OnRequestIgronFriend(id)--拒绝添加好友
	local data = C2S_FriendRefusedData();
	data.actid = id;
	print("拒绝添加好友"..data.actid);
	NetSys.instance:SendWorldMsg(data:SerializeToString(), C2S_FriendRefused);
end

function FriendManager.OnReceiveFriendSync(this,objMsg)
	print("接收到好友同步的消息")
	local msg = S2C_FriendSyncData(); 
	msg:ParseFromString(objMsg); 
	local data ={}
	local ids={}
	data.friendID = msg.friendInfo.friendID;
	data.timestamp = msg.friendInfo.timestamp;
	FriendManager.ListFriendDatas[data.friendID]=data;
	table.insert(ids,data.friendID)
	FriendManager.QueryUserInfoFromID(ids,
	function(datas)
		FriendManager.AddListFriendData(datas)
	end)
end

function FriendManager.AddListFriendData(datas)
	for i=1,#datas do
		local data = FriendManager.ListFriendDatas[datas[i].user_id];
		if(data~=nil)then 
--[[ 			print(data) ]]
			data.user_id = datas[i].user_id;
			data.user_name = datas[i].user_name;
			data.logoutTime = datas[i].logoutTime;
--[[ 			print("v.logoutTime--->"..data.logoutTime); ]]
			data.online_statu = datas[i].online_statu;
--[[ 			print("v.online_statu--->"..tostring(datas[i].online_statu)); ]]
			FriendManager.ListFriendDatas[datas[i].user_id]=data;
		end
	end
	EventSys.instance:DispatchLua(GameEvent.UpdateFriendData);
	--[[ if(ViewSys.instance:IsOpen("FriendView")) then
		FriendView.OnRefreshListPanel(FriendManager.ListFriendDatas)
	end ]]
end

function FriendManager.OnReceiveFriendRemove(this,objMsg)
	print("接收到好友删除的消息")
	local msg = S2C_FriendRemoveData(); 
	msg:ParseFromString(objMsg);
	print(msg.actid);
	FriendManager.ListFriendDatas[msg.actid]=nil;
	--[[ if(ViewSys.instance:IsOpen("FriendView")) then
		FriendView.OnRefreshListPanel(FriendManager.ListFriendDatas)
	end ]]
	EventSys.instance:DispatchLua(GameEvent.UpdateFriendData);
end

function FriendManager.OnReceiveFriendList(this,objMsg)
	print("接收到好友列表");
	local msg = S2C_FriendListData(); 
	msg:ParseFromString(objMsg); 
	print(#msg.friendList);
	if(#msg.friendList==0)then 
		return
	end
	local ids ={} 
	for i=1,#msg.friendList do
		table.insert(ids,msg.friendList[i].friendID);
		local data={}
		data.friendID = msg.friendList[i].friendID;
		data.timestamp = msg.friendList[i].timestamp;
		FriendManager.ListFriendDatas[msg.friendList[i].friendID]=data;
	end
	FriendManager.QueryUserInfoFromID(ids,
		function(datas)
			FriendManager.AddListFriendData(datas);
	end)
end

function FriendManager.OnReceiveQueryUserResult(this,objMsg)
	print("=============================接收到查询好友列表结果");
	local msg = S2C_QueryUserResultData	(); 
	msg:ParseFromString(objMsg); 
	print(#msg.userInfoList);
--[[ 	for i=1,#msg.userInfoList do 
		print("v.user_id--->"..msg.userInfoList[i].user_id);
		print("v.user_name--->"..msg.userInfoList[i].user_name);
		print("v.logoutTime--->"..msg.userInfoList[i].logoutTime);
		print("v.online_statu--->"..tostring(msg.userInfoList[i].online_statu));
	end ]]
	local datas ={};
	for k,v in ipairs(msg.userInfoList) do
		local data={};
		data.user_id=v.user_id;
		data.user_name=v.user_name;
		data.logoutTime=v.logoutTime;
		data.online_statu=v.online_statu;
		table.insert(datas,data);
	end
	local deleteIndexs={};
	for k,v in ipairs(OnReceiveQueryCallBack) do 
		if(v~=nil)then 
			v(datas);
			v=nil;
			table.insert(deleteIndexs,k);
		end
	end
	for i=1,#deleteIndexs do
		table.remove(OnReceiveQueryCallBack,deleteIndexs[i]);
	end
end

function FriendManager.OnReceiveAddFriendNotice(this,objMsg)
	print("接收到好友通知申请")
	local msg = S2C_FriendInviteNoticeData(); 
	msg:ParseFromString(objMsg); 
	local ids ={} 
	table.insert(ids,msg.actid);
	FriendManager.QueryUserInfoFromID(ids,
	function(datas)
		print(#datas)
		for i=1,#datas do
			table.insert(AddFriendDatas,datas[i]);
		end
		print("判断当前是否处于游戏中"..tostring(BattleInfo.gameType));
		if(BattleInfo.gameType==EStateType.None)then
			FriendManager.OnShowAddFriendTip();
		end
	end
	)
end

function FriendManager.OnReceiveAddList(this,objMsg)
	print("接收到好友申请列表");
	local msg = S2C_FriendRequestListData();
	msg:ParseFromString(objMsg);
	if(#msg.reqList==0)then
		print("好友申请列表为空");
		return;
	end
	FriendManager.QueryUserInfoFromID(msg.reqList,function(datas)
		print(#datas)
		for i=1,#datas do
			print("v.user_name--->"..datas[i].user_name);
			table.insert(AddFriendDatas,datas[i]);
		end
		FriendManager.OnShowAddFriendTip();
	end)
end

function FriendManager.OnShowAddFriendTip()
	print("检查好有申请列表的数据");
	if(#AddFriendDatas==0)then 
		return;
	end
	local FinishCallBack = function()
		table.remove(AddFriendDatas, 1)
		FriendManager.OnShowAddFriendTip()
	end
	local data =AddFriendDatas[1];
	local content =data.user_name.."请求添加您为好友";
	local txtConfim = "同意";
	local confirmCallback=function()
		print("同意申请");
		FriendManager.OnRequestAgreeFriend(data.user_id)
		FinishCallBack();
	end
	local txtCancel = "拒绝";
	local cancelCallback =function()
		print("拒绝申请");
		FriendManager.OnRequestIgronFriend(data.user_id)
		FinishCallBack();
	end
	TipMgr.ShowTip(nil,content,nil,txtConfim,confirmCallback,txtCancel,cancelCallback,cancelCallback,true);
end

function FriendManager.OnReceiveLatelyFriendList(this,objMsg)
	print("接收到最近一起游戏的玩家");
	local msg = S2C_RecentPlayerListData();
	msg:ParseFromString(objMsg);
	print(#msg.user_id_list);
--[[ 	local ids  ={};
	for i=1,#msg.user_id_list do
		if()
	end ]]
	isReceiveLatelyFriendList = true;
	LatelyFriendIdList={};
	for i=1,#msg.user_id_list do
		table.insert(LatelyFriendIdList,msg.user_id_list[i]);
	end
--[[ 	FriendManager.QueryUserInfoFromID(msg.user_id_list,
	function(datas)
		for i=1,#datas do
			table.insert(FriendManager.LatelyFriendList,datas[i]);
		end
	end 
	) ]]
end

function FriendManager.UpdateLatelyFriendList(callBack)
	FriendManager.QueryUserInfoFromID(LatelyFriendIdList,
	function(datas)
		FriendManager.LatelyFriendList={};
		FriendManager.RecommendFriendList={};--暂时先这样添加推荐好友数据
		for i=1,#datas do
			table.insert(FriendManager.LatelyFriendList,datas[i]);
			if(datas[i].online_statu==true)then 
				table.insert(FriendManager.RecommendFriendList,datas[i]);
			end
		end
		if(callBack~=nil)then 
			callBack();
		end
	end 
	)
end

function FriendManager.UpdateRecommendFriendList(callBack)
	FriendManager.QueryUserInfoFromID(LatelyFriendIdList,
	function(datas)
		
		for i=1,#datas do
			if(datas[i].online_statu==true)then 
				table.insert(FriendManager.RecommendFriendList,datas[i]);
			end
		end
		if(callBack~=nil)then 
			callBack();
		end
	end 
	)
end

function FriendManager.UpdateFriendListData(callBack)
	print("更新已经存在的好友的状态");
	local ids ={};
	for v,k in pairs(FriendManager.ListFriendDatas) do
		if(k~=nil)then 
			table.insert(ids,k.user_id);
		end
	end
	FriendManager.QueryUserInfoFromID(ids,function(datas) 
		FriendManager.AddListFriendData(datas);
		if(callBack~=nil)then 
			callBack()
		end
	end)
end

function FriendManager.FindFriendWithName(name)
	local ids ={};
	for v,data in pairs(FriendManager.ListFriendDatas) do
		local dataName = data.user_name;
		if(string.find(dataName,name)~=nil) then
			local id = data.user_id;
			table.insert(ids,id);
		end
	end
	return ids;
end

function FriendManager.CheckIsFriend(id)
	local b_friend = true;
	if(FriendManager.ListFriendDatas[id]==nil)then
		b_friend = false;
	end
	return b_friend;
end
