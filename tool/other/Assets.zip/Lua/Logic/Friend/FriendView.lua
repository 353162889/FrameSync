--From Lua Script Create
--ClassName: FriendView
--Author:    hukiry
--CreateTime:2018-7-4
require "Logic/Friend/FriendItem"
FriendView = class("FriendView",FriendViewUI)

local _this;
local currentSelectBtn=nil;
local AddFrendBtn = {};
local FriendListBtn={};
local RecommendBtn={};
local LatelyBtn={};

local HadInstanceAddItem={};
local HadInstanceListItem={};

function FriendView:Init()
	_this=self;
	self:InitBtn();
	_this.searchFriendPanel:SetActive(true);
	_this.friendListPanel:SetActive(false);
	_this.searchFriendItem:SetActive(false);
	_this.listFriendItem:SetActive(false); 
end

function FriendView:OpenView()
	FriendManager.UpdateFriendListData(nil);
	FriendManager.UpdateLatelyFriendList(function()
		if(_this.searchFriendPanel.activeSelf)then 
			FriendView.OnRecommendBtnClick()
		end
	end);
--[[ 	FriendView.OnRefreshListPanel(FriendManager.ListFriendDatas); ]]
	EventSys.instance:AddLuaEvent(GameEvent.UpdateFriendData,FriendView.ReceiveDataUpdate);
end

function FriendView:CloseView()
	self:DesView();
	EventSys.instance:RemoveLuaEvent(GameEvent.UpdateFriendData,FriendView.ReceiveDataUpdate);
--[[ 	FriendManager.OnRequestFriendList() ]]
end

function FriendView.ReceiveDataUpdate(evetId,obj)
	print("接收到好友数据更新的事件");
	FriendView.OnRefreshListPanel(FriendManager.ListFriendDatas)
end

function FriendView:DesView()
	_this.listInputField.text="";
	_this.addInputField.text="";
	FriendView.ClearAddPanel();
	FriendView.ClearRecommendAndLately();
end

function FriendView:InitBtn()
	AddFrendBtn.btnObj =  _this.addFrendBtn;
	AddFrendBtn.selectObj = _this.addFrendBtn.transform:Find("SelectIcon").gameObject;
	AddFrendBtn.selectObj:SetActive(false);
	FriendListBtn.selectObj = _this.friendListBtn.transform:Find("SelectIcon").gameObject;
	FriendListBtn.btnObj = _this.friendListBtn;
	FriendListBtn.selectObj:SetActive(false);
	currentSelectBtn = AddFrendBtn;
	currentSelectBtn.selectObj:SetActive(true);
	RecommendBtn.obj= _this.recommendBtn;
	RecommendBtn.selectObj = _this.recommendBtn.transform:Find("Select").gameObject;
	RecommendBtn.normarlObj = _this.recommendBtn.transform:Find("Normarl").gameObject;
	LatelyBtn.obj = _this.latelyBtn;
	LatelyBtn.selectObj = _this.latelyBtn.transform:Find("Select").gameObject;
	LatelyBtn.normarlObj = _this.latelyBtn.transform:Find("Normarl").gameObject;
	RecommendBtn.selectObj:SetActive(false);
	LatelyBtn.selectObj:SetActive(false);
	EventButtonListerer.Get(AddFrendBtn.btnObj, self.ShowSerchPanel)
	EventButtonListerer.Get(FriendListBtn.btnObj, self.ShowListPanel)
	EventButtonListerer.Get(_this.closeBtn, self.OnCloseClick)
	EventButtonListerer.Get(_this.addSearchBtn, self.OnAddSearchBtnClick)
	EventButtonListerer.Get(_this.listSearchBtn, self.OnListSearchBtnClick)
	EventButtonListerer.Get(_this.recommendBtn, self.OnRecommendBtnClick)
	EventButtonListerer.Get(_this.latelyBtn, self.OnLatelyBtnClick)
end

function FriendView.ShowSerchPanel()
	if(currentSelectBtn==addFrendBtn)then 
		print("当前已选中");
	end
	currentSelectBtn.selectObj:SetActive(false);
	currentSelectBtn = AddFrendBtn;
	currentSelectBtn.selectObj:SetActive(true);
	_this.searchFriendPanel:SetActive(true);
	_this.friendListPanel:SetActive(false);
	_this.listInputField.text="";
	FriendView.OnRecommendBtnClick();
end

function FriendView.ShowListPanel()
	if(currentSelectBtn==FriendListBtn)then 
		print("当前已选中");
	end
	currentSelectBtn.selectObj:SetActive(false);
	currentSelectBtn = FriendListBtn;
	currentSelectBtn.selectObj:SetActive(true);
	_this.searchFriendPanel:SetActive(false);
	_this.friendListPanel:SetActive(true);
	_this.addInputField.text="";
	FriendView.ClearAddPanel();
	FriendView.ClearRecommendAndLately();
	FriendView.OnRefreshListPanel(FriendManager.ListFriendDatas);
end

function FriendView.OnCloseClick()
	ViewSys.instance:Close("FriendView");
end

function FriendView.OnAddSearchBtnClick()
	print("添加好友列表搜索按钮点击");
	local name= _this.addInputField.text;
	print("当前搜索Name:"..name);
	FriendManager.QueryUserInfoFromName(name,
	function(datas)
		print("得到查找结果"..tostring(#datas))
		FriendView.OnRefreshAddPanel(datas);
	end);
end

function FriendView.CreateItem(item,parent)
	local obj = UnityEngine.GameObject.Instantiate(item);
	obj.gameObject:SetActive(true);
	obj.transform:SetParent(parent);
	obj.transform.localScale = Vector3.one;
	obj.transform.localPosition = Vector3.zero;
	return obj;
end

function FriendView.ClearAddPanel()
	for i=1,#HadInstanceAddItem do
		HadInstanceAddItem[i].obj:SetActive(false);
	end
end

function FriendView.ClearListPanel()
	for i=1,#HadInstanceListItem do
		HadInstanceListItem[i].obj:SetActive(false);
	end
end

function FriendView.OnRefreshAddPanel(datas)
	FriendView.ClearAddPanel();
	print(#datas);
	print(#HadInstanceAddItem);
	for i=1,#datas do 
		if(i>#HadInstanceAddItem)then 
			local obj = FriendView.CreateItem(_this.searchFriendItem,_this.searchContent);
			local item = FriendItem.Init(obj,datas[i]);
			table.insert(HadInstanceAddItem,item);
		else
			HadInstanceAddItem[i].obj:SetActive(true);
			HadInstanceAddItem[i]:UpdateView(datas[i],true);
		end
	end
	--[[ data.user_id=v.user_id;
	data.user_name=v.user_name;
	data.logoutTime=v.logoutTime;
	data.online_statu=v.online_statu; ]]
end

function FriendView.OnListSearchBtnClick()
	print("好友列表搜索按钮点击");
	local name= _this.listInputField.text;
	print("当前搜索Name:"..name);
	local ids = FriendManager.FindFriendWithName(name)
	local datas={};
	for i,v in pairs(ids) do
		local data = FriendManager.ListFriendDatas[v];
		table.insert(datas,data);
	end
	FriendView.OnRefreshListPanel(datas);
end

function FriendView.OnRecommendBtnClick()
	RecommendBtn.selectObj:SetActive(true);
	RecommendBtn.normarlObj:SetActive(false);
	LatelyBtn.selectObj:SetActive(false);
	LatelyBtn.normarlObj:SetActive(true);
	print("TODO：列表显示");
	FriendView.OnRefreshAddPanel(FriendManager.RecommendFriendList);
end

function FriendView:OnLatelyBtnClick()
	RecommendBtn.selectObj:SetActive(false);
	RecommendBtn.normarlObj:SetActive(true);
	LatelyBtn.selectObj:SetActive(true);
	LatelyBtn.normarlObj:SetActive(false);
	print("TODO：列表显示");
	FriendView.OnRefreshAddPanel(FriendManager.LatelyFriendList);
end

function FriendView.ClearRecommendAndLately()
	RecommendBtn.selectObj:SetActive(false);
	RecommendBtn.normarlObj:SetActive(true);
	LatelyBtn.selectObj:SetActive(false);
	LatelyBtn.normarlObj:SetActive(true);
end

function FriendView.OnRefreshListPanel(datas)
	print("刷新好友列表");
	FriendView.ClearListPanel();
	local i=1;
	for v,data in pairs(datas) do
		if(i>#HadInstanceListItem)then 
			local obj = FriendView.CreateItem(_this.listFriendItem,_this.listContent);
			local item = FriendItem.Init(obj,data);
			table.insert(HadInstanceListItem,item);
		else
			HadInstanceListItem[i].obj:SetActive(true);
			HadInstanceListItem[i]:UpdateView(data,false);
		end
		i=i+1;
	end
end
