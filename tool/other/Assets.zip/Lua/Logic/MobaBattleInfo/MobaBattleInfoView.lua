﻿--Moba战斗信息界面
MobaBattleInfoView = class("MobaBattleInfoView",MobaBattleInfoViewUI)

local BattleInfoEnum = {}
BattleInfoEnum.BaseInfo = 1
BattleInfoEnum.Skill = 2

local this
local isGameOver = false
local curSelectTab = BattleInfoEnum.BaseInfo
local img_showInfo = false
local img_showSkill = false
local lineMask = false

local maxPlaerNum = 6
local playerInfoItemTable = {}

local maxSkillCount = 3

function MobaBattleInfoView:Init()
	this = self
	local HeroList = BattleScene.instance.lstHero
	maxPlaerNum = HeroList.Count
	self:InitReference()
	self:RegeditEvent()
end

--初始化引用
function MobaBattleInfoView:InitReference()
	img_showInfo = self.btn_showInfo:GetComponent("Image")
	img_showSkill = self.btn_showSkill:GetComponent("Image")
	lineMask = self.lineConitaner:GetComponent("Mask")
end

--刷新所有显示
function MobaBattleInfoView:RefreshAll()
	this:RefreshPlayerInfo()
	this:RefreshSelectStatus() --刷新选中状态
	this:RefreshCampInfo() --刷新队伍击杀和积分等信息
	this:RefreshHeroSkillInfo() --刷新英雄技能信息
end

--刷新单个英雄技能信息
function MobaBattleInfoView:RefreshSingleHeroSkill(skillDataArr,index,listID)
	for i = 0,maxSkillCount - 1 do
		local skillList = playerInfoItemTable[index]["skillList"..listID]
		if i < skillDataArr.Count then
			skillList[i].gameObject:SetActive(true)
			local skillID = skillDataArr[i]
			UIUtil.SetSpriteByPath(skillList[i], "Skill/"..skillID..".png", true)
		else
			skillList[i].gameObject:SetActive(false)
		end
	end
end

--刷新所有英雄技能信息
function MobaBattleInfoView:RefreshHeroSkillInfo()
	local skillReplaceComp = BattleInfo.coreGaming:GetSysComp(EGamingSysCompType.ReplaceSkill)

	local HeroList = BattleScene.instance.lstHero
	for i = 0,HeroList.Count - 1 do
		local unit = HeroList[i]
		local func1 = function(skillDataArr)
			this:RefreshSingleHeroSkill(skillDataArr,i,1)
		end
		local func2 = function(skillDataArr)
			this:RefreshSingleHeroSkill(skillDataArr,i,2)
		end
		skillReplaceComp:GetSkillId(unit,func1,func2)

		local skill = unit.unitAttack:GetActiveSkillByIdx(2)
		local img_heroskill = playerInfoItemTable[i].img_heroskill
		UIUtil.SetSpriteByPath(img_heroskill, "Skill/"..skill.id..".png", true)
	end
	
end

--刷新队伍击杀和积分等信息
function MobaBattleInfoView:RefreshCampInfo()
	local mobaGamingOccupy = BattleInfo.coreGaming:GetSysComp(EGamingSysCompType.MobaOccupy)
	local blueScore = mobaGamingOccupy.blueScore
	local redScore = mobaGamingOccupy.redScore
	local statisticsComp = BattleInfo.coreGaming:GetSysComp(EGamingSysCompType.Statistics)
	
	local myKillNum = 0
	local enemyKillNum = 0
	local HeroList = BattleScene.instance.lstHero

	for i = 0,HeroList.Count - 1 do
		local unit = HeroList[i]
		local statistics = statisticsComp:GetStatisticsData(unit.id)

		if unit.camp == BattleScene.instance.mainHero.camp then
			myKillNum = myKillNum + statistics.kill
		else
			enemyKillNum = enemyKillNum + statistics.kill
		end
	end

	this.txt_myCampKillNum.text = myKillNum
	this.txt_myCampSocre.text = blueScore

	this.txt_enemyCampKillNum.text = enemyKillNum
	this.txt_enemyCampSocre.text = redScore
end

--刷新所有玩家信息
function MobaBattleInfoView:RefreshPlayerInfo()
	for i = 0,maxPlaerNum - 1 do
		if not playerInfoItemTable[i] then
			local playerItemObjData = {}
			if i == 0 then
				playerItemObjData.go = this.playerInfoItem
			else
				playerItemObjData.go = UnityEngine.GameObject.Instantiate(this.playerInfoItem)
				playerItemObjData.go.transform:SetParent(this.playerInfoContainer.transform, false)
			end

			playerItemObjData.maskBg = playerItemObjData.go:GetComponent("Image")
			playerItemObjData.playerBaseInfo = playerItemObjData.go.transform:Find("playerBaseInfo")
			playerItemObjData.playerSkill = playerItemObjData.go.transform:Find("playerSkill")

			playerItemObjData.txt_killNum = playerItemObjData.playerBaseInfo:Find("txt_killNum"):GetComponent("Text")
			playerItemObjData.txt_deathNum = playerItemObjData.playerBaseInfo:Find("txt_deathNum"):GetComponent("Text")
			playerItemObjData.txt_occupyTime = playerItemObjData.playerBaseInfo:Find("txt_occupyTime"):GetComponent("Text")
		
			playerItemObjData.img_heroIcon = playerItemObjData.go.transform:Find("img_heroIcon"):GetComponent("Image")
			playerItemObjData.txt_playerName = playerItemObjData.go.transform:Find("txt_playerName"):GetComponent("Text")
			playerItemObjData.txt_heroName = playerItemObjData.go.transform:Find("txt_heroName"):GetComponent("Text")
			playerItemObjData.img_isMyself = playerItemObjData.go.transform:Find("img_isMyself")
			playerItemObjData.img_heroskill = playerItemObjData.go.transform:Find("playerSkill/img_heroskill"):GetComponent("Image")

			playerItemObjData.skillList1 = {}
			playerItemObjData.skillList2 = {}
			for i = 0,maxSkillCount - 1 do
				playerItemObjData.skillList1[i] = playerItemObjData.go.transform:Find("playerSkill/skillList1/skill_"..i):GetComponent("Image")
				playerItemObjData.skillList2[i] = playerItemObjData.go.transform:Find("playerSkill/skillList2/skill_"..i):GetComponent("Image")
			end

			playerInfoItemTable[i] = playerItemObjData
		end

		this:RefreshSinglePlayerInfo(i)
	end
	
end

--刷新单个玩家信息
function MobaBattleInfoView:RefreshSinglePlayerInfo(index)
	--获取对象引用
	local playerItemObjData = playerInfoItemTable[index]
	local maskBg = playerItemObjData.maskBg
	local playerBaseInfo = playerItemObjData.playerBaseInfo
	local playerSkill = playerItemObjData.playerSkill
	local txt_killNum = playerItemObjData.txt_killNum
	local txt_deathNum = playerItemObjData.txt_deathNum
	local txt_occupyTime = playerItemObjData.txt_occupyTime
	local txt_playerName = playerItemObjData.txt_playerName
	local txt_heroName = playerItemObjData.txt_heroName
	local img_heroIcon = playerItemObjData.img_heroIcon
	local img_isMyself = playerItemObjData.img_isMyself

	--获取数据信息
	local HeroList = BattleScene.instance.lstHero
	local unit = HeroList[index]
	local heroInfo = HeroTable[unit.resId]
	local statisticsComp = BattleInfo.coreGaming:GetSysComp(EGamingSysCompType.Statistics)
	local statistics = statisticsComp:GetStatisticsData(unit.id)
	local min,second = TimeUtil.TranslateTimeFormat(statistics.occupyTime)

	txt_playerName.text = unit.name
	txt_heroName.text = heroInfo.hero_name
	UIUtil.SetSpriteByPath(img_heroIcon, heroInfo.icon)
	txt_killNum.text = statistics.kill
	txt_deathNum.text = statistics.die
	txt_occupyTime.text = min.."''"..second
	if curSelectTab == BattleInfoEnum.BaseInfo then
		playerBaseInfo.gameObject:SetActive(true)
		playerSkill.gameObject:SetActive(false)
	elseif curSelectTab == BattleInfoEnum.Skill then
		playerBaseInfo.gameObject:SetActive(false)
		playerSkill.gameObject:SetActive(true)
	end

	if unit.camp == BattleScene.instance.mainHero.camp then
		UIUtil.SetSpriteByPath(maskBg,"MobaBattleInfo/res_pnl9_base_blue.png", true)
	else
		UIUtil.SetSpriteByPath(maskBg,"MobaBattleInfo/res_pnl9_base_red.png", true)
	end

	if unit.id == BattleScene.instance.mainHero.id then
		img_isMyself.gameObject:SetActive(true)
	else
		img_isMyself.gameObject:SetActive(false)
	end
end

--刷新选中状态
function MobaBattleInfoView:RefreshSelectStatus()
	if curSelectTab == BattleInfoEnum.BaseInfo then
		UIUtil.SetSpriteByPath(img_showInfo, "MobaBattleInfo/fight_btn_statistics_light.png")
		UIUtil.SetSpriteByPath(img_showSkill, "MobaBattleInfo/fight_btn_skills.png")
		this.baseInfoContainer:SetActive(true)
		this.skillIconContainer:SetActive(false)
	elseif curSelectTab == BattleInfoEnum.Skill then
		UIUtil.SetSpriteByPath(img_showInfo, "MobaBattleInfo/fight_btn_statistics.png")
		UIUtil.SetSpriteByPath(img_showSkill, "MobaBattleInfo/fgiht_btn_skills_light.png")
		this.baseInfoContainer:SetActive(false)
		this.skillIconContainer:SetActive(true)
	end
	
end

--显示所有玩家基础信息
function MobaBattleInfoView:showPlayerBaseInfo()
	curSelectTab = BattleInfoEnum.BaseInfo
	this:RefreshAll()
end

--显示所有玩家技能信息
function MobaBattleInfoView:showPlayerSkill()
	curSelectTab = BattleInfoEnum.Skill
	this:RefreshAll()
end

function MobaBattleInfoView:ClosePanel()
	if isGameOver == false then
		ViewSys.instance:Close("MobaBattleInfoView")
	end
end

function MobaBattleInfoView:OpenView(param)
	if param.objParam then
		isGameOver = true
		this.mask.color = Color.New(1,1,1,1)
		this.mainContainer.color = Color.New(1,1,1,0)
		lineMask.enabled = false
		-- local achievement = param.objParam["achievement"];
		this.btn_back:SetActive(true)
		this.img_gameResult.gameObject:SetActive(true)

		local mainHero = BattleScene.instance.mainHero
		local occupyComp = BattleInfo.coreGaming:GetSysComp(EGamingSysCompType.MobaOccupy)
		local blueOccupy = occupyComp.blueScore
		local redOccupy = occupyComp.redScore
		if blueOccupy == redOccupy then
			UIUtil.SetSpriteByPath(this.img_gameResult, "Battle/res_icon_draw.png")
		elseif(blueOccupy > redOccupy) then
			if(mainHero.camp == ECamp.EBlue) then
				UIUtil.SetSpriteByPath(this.img_gameResult, "Battle/res_icon_victory.png")
			else
				UIUtil.SetSpriteByPath(this.img_gameResult, "Battle/res_icon_failed.png")
			end
		else
			if(mainHero.camp == ECamp.EBlue) then
				UIUtil.SetSpriteByPath(this.img_gameResult, "Battle/res_icon_failed.png")
			else
				UIUtil.SetSpriteByPath(this.img_gameResult, "Battle/res_icon_victory.png")
			end
		end
	else
		isGameOver = false
		this.mask.color = Color.New(1,1,1,0)
		this.mainContainer.color = Color.New(1,1,1,1)
		lineMask.enabled = true
		this.btn_back:SetActive(false)
		this.img_gameResult.gameObject:SetActive(false)
	end
	
	self:RefreshAll()
end

function MobaBattleInfoView:CloseView()
end

--返回主场景
function MobaBattleInfoView:BackMainScene()
	FightManager.ExitToLobby()
end

function MobaBattleInfoView:DestroyView()

end

function MobaBattleInfoView:RegeditEvent()
	EventButtonListerer.Get(self.btn_showInfo, self.showPlayerBaseInfo)
	EventButtonListerer.Get(self.btn_showSkill, self.showPlayerSkill)
	EventButtonListerer.Get(self.btn_back, self.BackMainScene)

	--点击遮罩关闭
	local onClickClose = function (go)
		this:ClosePanel()
	end
	EventTriggerListener.Get(self.mask.gameObject).onClick = EventTriggerListener.Get(self.mask.gameObject).onClick + onClickClose
end