﻿--From Lua Script Create
--ClassName: EquipmentShopManager
--Author:    hukiry
--CreateTime:2018-7-20

StrengthenEquipmentManager = class(StrengthenEquipmentManager)

StrengthenEquipmentManager.equipNum = 5
StrengthenEquipmentManager.materialNum = 5

function StrengthenEquipmentManager:Init()

end


