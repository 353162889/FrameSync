﻿--From Lua Script Create
--ClassName: StrengthenEquipmentView
--Author:    hukiry
--CreateTime:2018-7-23

require "Logic/StrengthenEquipment/StrengthenEquipmentManager"
StrengthenEquipmentView = class("StrengthenEquipmentView",StrengthenEquipmentViewUI)

local this

--装备翻页组件
local equipPageView

--翻页下方标识点
local pointArr = {}

local curSelectHeroInfo

--每个英雄对应的5个技能按钮
local equipBtnTable = {}

--装备突破解锁Item
local breakItemObjTable = {}

local heorListTable = {}

--显示已拥有英雄
local isShowHaveHero = true

function StrengthenEquipmentView:Init()
	this = self
	self:InitReference()  --初始化引用
	self:RegeditEvent()  --注册事件

	self:InitDefaultStatus() --初始化默认状态

	self:RefreshHeroList()  --刷新英雄列表
	
end

--初始化默认状态
function StrengthenEquipmentView:InitDefaultStatus()
	self.equipBreakContainer:SetActive(false)
	self.equipSelectContainer:SetActive(true)
	self.operateContainer:SetActive(false)
	this.img_select:SetActive(isShowHaveHero)
end

--显示英雄装备预览
function StrengthenEquipmentView:ShowHeroEquipPreview()
	if not curSelectHeroInfo then
		return
	end

	local heroID = curSelectHeroInfo.id

	self.equipBreakContainer:SetActive(false)
	self.equipSelectContainer:SetActive(true)
	self.operateContainer:SetActive(false)

	UIUtil.SetSpriteByPath(self.img_heroEquipIcon, "HeroIcon/"..heroID..".png")

	for index,v in pairs(equipBtnTable) do
		local equipID = MainLobbyManager.GetEquipID(heroID, index)
		print("强化装备|"..equipID)
		local img_equipIcon = v.img_equipIcon
		local equipInfo = ResEquipTable[equipID]
		UIUtil.SetSpriteByPath(img_equipIcon, equipInfo.icon)

	end
end

--获取当前英雄对应装备信息
function StrengthenEquipmentView:GetCurEquipInfo()
	local heroID = curSelectHeroInfo.id
	local index = equipPageView.curIndex
	local equipID,isUnlock = MainLobbyManager.GetEquipID(heroID, index)
	local equipInfo = ResEquipTable[equipID]
	return equipInfo,isUnlock
end

--创建装备突破 解锁item
function StrengthenEquipmentView:RefreshAllBreakItem()
	for i = 1,StrengthenEquipmentManager.equipNum do 
		local objData = {}
		if breakItemObjTable[i] then
			objData = breakItemObjTable[i]
		else
			if i == 1 then
				objData.go = self.equipBreakItem
			else
				objData.go = UnityEngine.GameObject.Instantiate(self.equipBreakItem)
				objData.go.transform:SetParent(equipPageView.content,false)
			end

			for j = 1,StrengthenEquipmentManager.materialNum do
				objData["img_material_"..j] = objData.go.transform:Find("img_material_"..j):GetComponent("Image")
				objData["txt_materialStatus_"..j] = objData.go.transform:Find("txt_materialStatus_"..j):GetComponent("Text")
				objData.img_curEquipIcon = objData.go.transform:Find("CurEquipIconBg/img_curEquipIcon"):GetComponent("Image")
				objData.img_nextEquipIcon = objData.go.transform:Find("NextEquipIconBg/img_nextEquipIcon"):GetComponent("Image")
				objData.txt_equipLevel = objData.go.transform:Find("txt_equipLevel"):GetComponent("Text")
			end
			table.insert(breakItemObjTable, objData)
		end
		
		self:RefreshSingleBreakItem(i)
	end
	
end

function StrengthenEquipmentView:RefreshSingleBreakItem(index)
	local objData = breakItemObjTable[index]
	local heroID = curSelectHeroInfo.id
	local equipID,isUnlock = MainLobbyManager.GetEquipID(heroID, index)
	local equipInfo = ResEquipTable[equipID]
	
	print("装备ID:"..equipInfo.id.."装备名字:"..equipInfo.name)
	
	local needItemTable = {}
	if isUnlock == false then
		needItemTable = equipInfo.need_item
	else
		if equipInfo.next_level_equipment ~= 0 then
			local nextEquipInfo = ResEquipTable[equipInfo.next_level_equipment]
			needItemTable = nextEquipInfo.need_item
		end
	end

	for index,stringData in pairs(needItemTable) do
		if type(stringData) == "string" then
			local dataArr = stringData:split("|")
			local itemCode = dataArr[1]
			local itemNum = dataArr[2]

			local itemInfo = ItemTable[tonumber(itemCode)]
			local hasNum = ItemMgr.GetItemNumByConfigId(itemCode)
			print("|需要道具ID : "..itemCode.." |拥有数量:"..hasNum)

			UIUtil.SetSpriteByPath(objData["img_material_"..index], itemInfo.icon)
			objData["txt_materialStatus_"..index].text = hasNum.."/"..itemNum
		end
	end

	print("--------------")
	-- print("isUnlock")
	-- print(isUnlock)
	-- print("nextEquipInfo")
	-- print(nextEquipInfo)

	UIUtil.SetSpriteByPath(objData.img_curEquipIcon, equipInfo.icon)
	objData.txt_equipLevel.text = ""
	if equipInfo.next_level_equipment == 0 then
		if isUnlock == true then
			objData.txt_equipLevel.text = "Lv - Max"
		end
	else
		local nextEquipInfo = ResEquipTable[equipInfo.next_level_equipment]
		UIUtil.SetSpriteByPath(objData.img_nextEquipIcon, nextEquipInfo.icon)
	end
	
end


--刷新英雄列表
function StrengthenEquipmentView:RefreshHeroList()
	for index,v in pairs(HeroTable) do

		--如果没有选中信息  第一个拥有的英雄算作默认选中对象
		if not curSelectHeroInfo then
			if MainLobbyManager.IsHeroBuy(v.id) == true then
				curSelectHeroInfo = v
				self:ShowHeroEquipPreview()
			end
		end

		local data = {}
		if heorListTable[index] then
			data = heorListTable[index]
		else
			local btn_heroIcon = UnityEngine.GameObject.Instantiate(self.btn_heroIcon)
			btn_heroIcon.transform:SetParent(self.heroListContent, false)
			local image = btn_heroIcon:GetComponent("Image")
			UIUtil.SetSpriteByPath(image, v.bigIcon)
			local clickHeroIcon = function()
				print("点击英雄ID:"..v.id)
				curSelectHeroInfo = v
				self:ShowHeroEquipPreview()
				self:RefreshHeroList()
			end

			EventButtonListerer.Get(btn_heroIcon, clickHeroIcon)

			data.go = btn_heroIcon
			data.img_heroSelect = btn_heroIcon.transform:Find("img_heroSelect").gameObject
			data.info = v
			heorListTable[index] = data
		end

		if isShowHaveHero == true then
			if MainLobbyManager.IsHeroBuy(v.id) == false then
				data.go:SetActive(false)
			end
		else
			data.go:SetActive(true)
		end

		if curSelectHeroInfo == v then
			print("相同ID:"..v.id)
			data.img_heroSelect:SetActive(true)
		else
			data.img_heroSelect:SetActive(false)
		end
	end

	self.btn_heroIcon:SetActive(false)
end

--初始化引用
function StrengthenEquipmentView:InitReference()
	equipPageView = self.equipScroll:GetComponent("CommonPageView")

	for i = 1,StrengthenEquipmentManager.equipNum do
		local objTable = {}
		objTable.btn = self["btn_equip_"..i]
		objTable.img_equipIcon = self["btn_equip_"..i].transform:Find("img_equipIcon"):GetComponent("Image")
		table.insert(equipBtnTable, objTable)
	end

	for i = 1,StrengthenEquipmentManager.equipNum do
		if i == 1 then
			pointArr[i] = self.img_point:GetComponent("Image")	
		else
			local img_point = UnityEngine.GameObject.Instantiate(self.img_point)
			img_point.transform:SetParent(self.pointLayout, false)
			pointArr[i] = img_point:GetComponent("Image")
		end
	end
end

function StrengthenEquipmentView:OpenView()
	self:ShowPageNum(1)
end

--显示页面
function StrengthenEquipmentView:ShowPageNum(index)
	equipPageView:SetPageNum(index)
	self:RefreshPointStatus(index)
end

--刷新页面点
function StrengthenEquipmentView:RefreshPointStatus(index)
	if not index then
		index = equipPageView.curIndex
	end
	print("index : "..index)
	for k,v in pairs(pointArr) do
		if k == index then
			UIUtil.SetSpriteByPath(v, "StrengthenEquipment/equipment_icon_no_02.png")
		else
			UIUtil.SetSpriteByPath(v, "StrengthenEquipment/equipment_icon_off_02.png")
		end
	end
end

function StrengthenEquipmentView:CloseView()
	
end

function StrengthenEquipmentView:DestroyView()

end

function StrengthenEquipmentView:ClosePanel()
	ViewSys.instance:Close("StrengthenEquipmentView")
end

--刷新装备描述
function StrengthenEquipmentView:RefreshEquipDesc()
	local equipInfo,isUnlock = self:GetCurEquipInfo()
	UIUtil.SetSpriteByPath(self.img_showEquipIcon, equipInfo.icon)
	self.txt_equipName.text = equipInfo.name
	self.txt_equipDesc.text = equipInfo.desc
	self.txt_costSliver.text = equipInfo.silver
	
	-- print("isUnlock"..isUnlock)
	if isUnlock == true then
		self.btn_break:SetActive(true)
		self.btn_unlock:SetActive(false)
	else
		self.btn_break:SetActive(false)
		self.btn_unlock:SetActive(true)
	end

end

function StrengthenEquipmentView:operateCurEquipment()
	if not curSelectHeroInfo then
		print("强化装备|没有选定装备!")
		return
	end

	local equipInfo = this:GetCurEquipInfo()

	local data = C2S_OperatHeroEquipmentData()
	data.hero_id = curSelectHeroInfo.id
	data.equipment_id = equipInfo.id

	print("强化装备|解锁或强化-heroID:"..data.hero_id)
	print("强化装备|解锁或强化-equipment_id:"..data.equipment_id)

	NetSys.instance:SendWorldMsg(data:SerializeToString(), C2S_OperatHeroEquipment);
end

--英雄数据发生变化
function StrengthenEquipmentView:HeroChangeRes(eventId,args)
	print("HeroChangeRes")
	this:RefreshEquipDesc()  --刷新装备描述和突破按钮状态
	this:RefreshAllBreakItem()  --刷新所有装备突破Item
end

function StrengthenEquipmentView:switchShowMode()
	isShowHaveHero = not isShowHaveHero
	this.img_select:SetActive(isShowHaveHero)
	this:RefreshHeroList()
end

function StrengthenEquipmentView:RegeditEvent()
	EventSys.instance:AddLuaEvent(GameEvent.HeroSync, self.HeroChangeRes);

	local moveEndCallback = function(index)
		self:RefreshEquipDesc()
		self:RefreshPointStatus()
		-- self:RefreshSingleBreakItem(index)
	end

	equipPageView:SetMoveEndCallback(moveEndCallback)

	--点击装备  打开解锁和突破界面
	for index,v in pairs(equipBtnTable) do
		local clickEquip = function()
			self.equipBreakContainer:SetActive(true)
			self.equipSelectContainer:SetActive(false)
			self.operateContainer:SetActive(true)
			self:ShowPageNum(index)  --显示指定页面
			self:RefreshEquipDesc()  --刷新装备描述和突破按钮状态
			self:RefreshAllBreakItem()  --刷新所有装备突破Item
		end
		EventButtonListerer.Get(v.btn, clickEquip)
	end
	
	EventButtonListerer.Get(this.btn_close, this.ClosePanel)
	EventButtonListerer.Get(this.btn_unlock, this.operateCurEquipment)
	EventButtonListerer.Get(this.btn_break, this.operateCurEquipment)
	EventButtonListerer.Get(this.btn_switchShowHero, this.switchShowMode)
	local onClickClose = function (go)
		this:ClosePanel()
	end
	EventTriggerListener.Get(self.mask).onClick = EventTriggerListener.Get(self.mask).onClick + onClickClose

end