--From Lua Script Create
--ClassName: HelpView
--Author:    hukiry
--CreateTime:2018-7-14

HelpView = class("HelpView",HelpViewUI)

local _this;
local CloseCallBack=nil;

function HelpView:Init()
	_this=self;
	EventButtonListerer.Get(self.bgBtn, self.OnCloseClick);
	EventButtonListerer.Get(self.closeBtn, self.OnCloseClick);
end

function HelpView:OpenView(param)
	local objParam = param.objParam;
	self.contentText.text = objParam.text;
	CloseCallBack = objParam.callBack;
end

function HelpView.ClearView()
	_this.contentText.text="";
end

function HelpView.OnCloseClick()
	if(CloseCallBack~=nil)then 
		CloseCallBack();
		CloseCallBack = nil;
	end
	HelpView.ClearView();
	ViewSys.instance:Close("HelpView")
end