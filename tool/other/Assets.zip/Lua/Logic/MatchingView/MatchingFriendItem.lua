--From Lua Script Create
--ClassName: MatchingFriendItem
--Author:    hukiry
--CreateTime:2018-7-9
require "Logic/MatchingView/MatchingManager"

MatchingFriendItem = class("MatchingFriendItem")

function MatchingFriendItem.Init(obj,data)
	local item = MatchingFriendItem.new();
	item.obj = obj;
	item.head = obj.transform:Find("HeadIcon"):GetComponent("Image");
	item.name = obj.transform:Find("NameText"):GetComponent("Text");
	item.currentState = nil;
	item.currentTimer = nil;
	item.NormalState={};
	item.RefuseState={};
	item.HadInvitedState={};
	item.InTeamState={};
	item.RefuseTimer={};
	item.HadInvitedTimer={};
	item.NormalState.obj = obj.transform:Find("States/NormalState").gameObject;
	item.RefuseState.obj = obj.transform:Find("States/RefuseState").gameObject;
	item.RefuseTimer.Text = obj.transform:Find("States/RefuseState/RefuseTime"):GetComponent("Text");
	item.RefuseTimer.MarkTime =nil;
	item.RefuseTimer.MaxCostTime = 0;
	item.RefuseTimer.CallBack=function()
		print("从拒绝状态回到默认状态");
		item:ToNormalState();
	end
	item.HadInvitedState.obj = obj.transform:Find("States/HadInvitedState").gameObject;
	item.HadInvitedTimer.Text = obj.transform:Find("States/HadInvitedState/HadInvitedTime"):GetComponent("Text");
	item.HadInvitedTimer.MarkTime =nil;
	item.HadInvitedTimer.MaxCostTime = 0;
	item.HadInvitedTimer.CallBack=function()
		print("从已邀请状态到默认状态");
		item:ToNormalState()
	end
	item.InTeamState.obj = obj.transform:Find("States/InTeamState").gameObject;
	local InviteClick = function()
		item:InviteFriend();
	end
	EventButtonListerer.Get(item.NormalState.obj, InviteClick);
	item.currentState = item.NormalState;
	item.RefuseState.obj:SetActive(false);
	item.HadInvitedState.obj:SetActive(false);
	item.InTeamState.obj:SetActive(false);

	item:RefreshItem(data);
	return item
end

function MatchingFriendItem:RefreshItem(data)
	if(MatchingManager.TeamListDatas[data.user_id]~=nil)then 
		self:ToInTeamState();
	else 
		if(self.currentState~=self.HadInvitedState and self.currentTimer==nil)then 
			self:ToNormalState();
		end
	end
	self.data= data;
	self.obj:SetActive(true);
	self.name.text = data.user_name;
end

function MatchingFriendItem:ClearItem()
	self.obj:SetActive(false);
	self.currentTimer=nil;
	self:ToNormalState();
end

function MatchingFriendItem:InviteFriend()
	print("邀请好友"..self.data.user_name);
	self:ToHadInvitedState();
end

function MatchingFriendItem:ToHadInvitedState()
	print("TO已邀请状态");
	self.currentState.obj:SetActive(false);
	self.currentState = self.HadInvitedState;
	self.currentState.obj:SetActive(true);
	self.currentTimer = self.HadInvitedTimer;
	LuaHelper.SetMatchingTimer(self.data.user_id);
--[[ 	self.currentTimer.MarkTime=System.DateTime.Now; ]]
	self.currentTimer.MaxCostTime=20;
	self.currentTimer.Text.text="20s";
	MatchingManager.OnRequestTeamInvite(self.data.user_id);
end

function MatchingFriendItem:ToNormalState()
	print("TO默认状态");
	self.currentState.obj:SetActive(false);
	self.currentState = self.NormalState;
	self.currentState.obj:SetActive(true);
	self.currentTimer=nil;
end

function MatchingFriendItem:ToRefuseState()
	print("TO拒绝状态");
	self.currentState.obj:SetActive(false);
	self.currentState = self.RefuseState;
	self.currentState.obj:SetActive(true);
	self.currentTimer = self.RefuseTimer;
	LuaHelper.SetMatchingTimer(self.data.user_id);
	self.currentTimer.MaxCostTime=20;
	self.currentTimer.Text.text="20s";
end

function MatchingFriendItem:ToInTeamState()
	print("TO组队状态");
	self.currentState.obj:SetActive(false);
	self.currentState = self.InTeamState;
	self.currentState.obj:SetActive(true);
	self.currentTimer=nil;
end

function MatchingFriendItem:Update(deltaTime)
	if(self.currentTimer==nil)then
		return
	end
	local second = LuaHelper.GetCostTime(self.data.user_id,self.currentTimer.MaxCostTime);
	self.currentTimer.Text.text = tostring(second).."s";
	if(second<=0)then
		self.currentTimer.Text.text = "0s";
		self.currentTimer.CallBack();
		self.currentTimer=nil;
	end
end