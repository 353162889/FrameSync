--From Lua Script Create
--ClassName: MatchingPlayerItem
--Author:    hukiry
--CreateTime:2018-7-11
require "Logic/MatchingView/MatchingManager"
MatchingPlayerItem = class("MatchingPlayerItem")

function MatchingPlayerItem.Init(obj,data)
	local item = MatchingPlayerItem.new();
	item.obj = obj;
	item.data = data;
	item.selectObj = obj.transform:Find("SelectObj").gameObject;
	item.selectObj:SetActive(false);
	return item;
end

function MatchingPlayerItem:RefreshItem(data)
	self.data = data;
	self.selectObj:SetActive(false);
end

function MatchingPlayerItem:ActiveItem(isReady)
	for i=0,self.obj.transform.parent.childCount-1 do
		if(self.obj.transform.parent:GetChild(i)==self.obj.transform)then 
			print(i);
		end
	end
	print("item亮起或关闭"..tostring(isReady));
	self.selectObj:SetActive(isReady);
end
