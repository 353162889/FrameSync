--From Lua Script Create
--ClassName: MatchingManager
--Author:    hukiry
--CreateTime:2018-7-10

MatchingManager = class(MatchingManager)

MatchingManager.TeamListDatas={}
MatchingManager.mOtherTeammate = {};
MatchingManager.isReady=false;
MatchingManager.MatchPlayerInfos={};--匹配到的玩家
MatchingManager.MatchPlayerDetailsDic={};--玩家的详情
MatchingManager.MatchId=nil;
MatchingManager.ReadyClickBack =nil;
MatchingManager.isBeInVited = false;

function MatchingManager.Init()
	MatchingManager.RegeditEvent()
end

function MatchingManager.RegeditEvent()
	NetSys.instance:AddMsgCallback(EChannelType.EWorldChannel, S2C_TeamInviteNotify,MatchingManager.OnReceiveTeamInviteNotify, nil);
	NetSys.instance:AddMsgCallback(EChannelType.EWorldChannel, S2C_TeamInfo,MatchingManager.OnReceiveTeamInfo, nil);
	NetSys.instance:AddMsgCallback(EChannelType.EWorldChannel, S2C_TeamInviteRefuseNotify,MatchingManager.OnReceiveTeamInviteRefuseNotify, nil);
	NetSys.instance:AddMsgCallback(EChannelType.EWorldChannel, S2C_TeamMemberJoin,MatchingManager.OnReceiveTeamMemberJoin, nil);
	NetSys.instance:AddMsgCallback(EChannelType.EWorldChannel, S2C_TeamMemberExit,MatchingManager.OnReceiveTeamMemberExit, nil);
	NetSys.instance:AddMsgCallback(EChannelType.EWorldChannel, S2C_TeamSetStatuCallBack,MatchingManager.OnReceiveTeamSetStatu, nil);
	NetSys.instance:AddMsgCallback(EChannelType.EWorldChannel, S2C_TeamLeaveCallBack,MatchingManager.OnReceiveTeamLeave, nil);
	NetSys.instance:AddMsgCallback(EChannelType.EWorldChannel, S2C_MatchPlayerList,MatchingManager.OnReceiveMatchInfo, nil);
	NetSys.instance:AddMsgCallback(EChannelType.EWorldChannel, S2C_MatchReadyNotify,MatchingManager.OnReceiveMatchReadyNotify, nil);	
	NetSys.instance:AddMsgCallback(EChannelType.EWorldChannel, S2C_MatchTeamPushInTop,MatchingManager.OnReceiveCancelToPlay, nil);
	NetSys.instance:AddMsgCallback(EChannelType.EWorldChannel, S2C_MatchSelectHeroSetp,MatchingManager.OnReceiveToSelectHero, nil);
	EventSys.instance:AddLuaEvent(GameEvent.FightFinish,MatchingManager.OnReceiveFightFinish);
end

function MatchingManager.OnReceiveFightFinish(eventId,obj)
	print("接收到战斗返回的消息")
	local number = MatchingManager.CheckTeamData();
	print("当前队伍数量"..tostring(number));
	if(number==0)then 
		return;
	end
	if(number>1)then 
	    VoiceHelper:ChangeToTeamChannel();
		ViewSys.instance:Open("MatchingView"); 
	else
		MatchingManager.OnRequestTeamLeaveData();
	end
end

function MatchingManager.OnRequsetCreatTeam()
	print("主动创建队伍");
	local data = C2S_TeamCreateData()
	data.match_id = MatchingManager.MatchId;
	NetSys.instance:SendWorldMsg(data:SerializeToString(), C2S_TeamCreate);
end

function MatchingManager.OnReQuestMatchReady()
	print("发送匹配准备");
	local data = C2S_MatchReadyOperatData()
	data.operat = true;
	NetSys.instance:SendWorldMsg(data:SerializeToString(), C2S_MatchReadyOperat);
end

function MatchingManager.OnRequestTeamInvite(id)
	print("发送组队请求")
	local data = C2S_TeamInviteData()
	data.user_id = id;
	data.match_id = MatchingManager.MatchId;
	NetSys.instance:SendWorldMsg(data:SerializeToString(), C2S_TeamInvite);
end

function MatchingManager.OnRequestTeamInviteResult(isAgree)
	print("发送队伍邀请处理")
	local data = C2S_TeamInviteResponData()
	data.is_agree = isAgree;
	NetSys.instance:SendWorldMsg(data:SerializeToString(), C2S_TeamInviteRespon);
end

function  MatchingManager.OnRequestTeamLeaveData()
	print("发送离开队伍请求")
	local data = C2S_TeamLeaveData()
	NetSys.instance:SendWorldMsg(data:SerializeToString(), C2S_TeamLeave);
end

function  MatchingManager.OnRequestTeamSetStatu()
	print("发送组队准备或取消请求")
	local data = C2S_TeamSetStatuData()
	NetSys.instance:SendWorldMsg(data:SerializeToString(), C2S_TeamSetStatu);
end

function MatchingManager.OnReceiveTeamInviteRefuseNotify(this,objMsg)
	print("接收到拒绝组队邀请通知")
	local msg =S2C_TeamInviteRefuseNotifyData();
	msg:ParseFromString(objMsg);
	print("msg.id"..msg.user_id)
	MatchingManager.MatchId = msg.match_id;
	print("接收到地图信息-->"..MatchingManager.MatchId);
	MatchingView.RefuseInvite(msg.user_id)
end

function MatchingManager.OnReceiveTeamInfo(this,objMsg)
	local msg = S2C_TeamInfoData(); 
	msg:ParseFromString(objMsg); 
	print("接收到队伍信息-->"..#msg.team_member_list);
	MatchingManager.MatchId = msg.match_id;
	print("接收到地图信息-->"..MatchingManager.MatchId);
	MatchingManager.TeamListDatas={};
	local isSelfTeam=false --判断是否是自己一个人的队伍;
	local ids ={}	
	for i=1, #msg.team_member_list do
		local data ={};
		data.user_id =  msg.team_member_list[i].user_id;
		data.statu =  msg.team_member_list[i].statu;
		print(tostring(data.statu))
		data.index =i;
		if(data.user_id==LoginInfo.userId)then 
			MatchingManager.isReady = data.statu==2;
			if #msg.team_member_list > 1 then
				VoiceHelper:LoginTeam(data.user_id, data.team_id);
			end
		end
		MatchingManager.TeamListDatas[data.user_id]=data;
		table.insert(ids,data.user_id);
	end
	if(#msg.team_member_list==1)then 
		isSelfTeam = true;
		MatchingView.RefreshMatchingView(isSelfTeam)
		VoiceHelper:Logout();
	else
		isSelfTeam = false
		FriendManager.QueryUserInfoFromID(ids,
		function(datas)
			for i=1,#datas do
				if(MatchingManager.TeamListDatas[datas[i].user_id]~=nil)then 
					MatchingManager.TeamListDatas[datas[i].user_id].user_name = datas[i].user_name;
					MatchingManager.TeamListDatas[datas[i].user_id].logoutTime = datas[i].logoutTime;
					MatchingManager.TeamListDatas[datas[i].user_id].online_statu = datas[i].online_statu;
				end
			end
			if(ViewSys.instance:IsOpen("MatchingView")) then
				MatchingView.RefreshMatchingView(isSelfTeam)
				if(MatchingManager.ReadyClickBack~=nil)then
					MatchingManager.ReadyClickBack();
					MatchingManager.ReadyClickBack=nil;
				end
			end
		end)
	end
end

function MatchingManager.OnReceiveMatchInfo(this,objMsg)
	print("接收到匹配到的玩家")
	MatchingManager.MatchPlayerInfos={};
	local msg = S2C_MatchPlayerListData(); 
	msg:ParseFromString(objMsg);
	print("---------11-----------");
	print("队伍1的数量"..tostring(#msg.team_1_player_list));
	print("队伍2的数量"..tostring(#msg.team_2_player_list));
	print("机器人队伍1的数量"..tostring(#msg.team_1_robot_list));
	print("机器人队伍2的数量"..tostring(#msg.team_2_robot_list));
	print("匹配到的玩家和机器人总数量"..tostring(#msg.team_1_robot_list+#msg.team_2_robot_list+#msg.team_1_player_list+#msg.team_2_player_list));
	local ids ={};
	local lstTeam = nil;
	for i=1,#msg.team_1_player_list do
		print(msg.team_1_player_list[i]);
		if(LoginInfo.userId==msg.team_1_player_list[i])then 
			MatchingManager.MatchPlayerInfos.selfTeamInfo = msg.team_1_player_list;
			MatchingManager.MatchPlayerInfos.otherTeamInfo =msg.team_2_player_list;
			MatchingManager.MatchPlayerInfos.selfRebootInfo = msg.team_1_robot_list;
			MatchingManager.MatchPlayerInfos.otherRebootInfo = msg.team_2_robot_list;
			lstTeam = msg.team_1_player_list;
		end
		table.insert(ids,msg.team_1_player_list[i]);
	end
	for i=1,#msg.team_2_player_list do
		print(msg.team_2_player_list[i]);
		if(LoginInfo.userId==msg.team_2_player_list[i])then 
			MatchingManager.MatchPlayerInfos.selfTeamInfo = msg.team_2_player_list;
			MatchingManager.MatchPlayerInfos.otherTeamInfo =msg.team_1_player_list;
			MatchingManager.MatchPlayerInfos.selfRebootInfo = msg.team_2_robot_list;
			MatchingManager.MatchPlayerInfos.otherRebootInfo = msg.team_1_robot_list;
			lstTeam = msg.team_2_player_list;
		end
		table.insert(ids,msg.team_2_player_list[i]);
	end

	MatchingManager.mOtherTeammate = {};
	for i = 1, #lstTeam do
		table.insert(MatchingManager.mOtherTeammate, lstTeam[i]);
	end

	local PlayerDatas = {};
	PlayerDatas.team1RebootData = msg.team_1_robot_list;
	PlayerDatas.team2RebootData = msg.team_2_robot_list;
	local rebootDatas ={};
	for i=1,#msg.team_1_robot_list do
		table.insert(rebootDatas,msg.team_1_robot_list[i]);
	end
	for i=1,#msg.team_2_robot_list do
		table.insert(rebootDatas,msg.team_2_robot_list[i]);
	end
	--[[ print("---------22-----------");
	print("队伍1的数量"..tostring(#msg.team_1_player_list));
	print("队伍2的数量"..tostring(#msg.team_2_player_list));
	print("机器人队伍1的数量"..tostring(#msg.team_1_robot_list));
	print("机器人队伍2的数量"..tostring(#msg.team_2_robot_list));
	print("匹配到的玩家和机器人总数量"..tostring(#msg.team_1_robot_list+#msg.team_2_robot_list+#msg.team_1_player_list+#msg.team_2_player_list)); ]]
	
	FriendManager.QueryUserInfoFromID(ids,
	function(datas)
		print(#datas);
		MatchingView.ClearPlayerList();
		MatchingView.UpdateRebootList(rebootDatas);
		PlayerDatas.userData = datas;--玩家数据
		
		MatchingView.ToReadyToPlayState(PlayerDatas)
	end)
	--将自己移除出自己队伍列表
	for i=1,#MatchingManager.MatchPlayerInfos.selfTeamInfo do
		if(LoginInfo.userId==MatchingManager.MatchPlayerInfos.selfTeamInfo[i])then 
			table.remove(MatchingManager.MatchPlayerInfos.selfTeamInfo,i);
			return;
		end
	end
end

function MatchingManager.OnReceiveTeamInviteNotify(this,objMsg)
	print("接收到组队请求");
	local msg = S2C_TeamInviteNotifyData(); 
	msg:ParseFromString(objMsg);
	local id = msg.user_id;
	MatchingManager.MatchId =msg.match_id;
	print("接收到地图信息-->"..MatchingManager.MatchId);
	print(id);
	if(FriendManager.ListFriendDatas[id]~=nil)then 
		MatchingManager.ShowTeamInvitePanel(FriendManager.ListFriendDatas[id].user_name);
	else
		local ids ={};
		table.insert(ids,id);
		FriendManager.QueryUserInfoFromID(ids,function(datas)
		MatchingManager.ShowTeamInvitePanel(datas[1].user_name)
				--[[ local data={};
				data.user_id=v.user_id;
				data.user_name=v.user_name;
				data.logoutTime=v.logoutTime;
				data.online_statu=v.online_statu;]]
		end)
	end
end

function MatchingManager.OnReceiveTeamMemberJoin(this,objMsg)
	print("接收到成员加入");
	local msg = S2C_TeamMemberJoinData();
	msg:ParseFromString(objMsg);
	local id = msg.user_id;
	print(id);
	MatchingView.FriendAddTeam(id)
end

function MatchingManager.OnReceiveTeamMemberExit(this,objMsg)
	print("接收到成员离开")
	local msg = S2C_TeamMemberExitData();
	msg:ParseFromString(objMsg);
	local id = msg.user_id;
	print(id);
	MatchingView.FriendLeave(id)
end

function MatchingManager.OnReceiveTeamLeave(this,objMsg)
	print("接收到自己离开的消息")
	local msg = S2C_TeamLeaveCallBackData();
	msg:ParseFromString(objMsg);
	MatchingManager.TeamListDatas={}
	VoiceHelper:Logout();
end

function MatchingManager.OnReceiveTeamSetStatu(this,objMsg)
	local msg = S2C_TeamSetStatuCallBackData();
	msg:ParseFromString(objMsg);
	local statu = msg.team_statu;
	print("接收到准备或取消"..statu);
--[[ 	TeamMemberStatuType_Idle = 1;			//空闲状态
	TeamMemberStatuType_Ready = 2;			//准备状态 ]]
	if(statu == TeamMemberStatuType_Idle) then
		MatchingManager.isReady = false;
	else if(statu == TeamMemberStatuType_Ready) then
		MatchingManager.isReady=true;
	end
end
	if(ViewSys.instance:IsOpen("MatchingView")) then
		MatchingView.ReceiveReadyOrCancel(MatchingManager.isReady);
	end
end

function MatchingManager.OnReceiveMatchReadyNotify(this,objMsg)
	local msg = S2C_MatchReadyNotifyData();
	msg:ParseFromString(objMsg);
	print("接收到匹配到的玩家准备或取消的消息-->id"..msg.user_id.."----bool"..tostring(msg.operat));
	MatchingView.ActviePlayerItem(msg.user_id,msg.operat);
end

function MatchingManager.OnReceiveCancelToPlay(this,objMsg)
	print("接收到进入游戏中断的消息");
	local msg = S2C_MatchTeamPushInTopData();
	msg:ParseFromString(objMsg);
	MatchingView.ToMatchingState();
end

function MatchingManager.OnReceiveToSelectHero(this,objMsg)
	print("接收到进入选择英雄的消息");
	local msg = S2C_MatchSelectHeroSetpData();
	msg:ParseFromString(objMsg);
	local MapData=ViewParam();
	MapData.objParam = {MatchId=1};
	MapData.objParam["MatchId"]=MatchingManager.MatchId;
	ViewSys.instance:Close("MatchingView");
	ViewSys.instance:Open("SelectHeroView",MapData);

	--切换到房间聊天频道
	VoiceHelper:LoginRoom(LoginInfo.userId, msg.chat_channel_id);
end

function MatchingManager.ShowTeamInvitePanel(name)
	local content =name.."想要与你组队";
	local confirmCallback =function()
		print("同意组队")
		MatchingManager.isBeInVited = true;
		MatchingManager.OnRequestTeamInviteResult(true);
		if(ViewSys.instance:IsOpen("MatchingView")) then
			MatchingView.RefreshMatchingView()
		else
			ViewSys.instance:Open("MatchingView");
		end
	end
	local cancelCallBack = function()
		print("拒绝组队")
		MatchingManager.OnRequestTeamInviteResult(false);
	end
	TipMgr.ShowTipType1(content,confirmCallback,cancelCallBack,cancelCallBack,cancelCallBack);
end

function MatchingManager.CheckTeamData()
	local number =0;
	for v,k in pairs(MatchingManager.TeamListDatas) do
		if(k~=nil)then 
			number=number+1;
		end
	end
	print("队伍成员数量"..number);
	return number;
end


