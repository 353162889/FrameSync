--From Lua Script Create
--ClassName: MatchingView
--Author:    hukiry
--CreateTime:2018-7-9

require "Logic/MatchingView/MatchingFriendItem"
require "Logic/MatchingView/MatchingPlayerItem"
require "Logic/Voice/VoiceHelper"

MatchingView = class("MatchingView",MatchingViewUI)

local _this;

local isFriendBtnClick = true;

local isReadyOrCancelClick = false;

local FriendItemList = {};

local TeamItemList={};

local PlayerItemList ={};

local ReadyClickSpacing=0;

local isMatching = false;

local isReadyToPlay =false;

local ReadyToPlayMaxTime=0;

local activeImageColor =nil;

local normalImageColor =nil;

local activeTitleColor =nil;

local normalTitleColor =nil;

local rebootIconList = {};


function MatchingView:Init()
	_this=self;
	self:RegeditEvent();
	self.matchingFriendItem:SetActive(false);
	for i=1,self.inTeamList.childCount-1 do
		local item ={};
		item.obj = self.inTeamList:GetChild(i).gameObject;
		item.head = self.inTeamList:GetChild(i):Find("HeadIcon/TeampHead"):GetComponent("Image");
		item.nameText = self.inTeamList:GetChild(i):Find("Name"):GetComponent("Text");
		item.teampHead = self.inTeamList:GetChild(i):Find("HeadIcon/TeampHead").gameObject;
		item.selectObj = self.inTeamList:GetChild(i):Find("HeadIcon/SelectObj").gameObject;
		table.insert(TeamItemList,item);
	end
	self.playerItem:SetActive(false);
	self.friendBtnImg = self.friendBtn:GetComponent(typeof(UnityEngine.UI.Image));
	self.friendBtnTitle =  self.friendBtn.transform:Find("Text"):GetComponent(typeof(UnityEngine.UI.Text));
	self.latelyBtnImg = self.latelyBtn:GetComponent(typeof(UnityEngine.UI.Image));
	self.latelyBtnTitle =  self.latelyBtn.transform:Find("Text"):GetComponent(typeof(UnityEngine.UI.Text));
	activeImageColor =  Color(0.88,0.88,0.65);
	normalImageColor =  Color(0.78,0.64,0.43);
	activeTitleColor = Color(0.59,0.44,0.22);
	normalTitleColor = Color(0.94,0.89,0.72);

	VoiceHelper:Init(self.objVoice:GetComponent("VoiceCtrlUI"));
end

function MatchingView:RegeditEvent()
	EventButtonListerer.Get(_this.backBtn, self.OnBackToLobby)
	EventButtonListerer.Get(_this.friendBtn, self.OnFriendBtnClick)
	EventButtonListerer.Get(_this.latelyBtn, self.OnLatelyBtnClick)
	EventButtonListerer.Get(_this.readyToMatchBtn, self.OnReadyClick)
	EventButtonListerer.Get(_this.cancelReadyBtn, self.OnCancelReadyClick)
	EventButtonListerer.Get(_this.cancelMatchingBtn, self.OnCancelMatchingClick)
	EventButtonListerer.Get(_this.readyToPlayBtn, self.OnReadyToPlayClick)
end

function MatchingView:OpenView()
	print("打开匹配界面");
	EventSys.instance:AddLuaEvent(GameEvent.StartMatch,MatchingView.ToMatchingState);
	EventSys.instance:AddLuaEvent(GameEvent.UpdateFriendData,MatchingView.OnReceiveFirendUpdate);
	EventSys.instance:AddLuaEvent(GameEvent.CancelMatch,MatchingView.OnReceiveCancelMatch);
	if(MatchingManager.CheckTeamData()==0 and MatchingManager.isBeInVited == false)then 
		MatchingManager.OnRequsetCreatTeam();
	end
	MatchingManager.isBeInVited = false;
	Main.AddUpdateFun(MatchingView.Update,self);
	isFriendBtnClick=true;
	FriendManager.UpdateFriendListData(function()
		MatchingView.UpdateFriendView(FriendManager.ListFriendDatas);
	end);
	MatchingView.SetBtnColor(true);
	MatchingView.RefreshMatchingView(false);
	MatchingView.BackToTeamState();

	VoiceHelper:Refresh(self.objVoice:GetComponent("VoiceCtrlUI"));
end

function MatchingView:CloseView()
	EventSys.instance:RemoveLuaEvent(GameEvent.StartMatch,MatchingView.ToMatchingState);
	EventSys.instance:RemoveLuaEvent(GameEvent.UpdateFriendData,MatchingView.OnReceiveFirendUpdate);
	EventSys.instance:RemoveLuaEvent(GameEvent.CancelMatch,MatchingView.OnReceiveCancelMatch);
	Main.RemoveUpdateFun(MatchingView.Update);
	MatchingView.ClearFriendList();
end

function MatchingView.OnReceiveCancelMatch(eventId,obj)
	MatchingView.BackToTeamState();
end

function MatchingView.OnReceiveFirendUpdate(eventId,obj)
	print("接收到好友数据更新");
	MatchingView.UpdateFriendView(FriendManager.ListFriendDatas)
end

function MatchingView.RefreshMatchingView(isSelfTeam)
	MatchingView.RefreshTeamList(isSelfTeam);
	MatchingView.ReceiveReadyOrCancel(MatchingManager.isReady)
end

function MatchingView.SetBtnColor(isFriend)
	if(isFriend==true)then 
		_this.friendBtnImg.color =  activeImageColor;
		_this.latelyBtnImg.color = normalImageColor;
		_this.friendBtnTitle.color =  activeTitleColor;
		_this.latelyBtnTitle.color =  normalTitleColor;
	else
		_this.friendBtnImg.color = normalImageColor;
		_this.latelyBtnImg.color =  activeImageColor;
		_this.friendBtnTitle.color =  normalTitleColor;
		_this.latelyBtnTitle.color =  activeTitleColor;
	end
end

function MatchingView:GetColor(str)
	local succ,color = UnityEngine.ColorUtility.TryParseHtmlString(str,nil)
	return color;
end

function MatchingView.OnBackToLobby()
	local teamNumber = MatchingManager.CheckTeamData();
	if(teamNumber>0)then
		MatchingManager.OnRequestTeamLeaveData();
	end
	ViewSys.instance:Close("MatchingView");
	ViewSys.instance:Open("MainLobbyView");
end



function MatchingView.OnFriendBtnClick()
	if(isFriendBtnClick==true)then 
		print("当前好有按钮已被点击")
		return
	end
	print("好友按钮点击");
	MatchingView.SetBtnColor(true)
	isFriendBtnClick=true;
	MatchingView.ClearFriendList();
	FriendManager.UpdateFriendListData(function()
		MatchingView.UpdateFriendView(FriendManager.ListFriendDatas);
	end);
end

function MatchingView.OnLatelyBtnClick()
	if(isFriendBtnClick==false)then 
		print("当前最近按钮已被点击")
		return
	end
	print("最近按钮点击");
	FriendManager.UpdateLatelyFriendList(function()
		MatchingView.UpdateFriendView(FriendManager.LatelyFriendList);
	end);
	MatchingView.SetBtnColor(false)
	isFriendBtnClick=false;
	MatchingView.ClearFriendList();
	
end

function MatchingView.UpdateFriendView(datas)
	local i =1;
	for v,k in pairs(datas) do
	if(k~=nil)then 
		if(k.online_statu==true)then
			if(i>#FriendItemList)then 
				local obj = MatchingView.CreatFriendItem(_this.matchingFriendItem,_this.friendList);
				local item = MatchingFriendItem.Init(obj,k);
				table.insert(FriendItemList,item);
			else
				FriendItemList[i]:RefreshItem(k);
			end
			i=i+1;
		end
	end
	end
end

function MatchingView.CreatFriendItem(item,parent)
	local obj = UnityEngine.GameObject.Instantiate(item);
	obj.gameObject:SetActive(true);
	obj.transform:SetParent(parent);
	obj.transform.localScale = Vector3.one;
	obj.transform.localPosition = Vector3.zero;
	return obj;
end

function MatchingView.RefuseInvite(id)
	for i=1,#FriendItemList do
		if(FriendItemList[i].data.user_id==id)then 
			FriendItemList[i]:ToRefuseState();
		end
	end
end

function MatchingView.FriendLeave(id)
	for i=1,#FriendItemList do
		if(FriendItemList[i].data.user_id==id)then 
			FriendItemList[i]:ToNormalState();
		end
	end
end

function MatchingView.FriendAddTeam(id)
	for i=1,#FriendItemList do
		if(FriendItemList[i].data.user_id==id)then 
			FriendItemList[i]:ToInTeamState();
		end
	end
end

function MatchingView.Update(deltaTime)
	for i=1,#FriendItemList do
		delta = UnityEngine.Time.deltaTime
		FriendItemList[i]:Update(delta);
	end
	if(ReadyClickSpacing>0) then 
		ReadyClickSpacing=ReadyClickSpacing-UnityEngine.Time.deltaTime;
		if(ReadyClickSpacing<=0)then 
			isReadyOrCancelClick=false;
		end
	end
	MatchingView.GetMatchingTime();
	MatchingView.GetReadyToPlayTime();
end

function MatchingView.ClearFriendList()
	for i=1,#FriendItemList do
		FriendItemList[i]:ClearItem();
	end
	for i=1,#rebootIconList do
		rebootIconList[i]:SetActive(false);
	end
end

function MatchingView.ClearTeamList()
	for i=1,#TeamItemList do
		TeamItemList[i].nameText.text = ""
		TeamItemList[i].teampHead:SetActive(false);
		TeamItemList[i].selectObj:SetActive(false);
	end
end

function MatchingView.RefreshTeamList(isSelfTeam)
	MatchingView.ClearTeamList();
	if(isSelfTeam==false)then 
		for v,k in pairs(MatchingManager.TeamListDatas) do
			if(k.user_name~=nil)then 
				print("刷新队伍列表"..k.user_name);
				TeamItemList[k.index].nameText.text = k.user_name;
				if(k.statu==2)then 
					TeamItemList[k.index].selectObj:SetActive(true)
				else if(k.statu==1)then 
					TeamItemList[k.index].selectObj:SetActive(false)
				end
			end
				TeamItemList[k.index].teampHead:SetActive(true);
			end
		end
	else
		TeamItemList[1].nameText.text=MainLobbyManager.playerBaseInfo.name
		--TeamItemList[1].selectObj:SetActive(true);
		TeamItemList[1].teampHead:SetActive(true);
	end

end

function MatchingView.OnReadyClick()
	if(isReadyOrCancelClick==true)then 
	 	return;
	end
	print("准备");
	if(MatchingManager.CheckTeamData()==false)then 
		MatchingManager.OnRequsetCreatTeam();
		MatchingManager.ReadyClickBack=function()
			isReadyOrCancelClick =true;
			MatchingManager.OnRequestTeamSetStatu();
			ReadyClickSpacing=1;
		end
	else
		isReadyOrCancelClick =true;
		MatchingManager.OnRequestTeamSetStatu();
		ReadyClickSpacing=1;
	end
end

function MatchingView.OnCancelReadyClick()
	if(isReadyOrCancelClick==true)then 
		return;
	end
	print("取消准备");
	isReadyOrCancelClick =true;
	MatchingManager.OnRequestTeamSetStatu();
	ReadyClickSpacing=1;
end

function MatchingView.ReceiveReadyOrCancel(isReady)
	isReadyOrCancelClick=false;
	ReadyClickSpacing=0;
	if(isReady==true)then 
		_this.readyToMatchBtn:SetActive(false);
		_this.cancelReadyBtn:SetActive(true);
	else
		_this.readyToMatchBtn:SetActive(true);
		_this.cancelReadyBtn:SetActive(false);
	end
end

function MatchingView.BackToTeamState()
	print("切换到组队状态");
	_this.matchingPanel:SetActive(false);
	_this.readyPanel:SetActive(false);
	_this.readyToPlayBtn:SetActive(true);
	isMatching =false;
	isReadyToPlay = false;
end

function MatchingView.ToReadyToPlayState(datas)
	print("切换到准备游戏状态");
	_this.matchingPanel:SetActive(false);
	_this.readyPanel:SetActive(true);
	LuaHelper.SetMatchingTimer(-2);
	isReadyToPlay = true;
	isMatching = false;
	ReadyToPlayMaxTime = 15;
	MatchingView.UpdatePlayerList(datas);
end

function MatchingView.GetReadyToPlayTime()
	if(isReadyToPlay==false)then 
		return;
	end
	local time = LuaHelper.GetCostTime(-2,ReadyToPlayMaxTime);
	_this.readyTimeText.text = tostring(time);
	if(time <=0)then 
		isReadyToPlay = false
	end
	
end

function MatchingView.ToMatchingState(eventId,obj)
	print("切换到匹配状态");
	_this.matchingPanel:SetActive(true);
	_this.readyPanel:SetActive(false);
	_this.readyToPlayBtn:SetActive(true);
	LuaHelper.SetMatchingTimer(-1);
	isMatching =true;
	isReadyToPlay=false;
end

function MatchingView.GetMatchingTime()
	if(isMatching==false)then
		return;
	end
	local time = LuaHelper.GetSpendTime(-1);
	_this.timeText.text = LuaHelper.GetSpendTime(-1);
end

function MatchingView.OnReadyToPlayClick()
	print("点击准备进入游戏");
	_this.readyToPlayBtn:SetActive(false);
	MatchingManager.OnReQuestMatchReady();
end

function MatchingView.OnCancelMatchingClick()
	print("点击取消匹配");
	MatchingView.OnCancelReadyClick();
	MatchingView.BackToTeamState();
end

function MatchingView.ClearPlayerList()
	for v,k in pairs(PlayerItemList) do
		k.obj:SetActive(false);
	end
end

function MatchingView.UpdateRebootList(datas)
	for i=1,#datas do
		local id = datas[i].robot_user_id;
		print(id);
		if(PlayerItemList[id]==nil)then 
			local obj = MatchingView.CreatFriendItem(_this.playerItem,_this.playerList);
			local item = MatchingPlayerItem.Init(obj,datas[i]);
			item:RefreshItem(datas[i]);
			item:ActiveItem(true);
			print(item);
			print(id);
			PlayerItemList[id]={};
			PlayerItemList[id] = item;
		else
			PlayerItemList[id]:RefreshItem(datas[i]);
			PlayerItemList[id].obj:SetActive(true);
			PlayerItemList[id]:ActiveItem(true);
		end
	end
end

function MatchingView.UpdatePlayerList(datas)
	print("刷新匹配到的玩家列表")
	for i=1,#datas.userData do
		--[[ print("v.user_id--->"..datas[i].user_id);
		print("v.user_name--->"..datas[i].user_name);
		print("v.logoutTime--->"..datas[i].logoutTime);
		print("v.online_statu--->"..tostring(datas[i].online_statu)); ]]
		local id = datas.userData[i].user_id;
		if(PlayerItemList[id]==nil)then 
			local obj = MatchingView.CreatFriendItem(_this.playerItem,_this.playerList);
			local item = MatchingPlayerItem.Init(obj,datas.userData[i]);
			item:RefreshItem(datas.userData[i]);
			print(item);
			print(id);
			PlayerItemList[id]={};
			PlayerItemList[id] = item;
		else
			PlayerItemList[id]:RefreshItem(datas[i]);
			PlayerItemList[id].obj:SetActive(true);
		end
	end
end

function MatchingView.ActviePlayerItem(id,isReady)
	print("玩家准备亮起"..tostring(isReady));
	PlayerItemList[id]:ActiveItem(isReady);
end


