﻿--From Lua Script Create
--ClassName: ScrollPageControl
--Author:    hukiry
--CreateTime:2018-6-29
require "Logic/Shop/PageItem" 
ScrollPageControl = {}

local _this;
local count =13;
local itemDatas = {};
local pageItemList = {};


function ScrollPageControl.Init(view)
	_this=view;
	--[[ l=0;
	for i=1,count do 
		table.insert(itemDatas,i);
		l=l+1;
		print("数据数量:"..l);
		print("i=="..i);
	end
	ScrollPageControl.RefreshView(itemDatas); ]]
end

function ScrollPageControl.CreatPageItem()
	local obj = UnityEngine.GameObject.Instantiate(_this.pageItem);
	obj.gameObject:SetActive(true);
	obj.transform:SetParent(_this.pageItem.transform.parent);
	obj.transform.localScale = Vector3.one;
	obj.transform.localPosition = Vector3.zero;
	return obj;
end

function ScrollPageControl.RefreshView(datas)
	for i=1,#pageItemList do
		pageItemList[i].go:SetActive(false);
		pageItemList[i]:Des();
	end
	local pagecount = math.ceil(#datas / 6);
	for i=0,pagecount-1 do 
		local teampDatas ={};
		local j= i*6+1;
		local j_bool = true;
		while(j_bool) do
			table.insert(teampDatas,datas[j]);
			j=j+1;
			j_bool =(j<((i*6)+7))and(j<=#datas)
		end
		local obj
		if(#pageItemList>i) then
			obj = pageItemList[i+1].go;
			obj:SetActive(true);
			print(pageItemList[i+1])
			pageItemList[i+1]:RefreshItem(teampDatas);
		else
			obj=ScrollPageControl.CreatPageItem();
			local item = PageItem.InitView(_this.iconItem,teampDatas,obj);
			item.go = obj;
			table.insert(pageItemList,item);
		end
		
	end
end
