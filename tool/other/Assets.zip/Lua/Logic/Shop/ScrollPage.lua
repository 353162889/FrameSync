﻿--From Lua Script Create
--ClassName: New Lua
--Author:    hukiry
--CreateTime:2018-6-29
ScrollPage={}

local _this;

local rect;
local pages={};
local currentPageIndex = -1;
local smooting = 4;
local targethorizontal = 0;
local isDrag = false;
ScrollPage.startime = 0;
local delay = 0.1;

function ScrollPage.Init(view)
	_this=view;
	ScrollPage.RegeditEvent();
	print(_this.itemPanels.name);
	rect = _this.itemPanels.transform:GetComponent("ScrollRect");
	print(UnityEngine.Time.time)
	ScrollPage.startime = 0;
end

function ScrollPage.RegeditEvent()
	EventTriggerListener.Get(_this.itemPanels).onBeginDragEvent = EventTriggerListener.Get(_this.itemPanels).onBeginDragEvent+ScrollPage.OnBegin;
	EventTriggerListener.Get(_this.itemPanels).onEndDragEvent = EventTriggerListener.Get(_this.itemPanels).onEndDragEvent+ScrollPage.OnEnd;
end

function ScrollPage.OnBegin(go)
	isDrag = true;
end

function ScrollPage.OnEnd(go)
	if(#pages==0)then 
		return
	end
	isDrag = false;
	local posX = rect.horizontalNormalizedPosition;
	local index = 1;
	local offset = UnityEngine.Mathf.Abs(pages[index] - posX);
	for i=2,#pages do
		print("end......"..tostring(i));
		local temp = UnityEngine.Mathf.Abs(pages[i] - posX);
		if (temp < offset) then
			index = i;
			offset = temp;
		end
	end
	if index~=currentPageIndex then
		currentPageIndex = index;
		if(ShopView.OnPageChanged~=nil)then
			ShopView.OnPageChanged(#pages, currentPageIndex);
		end
	end
	targethorizontal = pages[index];
end

function ScrollPage.Update(deltaTime)
	ScrollPage.startime=ScrollPage.startime+UnityEngine.Time.deltaTime;
	if(ScrollPage.startime<(delay)) then
		targethorizontal =0
		return
	end
	ScrollPage.UpdatePages();
	if ((not isDrag) and (#pages>0)) then
		rect.horizontalNormalizedPosition = UnityEngine.Mathf.Lerp(rect.horizontalNormalizedPosition, targethorizontal, Time.deltaTime * smooting);
	end
end

function ScrollPage.UpdatePages()
	local count =rect.content.childCount;
	local temp = 0;
	for i=0,count-1 do
		if(rect.content:GetChild(i).gameObject.activeSelf) then
			temp=temp+1;
		end
	end
	count = temp;
	if(#pages~=count)then
		if(count~=0)then
			pages={};
			for i=0,count-1 do
				local page = 0;
				if(count~=1) then
					page = i / (count - 1);
				end
				table.insert(pages,page)
			end
		end
		ScrollPage.OnEnd(nil);
	end
end

function ScrollPage.Refresh()
	rect.horizontalNormalizedPosition =0
	ScrollPage.startime=0;
end
