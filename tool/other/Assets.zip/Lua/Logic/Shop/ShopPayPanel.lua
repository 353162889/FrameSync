﻿--From Lua Script Create
--ClassName: ShopPayPanel
--Author:    hukiry
--CreateTime:2018-7-3

ShopPayPanel = {}

local _this;
local currentItem = nil;
local currentData;
local buyNumber =1;
local price = nil;
local totalPrice = nil;
local name =nil;
local maxCount =nil;

function ShopPayPanel.Init(view)
	_this=view;
	_this.payPanel:SetActive(false);
	ShopPayPanel:RegeditEvent();
	MainLobbyManager.ShopRewardOverCallBack = function()
		_this.payPanel:SetActive(false);
	end
end

function ShopPayPanel.OpenView(item)
	currentItem = item;
	currentData = item.data;
	_this.payPanel:SetActive(true);
	print("v.item_id"..tostring(currentData.item_id));
	print("v.item_count"..tostring(currentData.item_count));
	print("v.money_type"..tostring(currentData.money_type));
	print("v.cost_money"..tostring(currentData.cost_money));
	print("v.discount_percent"..tostring(currentData.discount_percent));
	_this.iconSprite.sprite =  CResourceSys.instance:Load(EResType.EIcon, ItemTable[currentData.item_id].icon);
	if(currentData.money_type == HumanResouceType_Silver) then
        _this.coinTypeIcon.sprite = CResourceSys.instance:Load(EResType.EIcon, "Item/icon_item_silver.png");
    elseif(currentData.money_type == HumanResouceType_Gold) then
        _this.coinTypeIcon.sprite = CResourceSys.instance:Load(EResType.EIcon, "Item/icon_item_gold.png");
    elseif(currentData.money_type==HumanResouceType_RMB) then
    
	end
	price = currentData.cost_money;
	buyNumber =1;
	maxCount = currentData.item_count;
	totalPrice = price*buyNumber;
	_this.payNumber.text =tostring(totalPrice); 
	_this.numberShowText.text = tostring(buyNumber);
	name =  ItemTable[currentData.item_id].name;
	_this.itemTitle.text = name;
	_this.desText.text = ItemTable[currentData.item_id].desc;
end

function ShopPayPanel:RegeditEvent()
--[[ 	EventButtonListerer.Get(_this.maskClick, self.OnCloseBtnClick); ]]
	EventButtonListerer.Get(_this.addBtn, self.OnAddBtnClick);
	EventButtonListerer.Get(_this.reduceBtn, self.OnReduceBtnClick);
	EventButtonListerer.Get(_this.buyBtn, self.OnBuyBtnClick);
	EventButtonListerer.Get(_this.closeBtn, self.OnCloseBtnClick);
end

function ShopPayPanel.OnAddBtnClick()
	if(buyNumber==99 or buyNumber==maxCount)then
		print("当前购买数量已达到最大上限");
		return;
	end
	buyNumber=buyNumber+1;
	totalPrice = price*buyNumber;
	_this.payNumber.text =tostring(totalPrice); 
	_this.numberShowText.text = tostring(buyNumber);
end

function ShopPayPanel.OnReduceBtnClick()
	if(buyNumber==1)then
		print("当前购买数量已达到最小上限");
		return;
	end
	buyNumber=buyNumber-1;
	totalPrice = price*buyNumber;
	_this.numberShowText.text = tostring(buyNumber);
	_this.payNumber.text =tostring(totalPrice); 
end

function ShopPayPanel.OnCloseBtnClick()
	_this.payPanel:SetActive(false);
end

function ShopPayPanel.OnBuyBtnClick()
	local content = "是否花费"..tostring(totalPrice).."购买:"..name.."X"..tostring(buyNumber);
	local Click = function()
		print("请求购买")
		local data = C2S_SecertShopBuyData();
		data.buy_index = currentData.index;
		data.buy_count = buyNumber;
		ShopView.OnBuyResultRefreshCallBack=function()
			--[[ print(tostring(buyNumber));
			print(tostring(maxCount)); ]]
			maxCount = maxCount-buyNumber;
			print("刷新数量："..maxCount);
			print(currentItem)
			currentItem:UpdateCount(maxCount)
		end
		NetSys.instance:SendWorldMsg(data:SerializeToString(), C2S_SecertShopBuy);
		
	end
	TipMgr.ShowTipType1(content,Click,nil,nil,nil);
	
end

