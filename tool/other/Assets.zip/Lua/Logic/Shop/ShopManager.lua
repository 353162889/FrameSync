--From Lua Script Create
--ClassName: ShopManager
--Author:    hukiry
--CreateTime:2018-7-9

ShopManager = class(MainLobbyManager)
ShopManager.secertItemList ={};
local shopRefreshTime=0;--神秘商店刷新时间 

function ShopManager.Init()
	NetSys.instance:AddMsgCallback(EChannelType.EWorldChannel, S2C_SecertShopInfo, ShopManager.OnReceiveShopList, nil)
end

function ShopManager.OnReceiveShopList(this,objMsg)
	print("接收到商店物品信息");
	local msg = S2C_SecertShopInfoData(); 
	msg:ParseFromString(objMsg); 
	print("refresh_time_remaining"..tostring(msg.refresh_time_remaining))
	LuaHelper.MarkNowTime(1,tostring(msg.refresh_time_remaining));--记录当前的时间戳
	print("refresh_times"..tostring(msg.refresh_times))
	print("商品总数:"..tostring(#msg.secert_item_list));
	local datas={};
	datas.refresh_time_remaining = msg.refresh_time_remaining;
	datas.refresh_times = msg.refresh_times;
	datas.secert_item_list = msg.secert_item_list;
	for k,v in ipairs(msg.secert_item_list) do
		local data ={};
		data.item_id=v.item_id;
		data.item_count=v.item_count;
		data.money_type=v.money_type;
		data.cost_money=v.cost_money;
		data.discount_percent=v.discount_percent;
		data.goods_type = v.goods_type;
		data.index = k-1;
		table.insert(datas,data);
		print("v.discount_percent"..tostring(v.discount_percent));
		--[[ print("v.item_id"..tostring(v.item_id));
		print("v.item_count"..tostring(v.item_count));
		print("v.money_type"..tostring(v.money_type));
		print("v.cost_money"..tostring(v.cost_money));
		print("v.discount_percent"..tostring(v.discount_percent)); ]]
	end
	ShopManager.secertItemList = datas;
	if(msg.refresh_times>shopRefreshTime) then 
		if(ViewSys.instance:IsOpen("ShopView")) then
			ShopView.RefreshData();
		end
	end
	shopRefreshTime=msg.refresh_times;
end