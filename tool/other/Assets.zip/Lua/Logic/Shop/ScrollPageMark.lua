﻿--From Lua Script Create
--ClassName: ScrollPageMark
--Author:    Tzy
--CreateTime:2018-6-29

ScrollPageMark = {}

local _this;

local toggleList={}

local currentIsOnToggle=nil;

function ScrollPageMark.Init(view)
	_this=view;
	
	ShopView.OnPageChanged = ScrollPageMark.OnScrollPageChanged;
	print(ShopView.OnPageChanged);
end

function ScrollPageMark.OnScrollPageChanged(pageCount,currentPageIndex)
	if(pageCount~=toggleList.Count)then
		if(pageCount>#toggleList)then 
			local cc = pageCount - #toggleList;
			print("cc"..tostring(cc));
			for i=0,cc-1 do
				local t = UnityEngine.GameObject.Instantiate(_this.toggle);
				t.gameObject:SetActive(true);
				t.transform:SetParent(_this.toggleGroup.transform);
				t.transform.localScale = Vector3.one;
				t.transform.localPosition = Vector3.zero;
				t = t:GetComponent("Toggle");
				table.insert(toggleList,t);
			end
		else if(pageCount < #toggleList)then 
			while(#toggleList>pageCount) do
				local t = toggleList[#toggleList - 1];
			    table.remove(toggleList,#toggleList - 1);
				UnityEngine.Object.DestroyImmediate(t.gameObject);
			end
		end
	end
end
	if(#toggleList==0)then 
		return;
	end
	if(currentPageIndex>=0) then
		if(currentIsOnToggle~=nil) then
			currentIsOnToggle.isOn = false;
		end	
		currentIsOnToggle = toggleList[currentPageIndex];
		toggleList[currentPageIndex].isOn = true;
	end
end