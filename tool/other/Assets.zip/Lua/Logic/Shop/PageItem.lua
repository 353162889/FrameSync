﻿--From Lua Script Create
--ClassName: PageItem
--Author:    hukiry
--CreateTime:2018-6-29
require "Logic/Shop/ShopIconItem" 
PageItem = class("PageItem")

function PageItem.InitView(iconItem,datas,panel)
	local pageItem = PageItem.new();
	if(pageItem.item==nil or pageItem.content==nil) then 
		pageItem.item = iconItem
		pageItem.content = panel.transform:Find("Panel");
	end
	
	local count = #datas;
	for i=1,count do
		local obj;
		print(tostring(pageItem.iconItemList==nil));
		if(pageItem.iconItemList==nil) then
			pageItem.iconItemList={};
		end
		if(i>#pageItem.iconItemList) then
			obj= PageItem.CreatItem(pageItem.item,pageItem.content);
			local Item = ShopIconItem.Init(obj,datas[i]);
			Item.go = obj;
			table.insert(pageItem.iconItemList,Item)
		else
			self:RefreshItem();
		end
	end
	pageItem.go = obj;
	return pageItem;
end


function PageItem.CreatItem(item,parent)
	local obj = UnityEngine.GameObject.Instantiate(item);
	obj.gameObject:SetActive(true);
	obj.transform:SetParent(parent);
	obj.transform.localScale = UnityEngine.Vector3.one;
	obj.transform.localPosition = UnityEngine.Vector3.zero;
	return obj
end

function PageItem:RefreshItem(datas)
	for i=1,#datas do
		if(i>#self.iconItemList) then
			obj= PageItem.CreatItem(self.item,self.content);
			local Item = ShopIconItem.Init(obj,datas[i]);
			Item.go = obj;
			table.insert(self.iconItemList,Item)
		else
			obj = self.iconItemList[i].go;
			obj:SetActive(true);
			self.iconItemList[i]:Refresh(datas[i]);
		end
	end
end

function PageItem:Des()
	if(self.iconItemList~=nil)then
		for i=1,#self.iconItemList do
			self.iconItemList[i].go:SetActive(false);
		end
	end
end
