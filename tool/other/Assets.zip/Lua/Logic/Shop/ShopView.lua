﻿--From Lua Script Create
--ClassName: ShopView
--Author:    Tzy
--CreateTime:2018-6-29
require "Logic/Shop/ScrollPage"
require "Logic/Shop/ScrollPageMark"
require "Logic/Shop/ScrollPageControl"
require	"Logic/Shop/ScrollPageMark"
require	"Logic/Shop/ShopPayPanel"

ShopView = class("ShopView",ShopViewUI)

local _this;

ShopView.OnPageChanged=nil;
ShopView.isCanRefresh =true;
local ShenQiBtn ={};
local YingXiongSuiPianBtn={};
local CaiLiaoBtn ={};
local CurrentSelectBtn=nil;
local itemDatas = {};
ShopView.OnBuyResultRefreshCallBack = nil;

function ShopView:Init()
	_this=self;
	_this.iconItem:SetActive(false);
	_this.toggle:SetActive(false);
	_this.pageItem:SetActive(false);
	_this.selectBtns:SetActive(false);
	ScrollPageMark.Init(self);
	ScrollPage.Init(self);
	ScrollPageMark.Init(self);
	ScrollPageControl.Init(self);
	ShopPayPanel.Init(self);
	self:RegeditEvent();
	self:InitSelectBtns();
	self:InitNetEvent();
end

function ShopView:OpenView()
	self:UpdateTopBar();
	ShopView.RefreshData();
	local time = LuaHelper.GetTimeStr(1);
	ShopView:SetTime(time)
	Main.AddUpdateFun(ShopView.Update,_this);
end

function ShopView:CloseView()
	Main.RemoveUpdateFun(ShopView.Update);
end

function ShopView.Update(deltaTime)
	ScrollPage.Update(deltaTime)
	ShopView:SetTime(LuaHelper.GetTimeStr(1))
end

function ShopView:InitNetEvent()
	NetSys.instance:AddMsgCallback(EChannelType.EWorldChannel, S2C_SecertShopRefreshResult, ShopView.OnRefreshResult, nil);
	NetSys.instance:AddMsgCallback(EChannelType.EWorldChannel, S2C_SecertShopBuyResult, ShopView.OnShopBuyResult, nil);
	EventSys.instance:AddLuaEvent(GameEvent.PlayerResourcesUpdate,ShopView.UpdatePlayerResources);
end

function ShopView:InitSelectBtns()
	ShenQiBtn.index =1;
	ShenQiBtn.obj = self.shenQiBtn;
	ShenQiBtn.selectIcon = self.shenQiBtn.transform:Find("selectIcon").gameObject;
	ShenQiBtn.normalIcon = self.shenQiBtn.transform:Find("normalIcon").gameObject;
	YingXiongSuiPianBtn.index =2;
	YingXiongSuiPianBtn.obj = self.yingXiongSuiPianBtn;
	YingXiongSuiPianBtn.selectIcon = self.yingXiongSuiPianBtn.transform:Find("selectIcon").gameObject;
	YingXiongSuiPianBtn.normalIcon = self.yingXiongSuiPianBtn.transform:Find("normalIcon").gameObject;
	CaiLiaoBtn.index =3;
	CaiLiaoBtn.obj = self.caiLiaoBtn;
	CaiLiaoBtn.selectIcon = self.caiLiaoBtn.transform:Find("selectIcon").gameObject;
	CaiLiaoBtn.normalIcon = self.caiLiaoBtn.transform:Find("normalIcon").gameObject;
	ShenQiBtn.selectIcon:SetActive(false);
	YingXiongSuiPianBtn.selectIcon:SetActive(false);
	CaiLiaoBtn.selectIcon:SetActive(false);
	CurrentSelectBtn = ShenQiBtn;
	CurrentSelectBtn.selectIcon:SetActive(true);
	CurrentSelectBtn.normalIcon:SetActive(false);
	EventButtonListerer.Get(self.shenQiBtn, self.OnShenQiClick)
	EventButtonListerer.Get(self.yingXiongSuiPianBtn, self.OnYingXiongSuiPianClick)
	EventButtonListerer.Get(self.caiLiaoBtn, self.OnCaiLiaoBtnClick)
	ShenQiBtn.obj:SetActive(false);
	YingXiongSuiPianBtn.obj:SetActive(false);
	CaiLiaoBtn.obj:SetActive(false);
	for i=1,#ShopTable[1].BtnIds do
		local id = ShopTable[1].BtnIds[i];
		print(id);
		print(ShopView.GetBtnForId(id));
		ShopView.GetBtnForId(id).obj:SetActive(true); 
		if(i==1) then 
			CurrentSelectBtn = ShopView.GetBtnForId(id);
			CurrentSelectBtn.selectIcon:SetActive(true);
			CurrentSelectBtn.normalIcon:SetActive(false);
		end
	end
end

function ShopView.GetBtnForId(id)
	if(id==1) then 
		return ShenQiBtn;
	else if(id==2)then
		return YingXiongSuiPianBtn;
	else if(id==3)then
		return CaiLiaoBtn;
	end
end
end
end

function ShopView:OnShenQiClick()
	if(CurrentSelectBtn==ShenQiBtn) then 
		print("当前已选中该按钮");
		return
	end
	ShopView.ChangeCurrentBtn(ShenQiBtn)
end

function ShopView:OnYingXiongSuiPianClick()
	if(CurrentSelectBtn==YingXiongSuiPianBtn) then 
		print("当前已选中该按钮");
		return
	end
	ShopView.ChangeCurrentBtn(YingXiongSuiPianBtn)
end

function ShopView.OnCaiLiaoBtnClick()
	if(CurrentSelectBtn==CaiLiaoBtn) then 
		print("当前已选中该按钮");
		return
	end
	ShopView.ChangeCurrentBtn(CaiLiaoBtn)
end

function ShopView.ChangeCurrentBtn(btn)
	CurrentSelectBtn.selectIcon:SetActive(false);
	CurrentSelectBtn.normalIcon:SetActive(true);
	CurrentSelectBtn = btn;
	CurrentSelectBtn.selectIcon:SetActive(true);
	CurrentSelectBtn.normalIcon:SetActive(false);
	ShopView.RefreshView(CurrentSelectBtn.index);
end

function ShopView.UpdateTopBar()
	_this.txtSliver.text = MainLobbyManager.playerBaseInfo.silver;
	_this.txtGold.text = MainLobbyManager.playerBaseInfo.gold;
end

function ShopView:BackToLobby()
	ViewSys.instance:Close("ShopView");
	ViewSys.instance:Open("MainLobbyView");
end

function ShopView:RegeditEvent()
	EventButtonListerer.Get(self.refreshBtn, self.OnRefreshClick)
	EventButtonListerer.Get(self.backLobbyBtn, self.BackToLobby)
end

function ShopView.RefreshData()
	itemDatas={};
	local Goods1={};
	local Goods2={};
	local Goods3={};
	local Goods={};--所有商品
	for k,v in ipairs(ShopManager.secertItemList) do
		--[[ print("v.item_id"..tostring(v.item_id));
		print("v.item_count"..tostring(v.item_count));
		print("v.money_type"..tostring(v.money_type));
		print("v.cost_money"..tostring(v.cost_money));
		print("v.discount_percent"..tostring(v.discount_percent)); ]]
		--print("v.goods_type"..tostring(v.goods_type));
		if(v.goods_type==1) then 
			table.insert(Goods1,v);
		else if(v.goods_type==2) then 
			table.insert(Goods2,v);
		else if (v.goods_type==3) then 
			table.insert(Goods3,v);
		end
	end
	end
			table.insert(Goods,v);
	end
	table.insert(itemDatas,Goods1);
	table.insert(itemDatas,Goods2);
	table.insert(itemDatas,Goods3);
	table.insert(itemDatas,Goods);
	ShopView.RefreshView(4)
end

function ShopView.RefreshView(index)
	local pagecount = math.ceil(#itemDatas[index] / 6);
	ShopView.OnPageChanged(pagecount,1);
	ScrollPageControl.RefreshView(itemDatas[index]);
	ScrollPage.Refresh();
end

function ShopView.OnRefreshClick()
	print("刷新按钮点击");
	local price;
	if(ShopManager.secertItemList.refresh_times+1>20)then 
		price =  ShopPriceRefresh[20].refresh_cost
	else
		 price = ShopPriceRefresh[ShopManager.secertItemList.refresh_times+1].refresh_cost
	end
	local content = string.format(ShopTable[1].refreshDes,price);
	local Click = function()
		print("请求刷新")
		local data = C2S_SecertShopRefreshData();
		NetSys.instance:SendWorldMsg(data:SerializeToString(), C2S_SecertShopRefresh);
	end
	TipMgr.ShowTipType1(content,Click,nil,nil,nil);
end

function ShopView.OnRefreshResult(this,objMsg)
	 local msg = S2C_SecertShopRefreshResultData(); 
	 msg:ParseFromString(objMsg); 
	 print("接收到刷新结果--->"..tostring(msg.error_num));
	 if(msg.error_num==0)then
		ShopView.RefreshData();
		ShopView.UpdateTopBar();
	 else if(msg.error_num==1020) then 
		ShopView.ShowErrorPanel("货币不足");
	 end
	end
end

function ShopView.OnShopBuyResult(this,objMsg)
	local msg = S2C_SecertShopBuyResultData(); 
	msg:ParseFromString(objMsg); 
	print("接收到购买结果--->"..msg.error_num);
	if(msg.error_num==0)then
		print();
		if(ShopView.OnBuyResultRefreshCallBack~=nil) then 
			ShopView.OnBuyResultRefreshCallBack()
			ShopView.OnBuyResultRefreshCallBack=nil;
		end 
	   --[[ ShopView.Refresh(true); ]]
	end
end

function ShopView:SetTime(time)
	self.refreshTimeText.text = time;
end

function ShopView.UpdatePlayerResources()
	ShopView.UpdateTopBar();
end

function ShopView.ShowErrorPanel(content)
	TipMgr.ShowTipType2(content,nil,nil);
end