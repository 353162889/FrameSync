﻿--From Lua Script Create
--ClassName: IconItem
--Author:    hukiry
--CreateTime:2018-6-29
--[[ print("v.item_id"..tostring(v.item_id));
		print("v.item_count"..tostring(v.item_count));
		print("v.money_type"..tostring(v.money_type));
		print("v.cost_money"..tostring(v.cost_money));
        print("v.discount_percent"..tostring(v.discount_percent)); ]]
require	"Logic/Shop/ShopPayPanel"
ShopIconItem = class("ShopIconItem")

function ShopIconItem.Init(obj,data)
    local item = ShopIconItem.new();
    item.data = data;
    item.obj = obj;
    item.icon = item.obj.transform:Find("icon"):GetComponent("Image");
    item.countText = item.obj.transform:Find("count"):GetComponent("Text");
    item.manayText = item.obj.transform:Find("manayText"):GetComponent("Text");
    item.MoneyTypeIcon = item.obj.transform:Find("MoneyTypeIcon"):GetComponent("Image");
    item.SellOutTitle = item.obj.transform:Find("SellOutTitle").gameObject;
    item.DiscountObj = item.obj.transform:Find("Discount").gameObject;
    item.DiscountText = item.obj.transform:Find("Discount/Text"):GetComponent("Text");
    local OnClick = function()
        if(item.data.item_count>0)then
            ShopPayPanel.OpenView(item);
        else
            local content = ShopTable[1].sellOut;
            TipMgr.ShowTipType2(content,nil,nil,nil,nil);
        end
    end
    EventButtonListerer.Get(item.obj, OnClick);
    ShopIconItem.UpdateView(item,data);
    return item;
end

function ShopIconItem:Refresh(data)
    ShopIconItem.UpdateView(self,data);
end

function ShopIconItem.UpdateView(item,data)
    item.data = data;
    item.icon.sprite = CResourceSys.instance:Load(EResType.EIcon, ItemTable[data.item_id].icon);
    item.countText.text = tostring(data.item_count);
    item.manayText.text = tostring(data.cost_money);
    if(data.money_type == HumanResouceType_Silver) then
        item.MoneyTypeIcon.sprite = CResourceSys.instance:Load(EResType.EIcon, "Item/icon_item_silver.png");
    elseif(data.money_type == HumanResouceType_Gold) then
        item.MoneyTypeIcon.sprite = CResourceSys.instance:Load(EResType.EIcon, "Item/icon_item_gold.png");
    elseif(data.money_type==HumanResouceType_RMB) then
    end

    if(data.discount_percent>0)then 
        item.DiscountObj:SetActive(true);
        local dic = 100-data.discount_percent;
        dic = math.floor(dic/10);
        if(dic==0)then 
            dic =1;
        end
        item.DiscountText.text = tostring(dic).."折";
    else
        item.DiscountObj:SetActive(false);
    end

    if(data.item_count==0)then 
        item.SellOutTitle:SetActive(true);
    else
        item.SellOutTitle:SetActive(false);
    end
end
--刷新数量
function ShopIconItem:UpdateCount(count)
    self.data.item_count =count;
    self.countText.text = tostring(count);
    if(count==0)then 
        self.SellOutTitle:SetActive(true);
    end 
end

function ShopIconItem:ShowSellOutView()

end