TipView = class("TipView",TipViewUI);

function TipView:Init()
	local onClickClose = function (go)
		self:OnClickClose();
	end
	EventTriggerListener.Get(self.btnClose.gameObject).onClick = EventTriggerListener.Get(self.btnClose.gameObject).onClick + onClickClose;

	local onClickMaskClose = function (go)
		self:OnClickMaskClose();
	end
	EventTriggerListener.Get(self.mask).onClick = EventTriggerListener.Get(self.mask).onClick + onClickMaskClose;

	local onClickConfirm = function (go)
		self:OnClickConfirm();
	end
	EventTriggerListener.Get(self.btnConfirm.gameObject).onClick = EventTriggerListener.Get(self.btnConfirm.gameObject).onClick + onClickConfirm;

	local onClickCancel = function (go)
		self:OnClickCancel();
	end
	EventTriggerListener.Get(self.btnCancel.gameObject).onClick = EventTriggerListener.Get(self.btnCancel.gameObject).onClick + onClickCancel;
	self.txtContent.text = "";
	self.contentHeight = self.txtContent.preferredHeight;
end

function TipView:OpenView(param)
	local luaParam = param.objParam;
	local txtTitle = luaParam["txtTitle"];
	if(txtTitle ~= nil) then
		self.txtTitle.gameObject:SetActive(true);
		self.txtTitle.text = txtTitle;
	else
		self.txtTitle.gameObject:SetActive(false);
	end

	local txtContent = luaParam["txtContent"];
	if(txtContent ~= nil) then
		self.txtContent.gameObject:SetActive(true);
		self.txtContent.text = txtContent;
		local lineCount = self.txtContent.preferredHeight / self.contentHeight;
		if(lineCount < 2) then
			self.txtContent.alignment = UnityEngine.TextAnchor.MiddleCenter;
		else
			self.txtContent.alignment = UnityEngine.TextAnchor.MiddleLeft;
		end 
	else
		self.txtContent.gameObject:SetActive(false);
	end
	
	local txtTip = luaParam["txtTip"]
	if(txtTip ~= nil) then
		self.txtTip.gameObject:SetActive(true);
		self.txtTip.text = txtTip;
	else
		self.txtTip.gameObject:SetActive(false);
	end

	local txtConfirm = luaParam["txtConfirm"]
	if(txtConfirm ~= nil) then
		self.txtConfirm.text = txtConfirm;
	else
		self.txtConfirm.text = "确定";
	end

	local txtCancel = luaParam["txtCancel"]
	if(txtCancel ~= nil) then
		self.txtCancel.text = txtCancel;
	else
		self.txtCancel.text = "取消";
	end

	local confirmCallback = luaParam["confirmCallback"]
	self.confirmCallback = confirmCallback;
	self.btnConfirm.gameObject:SetActive(txtConfirm ~= nil or confirmCallback ~= nil);

	local cancelCallback = luaParam["cancelCallback"]
	self.cancelCallback = cancelCallback;
	self.btnCancel.gameObject:SetActive(txtCancel ~= nil or cancelCallback ~= nil);

	local closeCallback = luaParam["closeCallback"]
	self.closeCallback = closeCallback;
	self.btnClose.gameObject:SetActive(closeCallback ~= nil);

	self.isMaskClose = luaParam["maskClose"]
end

function TipView:CloseThis()
	ViewSys.instance:Close("TipView")
end

function TipView:OnClickClose()
	if(nil ~= self.closeCallback) then
		local callback = self.closeCallback;
		self:CloseThis();
		callback();
	end
end

function TipView:OnClickMaskClose()
	if(self.isMaskClose) then
		self:OnClickClose();
	end
end

function TipView:OnClickConfirm()
	if(nil ~= self.confirmCallback) then
		local callback = self.confirmCallback;
		self:CloseThis();
		callback();
	end
end

function TipView:OnClickCancel()
	if(nil ~= self.cancelCallback) then
		local callback = self.cancelCallback;
		self:CloseThis();
		callback();
	end
end

function TipView:CloseView()
	self.confirmCallback = nil;
	self.cancelCallback = nil;
	self.closeCallback = nil;
end

function TipView:DestroyView()
	self.confirmCallback = nil;
	self.cancelCallback = nil;
	self.closeCallback = nil;
end