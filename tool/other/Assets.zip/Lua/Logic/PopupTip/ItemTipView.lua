ItemTipView = class("ItemTipView",ItemTipViewUI)

function ItemTipView:Init()
	-- body
	local onClickClose = function (go)
		ViewSys.instance:Close("ItemTipView");
	end
	EventTriggerListener.Get(self.mask).onClick = EventTriggerListener.Get(self.mask).onClick + onClickClose;
end

function ItemTipView:OpenView(param)
	local tableParam = param.objParam;
	local itemDefineId = tableParam["itemId"];
	local worldPos = tableParam["worldPos"];
	local itemConfig = ItemTable[itemDefineId];
	self.txtTitle.text = itemConfig.name;
	self.txtContent.text = itemConfig.desc;
	self.imgIcon.sprite = CResourceSys.instance:Load(EResType.EIcon,itemConfig.icon);
	local delta = self.bgContent.transform.sizeDelta;
	delta.y = self.txtContent.preferredHeight;
	self.bgContent.transform.sizeDelta = delta;
	LuaHelper.SetPos(self.bubble,worldPos.x,worldPos.y,worldPos.z);
	local localPosition = self.bubble.transform.localPosition;
	LuaHelper.SetLocalPos(self.bubble,localPosition.x,localPosition.y,0);
	LuaHelper.SetLocalScale(self.bubble,0.2,0.2,0.2);
	if(self.tweener ~= nil) then
		self.tweener:Kill(true);
		self.tweener = nil;
	end
	self.tweener = self.bubble.transform:DOScale(1,0.3):SetEase(DG.Tweening.Ease.OutCubic);
end

function ItemTipView:CloseView()
end

function ItemTipView:DestroyView()
	-- body
end