TipMgr = {}

--txtTitle:标题
--txtContent:内容
--txtTip:内容下面的提示描述
--txtConfim:确定按钮文本显示
--confirmCallback:确定按钮回调
--txtCancel:取消按钮文本显示
--cancelCallback:取消按钮回调
--closeCallback:关闭按钮或点击mask关闭时回调
--maskClose:是否点击mask关闭面板
function TipMgr.ShowTip(txtTitle,txtContent,txtTip,txtConfirm,confirmCallback,txtCancel,cancelCallback,closeCallback,maskClose)
	local param = ViewParam();
	local isMaskClose = true;
	if(maskClose ~= nil) then isMaskClose = maskClose end
	local table = 
	{
		txtTitle = txtTitle,
		txtContent = txtContent,
		txtTip = txtTip,
		txtConfirm = txtConfirm,
		confirmCallback = confirmCallback,
		txtCancel = txtCancel,
		cancelCallback = cancelCallback,
		closeCallback = closeCallback,
		maskClose = isMaskClose,
	};
	param.objParam = table;
	if(ViewSys.instance:IsOpen("TipView")) then
		ViewSys.instance:Close("TipView");
	end
	ViewSys.instance:Open("TipView",param);
end

--txtContent:内容
--confirmCallback:确定按钮回调
--cancelCallback:取消按钮回调
--closeCallback:关闭按钮或点击mask关闭时回调
--maskClose:是否点击遮罩关闭,传nil默认关闭
function TipMgr.ShowTipType1(txtContent,confirmCallback,cancelCallback,closeCallback,maskClose)
	local param = ViewParam();
	local table = 
	{
		txtContent = txtContent,
		confirmCallback = confirmCallback,
		cancelCallback = cancelCallback,
		closeCallback = closeCallback,
		maskClose = maskClose,
	};
	param.objParam = table;
	if(ViewSys.instance:IsOpen("TipType1View")) then
		ViewSys.instance:Close("TipType1View");
	end
	ViewSys.instance:Open("TipType1View",param);
end

--txtContent:内容
--cancelCallback:取消按钮回调
--closeCallback:关闭按钮或点击mask关闭时回调
--maskClose:是否点击遮罩关闭,传nil默认关闭
function TipMgr.ShowTipType2(txtContent,closeCallback,maskClose)
	local param = ViewParam();
	local table = 
	{
		txtContent = txtContent,
		closeCallback = closeCallback,
		maskClose = maskClose,
	};
	param.objParam = table;
	if(ViewSys.instance:IsOpen("TipType2View")) then
		ViewSys.instance:Close("TipType2View");
	end
	ViewSys.instance:Open("TipType2View",param);
end

--title：奖励提示语，可传空
--rewardIds:物品ID表
--numbers：物品数量表
--callback：回调事件，可传空,,
function TipMgr.ShowRewardTip(title,ids,numbers,callback)
	local param = ViewParam()
	local table = 
	{
		 title = title,
		 ids = ids,
		 numbers = numbers,
		 callback = callback
	}
	param.objParam = table
	if(ViewSys.instance:IsOpen("TipRewardView")) then
		ViewSys.instance:Close("TipRewardView");
	end
	ViewSys.instance:Open("TipRewardView",param);
end


function TipMgr.IsOpenTipView()
	return ViewSys.instance:IsOpen("TipView") or ViewSys.instance:IsOpen("TipType1View") or ViewSys.instance:IsOpen("TipType2View");
end

function TipMgr.ShowTipDescView(title,content)
	local param = ViewParam()
	content = (string.gsub(content,"\\n","\n"));
	local table = 
	{
		 title = title,
		 content = content,
	}
	param.objParam = table
	if(ViewSys.instance:IsOpen("TipDescView")) then
		ViewSys.instance:Close("TipDescView");
	end
	ViewSys.instance:Open("TipDescView",param);
end

function TipMgr.ShowItemTip(itemId,worldPos)
	local param = ViewParam()
	local table = 
	{
		 itemId = itemId,
		 worldPos = worldPos,
	}
	param.objParam = table;
	if(ViewSys.instance:IsOpen("ItemTipView")) then
		ViewSys.instance:Close("ItemTipView");
	end
	ViewSys.instance:Open("ItemTipView",param);
end

function TipMgr.ShowHelpView(content,callback)
	local param = ViewParam()
	local table = 
	{
		 text = content,
		 callback = callback
	}
	param.objParam = table
	if(ViewSys.instance:IsOpen("HelpView")) then
		ViewSys.instance:Close("HelpView");
	end
	ViewSys.instance:Open("HelpView",param);
end

function TipMgr.CloseItemTip()
	ViewSys.instance:Close("ItemTipView");
end