TipDescView = class("TipDescView",TipDescViewUI)

function TipDescView:Init()
	local onClickClose = function (go)
		ViewSys.instance:Close("TipDescView");
	end
	EventTriggerListener.Get(self.btnClose.gameObject).onClick = EventTriggerListener.Get(self.btnClose.gameObject).onClick + onClickClose;
	EventTriggerListener.Get(self.mask).onClick = EventTriggerListener.Get(self.mask).onClick + onClickClose;
end

function TipDescView:OpenView(param)
	local tableParam = param.objParam;
	local title = tableParam["title"];
	local content = tableParam["content"];
	self.txtTitle.text = title;
	self.txtContent.text = content;
end

function TipDescView:CloseView()
	-- body
end

function TipDescView:DestroyView()
	-- body
end