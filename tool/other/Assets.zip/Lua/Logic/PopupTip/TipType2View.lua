
TipType2View = class("TipType2View",TipType2ViewUI);

function TipType2View:Init()

	local onClickClose = function (go)
		self:OnClickClose();
	end
	EventTriggerListener.Get(self.btnClose.gameObject).onClick = EventTriggerListener.Get(self.btnClose.gameObject).onClick + onClickClose;
	local onClickMaskClose = function (go)
		self:OnClickMaskClose();
	end
	EventTriggerListener.Get(self.mask).onClick = EventTriggerListener.Get(self.mask).onClick + onClickMaskClose;

	self.txtContent.text = "";
	self.contentHeight = self.txtContent.preferredHeight;
end

function TipType2View:OpenView(param)
	local luaParam = param.objParam;

	local txtContent = luaParam["txtContent"];
	if(txtContent ~= nil) then
		self.txtContent.gameObject:SetActive(true);
		self.txtContent.text = txtContent;
		local lineCount = self.txtContent.preferredHeight / self.contentHeight;
		if(lineCount < 2) then
			self.txtContent.alignment = UnityEngine.TextAnchor.MiddleCenter;
		else
			self.txtContent.alignment = UnityEngine.TextAnchor.MiddleLeft;
		end 
	else
		self.txtContent.gameObject:SetActive(false);
	end
	

	local closeCallback = luaParam["closeCallback"]
	self.closeCallback = closeCallback;

	self.maskClose = luaParam["maskClose"];
	if(self.maskClose == nil) then self.maskClose = true end
end

function TipType2View:CloseThis()
	ViewSys.instance:Close("TipType2View")
end

function TipType2View:OnClickClose()
	local callback = self.closeCallback;
	self:CloseThis();
	if(nil ~= callback) then
		callback();
	end
end

function TipType2View:OnClickMaskClose()
	if(self.maskClose) then
		self:OnClickClose();
	end
end

function TipType2View:CloseView()
	self.closeCallback = nil;
end

function TipType2View:DestroyView()
	self.closeCallback = nil;
end