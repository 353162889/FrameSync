TipType1View = class("TipType1View",TipType1ViewUI);

function TipType1View:Init()
	local onClickMaskClose = function (go)
		self:OnClickMaskClose();
	end
	EventTriggerListener.Get(self.mask).onClick = EventTriggerListener.Get(self.mask).onClick + onClickMaskClose;

	local onClickConfirm = function (go)
		self:OnClickConfirm();
	end
	EventTriggerListener.Get(self.btnConfirm.gameObject).onClick = EventTriggerListener.Get(self.btnConfirm.gameObject).onClick + onClickConfirm;

	local onClickCancel = function (go)
		self:OnClickCancel();
	end
	EventTriggerListener.Get(self.btnCancel.gameObject).onClick = EventTriggerListener.Get(self.btnCancel.gameObject).onClick + onClickCancel;
	self.txtContent.text = "";
	self.contentHeight = self.txtContent.preferredHeight;
end

function TipType1View:OpenView(param)
	local luaParam = param.objParam;

	local txtContent = luaParam["txtContent"];
	if(txtContent ~= nil) then
		self.txtContent.gameObject:SetActive(true);
		self.txtContent.text = txtContent;
		local lineCount = self.txtContent.preferredHeight / self.contentHeight;
		if(lineCount < 2) then
			self.txtContent.alignment = UnityEngine.TextAnchor.MiddleCenter;
		else
			self.txtContent.alignment = UnityEngine.TextAnchor.MiddleLeft;
		end 
	else
		self.txtContent.gameObject:SetActive(false);
	end
	

	local confirmCallback = luaParam["confirmCallback"]
	self.confirmCallback = confirmCallback;

	local cancelCallback = luaParam["cancelCallback"]
	self.cancelCallback = cancelCallback;

	self.maskClose = luaParam["maskClose"];
	if(self.maskClose == nil) then self.maskClose = true end
end

function TipType1View:CloseThis()
	ViewSys.instance:Close("TipType1View")
end

function TipType1View:OnClickClose()
	local callback = self.closeCallback;
	self:CloseThis();
	if(nil ~= callback) then
		callback();
	end
end

function TipType1View:OnClickMaskClose()
	if(self.maskClose) then
		self:OnClickClose();
	end
end

function TipType1View:OnClickConfirm()
	local callback = self.confirmCallback;
	self:CloseThis();
	if(nil ~= callback) then
		callback();
	end
end

function TipType1View:OnClickCancel()
	local callback = self.cancelCallback;
	self:CloseThis();
	if(nil ~= callback) then
		callback();
	end
end

function TipType1View:CloseView()
	self.confirmCallback = nil;
	self.cancelCallback = nil;
	self.closeCallback = nil;
end

function TipType1View:DestroyView()
	self.confirmCallback = nil;
	self.cancelCallback = nil;
	self.closeCallback = nil;
end