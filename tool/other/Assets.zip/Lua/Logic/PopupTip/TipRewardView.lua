--[[
名称：奖励面板
模块：PopupTip
--]]
TipRewardView = class("TipRewardView", TipRewardViewUI);


local OnCloseCallBack=nil
local titleModel=nil
local title=nil
local MaxSize =4 ---最多显示4个
local DataQueue={}--数据结构 ids{} numbers{}
local IconItems={}--Item-生成的图标

function TipRewardView:Init()
	print("初始化奖励界面")
	self:RegisterEvent()
end
--数据结构 title ids{} numbers{} callback
function TipRewardView:OpenView(param)
	print("打开奖励界面")
	OnCloseCallBack=nil
	TipRewardView.ClearView()
	TipRewardView.InitDataQueue(param)
	TipRewardView.TakeOutDataQueue()
end


function TipRewardView:CloseView()
	print("关闭奖励界面")
	self.ClearView()
end

function TipRewardView.InitDataQueue(param)
	print("初始化缓存数据的数据表")
	local objParam = param.objParam;
	if objParam.title~=nil then
		titleModel=objParam.title;
	else
		titleModel="恭喜您获得:"
	end
	if objParam.callback~=nil then
		OnCloseCallBack = objParam.callback 
	end
	if DataQueue.ids == nil then DataQueue.ids={} end
	if DataQueue.numbers == nil then DataQueue.numbers = {} end
	for i=1,#objParam.ids do
		table.insert(DataQueue.ids,objParam.ids[i])
		table.insert(DataQueue.numbers,objParam.numbers[i])
	end
end

function TipRewardView.TakeOutDataQueue()
	print("从缓存的数据表里取数据")
	if #DataQueue.ids>MaxSize then 
		for i =1,MaxSize do
			TipRewardView.UpdateView(1)
			table.remove (DataQueue.ids,1)
			table.remove (DataQueue.numbers,1)
		end
	else 
		for i =1,#DataQueue.ids do
			TipRewardView.UpdateView(1)
			table.remove (DataQueue.ids,1)
			table.remove (DataQueue.numbers,1)
		end
	end 
end

function TipRewardView.UpdateView(dataIndex)
	print("通过数据索引值更新界面")
	local iconItem = IconItem.Create(TipRewardView.itemContent)
	local cfg = ItemTable[DataQueue.ids[dataIndex]]
	iconItem:UpdateByCfg(cfg,DataQueue.numbers[dataIndex])
	--iconItem:UpdateByIcon(ItemTable[DataQueue.ids[dataIndex]].icon,DataQueue.numbers[dataIndex])
	table.insert(IconItems,iconItem)
	if title~=nil then
		title = title..","..ItemTable[DataQueue.ids[dataIndex]].name.."X"..DataQueue.numbers[dataIndex]
	else
		title = ItemTable[DataQueue.ids[dataIndex]].name.."X"..DataQueue.numbers[dataIndex]
	end
	TipRewardView.titleContent.text =titleModel..title
end

function TipRewardView.ClearView()
	print("清理界面")
	for i=1,#IconItems do
		IconItems[i]:Destroy()
	end
	IconItems = {}
	title =nil
	TipRewardView.titleContent.text =nil
end

function TipRewardView.OnClose()
	print("按钮点击关闭")
	if #DataQueue.ids~=0 then
		TipRewardView.ClearView()
		TipRewardView.TakeOutDataQueue()
	else
		ViewSys.instance:Close("TipRewardView")
		if OnCloseCallBack ~=nil then
			print("@@@@@@@@@")
			OnCloseCallBack()
		end
	end
	
end

function TipRewardView:RegisterEvent()
	print("初始化按钮事件")
	EventButtonListerer.Get(self.mask, self.OnClose)
	EventButtonListerer.Get(self.yesBtn,self.OnClose)
end
