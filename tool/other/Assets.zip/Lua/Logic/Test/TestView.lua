TestView = class("TestView",TestViewUI)

function TestView:Init()
	-- body
	--下面的写法有问题
	print("TestView:Init")
	local OptionData = UnityEngine.UI.Dropdown.OptionData;
	local arrTxt = {"setmatchplayer","addmoney","additem","setteammatchtime","client","nextday"}
	self.clientCmd = {};
	self.clientCmd["StartTimeScale"] = self.OnStartTimeScale;
	self.clientCmd["StopTimeScale"] = self.OnStopTimeScale;
	self.clientCmd["AddBuff"] = self.OnAddBuff;
	self.clientCmd["RemoveBuff"] = self.OnRemoveBuff;
	self.clientCmd["SetSessionId"] = self.OnSetSessionId;
	self.clientCmd["SetHeroId"] = self.OnSetHeroId;
	self.dropdown:ClearOptions();
	for i=1,#arrTxt do
		local data = OptionData();
		data.text = arrTxt[i];
		self.dropdown.options:Add(data)
	end
	self.dropdown.value = 0;
	self.dropdown.captionText.text = arrTxt[1];
	
	local listener = EventTriggerListener.Get(self.btnClose.gameObject);
	local clickClose = function (go)
		self:OnClickClose(go);
	end
	listener.onClick = listener.onClick + clickClose;

	listener = EventTriggerListener.Get(self.btnSendCmd.gameObject);
	local clickSendCmd = function (go)
		self:OnClickSendCmd(go);
	end
	listener.onClick = listener.onClick + clickSendCmd;

	listener = EventTriggerListener.Get(self.btn1.gameObject);
	self.txtBtn1.text = "掉血测试";
	local onClick1 = function (go)
		self:OnClickBtn1(go);
	end
	listener.onClick = listener.onClick + onClick1;

	listener = EventTriggerListener.Get(self.btn2.gameObject);
	self.txtBtn2.text = "主玩家添加积分";
	local onClick2 = function (go)
		self:OnClickBtn2(go);
	end
	listener.onClick = listener.onClick + onClick2;

	listener = EventTriggerListener.Get(self.btn3.gameObject);
	self.txtBtn3.text = "返回大厅";
	local onClick3 = function (go)
		self:OnClickBtn3(go);
	end
	listener.onClick = listener.onClick + onClick3;

	listener = EventTriggerListener.Get(self.btn4.gameObject);
	self.txtBtn4.text = "战斗重连测试";
	local onClick4 = function (go)
		self:OnClickBtn4(go);
	end
	listener.onClick = listener.onClick + onClick4;

	listener = EventTriggerListener.Get(self.btn5.gameObject);
	self.txtBtn5.text = "停止心跳";
	local onClick5 = function (go)
		self:OnClickBtn5(go);
	end
	listener.onClick = listener.onClick + onClick5;

	listener = EventTriggerListener.Get(self.btn6.gameObject);
	self.txtBtn6.text = "其他玩家添加积分";
	local onClick6 = function (go)
		self:OnClickBtn6(go);
	end
	listener.onClick = listener.onClick + onClick6;
	self.playerId = 1;

	local lstStrPlayers = Util.Split(ConstTable["test_player_ids"].p_string,',')
	self.testPlayers = {};
	for i=1,#lstStrPlayers do
		table.insert(self.testPlayers,tonumber(lstStrPlayers[i]));
	end
end

function TestView:OnClickClose(go)
	ViewSys.instance:Close("TestView");
end

function TestView:OnClickSendCmd(go)
	local index = self.dropdown.value;
	local cmd_pre = self.dropdown.options[index].text;
	local cmd_end = self.inpCmd.text;
	if(cmd_pre == "client") then
		local arr = Util.Split(cmd_end,':');
		if(#arr > 0) then
			local func = self.clientCmd[arr[1]];
			if(nil ~= func) then
				local param = nil;
				if(#arr > 1) then param = arr[2] end;
				func(self,param);
			end
		end
	else
		if(cmd_end ~= nil and cmd_end ~= "") then
			-- local num = tonumber(cmd_end);
			-- if(num == nil)then
			-- 	Util.LogColor("#ff0000","输入的数据:"..cmd_end+"不符合数字格式要求")
			-- 	return 
			-- end
		end
	    local data = C2S_GMCommandData();
	    data.command = cmd_pre.." ".. cmd_end;
	    Util.LogColor("#ff0000",data.command);
		NetSys.instance:SendWorldMsg(data:SerializeToString(), C2S_GMCommand);
	end
end

function TestView:OnStartTimeScale(param)
	if(nil ~= param) then
		local scale = tonumber(param);
		if(scale ~= nil) then
			FrameSyncSys.instance:StartTimeScale(scale);
		end
	end
end

function TestView:OnStopTimeScale(param)
	FrameSyncSys.instance:StopTimeScale();
end

function TestView:OnAddBuff(param)
	if(nil ~= param) then
		local buffId = tonumber(param);
		if(buffId ~= nil) then
			if(nil ~= BattleScene.instance.mainHero) then
				BattleScene.instance.mainHero.unitBuff:Add(PvpTool.GenerateBuffId(),buffId,nil);
				Util.LogColor("#ff0000","OnAddBuff",buffId)
			end
		end
	end
end

function TestView:OnRemoveBuff(param)
	if(nil ~= param) then
		local buffId = tonumber(param);
		if(buffId ~= nil) then
			if(nil ~= BattleScene.instance.mainHero) then
				BattleScene.instance.mainHero.unitBuff:RemoveByResId(buffId);
				Util.LogColor("#ff0000","OnRemoveBuff",buffId)
			end
		end
	end
end

function TestView:OnSetSessionId(param)
	if(nil ~= param) then
		local sessionId = tonumber(param);
		if(sessionId ~= nil) then
			LoginView.sessionId = sessionId;
		end
	end
end

function TestView:OnSetHeroId(param)
	if(nil ~= param) then
		local heroId = tonumber(param);
		if(heroId ~= nil) then
			LoginView.heroId = heroId;
		end
	end
end

function TestView:OnClickBtn1(go)
	if(nil ~= BattleScene.instance.mainHero) then
		local damageInfo = DamageInfo();
		damageInfo.attack = nil;
		damageInfo.defence = BattleScene.instance.mainHero;
		damageInfo.damage = 10000;
		BattleScene.instance.mainHero:OnHurt(damageInfo);
	end
	Util.LogColor("#ff0000","OnClickBtn1")
end

function TestView:OnClickBtn2(go)
	-- if(nil ~= BattleScene.instance.mainHero) then
	-- 	local damageInfo = DamageInfo();
	-- 	--damageInfo.attack = BattleScene.instance.mainHero;
	-- 	damageInfo.attack = nil;
	-- 	damageInfo.defence = BattleScene.instance.mainHero;
	-- 	damageInfo.damage = 50000;
	-- 	BattleScene.instance.mainHero:OnHurt(damageInfo);
	-- end
	--TipMgr.ShowTipType1("Server disconnected, please re-enter the game",nil,nil,nil);
	-- local itemIds = {900001,900002};
	-- local itemNums = {1000,1000}
	-- TipMgr.ShowRewardTip(nil,itemIds,itemNums,nil);
	if(nil ~= BattleScene.instance.mainHero) then
		BattleScene.instance.mainHero.unitAttr.coin = BattleScene.instance.mainHero.unitAttr.coin + 500;
	end
end
function TestView:OnClickBtn3(go)
	if(not BattleInfo.isStandAlone) then
		local data = C2S_ExitBattleData();
		local onExitBattle = function (obj,objMsg)
			Util.LogColor("#ff0000","S2C_ExitBattle")
			TestView.ExitBattle();
		end
		Util.LogColor("#ff0000","C2S_ExitBattle")
		NetSys.instance:SendPvpMsg(data:SerializeToString(), C2S_ExitBattle,S2C_ExitBattle,onExitBattle,nil);
		 FightManager.ExitToLobby(); 
	else
		TestView.ExitBattle();
	end
end

function TestView.ExitBattle()
    --FightManager.ExitToLobby();
end


function TestView:OnClickBtn4(go)
	local channel = NetSys.instance:GetChannel(EChannelType.EPvpChannel);
	channel:BeginReconnect();
end


TestView.heartBeat = true;
function TestView:OnClickBtn5(go)
	local channel = NetSys.instance:GetChannel(EChannelType.EPvpChannel);
	TestView.heartBeat = not TestView.heartBeat;
	if(TestView.heartBeat)then 
		self.txtBtn5.text = "停止心跳";
	else
		self.txtBtn5.text = "开启心跳";
	end
	channel:StartHeartBeat(TestView.heartBeat);
end
function TestView:OnClickBtn6(go)
	local lst = BattleScene.instance.lstHero;
	local count = lst.Count - 1;
	for i=0,count do
		lst[i].unitAttr.coin = lst[i].unitAttr.coin + 500;
	end
end

function TestView:OpenView(param)
	-- body
	print("TestView:OpenView")
	EventSys.instance:AddLuaEvent(GameEvent.OnItemUpdate,TestView.OnItemUpdate);
end

function TestView.OnItemUpdate(eventId,arg)
end

function TestView:CloseView()
	-- body
	print("TestView:CloseView")
end

function TestView:DestroyView()
	-- body
	print("TestView:DestroyView")
end
