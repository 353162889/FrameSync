﻿--From Lua Script Create
--ClassName: EquipmentShopManager
--Author:    hukiry
--CreateTime:2018-7-20

EquipmentShopManager = class(EquipmentShopManager)

--商店出售数量对 
EquipmentShopManager.equipShopNum = 5

--英雄可装备数量
EquipmentShopManager.heroEquipNum = 5

-- EquipmentShopManager.quickBuyData = {}

function EquipmentShopManager:Init()

end

function EquipmentShopManager:BuyEquipByID(equipID)
	local equipShopComp = BattleInfo.coreGaming:GetSysComp(EGamingSysCompType.EquipShop)
	-- local equipInfo = ResEquipTable[equipID]
	local mianHeroID = BattleScene.instance.mainHero.id
	-- local coin = BattleScene.instance.mainHero.unitAttr.coin --经验值

	-- if coin < equipInfo.exp_cost then
	-- 	--经验不足
	-- 	print("经验不足")
	-- 	return
	-- end

	equipShopComp:BuyEquipByInfo(mianHeroID, equipID)
end

--获得英雄Unit
function EquipmentShopManager:GetCurHeroUnit()
	local mainHero = BattleScene.instance.mainHero
	if mainHero then
		local id = mainHero.id
		local unit = BattleScene.instance:GetUnit(id)
		return unit
	else
		error("BattleScene.instance.mainHero 不存在")
	end
end

--获取当前英雄身上装备列表
function EquipmentShopManager:GetCurHeroEquipArr()
	local unit = EquipmentShopManager:GetCurHeroUnit()
	if unit then
		local arrDressEquip = unit.unitEquip.arrDressEquip
		return arrDressEquip
	end
end

--获取指定类型装备信息
function EquipmentShopManager:GetEquipInfoByData(heroInfo,type)
	for _,id in pairs(heroInfo.unlock_equipment_list) do
		local equipInfo = ResEquipTable[id]
		if equipInfo.type == type then
			return equipInfo
		end
	end

end

--是否已经购买指定位置装备
function EquipmentShopManager:IsBoughtEquipByID(equipID)
	local isBought = false
	local equipInfo = ResEquipTable[equipID]

	local equipArr = EquipmentShopManager:GetCurHeroEquipArr()
	for i = 0,EquipmentShopManager.heroEquipNum - 1 do
		local equipData = equipArr[i]
		if equipData then
			local bodyEquipInfo = ResEquipTable[equipData.resId]
			if bodyEquipInfo.type == equipInfo.type then
				isBought = true
				break
			end
		end
	end

	return isBought
end

--是否解锁指定装备
function EquipmentShopManager:IsUnlockEquipByID(equipID)
	local isUnlock = false

	local unit = EquipmentShopManager:GetCurHeroUnit()
	if unit then
		local equipDataList = unit.unitEquip.lstEquip
		for i = 0,equipDataList.Count - 1 do
			if equipID == equipDataList[i].resId then
				isUnlock = true
				break
			end
		end
	end

	return isUnlock
end

--获得快速购买装备数据
function EquipmentShopManager:GetQuickBuyEquipData(money)
	local data = {}
	local maxNum = 2
	local unit = EquipmentShopManager:GetCurHeroUnit()
	local equipDataList = unit.unitEquip.lstEquip

	for i = 0,equipDataList.Count - 1 do
		local resId = equipDataList[i].resId
		local equipInfo = ResEquipTable[resId]
		local isBought = EquipmentShopManager:IsBoughtEquipByID(equipInfo.id)
		local isUnlock = EquipmentShopManager:IsUnlockEquipByID(equipInfo.id)
		if isBought == false and isUnlock == true and equipInfo.exp_cost <= money then
			table.insert(data,equipInfo)
		end
	end

	--从贵到便宜 排序装备
	local sortFunc = function(a,b)
		return a.exp_cost > b.exp_cost
	end
	table.sort(data, sortFunc)

	local quickData = {}
	for k,v in pairs(data) do
		table.insert(quickData,v)
		if #quickData >= maxNum then
			break
		end
	end
	return quickData
end

--获取装备数据
function EquipmentShopManager:GetCurEquipmentShopData()
	local dataTable = {}
	
	local unit = EquipmentShopManager:GetCurHeroUnit()
	if unit then
		local equipDataList = unit.unitEquip.lstEquip
		local heroInfo = HeroTable[unit.resId]
		
		for i = 0,equipDataList.Count - 1 do
			local data = {}
			local resId = equipDataList[i].resId
			-- print("装备ID:"..resId)

			local equipInfo = ResEquipTable[resId]

			if dataTable[equipInfo.type] then
				data = dataTable[equipInfo.type]
			end

			if equipInfo.is_base == true then  --基础装备
				data.baseEquipInfo = equipInfo
			else
				data.unlockEquipInfo = equipInfo
			end
			dataTable[equipInfo.type] = data
		end

		for type,v in pairs(dataTable) do
			if not v.unlockEquipInfo then
				v.unlockEquipInfo = EquipmentShopManager:GetEquipInfoByData(heroInfo,type)
			end
		end
	end

	-- for type,v in pairs(dataTable) do
	-- 	print("type:"..type)
	-- 	print("基础装备ID : "..v.baseEquipInfo.id)
	-- 	print("解锁装备ID : "..v.unlockEquipInfo.id)
	-- end

	return dataTable
end	
