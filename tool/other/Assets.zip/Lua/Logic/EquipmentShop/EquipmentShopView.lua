﻿--From Lua Script Create
--ClassName: EquipmentShopView
--Author:    hukiry
--CreateTime:2018-7-20

require "Logic/EquipmentShop/EquipmentShopManager"
EquipmentShopView = class("EquipmentShopView",EquipmentShopViewUI)

local this

--枚举
local SelectType = {}
SelectType.Body = 1
SelectType.Base = 2
SelectType.Unlock = 3

--缓存
local equipObjTable = {}
local curSelectEquipData = false
local heroEquipTable = {}  --英雄身上装备Table

function EquipmentShopView:Init()
	this = self
	self:RegeditEvent()
	self:RefreshAllShow()  --刷新所有显示
end

--刷新装备商店信息
function EquipmentShopView:RefreshEquipShop()
	local dataTable = EquipmentShopManager:GetCurEquipmentShopData()
	for index,v in pairs(dataTable) do
		if not equipObjTable[index] then
			local objData = {}
			if index == 1 then
				objData.go = self.singleEquipContainer
			else
				objData.go = UnityEngine.GameObject.Instantiate(self.singleEquipContainer);
				objData.go.transform:SetParent(self.equipContent, false)
			end

			objData.img_rightIsLock = objData.go.transform:Find("rightEquipItem/img_isLock").gameObject
			objData.txt_leftName = objData.go.transform:Find("leftEquipItem/txt_equipmentName"):GetComponent("Text")
			objData.txt_rightName = objData.go.transform:Find("rightEquipItem/txt_equipmentName"):GetComponent("Text")
			objData.btn_leftEquip = objData.go.transform:Find("leftEquipItem/btn_equip").gameObject
			objData.btn_rightEquip = objData.go.transform:Find("rightEquipItem/btn_equip").gameObject
			objData.img_leftLightBg = objData.go.transform:Find("leftEquipItem/img_lightBg").gameObject
			objData.img_rightLightBg = objData.go.transform:Find("rightEquipItem/img_lightBg").gameObject
			objData.img_leftEquipIcon = objData.btn_leftEquip.transform:Find("Mask/img_equipIcon"):GetComponent("Image")
			objData.img_rightEquipIcon = objData.btn_rightEquip.transform:Find("Mask/img_equipIcon"):GetComponent("Image")
			objData.txt_baseEquipCost = objData.go.transform:Find("leftArrow/txt_baseEquipCost"):GetComponent("Text")
			objData.txt_unlockEquipCost = objData.go.transform:Find("rightArrow/txt_unlockEquipCost"):GetComponent("Text")
			objData.baseEquipInfo = v.baseEquipInfo  --基础装备
			objData.unlockEquipInfo = v.unlockEquipInfo  --基础装备
			table.insert(equipObjTable, objData)

			local baseEquipInfo = v.baseEquipInfo  --基础装备
			local unlockEquipInfo = v.unlockEquipInfo  --解锁装备

			if not curSelectEquipData then
				self:SetSelectEquipData(baseEquipInfo, SelectType.Base)
			end

			--点击左边
			local clickLeftEquip = function()
				self:SetSelectEquipData(baseEquipInfo, SelectType.Base)
				self:RefreshAllShow() --刷新所有显示
			end
			EventButtonListerer.Get(objData.btn_leftEquip, clickLeftEquip)

			--点击右边
			local clickRightEquip = function()
				self:SetSelectEquipData(unlockEquipInfo, SelectType.Unlock)
				self:RefreshAllShow() --刷新所有显示
			end
			EventButtonListerer.Get(objData.btn_rightEquip, clickRightEquip)

			UIUtil.SetSpriteByPath(objData.img_leftEquipIcon, baseEquipInfo.icon)
			UIUtil.SetSpriteByPath(objData.img_rightEquipIcon, unlockEquipInfo.icon)
			objData.txt_baseEquipCost.text = "-"..baseEquipInfo.exp_cost.."经验"
			objData.txt_unlockEquipCost.text = "-"..unlockEquipInfo.exp_cost.."经验"
			objData.txt_leftName.text = baseEquipInfo.name
			objData.txt_rightName.text = unlockEquipInfo.name

			local isUnlock = EquipmentShopManager:IsUnlockEquipByID(unlockEquipInfo.id)
			if isUnlock == true then
				objData.img_rightIsLock:SetActive(false)
			else
				objData.img_rightIsLock:SetActive(true)
			end
		end

		self:RefreshSingleEquipShopItem(index)
	end

end

--刷新装备商店 单个Item
function EquipmentShopView:RefreshSingleEquipShopItem(index)
	if curSelectEquipData then
		local info = curSelectEquipData.info
		local selectType = curSelectEquipData.selectType
		local v = equipObjTable[index]

		v.img_leftLightBg:SetActive(false)
		v.img_rightLightBg:SetActive(false)

		if info.id == v.baseEquipInfo.id and selectType == SelectType.Base then
			v.img_leftLightBg:SetActive(true)
		end

		if info.id == v.unlockEquipInfo.id and selectType == SelectType.Unlock then
			v.img_rightLightBg:SetActive(true)
		end
	end
end


--刷新英雄身上装备列表
function EquipmentShopView:RefreshHeroEquipList()
	local equipArr = EquipmentShopManager:GetCurHeroEquipArr()

	for i = 0,EquipmentShopManager.heroEquipNum - 1 do
	
		local objData = {}
		if heroEquipTable[i] then
			objData = heroEquipTable[i]
		else
			if i == 0 then
				objData.go = self.heroEquipItem
			else
				objData.go = UnityEngine.GameObject.Instantiate(self.heroEquipItem)
				objData.go.transform:SetParent(self.equipmentLayout, false)
			end
			objData.img_lightBg = objData.go.transform:Find("img_lightBg"):GetComponent("Image")
			objData.btn_equip = objData.go.transform:Find("btn_equip").gameObject
			objData.img_equipIcon = objData.btn_equip.transform:Find("Mask/img_equipIcon"):GetComponent("Image")
			
			heroEquipTable[i] = objData
		end

		local equipData = equipArr[i]
		print("index:"..i)
		if equipData then
			local equipInfo = ResEquipTable[equipData.resId]
			print("装备:"..equipInfo.name)
			UIUtil.SetSpriteByPath(objData.img_equipIcon, equipInfo.icon)
			objData.img_equipIcon.gameObject:SetActive(true)
			objData.info = equipInfo
			local clickBodyEquip = function()
				print("点击身上装备名字:"..equipInfo.name)
				self:SetSelectEquipData(equipInfo, SelectType.Body)
				self:RefreshAllShow()  --刷新所有显示
			end
			EventButtonListerer.RemoveAllListeners(objData.btn_equip)
			EventButtonListerer.Get(objData.btn_equip, clickBodyEquip)

			if curSelectEquipData and curSelectEquipData.selectType == SelectType.Body and curSelectEquipData.info.id == equipInfo.id then
				objData.img_lightBg.gameObject:SetActive(true)
			else
				objData.img_lightBg.gameObject:SetActive(false)
			end
		else
			objData.img_equipIcon.gameObject:SetActive(false)
			objData.img_lightBg.gameObject:SetActive(false)
		end
		
	end
end

--刷新选中装备信息
function EquipmentShopView:RefreshSelectEquipInfo()
	if curSelectEquipData then
		local info = curSelectEquipData.info
		local selectType = curSelectEquipData.selectType
		self.txt_selectEquipName.text = info.name
		self.txt_equipmentDesc.text = info.desc

		local isBought = EquipmentShopManager:IsBoughtEquipByID(info.id)
		local isUnlock = EquipmentShopManager:IsUnlockEquipByID(info.id)

		self.btn_buyEquipment:SetActive(false)
		self.img_isBought:SetActive(false)
		self.img_isEquipLock:SetActive(false)

		print("isBought:")
		print(isBought)
		print("isUnlock:")
		print(isUnlock)

		if isUnlock == true then
			--已解锁
			if isBought == true then  
				--已购买
				self.img_isBought:SetActive(true)
			else  
				--可购买
				self.btn_buyEquipment:SetActive(true)
			end
		else
			--未解锁  显示[锁定]状态
			self.img_isEquipLock:SetActive(true)
		end

		
	end

end

--设置选中数据
function EquipmentShopView:SetSelectEquipData(info,selectType)
	if not curSelectEquipData then
		curSelectEquipData = {}
	end
	curSelectEquipData.info = info
	curSelectEquipData.selectType = selectType
end

--刷新所有显示
function EquipmentShopView:RefreshAllShow()
	self:RefreshEquipShop()   --刷新装备商店信息
	self:RefreshHeroEquipList()   --刷新英雄身上装备
	self:RefreshSelectEquipInfo()  --刷新选中装备信息
end

function EquipmentShopView:OpenView()
	self:RefreshSelectEquipInfo()
end

function EquipmentShopView:CloseView()

end

function EquipmentShopView:DestroyView()

end

function EquipmentShopView:ClosePanel()
    ViewSys.instance:Close("EquipmentShopView")
end

function EquipmentShopView:BuyCurSelectEquip()
	if not curSelectEquipData then
		print("没有选定装备信息!")
		return
	end

	--购买装备
	EquipmentShopManager:BuyEquipByID(curSelectEquipData.info.id)
end

function EquipmentShopView:OnEquipDress()
	print("装备商店|穿上装备回调")
	this:RefreshHeroEquipList()
	this:RefreshSelectEquipInfo()
end

function EquipmentShopView:RegeditEvent()
	EventSys.instance:AddEvent(EEventType.OnUnitEquipDress,self.OnEquipDress);	
	EventButtonListerer.Get(this.btn_buyEquipment, this.BuyCurSelectEquip)
	local onClickClose = function ()
		self:ClosePanel()
	end
    EventTriggerListener.Get(self.mask).onClick = EventTriggerListener.Get(self.mask).onClick + onClickClose;
end