--主要记录登录逻辑中的一些数据
LoginInfo = {};

--登录服务器
--连接登录服务器的ip
LoginInfo.loginIp = "";
--连接登录服务器的端口
LoginInfo.loginPort = 0;
--登录类型(1表示一般登录，2表示sdk登录)
LoginInfo.loginType = 0;
--登录时使用的验证码（当登录类型=1时，使用登录账号，当登录类型为2时，使用sdk返回的session）
LoginInfo.loginAutoCode = "";
--登录密码（暂时不使用）
LoginInfo.loginPassward = "";
--大版本号
LoginInfo.majorVersion = 0;
--小版本号
LoginInfo.minorVersion = 0;


--大厅服务器
--登录成功返回的用户ID
LoginInfo.userId = 0;
--大厅服务器的ip
LoginInfo.worldIp = "";
--大厅服务器的端口
LoginInfo.worldPort = "";
--大厅服务器的验证码
LoginInfo.worldAuthCode = "";

--登录时的额外信息
LoginInfo.hasNoComplateGame = false;

function LoginInfo.Clear()
	LoginInfo.loginIp = "";
	LoginInfo.loginPort = 0;
	LoginInfo.loginType = 0;
	LoginInfo.loginAutoCode = "";
	LoginInfo.loginPassward = "";

	LoginInfo.userId = 0;
	LoginInfo.worldIp = "";
	LoginInfo.worldPort = "";
	LoginInfo.worldAuthCode = "";
end