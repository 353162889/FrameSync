local _ipAddress = CResourceSys.instance.gameConfig.mLoginSvrUrl;
local _port = CResourceSys.instance.gameConfig.mLoginSvrPort;

local _nameConst = "combokill_20180613_authcode";

LoginView = class("LoginView", LoginViewUI); 

function LoginView:Init()
	local onClickLogin = function (go)
		self:OnClickLogin();
	end
	EventTriggerListener.Get(self.loginBtn).onClick = EventTriggerListener.Get(self.loginBtn).onClick + onClickLogin;
end

function LoginView:OpenView(param)
	if (true == SDKManager.instance.isBaseVersion) then
		self.userNameInput.transform.parent.gameObject:SetActive(true);
	else
		self.userNameInput.transform.parent.gameObject:SetActive(false);
	end
	local userName = LocalStorage.instance:GetString(_nameConst,"");
	self.userNameInput.text = userName;
	LoginMgr.Clear();
end

function LoginView:CloseView()
	LoginMgr.Clear();
end

function LoginView:DestroyView()
	-- body
end

LoginView.sessionId = 3;
LoginView.heroId = 1001;
function LoginView:OnClickLogin()
	if(not CGameRoot.instance.isStandAlone) then
		SDKManager.instance:Login();
	else
		MainLobbyManager.playerBaseInfo = {};
		MainLobbyManager.playerBaseInfo.name = "玩家";
		MatchInfo.Clear();
	    MatchInfo.hasNoComplateGame = false; 
	    MatchInfo.battleServerIP = ""; 
	    MatchInfo.battleServerTcpPort = 0; 
	    MatchInfo.battleServerUdpPort = 0; 
	    MatchInfo.battleAuthCode = 0; 
	    MatchInfo.kcpId = 0; 
	    MatchInfo.sessionId = LoginView.sessionId;

	   
		ViewSys.instance:Close("LoginView");
		BattleSceneLoad.Load()
		BattleInfo.selectHeroDefineId = LoginView.heroId;
		BattleInfo.selectHeroSkinId = LoginView.heroId;
		BattleInfo.lastExitFrameIndex = 0;
	end
end

function LoginView.ConnectLoginServer(authCode)
	local curAuthCode = "";
	local loginType = 0;
    if (true == SDKManager.instance.isBaseVersion) then
        local userName = LoginView.userNameInput.text;
		if(userName == nil or userName == "") then
			TipMgr.ShowTipType2("The input userName cannot be empty!",nil);
			return;
		end
		loginType = 1;
		curAuthCode = userName;
    else
        curAuthCode = authCode;
        loginType = 2;
    end
    local onLoginCallback = function (succ)
    	LoginView:OnLoginResult(succ);
    end
    LoginView.loginAuthCode = curAuthCode;
    LoginMgr.Login(_ipAddress,_port,loginType,curAuthCode,"",onLoginCallback);
end

function LoginView:OnLoginResult(succ)
	if(succ) then
		Util.LogColor("#ff0000","登录成功")

		if(self.loginAuthCode ~= nil) then
			LocalStorage.instance:SetString(_nameConst,self.loginAuthCode)
		end
		--登录成功消息
		ViewSys.instance:Close("LoginView");
		--默认非单机
		CGameRoot.instance.isStandAlone = false; 
		if(MatchInfo.hasNoComplateGame) then
			BattleSceneLoad.Load()
		else
			--如果已取名，不在进入取名界面
			local curName = MainLobbyManager.playerBaseInfo.name;
			if(curName == nil or curName == "") then
				ViewSys.instance:Open("LobbyView");
			else
				ViewSys.instance:Open("MainLobbyView");
			end
		end
	else
		if(not TipMgr.IsOpenTipView()) then
			TipMgr.ShowTipType2("Login Fail!",nil);
		end
	end
end
