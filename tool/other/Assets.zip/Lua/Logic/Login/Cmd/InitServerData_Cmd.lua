--等待初始化数据完成
InitServerData_Cmd = class("InitServerData_Cmd",CommandBase)
function InitServerData_Cmd:Execute(context)
	InitServerData_Cmd.super.Execute(self,context);
	self.onInitCompleteResult = function (eventId,obj)
		self:OnInitCompleteResult(eventId,obj);
	end
	Util.Log("等待数据初始化"); 
	EventSys.instance:AddLuaEvent(GameEvent.LoginDataInitComplete,self.onInitCompleteResult);
end

function InitServerData_Cmd:OnInitCompleteResult(eventId,obj)
	--如果出事化完成后，有额外的数据，在这里初始化
	Util.Log("数据初始化完成"); 
	self:OnExecuteDone(CmdExecuteState.Success);
end

function InitServerData_Cmd:OnDestroy()
	if(nil ~= self.onInitCompleteResult) then
		EventSys.instance:RemoveLuaEvent(GameEvent.LoginDataInitComplete,self.onInitCompleteResult);
		self.onInitCompleteResult = nil;
	end
	InitServerData_Cmd.super.OnDestroy(self);
end