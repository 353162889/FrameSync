--主要负责连接登录服务器的处理
ConnectLoginServer_Cmd = class("ConnectLoginServer_Cmd",CommandBase)
function ConnectLoginServer_Cmd:Execute(context)
	ConnectLoginServer_Cmd.super.Execute(self,context);
	local onConnectLoginServer = function (succ)
		self:ConnectLoginServer(succ);
	end
    Util.Log("开始连接登录服务器"..tostring(LoginInfo.loginIp)); 
	NetSys.instance:ConnectServer(EChannelType.ELoginChannel, LoginInfo.loginIp, LoginInfo.loginPort, onConnectLoginServer); 
end

function ConnectLoginServer_Cmd:ConnectLoginServer(succ)
	if succ then
        local data = C2S_LoginRequireData(); 
        data.login_type = LoginInfo.loginType; 
        data.auth_code = LoginInfo.loginAutoCode; 
        data.password = LoginInfo.loginPassward;
        data.major_version = LoginInfo.majorVersion;
        data.minor_version = LoginInfo.minorVersion;
        if SDKManager.instance:IsIOSVersion() then
            data.sdk_type = 2;
        else
            data.sdk_type = 1;
        end
        self.onLoginResult = function (obj, objMsg)
        	self:OnLoginResult(obj,objMsg)
        end
        Util.Log("开始验证登录服务器"); 
        NetSys.instance:SendLoginMsg(data:SerializeToString(), C2S_LoginRequire, S2C_LoginResult, self.onLoginResult, nil); 
    else
    	Util.LogError("连接登录服务器失败"); 
        self:OnExecuteDone(CmdExecuteState.Fail);
        --print("-----------------------------------------------------------------------")
    end
end

function ConnectLoginServer_Cmd:OnLoginResult(obj, objMsg)
	self.onLoginResult = nil;
	local msg = S2C_LoginResultData(); 
    msg:ParseFromString(objMsg); 
    --print("----------------------...", msg, msg.result)
    if msg.result == Error_None then
        --do
        LoginInfo.userId = msg.actID;
        LoginInfo.worldIp = msg.serverIP;
        LoginInfo.worldPort = msg.port;
        LoginInfo.worldAuthCode = msg.authCode;

        --初始化td
        SDKManager.instance:SetTDAccount(tostring(msg.actID));
        SDKManager.instance:OnTDEvent("登陆成功");

        --关闭登录服务器
        NetSys.instance:CloseConnect(EChannelType.ELoginChannel); 
        self:OnExecuteDone(CmdExecuteState.Success);
    else
    	Util.LogError("登录登录服务器失败","loginType",LoginInfo.loginType,"loginAutoCode",LoginInfo.loginAutoCode,"loginPassward",LoginInfo.loginPassward); 
        if(msg.result == Error_AuthCheckFaild) then
            TipMgr.ShowTipType2("Login Fail! Incorrect username or password",nil);
        elseif(msg.result == Error_VersionCode) then
            TipMgr.ShowTipType2("Login Fail! Incorrect version code",nil);
        end
        self:OnExecuteDone(CmdExecuteState.Fail);
    end
end

function ConnectLoginServer_Cmd:OnDestroy()
	NetSys.instance:RemoveConnectServerCallback(EChannelType.ELoginChannel);
	if(self.onLoginResult ~= nil) then
		NetSys.instance:RemoveMsgCallback(EChannelType.ELoginChannel,S2C_LoginResult,ConnectLoginServer_Cmd.ResLogin);
		self.onLoginResult = nil;
	end
	ConnectLoginServer_Cmd.super.OnDestroy(self);
end