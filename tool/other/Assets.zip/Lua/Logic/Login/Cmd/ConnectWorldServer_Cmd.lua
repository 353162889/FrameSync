--主要处理连接世界服务器
ConnectWorldServer_Cmd = class("ConnectWorldServer_Cmd",CommandBase)
function ConnectWorldServer_Cmd:Execute(context)
	ConnectWorldServer_Cmd.super.Execute(self,context);
	local onConnectWorldResult = function (succ)
		self:OnConnectWorldResult(succ);
	end
	Util.Log("开始连接世界服务器"); 
	NetSys.instance:ConnectServer(EChannelType.EWorldChannel, LoginInfo.worldIp, LoginInfo.worldPort, onConnectWorldResult); 
end

function ConnectWorldServer_Cmd:OnConnectWorldResult(succ)
	if succ then
		local onCheckCodeResult = function (result)
			self:OnCheckCodeResult(result);
		end
		Util.Log("开始检测世界服务器"); 
		NetSys.instance:CheckCode(EChannelType.EWorldChannel,LoginInfo.userId,LoginInfo.worldAuthCode,onCheckCodeResult);
    else
    	Util.LogError("连接世界服务器失败"); 
        self:OnExecuteDone(CmdExecuteState.Fail);
    end
end

function ConnectWorldServer_Cmd:OnCheckCodeResult(result)
	if result == Error_None then
        Util.Log("检测世界服务器成功")
        --世界服务器开启心跳包检测断线
         local channel = NetSys.instance:GetChannel(EChannelType.EWorldChannel);
         channel:StartHeartBeat(true);
         channel:SetOutOfTime(600);
         self:OnExecuteDone(CmdExecuteState.Success);
    else
    	Util.LogError("检测世界服务器失败 错误码："..msg.result); 
    	self:OnExecuteDone(CmdExecuteState.Fail);
    end
end

function ConnectWorldServer_Cmd:OnDestroy()
	NetSys.instance:RemoveConnectServerCallback(EChannelType.EWorldChannel);
	NetSys.instance:RemoveCheckCodeCallback(EChannelType.EWorldChannel);
	ConnectWorldServer_Cmd.super.OnDestroy(self);
end