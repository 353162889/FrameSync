require "Logic/Login/Cmd/ConnectLoginServer_Cmd"
require "Logic/Login/Cmd/ConnectWorldServer_Cmd"
require "Logic/Login/Cmd/InitServerData_Cmd"

--处理连接登录服务器与大厅服务器（等待数据初始化完成）
LoginMgr = {}

LoginMgr.isLogining = false;

function LoginMgr.Init()
	--这个处理不能在命令流中处理，如果AddMsgCallback命令比较晚，（lua中的包是通过是否添加监听判定的），此时有可能包已解析完，但没有添加监听事件，导致出现问题
	NetSys.instance:AddMsgCallback(EChannelType.EWorldChannel,S2C_InitComplete,LoginMgr.S2C_InitCompleteData,nil);
end

function LoginMgr.S2C_InitCompleteData(obj,objMsg)
	--派发出初始化数据完成消息
	EventSys.instance:DispatchLua(GameEvent.LoginDataInitComplete);
end

--ip:Ip
--port:端口
--loginType:登录类型（1、普通登录，2、sdk登录)
--登录口令(根据不同登录类型不一样的值)
--登录密码
--登录回调 callback(bool)
function LoginMgr.Login(ip,port,loginType,authCode,password,callback)
	if(LoginMgr.isLogining)then 
		return;
	end
	LoginInfo.Clear();
	LoginMgr.Clear();
	NetSys.instance:CloseConnect(EChannelType.ELoginChannel); 
	NetSys.instance:CloseConnect(EChannelType.EWorldChannel); 
	LoginMgr.loginTime = 10;--登录最大等待时间
	LoginMgr.callback = callback;

	LoginInfo.loginIp = ip;
	LoginInfo.loginPort = port;
	LoginInfo.loginType = loginType;
	LoginInfo.loginAutoCode = authCode;
	LoginInfo.loginPassward = password;
	LoginInfo.majorVersion = CResourceSys.instance.gameConfig.mMajorVersion;
	LoginInfo.minorVersion = CResourceSys.instance.gameConfig.mMinorVersion;


	local sequence = CommandSequence.new();
	LoginMgr.sequence = sequence;
	local cmdConnectLoginServer= ConnectLoginServer_Cmd.new();
	local cmdConnectWorldServer = ConnectWorldServer_Cmd.new();
	local cmdInitServerData = InitServerData_Cmd.new();
	sequence:AddSubCommand(cmdConnectLoginServer);
	sequence:AddSubCommand(cmdConnectWorldServer);
	sequence:AddSubCommand(cmdInitServerData);

	sequence:AddDoneFunc(LoginMgr.OnLoadDone)
	sequence:Execute({});
	LoginMgr.isLogining = true;

	Main.AddUpdateFun(LoginMgr.Update, nil); 

end

function LoginMgr.Clear()
	LoginMgr.isLogining = false;
	LoginMgr.loginTime = 0; 
	LoginMgr.callback = nil;
	Main.RemoveUpdateFun(LoginMgr.Update,nil); 
	if(LoginMgr.sequence ~= nil) then
		LoginMgr.sequence:OnDestroy();
		LoginMgr.sequence = nil;
	end
end

function LoginMgr.OnLoadDone(cmd)
	local callback = LoginMgr.callback;
	LoginMgr.callback = nil;
	if(cmd.state == CmdExecuteState.Success) then
		if(callback ~= nil) then
			callback(true);
		end
		EventSys.instance:DispatchLua(GameEvent.LoginSuccess);--发送登入成功事件
	else
		TipMgr.ShowTipType2("Login Fail!",nil);
		if(callback ~= nil) then
			callback(false);
		end
	end
	LoginMgr.sequence = nil;
	LoginMgr.Clear();
end

function LoginMgr.Update(obj,deltaTime)
	LoginMgr.loginTime = LoginMgr.loginTime - deltaTime;
	if(LoginMgr.loginTime < 0) then
		local callback = LoginMgr.callback;
		LoginMgr.callback = nil;
		if(callback ~= nil) then
			callback(false);
		end
		LoginMgr.Clear();
	end
	if(LoginMgr.sequence ~= nil) then
		LoginMgr.sequence:OnUpdate();
	end
end