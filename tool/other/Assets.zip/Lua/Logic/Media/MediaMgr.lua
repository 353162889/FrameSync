MediaMgr = {}

MediaMgr.times = 0;
MediaMgr.maxTimes = 0;

function MediaMgr.Init()
	for k,v in pairs(MediaTable) do
		if(v.times > MediaMgr.maxTimes) then
			MediaMgr.maxTimes = v.times;
		end
	end
	NetSys.instance:AddMsgCallback(EChannelType.EWorldChannel, S2C_WatchingAdvertInfo, MediaMgr.S2C_WatchingAdvertInfoData, nil);
end

function MediaMgr.ShowMedia(maxTimesShowDialog)
	if(true) then return end
	if (true == SDKManager.instance.isBaseVersion) then return end
	if(MediaMgr.times >= MediaMgr.maxTimes and not maxTimesShowDialog) then 
		return;
	end;
	local desc = string.format("点击确认后观看广告，观看后将获得巨额奖励 (%s/%s)",MediaMgr.times,MediaMgr.maxTimes)
	TipMgr.ShowTipType1(desc,function ()
		if(SDKManager.instance:IsMediaPrepared()) then
        --播放激励视频
        	SDKManager.instance:PlayMediaStart();
	    else
	    	TipMgr.ShowTipType2("广告正在加载中，请稍后观看",nil);
	    end
    end,nil,nil,false)
end

function MediaMgr.S2C_WatchingAdvertInfoData(obj,objMsg)
	local msg = S2C_WatchingAdvertInfoData();
	msg:ParseFromString(objMsg);
	MediaMgr.times = msg.times;
	Util.LogColor("#ff0000","S2C_WatchingAdvertInfoData","MediaMgr.times",MediaMgr.times);
end