VoiceHelper = class("VoiceHelper");

VoiceHelper.DISABLE = 1;
VoiceHelper.MY_TEAMMATE = 2;
VoiceHelper.ALL_TEAMMATE = 3;

VoiceHelper.mMicType = VoiceHelper.DISABLE;
VoiceHelper.mVoiceType = VoiceHelper.ALL_TEAMMATE;
VoiceHelper.mTeamId = 0;
VoiceHelper.mRoomId = 0;
VoiceHelper.mUserId = 0;
VoiceHelper.mIsLogin = false;

function VoiceHelper:Init(cVoiceCtrl)
    EventButtonListerer.Get(cVoiceCtrl.mCurDisableMic, self.OnCurMicCkick)
    EventButtonListerer.Get(cVoiceCtrl.mCurEnableMic, self.OnCurMicCkick)

    if not IsNil(cVoiceCtrl.mWidgetMic) then
        EventButtonListerer.Get(cVoiceCtrl.mSelectDisableMic, self.OnSelectDisableMic)
        EventButtonListerer.Get(cVoiceCtrl.mSelectEnableMic, self.OnSelectMyTeammateMic)
        EventButtonListerer.Get(cVoiceCtrl.mSelectEnableMic2, self.OnSelectEnableMic)
    end

    EventButtonListerer.Get(cVoiceCtrl.mCurDisableVoice, self.OnCurVoiceCkick)
    EventButtonListerer.Get(cVoiceCtrl.mCurEnableVoice, self.OnCurVoiceCkick)

    if not IsNil(cVoiceCtrl.mWidgetVoice) then
        EventButtonListerer.Get(cVoiceCtrl.mSelectDisableVoice, self.OnSelectDisableVoice)
        EventButtonListerer.Get(cVoiceCtrl.mSelectEnableVoice, self.OnSelectMyTeammateVoice)
        EventButtonListerer.Get(cVoiceCtrl.mSelectEnableVoice2, self.OnSelectEnableVoice)
    end
end

function VoiceHelper:Refresh(cVoiceCtrl)
    self.mVoiceCtrl = cVoiceCtrl;

    if (self.mMicType == VoiceHelper.DISABLE) then
        cVoiceCtrl.mCurDisableMic:SetActive(true);
        cVoiceCtrl.mCurEnableMic:SetActive(false);
        if not IsNil(cVoiceCtrl.mWidgetMic) then
            cVoiceCtrl.mWidgetMic:SetActive(false);
        end
    else
        cVoiceCtrl.mCurDisableMic:SetActive(false);
        cVoiceCtrl.mCurEnableMic:SetActive(true);
        if not IsNil(cVoiceCtrl.mWidgetMic) then
            cVoiceCtrl.mWidgetMic:SetActive(false);
            if (self.mMicType == VoiceHelper.MY_TEAMMATE) then
                cVoiceCtrl.mTxtMicType.text = "组队";
            else
                cVoiceCtrl.mTxtMicType.text = "全队";
            end
        else
            cVoiceCtrl.mTxtMicType.text = "";
        end
    end

    if (self.mVoiceType == VoiceHelper.DISABLE) then
        cVoiceCtrl.mCurDisableVoice:SetActive(true);
        cVoiceCtrl.mCurEnableVoice:SetActive(false);
        if not IsNil(cVoiceCtrl.mWidgetVoice) then
            cVoiceCtrl.mWidgetVoice:SetActive(false);
        end
    else
        cVoiceCtrl.mCurDisableVoice:SetActive(false);
        cVoiceCtrl.mCurEnableVoice:SetActive(true);
        if not IsNil(cVoiceCtrl.mWidgetVoice) then
            cVoiceCtrl.mWidgetVoice:SetActive(false);
            if (self.mVoiceType == VoiceHelper.MY_TEAMMATE) then
                cVoiceCtrl.mTxtVoiceType.text = "组队";
            else
                cVoiceCtrl.mTxtVoiceType.text = "全队";
            end
        else
            cVoiceCtrl.mTxtVoiceType.text = "";
        end
    end
end

function VoiceHelper:ShowMicSetting()
    self.mVoiceCtrl.mWidgetMic:SetActive(true);
    self.mVoiceCtrl.mWidgetVoice:SetActive(false);

    if (self.mMicType == VoiceHelper.DISABLE) then
        self.mVoiceCtrl.mSelectDisableMic:SetActive(false);
        self.mVoiceCtrl.mSelectEnableMic:SetActive(true);
        self.mVoiceCtrl.mTxtSelectMicType.text = "组队";
        self.mVoiceCtrl.mSelectEnableMic2:SetActive(true);
        self.mVoiceCtrl.mTxtSelectMicType2.text = "全队";
    else
        self.mVoiceCtrl.mSelectDisableMic:SetActive(true);
        self.mVoiceCtrl.mSelectEnableMic:SetActive(false);
        self.mVoiceCtrl.mSelectEnableMic2:SetActive(true);

        if (self.mMicType == VoiceHelper.MY_TEAMMATE) then
            self.mVoiceCtrl.mTxtSelectMicType2.text = "全队";
        else
            self.mVoiceCtrl.mTxtSelectMicType2.text = "组队";
        end
    end
end

function VoiceHelper:ShowVoiceSetting()
    self.mVoiceCtrl.mWidgetVoice:SetActive(true);
    self.mVoiceCtrl.mWidgetMic:SetActive(false);

    if (self.mVoiceType == VoiceHelper.DISABLE) then
        self.mVoiceCtrl.mSelectDisableVoice:SetActive(false);
        self.mVoiceCtrl.mSelectEnableVoice:SetActive(true);
        self.mVoiceCtrl.mTxtSelectVoiceType.text = "组队";
        self.mVoiceCtrl.mSelectEnableVoice2:SetActive(true);
        self.mVoiceCtrl.mTxtSelectVoiceType2.text = "全队";
    else
        self.mVoiceCtrl.mSelectDisableVoice:SetActive(true);
        self.mVoiceCtrl.mSelectEnableVoice:SetActive(false);
        self.mVoiceCtrl.mSelectEnableVoice2:SetActive(true);

        if (self.mVoiceType == VoiceHelper.MY_TEAMMATE) then
            self.mVoiceCtrl.mTxtSelectVoiceType2.text = "全队";
        else
            self.mVoiceCtrl.mTxtSelectVoiceType2.text = "组队";
        end
    end
end

function VoiceHelper:Login(nUserId, nRoomId)
    if self.mIsLogin then
        self:Logout();
    end

    self.mIsLogin = true;
    SDKManager.instance:VoiceLogin(tostring(nUserId), tostring(nRoomId));
    self:UpdateSetting();
end

function VoiceHelper:LoginTeam(nUserId, nTeamId)
    self.mTeamId = nTeamId;
    self:Login(nUserId, nTeamId);
end

function VoiceHelper:LoginRoom(nUserId, nRoomId)
    self.mRoomId = nRoomId;
    self:Login(nUserId, nRoomId);
end

function VoiceHelper:ChangeToTeamChannel()
    VoiceHelper:LoginTeam(self.mUserId, self.mTeamId);
end

function VoiceHelper:Logout()
    SDKManager.instance:VoiceLogout();
    self.mIsLogin = false;
end

function VoiceHelper:UpdateSetting()
    if not self.mIsLogin then
        return;
    end

    if self.mMicType == VoiceHelper.DISABLE then
        SDKManager.instance:VoiceMicEnable(false);
    else
        SDKManager.instance:VoiceMicEnable(true);
    end

    if self.mVoiceType == VoiceHelper.DISABLE then
        SDKManager.instance:SetPauseVoiceAudio(true);
    else 
        SDKManager.instance:SetPauseVoiceAudio(false);
        for i = 1, #MatchingManager_3V3.mOtherTeammate do
            local cOtherTeammate = MatchingManager_3V3.mOtherTeammate[i];
            SDKManager.instance:EnablePlayVoiceWithUserId(self.mVoiceType == VoiceHelper.ALL_TEAMMATE, tostring(cOtherTeammate))
        end
    end
end

function VoiceHelper.OnCurMicCkick()
    if not IsNil(VoiceHelper.mVoiceCtrl.mWidgetMic) then
        VoiceHelper:ShowMicSetting();
    else
        if VoiceHelper.mMicType == VoiceHelper.ALL_TEAMMATE or VoiceHelper.mMicType == VoiceHelper.MY_TEAMMATE then
            VoiceHelper.mMicType = VoiceHelper.DISABLE;
        else
            VoiceHelper.mMicType = VoiceHelper.ALL_TEAMMATE;
        end
        VoiceHelper:Refresh(VoiceHelper.mVoiceCtrl);
        VoiceHelper:UpdateSetting();
    end
end

function VoiceHelper.OnCurVoiceCkick()
    if not IsNil(VoiceHelper.mVoiceCtrl.mWidgetVoice) then
        VoiceHelper:ShowVoiceSetting();
    else
        if VoiceHelper.mVoiceType == VoiceHelper.ALL_TEAMMATE or VoiceHelper.mVoiceType == VoiceHelper.MY_TEAMMATE then
            VoiceHelper.mVoiceType = VoiceHelper.DISABLE;
        else
            VoiceHelper.mVoiceType = VoiceHelper.ALL_TEAMMATE;
        end
        VoiceHelper:Refresh(VoiceHelper.mVoiceCtrl);
        VoiceHelper:UpdateSetting();
    end
end

function VoiceHelper.OnSelectDisableMic()
    VoiceHelper.mMicType = VoiceHelper.DISABLE;
    VoiceHelper:Refresh(VoiceHelper.mVoiceCtrl);
    VoiceHelper:UpdateSetting();
end

function VoiceHelper.OnSelectEnableMic()
    if VoiceHelper.mMicType == VoiceHelper.ALL_TEAMMATE then
        VoiceHelper.mMicType = VoiceHelper.MY_TEAMMATE;
    else
        VoiceHelper.mMicType = VoiceHelper.ALL_TEAMMATE;
    end
    VoiceHelper:Refresh(VoiceHelper.mVoiceCtrl);
    VoiceHelper:UpdateSetting();
end

function VoiceHelper.OnSelectMyTeammateMic()
    VoiceHelper.mMicType = VoiceHelper.MY_TEAMMATE;
    VoiceHelper:Refresh(VoiceHelper.mVoiceCtrl);
    VoiceHelper:UpdateSetting();
end

function VoiceHelper.OnSelectDisableVoice()
    VoiceHelper.mVoiceType = VoiceHelper.DISABLE;
    VoiceHelper:Refresh(VoiceHelper.mVoiceCtrl);
    VoiceHelper:UpdateSetting();
end

function VoiceHelper.OnSelectMyTeammateVoice()
    VoiceHelper.mVoiceType = VoiceHelper.MY_TEAMMATE;
    VoiceHelper:Refresh(VoiceHelper.mVoiceCtrl);
    VoiceHelper:UpdateSetting();
end

function VoiceHelper.OnSelectEnableVoice()
    if VoiceHelper.mVoiceType == VoiceHelper.ALL_TEAMMATE then
        VoiceHelper.mVoiceType = VoiceHelper.MY_TEAMMATE;
    else
        VoiceHelper.mVoiceType = VoiceHelper.ALL_TEAMMATE;
    end
    VoiceHelper:Refresh(VoiceHelper.mVoiceCtrl);
    VoiceHelper:UpdateSetting();
end