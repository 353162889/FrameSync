AudioDefine = {}
AudioDefine.HeatBeat = 2001;	--心跳声
AudioDefine.MainHeroDie = 2008;	--主玩家死亡
AudioDefine.MainHeroKill = 2009;	--主玩家杀人
AudioDefine.EatEnergy = 2010;		--吃一般豆子
AudioDefine.EatEnergyFinish = 2011; --吃一般豆子结束
AudioDefine.EatCoin = 2012;			--吃积分
AudioDefine.SkillRepalce = 2059;	--技能替换
