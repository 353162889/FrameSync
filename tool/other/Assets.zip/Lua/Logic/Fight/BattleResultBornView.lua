BattleResultBornView = class("BattleResultBornView",BattleResultBornViewUI)

function BattleResultBornView:Init()
	local onClickBack = function (go)
		self:OnClickBack();
	end
	EventTriggerListener.Get(self.btnBack.gameObject).onClick = EventTriggerListener.Get(self.btnBack.gameObject).onClick + onClickBack;
	self.lstFirstBorn = {}
	self.lstSecondBorn = {}
end

--objParam中存取格式为{{cfg,count},{cfg,count}}
function BattleResultBornView:OpenView(param)
	local objParam = param.objParam;
	local firstBorn = objParam["moneyItems"];
	local secondBorn = objParam["itemItems"];
	
	local aceUserId = objParam["aceUserId"];	
	local kdUserId = objParam["kdUserId"];
	local mvpUserId = objParam["mvpUserId"];
	local userId = tostring(BattleInfo.userId);
	local isSelfACE = userId == aceUserId;
	local isSelfKD = userId == kdUserId;
	local isSelfMVP = userId == mvpUserId;
	local isPlayAnim = isSelfACE or isSelfKD or isSelfMVP;
	Util.LogColor("#ff0000","isPlayAnim",isPlayAnim,"userId",userId,"aceUserId",aceUserId,"kdUserId",kdUserId,"mvpUserId",mvpUserId)
	self:UpdateBorn(self.born1Grid,self.lstFirstBorn,firstBorn);
	self:UpdateBorn(self.born2Grid,self.lstSecondBorn,secondBorn);
	if(self.effectGO == nil) then
		self.effectGO = EffectManager.instance:Create("eff_ui_finish_light",false,nil);
		UIViewUtil.AddUIEffect(self.effect,self.effectGO);
	end

	if(isPlayAnim) then
		self.boxEffect:SetActive(true);
		self.content:SetActive(false);
		self.sequence = DG.Tweening.DOTween.Sequence();
		local onComplete = function ()
			self.boxEffect:SetActive(false);
			self.content:SetActive(true);
			self.sequence = nil;
		end
		self.sequence:InsertCallback(3,onComplete);
		self.boxEffectGO = EffectManager.instance:Create("eff_ui_finish_box",false,nil);
		UIViewUtil.AddUIEffect(self.boxEffect,self.boxEffectGO);
	else
		self.boxEffect:SetActive(false);
		self.content:SetActive(true);
	end
	self.imgAce:SetActive(isSelfACE);
	self.imgMvp:SetActive(isSelfMVP);
	self.imgKd:SetActive(isSelfKD);
end

function BattleResultBornView:UpdateBorn(parent,lstBorn,borns)
	for i=1,#lstBorn do
		lstBorn[i]:SetActive(false);
	end
	if(borns == nil) then return end
	local index = 1;
	for i=1,#borns do
		local cfg = borns[i][1];
		local count = borns[i][2];
		if(#lstBorn < i) then
			local iconItem = IconItem.Create(parent);
			table.insert(lstBorn,iconItem);
		end
		print("----------------------------------------count"..count)
		lstBorn[i]:UpdateByCfg(cfg,count);
		lstBorn[i]:SetActive(true);
		index = index + 1;
	end
	for i=index,#lstBorn do
		lstBorn[i]:SetActive(false);
	end
end

function BattleResultBornView:OnClickBack()
	ViewSys.instance:Close("BattleResultBornView")
end

function BattleResultBornView:CloseView()
	-- body
	if(self.effectGO ~= nil) then
		EffectManager.instance:Destory(self.effectGO);
		self.effectGO = nil;
	end
	if(self.boxEffectGO ~= nil) then
		EffectManager.instance:Destory(self.boxEffectGO);
		self.boxEffectGO = nil;
	end
	if(self.sequence ~= nil) then
		self.sequence:Kill(false);
		self.sequence = nil;
	end
end

function BattleResultBornView:DestroyView()
	for i=1,#self.lstFirstBorn do
		self.lstFirstBorn[i]:Destroy();
	end
	for i=1,#self.lstSecondBorn do
		self.lstSecondBorn[i]:Destroy();
	end
	self.lstFirstBorn = {};
	self.lstSecondBorn = {};
end