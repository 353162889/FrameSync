
require "Logic/Fight/EffectBarView"
require "Logic/Fight/RankView"
require "Logic/Fight/MapView"
require "Logic/Fight/ScreenEffectView"
require "Logic/Fight/TeamBarView"
require "Logic/Fight/OperateView"
require "Logic/Fight/KillView"
require "Logic/Fight/LockBarView"
-- require "Logic/Fight/QuickBuyEquipView"
FightView = class("FightView", FightViewUI);
local _this;

function FightView:Init()
    -- self.quickBuyEquipView = QuickBuyEquipView.new();
    -- self.quickBuyEquipView:InitView(self.quickBuyEquipContainer);
    _this = self;
    if(self.ani_skillIcon~=nil)then
        self.ani_skillIconObj:SetActive(false);
        self.ani_skillIcon:GetComponent("AnimationEventHelper").PlayEndCallBack=function()
            FightView.OnSkillReplaceOver();
        end
    end
    self.operateView = OperateView.new();
    self.operateView:InitView(self.operateBars);
    self.killView = KillView.new();
    self.killView:InitView(self.killBars);
    self.effectBarView = EffectBarView.new();
    self.effectBarView:InitView(self.effectBars,self.operateView.skillBtn1.transform.position,self.operateView.skillBtn2.transform.position,self.operateView.skillBtn3.transform.position);
    self.rankView = RankView.new();
    self.rankView:InitView(self.rank);
    self.mapView = MapView.new();
    self.mapView:InitView(self.map);
    self.screenEffectView = ScreenEffectView.new();
    self.screenEffectView:InitView(self.screenEffect);
    self.teamBarView = TeamBarView.new();
    self.teamBarView:InitView(self.team);
    self.lockView = LockBarView.new();
    self.lockView:InitView(self.lockBars);
   
    self.dieTime = 0;
    self.dieTotalTime = 0;
    self.dynamicTxtCoinCount = GameObjectUtil.AddComponentOnce(self.txtCoinCount.gameObject,typeof(DynamicNumber));
    self:RegeditEvent()   --注册点击事件

    VoiceHelper:Init(self.objVoice:GetComponent("VoiceCtrlUI"));
   
end

function FightView:OpenView(param)
    self.coreGamingSys = BattleInfo.coreGaming;
    Main.AddUpdateFun(FightView.Update, self);
    self.effectBarView:OpenView(param);
    self.rankView:OpenView(param);
    self.mapView:OpenView(param);
    self.screenEffectView:OpenView(param);
    self.teamBarView:OpenView(param);
    self.operateView:OpenView(param);
    self.lockView:OpenView(param);
    -- self.quickBuyEquipView:OpenView(param);
    self.killView:OpenView(param);
    self.coinChange = function (oldValue,newValue)
         self.dynamicTxtCoinCount:SetNumberAtStart(oldValue,newValue,1);
    end
    self.mainHeroUpdate = function (eventId,obj)
        self:OnMainHeroUpdate();
    end
    EventSys.instance:AddEvent(EEventType.OnMainHeroUpdate, self.mainHeroUpdate);

    self.onUnitRevive = function (eventId,unit)
        if(self.mainHero ~= nil and unit.id == self.mainHero.id) then
            self:OnMainHeroRevive();
        end
    end
    EventSys.instance:AddEvent(EEventType.OnUnitRevive,self.onUnitRevive);

    self.onUnitDie = function (eventId,damageInfo)
        if(damageInfo ~= nil and self.mainHero ~= nil) then
            local resInfo = nil;
            --区分英雄和小兵（野怪）
            if(damageInfo.defence.unitType == EUnitType.EHero) then
                resInfo = HeroTable[damageInfo.defence.resId];
            else
                resInfo = SoldierTable[damageInfo.defence.resId];
            end
            if(damageInfo.defence.id == self.mainHero.id) then
                AudioSys.instance:PlayByTrans(resInfo.die_audio,AudioSys.instance.AudioListenerObj.transform);
                self:OnMainHeroDie(damageInfo);
            else
                AudioSys.instance:PlayByPosLmt(resInfo.die_audio,self.mainHero.unitView.transform.position, damageInfo.defence.unitView.transform.position);
            end
            if(damageInfo.attack ~= nil and damageInfo.attack.id == self.mainHero.id and damageInfo.defence.unitType == EUnitType.EHero) then
                EffectManager.instance:Create(EffectDefine.KillGetCoin,true,self.iconSelfHeroEffect);
            end
        end
    end
    EventSys.instance:AddEvent(EEventType.OnUnitDie,self.onUnitDie);

    if(BattleScene.instance.mainHero ~= nil) then
        self:OnMainHeroUpdate();
        BattleScene.instance.mainHero.unitAttack.OnSkillCDStateUpdate =  BattleScene.instance.mainHero.unitAttack.OnSkillCDStateUpdate+FightView.CDEnd;
    end

    self.onGameEnd = function (eventId,obj)
        local param = ViewParam();
        param.objParam = {};
        param.objParam["gameEndType"] = obj;
        self:OnGameEnd(param);
    end
    EventSys.instance:AddEvent(EEventType.OnBattleEnd,self.onGameEnd);
    self.isGameEnd = false;

    self.battleChannel = NetSys.instance:GetChannel(EChannelType.EPvpChannel);

    VoiceHelper:Refresh(self.objVoice:GetComponent("VoiceCtrlUI"));
    EventSys.instance:AddEvent(EEventType.OnSkillReplace, FightView.OnReceiveSkillReplace);
end

function FightView:OnGameEnd(param)
    self.isGameEnd = true;
    local time = ConstTable["game_end_time_scale_time"].p_int / 1000.0;
    local scale = ConstTable["game_end_time_scale"].p_int / 1000.0;
    self.deltaEndTime = time * scale;
    LuaHelper.SetTimeScale(scale);
    self.gameEndParam = param;
end

function FightView:CloseView()
    self.isGameEnd = false;
    LuaHelper.SetTimeScale(1);
    Main.RemoveUpdateFun(FightView.Update);
    self.effectBarView:CloseView();
    self.rankView:CloseView();
    self.mapView:CloseView();
    self.screenEffectView:CloseView();
    self.teamBarView:CloseView();
    self.operateView:CloseView();
    self.killView:CloseView();
    self.lockView:CloseView();
    -- self.quickBuyEquipView:CloseView();
    if(self.mainHeroUpdate ~= nil) then
         EventSys.instance:RemoveEvent(EEventType.OnMainHeroUpdate, self.mainHeroUpdate);
         self.mainHeroUpdate = nil;
    end

     if(self.onUnitRevive ~= nil) then
        EventSys.instance:RemoveEvent(EEventType.OnUnitRevive,self.onUnitRevive);
        self.onUnitRevive = nil;
    end

     if(self.onUnitDie ~= nil) then
        EventSys.instance:RemoveEvent(EEventType.OnUnitDie,self.onUnitDie);
        self.onUnitDie = nil;
    end

    if(self.onGameEnd ~= nil) then
        EventSys.instance:RemoveEvent(EEventType.OnBattleEnd,self.onGameEnd);
        self.onGameEnd = nil;
    end
    BattleScene.instance.mainHero.unitAttack.OnSkillCDStateUpdate =  BattleScene.instance.mainHero.unitAttack.OnSkillCDStateUpdate-FightView.CDEnd;
    self:ResetMainHero();
    self.coinChange = nil;
    EventSys.instance:RemoveEvent(EEventType.OnSkillReplace, FightView.OnReceiveSkillReplace);
    -- ViewSys.instance:Close("EquipmentShopView")
end

function FightView:Update(deltaTime)
    if(self.isGameEnd) then
        self.deltaEndTime = self.deltaEndTime - deltaTime;
        if(self.deltaEndTime < 0) then
            self.isGameEnd = false;
            LuaHelper.SetTimeScale(1);
            FightManager.ShowBattleResult(self.gameEndParam);
        end
    end
   
    self.teamBarView:OnUpdate(deltaTime);
    self.operateView:OnUpdate(deltaTime);
    self.killView:OnUpdate(deltaTime);
    self.icon_timeNum.text= TimeHelper.GetFormatTime(self.coreGamingSys.leaveGameTime);
    local nFpsValue = CGameRoot.instance.realFPS;
    local nPingValue = self.battleChannel.ping;
    self.fpsValue.text = string.format("%d", nFpsValue);
    self.pingValue.text = string.format("%d",nPingValue);
    if(self.dieTime > 0) then
        self.iconSelfHeroMask.enabled = true;
        self.iconSelfHeroMask.fillAmount = (self.dieTime / self.dieTotalTime);
        self.dieTime = self.dieTime - deltaTime;
    else
        self.iconSelfHeroMask.enabled = false;
    end
end

function FightView:DestroyView()
     self.effectBarView:DestroyView();
     self.rankView:DestroyView();
     self.mapView:DestroyView();
     self.screenEffectView:DestroyView();
     self.teamBarView:DestroyView();
     self.operateView:DestroyView();
     self.killView:DestroyView();
     self.lockView:DestroyView();
     
     Main.RemoveUpdateFun(FightView.Update, self);
end

function FightView:OnMainHeroDie(damageInfo)
    if(self.mainHero.unitAttr.coin > 0) then
        self.dieTotalTime = self.mainHero.totalDieTime / 1000.0;
        self.dieTime = self.dieTotalTime;
        if(damageInfo ~= nil and damageInfo.attack ~= nil) then
            ChaseCamera.instance:SetFllower(damageInfo.attack, 1);
            ChaseCamera.instance:SetOrthoSize(ChaseCamera.instance.cameraOrthoSize + 5, 1);
        end
        if(damageInfo ~= nil and damageInfo.attack ~= nil) then
            EffectManager.instance:Create(EffectDefine.DieLostCoin,true,self.iconEnemyHeroEffect);
        end
    end
end

function FightView:OnMainHeroRevive()
     ChaseCamera.instance:SetFllower(self.mainHero, 1);
     ChaseCamera.instance:SetOrthoSize(ChaseCamera.instance.cameraOrthoSize, 1);
end

function FightView:OnMainHeroUpdate()
    self:ResetMainHero();
    self.mainHero = BattleScene.instance.mainHero;
    if(self.mainHero ~= nil) then
        self.iconSelfHero.sprite = CResourceSys.instance:Load(EResType.EIcon,HeroTable[self.mainHero.resId].icon);
        self.mainHero.unitAttr.OnCoinChange = self.mainHero.unitAttr.OnCoinChange + self.coinChange;
        self.txtCoinCount.text = tostring(self.mainHero.unitAttr.coin);
    end
end

--注册点击事件
function FightView:RegeditEvent()
    -- EventButtonListerer.Get(self.btn_equipmentShop, self.OpenEquipmentShop)
end

-- function FightView:OpenEquipmentShop()
--     ViewSys.instance:Open("EquipmentShopView")
-- end

function FightView:ResetMainHero()
    if(self.mainHero ~= nil) then
        self.mainHero.unitAttr.OnCoinChange = self.mainHero.unitAttr.OnCoinChange - self.coinChange;
    end
    self.mainHero = nil;
end

function FightView.OnReceiveSkillReplace(eventId, obj)
    print("技能改变"..obj);
    local strs =  Util.Split( obj,"|" )
    local mainHero = BattleScene.instance.mainHero;
    local skill = mainHero.unitAttack:GetActiveSkillByIdx(strs[1]);
    local cdTime = math.ceil((skill.cdEndTime - FrameSyncSys.time) / 1000)
    if(strs[1] =="0")then 
        _this.ani_skillIconObj.transform.position = _this.skillBtn1.transform.position;
        if(cdTime==0)then
            FightView.RotateSkill_1(false)
        else
            _this.skillIcon1.transform.localEulerAngles = Vector3(0,0,-30);
        end
    end
    if(strs[1] =="1")then 
        _this.ani_skillIconObj.transform.position = _this.skillBtn2.transform.position;
        if(cdTime==0)then
            FightView.RotateSkill_2(false)
        else
            _this.skillIcon2.transform.localEulerAngles = Vector3(0,0,-30);
        end
    end
    _this.ani_skillIcon.sprite = CResourceSys.instance:Load(EResType.EIcon,"Skill/"..strs[2]..".png");
    _this.ani_skillIconObj.gameObject:SetActive(true);

end

function FightView.CDEnd(skill)
    print("技能CD结束");
    print(skill.id);
    print(BattleScene.instance.mainHero.unitAttack:GetActiveSkillByIdx(0).id);
    local mainHero = BattleScene.instance.mainHero;
    local cdTime = math.ceil((skill.cdEndTime - FrameSyncSys.time) / 1000);
    print(tostring(cdTime));
    if(skill.id ==mainHero.unitAttack:GetActiveSkillByIdx(0).id)then 
        if(cdTime==0)then 
            print("技能CD结束32222");
            FightView.RotateSkill_1(true);
        end
    end
    if(skill.id == BattleScene.instance.mainHero.unitAttack:GetActiveSkillByIdx(1).id)then 
        if(cdTime==0)then
            print("技能CD结束123123"); 
            FightView.RotateSkill_2(true);
        end
    end
end

function FightView.RotateSkill_1(isRotate)
    if(isRotate==false)then 
        _this.skillIcon1.transform.localEulerAngles = Vector3(0,0,-30);
    end
    local tween = _this.skillIcon1.transform:DORotate(Vector3.zero,0.3);
    tween:OnComplete(function()
        print("转动结束");
        AudioSys.instance:Play(AudioDefine.EatEnergyFinish);
    end)
end

function FightView.RotateSkill_2(isRotate)
    if(isRotate==false)then 
        _this.skillIcon2.transform.localEulerAngles = Vector3(0,0,-30);
    end
    local tween = _this.skillIcon2.transform:DORotate(Vector3.zero,0.3);
    tween:OnComplete(function()
        print("转动结束");
        AudioSys.instance:Play(AudioDefine.EatEnergyFinish);
    end)
end


function FightView.OnSkillReplaceOver()
    print("技能替换动画播放结束")
    _this.ani_skillIconObj.gameObject:SetActive(false);
end