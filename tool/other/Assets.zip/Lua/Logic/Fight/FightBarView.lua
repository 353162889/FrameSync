require "Logic/Fight/HPBarView"
require "Logic/Fight/BubbleBarView"
FightBarView = class("FightBarView", FightBarViewUI);

function FightBarView:Init()
	 HPBarView:InitView(self.hPBars);
    BubbleBarView:InitView(self.bubbleBars);
end

function FightBarView:OpenView(param)
	HPBarView:OpenView(param);
    BubbleBarView:OpenView(param);
    Main.AddUpdateFun(FightBarView.OnUpdate, self);
end

function FightBarView:OnUpdate(deltaTime)
	 HPBarView:OnUpdate();
    BubbleBarView:OnUpdate();
end

function FightBarView:CloseView()
	Main.RemoveUpdateFun(FightBarView.OnUpdate);
	HPBarView:CloseView();
    BubbleBarView:CloseView();
end

function FightBarView:DestroyView()
	 HPBarView:DestroyView();
     BubbleBarView:DestroyView();
end