RankView = class("RankView")

function RankView:InitView(go)
	-- body
	self.go = go;
	self.transform = self.go.transform;

	self.heroRankList = self.transform:Find("heroRankList").gameObject;
    self.rank1 = self.transform:Find("heroRankList/rank1").gameObject;
    self.rankIcon1 = self.transform:Find("heroRankList/rank1/rankIcon1"):GetComponent("Image");
    self.rankTxtName1 = self.transform:Find("heroRankList/rank1/rankTxtName1"):GetComponent("Text");
    self.rankCoin1 = self.transform:Find("heroRankList/rank1/rankCoin1"):GetComponent("Text");
    self.rank2 = self.transform:Find("heroRankList/rank2").gameObject;
    self.rankIcon2 = self.transform:Find("heroRankList/rank2/rankIcon2"):GetComponent("Image");
    self.rankTxtName2 = self.transform:Find("heroRankList/rank2/rankTxtName2"):GetComponent("Text");
    self.rankCoin2 = self.transform:Find("heroRankList/rank2/rankCoin2"):GetComponent("Text");
    self.rank3 = self.transform:Find("heroRankList/rank3").gameObject;
    self.rankIcon3 = self.transform:Find("heroRankList/rank3/rankIcon3"):GetComponent("Image");
    self.rankTxtName3 = self.transform:Find("heroRankList/rank3/rankTxtName3"):GetComponent("Text");
    self.rankCoin3 = self.transform:Find("heroRankList/rank3/rankCoin3"):GetComponent("Text");
    self.rankSelfIcon = self.transform:Find("rankSelf/rankSelfIcon"):GetComponent("Image");
    self.rankSelfName = self.transform:Find("rankSelf/rankSelfName"):GetComponent("Text");
    self.rankSelfCoin = self.transform:Find("rankSelf/rankSelfCoin"):GetComponent("Text");
    self.rankSelfRank = self.transform:Find("rankSelf/rankSelfRank"):GetComponent("Text");

end

function RankView:OpenView(param)
	-- body
	self.gameRank = BattleInfo.coreGaming:GetSysComp(EGamingSysCompType.Rank);
	self.onRankUpdate = function (eventId,obj)
		self:Refresh();
	end
	EventSys.instance:AddEvent(EEventType.OnRankUpdate,self.onRankUpdate)
	self.onRankVisiable = function (eventId,obj)
		local visiable = obj;
		self.go:SetActive(visiable);
	end
	EventSys.instance:AddLuaEvent(GameEvent.RankViewVisiable,self.onRankVisiable)
	self:Refresh();
end

function RankView:CloseView()
	if(self.onRankUpdate ~= nil) then
		EventSys.instance:RemoveEvent(EEventType.OnRankUpdate,self.onRankUpdate)
		self.onRankUpdate = nil;
	end
	if(self.onRankVisiable ~= nil) then
		EventSys.instance:RemoveLuaEvent(GameEvent.RankViewVisiable,self.onRankVisiable)
		self.onRankVisiable = nil;
	end
	self.gameRank = nil;
end

function RankView:Refresh()
	local lst = self.gameRank.lstRankunit;
	local count = lst.Count;
	if(self.rank3.activeSelf ~= (count > 2)) then
		self.rank3:SetActive(count > 2);
	end
	if(self.rank2.activeSelf ~= (count > 1)) then
		self.rank2:SetActive(count > 1);
	end
	if(count > 0) then
		local unit = lst[0];
		self.rankIcon1.sprite = CResourceSys.instance:Load(EResType.EIcon,HeroTable[unit.resId].icon);
		self.rankTxtName1.text = unit.name;
		self.rankCoin1.text = tostring(unit.unitAttr.coin);
	end
	if(count > 1) then
		local unit = lst[1];
		self.rankIcon2.sprite = CResourceSys.instance:Load(EResType.EIcon,HeroTable[unit.resId].icon);
		self.rankTxtName2.text = unit.name;
		self.rankCoin2.text = tostring(unit.unitAttr.coin);
	end
	if(count > 2) then
		local unit = lst[2];
		self.rankIcon3.sprite = CResourceSys.instance:Load(EResType.EIcon,HeroTable[unit.resId].icon);
		self.rankTxtName3.text = unit.name;
		self.rankCoin3.text = tostring(unit.unitAttr.coin);
	end
	if(BattleScene.instance.mainHero ~= nil) then
		local unit = BattleScene.instance.mainHero;
		self.rankSelfIcon.sprite = CResourceSys.instance:Load(EResType.EIcon,HeroTable[unit.resId].icon);
		self.rankSelfRank.text = tostring(self.gameRank:GetRank(unit.id));
		self.rankSelfName.text = unit.name;
		self.rankSelfCoin.text = tostring(unit.unitAttr.coin);
	end
end

function RankView:DestroyView()
	-- body
end