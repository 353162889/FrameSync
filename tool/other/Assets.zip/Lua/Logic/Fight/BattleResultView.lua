--[[
描述：胜利失败界面
日期：2018-3-1修改
--]]

BattleResultView = class("BattleResultView", BattleResultViewUI)
-- local _this

function BattleResultView:Init()
    -- _this = self
    EventButtonListerer.Get(self.btnBack, self.Close); 
end

function BattleResultView:OpenView(param)
    self.gameEndType = param.objParam["gameEndType"];
    self.achievement = param.objParam["achievement"];
    local gameRank = BattleInfo.coreGaming:GetSysComp(EGamingSysCompType.Rank);
    local myRank = gameRank:GetRank(BattleScene.instance.mainHero.id);
    if myRank < 10 then
        self.ranking1.sprite = CResourceSys.instance:Load(EResType.EIcon,"Numbers/ani_time_"..myRank..".png");
        self.ranking1.transform.gameObject:SetActive(true);
        self.ranking2.transform.gameObject:SetActive(false);
        if myRank == 1 then
            self.aniIconTime.sprite = CResourceSys.instance:Load(EResType.EIcon,"Numbers/res_icon_time_1st.png");
        elseif myRank == 2 then
            self.aniIconTime.sprite = CResourceSys.instance:Load(EResType.EIcon,"Numbers/res_icon_time_2nd.png");
        elseif myRank == 3 then
            self.aniIconTime.sprite = CResourceSys.instance:Load(EResType.EIcon,"Numbers/res_icon_time_3rd.png");
        else
            self.aniIconTime.sprite = CResourceSys.instance:Load(EResType.EIcon,"Numbers/res_icon_time_th.png");
        end
    else 
        self.ranking2.sprite = CResourceSys.instance:Load(EResType.EIcon,"Numbers/ani_time_"..math.floor(myRank / 10)..".png");
        self.ranking3.sprite = CResourceSys.instance:Load(EResType.EIcon,"Numbers/ani_time_"..(myRank % 10)..".png");
        self.aniIconTime.sprite = CResourceSys.instance:Load(EResType.EIcon,"Numbers/res_icon_time_th.png");
        self.ranking1.transform.gameObject:SetActive(false);
        self.ranking2.transform.gameObject:SetActive(true);
    end
    BattleViewAnimationControl:Init(self); 
    self:SetResult(self.achievement); --param.strParam

    SDKManager.instance:OnTDEvent("首次进入结算界面");

    local nHeroResId = BattleScene.instance.mainHero.resId;
    local statisticsComp = BattleInfo.coreGaming:GetSysComp(EGamingSysCompType.Statistics);
    local statistics = statisticsComp:GetStatisticsData(BattleScene.instance.mainHero.id);
    SDKManager.instance:OnTDEvent("英雄" .. nHeroResId .. "击杀次数", statistics.kill);
    SDKManager.instance:OnTDEvent("英雄" .. nHeroResId .. "死亡次数", statistics.die);
    --NetSys.instance:AddMsgCallback(EChannelType.EPvpChannel, S2C_ExitBattle, BattleResultView.S2C_ExitBattleData, nil); 
end

function BattleResultView:CloseView()
     Main.RemoveUpdateFun(BattleViewAnimationControl.UpdateAnimation);
    --NetSys.instance:RemoveMsgCallback(EChannelType.EPvpChannel, S2C_ExitBattle, BattleResultView.S2C_ExitBattleData); 
end

-- function BattleResultView.S2C_ExitBattleData()
--     Util.LogColor("#ff0000","S2C_ExitBattleData");
--     BattleResultView.ExitBattle();
-- end

function BattleResultView.ExitBattle()

    BattleViewAnimationControl:Close(); 
    FightManager.ExitToLobby();
    MediaMgr.ShowMedia(false);
end

function BattleResultView:DestroyView()
    
end

function BattleResultView:SetResult(achievement)
    BattleViewAnimationControl:RefreshRankData(achievement); 
end

function BattleResultView.Close()
    if BattleViewAnimationControl.isAnimDone == true then

       BattleResultView.ExitBattle();
       -- if(BattleInfo.isStandAlone or BattleResultView.gameEndType == GameEndType.ENormal) then
       --      BattleResultView.ExitBattle();
       --  else
       --      local data = C2S_ExitBattleData()
       --      NetSys.instance:SendPvpMsg(data:SerializeToString(), C2S_ExitBattle); 
       --  end
    end
end
