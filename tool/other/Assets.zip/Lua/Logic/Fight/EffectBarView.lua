EffectBarView = class("EffectBarView")

function EffectBarView:InitView(go,skillBtn1Pos,skillBtn2Pos,skillBtn3Pos)
	self.go = go;
	self.trans = self.go.transform;
	self.lstEffect = {};
	self.skillBtn1Position = skillBtn1Pos;
	self.skillBtn2Position = skillBtn2Pos;
	self.skillBtn3Position = skillBtn3Pos;
	self.positionTable = {};
	self.lstPosition = {};
	self.lstItemModel = {};
	self.lstItemTweener = {};
end

function EffectBarView:ResetLstPosition()
	for i=#self.lstPosition,1,-1 do
		table.remove(self.lstPosition,i);
	end
end

function EffectBarView:OpenView(param)
	self.onHitFood = function (food)
		self:OnHitFood(food);
	end

	self.onUnitHitFood = function (eventId,arr)
		self:OnHeroHitFood(arr[0],arr[1]);
	end
	EventSys.instance:AddEvent(EEventType.OnUnitHitItem, self.onUnitHitFood);

	-- body
	self.mainHeroUpdate = function (eventId,obj)
        self:OnMainHeroUpdate();
    end
    EventSys.instance:AddEvent(EEventType.OnMainHeroUpdate, self.mainHeroUpdate);

    if(BattleScene.instance.mainHero ~= nil) then
        self:OnMainHeroUpdate();
    end

end

function EffectBarView:OnMainHeroUpdate()
	self:ResetMainHero();
	self.mainHero = BattleScene.instance.mainHero;
	if(self.mainHero == nil) then return end;
	self.mainHero.OnHeroHitItem = self.mainHero.OnHeroHitItem + self.onHitFood;
	self.cActiveSkill1 = self.mainHero.unitAttack:GetActiveSkillByIdx(0);
    self.cActiveSkill2 = self.mainHero.unitAttack:GetActiveSkillByIdx(1);
    self.cActiveSkill3 = self.mainHero.unitAttack:GetActiveSkillByIdx(2);
end

function EffectBarView:ResetMainHero()
    if(self.mainHero ~= nil) then
        if(self.onHitFood ~= nil) then
            self.mainHero.OnHeroHitItem = self.mainHero.OnHeroHitItem - self.onHitFood;
        end
    end
    self.mainHero = nil;
end

function EffectBarView:IsSkillConsume(skill,attrType)
    if(skill.consumeType == EConsumeType.ENone) then
        return false;
    end
    if (skill.consumeType == attrType) then
        return true;
    end
    return false;
end

function EffectBarView:GetSkillPosition(energyType)
	self:ResetLstPosition();
	if(self.cActiveSkill1 ~= nil and self:IsSkillConsume(self.cActiveSkill1,energyType)) then
		table.insert(self.lstPosition,self.skillBtn1Position);
	end
	if(self.cActiveSkill2 ~= nil and self:IsSkillConsume(self.cActiveSkill2,energyType)) then
		table.insert(self.lstPosition,self.skillBtn2Position);
	end
	if(self.cActiveSkill3 ~= nil and self:IsSkillConsume(self.cActiveSkill3,energyType)) then
		table.insert(self.lstPosition,self.skillBtn3Position);
	end
	return self.lstPosition;
end

function EffectBarView:OnHeroHitFood(hero,food)
	if(self.mainHero ~= nil and self.mainHero.id == hero.id) then return end;
	if(ChaseCamera.instance:IsInView(hero.curPosition)) then
    	self:ShowSceneFoodEffect(hero,food,false);
	end
end

function EffectBarView:OnHitFood(food)
    if(food.coin > 0) then
    	AudioSys.instance:Play(AudioDefine.EatCoin);
	else
		AudioSys.instance:Play(AudioDefine.EatEnergy);
	end
    self:ShowSceneFoodEffect(self.mainHero,food,true);
end

function EffectBarView:ShowSceneFoodEffect(hero,food,isSelf)
	local centerPoint = hero.unitView.unitHangPoint:GetTransform("basemiddle_fixdirect");
    if(centerPoint == nil) then return end;
	local resFood = FoodTable[food.resId];
	local cPrefab = CResourceSys.instance:Load(EResType.EItem, resFood.prefab_name);
    local cItemModel = CGameObjectPool.instance:Get(cPrefab);
    cItemModel:SetActive(true);
    LuaHelper.AddChild(centerPoint.gameObject,cItemModel,true);
    local scale = 1000.0 / hero.localScale;
    LuaHelper.SetLocalScale(cItemModel,scale,scale,scale);
    local position = food.itemView.transform.position;
    LuaHelper.SetPos(cItemModel,position.x,position.y,position.z);
    local trans = cItemModel.transform;
    local onComplate = function ()
    	self:DisposeItemModel(cItemModel);
    	if(isSelf) then
    		self:ShowEffects(resFood);
    	end
    end
    local tweener = trans:DOLocalMove(Vector3.zero,0.3):SetEase(DG.Tweening.Ease.InExpo):OnComplete(onComplate);
    table.insert(self.lstItemModel,cItemModel);
    table.insert(self.lstItemTweener,tweener);
end

function EffectBarView:DisposeItemModel(itemModel)
	for i=#self.lstItemModel,1,-1 do
		if(self.lstItemModel[i] == itemModel) then
			local itemParent = BattleScene.instance:GetItemRoot();
			LuaHelper.AddChild(itemParent.gameObject,self.lstItemModel[i],true);
			CGameObjectPool.instance:Save(self.lstItemModel[i]);
			table.remove(self.lstItemModel,i);
			self.lstItemTweener[i]:Kill(false);
			table.remove(self.lstItemTweener,i);
			break;
		end
	end
end

function EffectBarView:ShowEffects(resFood)
	local worldPosition = ViewSys.instance:GetUIWorldPosition(ChaseCamera.instance.mainCamera,self.mainHero.unitView.transform.position);
	if(resFood.energy1 > 0) then
		local flyEffect = ConstTable["energy1_fly_effect"].p_string;
		local arriveEffect = ConstTable["energy1_arrive_effect"].p_string;
		local lstPositions = self:GetSkillPosition(EConsumeType.EEnergy1);
		for i=1,#lstPositions do
			self:CreateEffect(worldPosition,flyEffect,arriveEffect,lstPositions[i]);
		end
	end
	if(resFood.energy2 > 0) then
		local flyEffect = ConstTable["energy2_fly_effect"].p_string;
		local arriveEffect = ConstTable["energy2_arrive_effect"].p_string;
		local lstPositions = self:GetSkillPosition(EConsumeType.EEnergy2);
		for i=1,#lstPositions do
			self:CreateEffect(worldPosition,flyEffect,arriveEffect,lstPositions[i]);
		end
	end
	if(resFood.energy3 > 0) then
		local flyEffect = ConstTable["energy3_fly_effect"].p_string;
		local arriveEffect = ConstTable["energy3_arrive_effect"].p_string;
		local lstPositions = self:GetSkillPosition(EConsumeType.EEnergy3);
		for i=1,#lstPositions do
			self:CreateEffect(worldPosition,flyEffect,arriveEffect,lstPositions[i]);
		end
	end
end

function EffectBarView:CreateEffect(worldPosition,flyEffect,arriveEffect,arrivePosition)
	local effect = EffectManager.instance:Create(flyEffect,false,self.trans);
	LuaHelper.SetPos(effect,worldPosition.x,worldPosition.y,worldPosition.z);
	
	local onComplete = function ()
		for i=#self.lstEffect,1,-1 do
			if(self.lstEffect[i] == effect) then
				EffectManager.instance:Destory(self.lstEffect[i]);
				table.remove(self.lstEffect,i);
				break
			end
		end
		local arriveEffect = EffectManager.instance:Create(arriveEffect,true,self.trans);
		LuaHelper.SetPos(arriveEffect,arrivePosition.x,arrivePosition.y,arrivePosition.z);
		AudioSys.instance:Play(AudioDefine.EatEnergyFinish);
		--EffectManager.instance:SetEffectDuration(arriveEffect,0.5);
	end
	local sequence = DG.Tweening.DOTween.Sequence();
	local trans = effect.transform;
	local center = Vector3(worldPosition.x + (worldPosition.x) * 0.2,worldPosition.y + (worldPosition.y) * 0.1,0);
	self.positionTable[1] = worldPosition;
	self.positionTable[2] = center;
	self.positionTable[3] = arrivePosition;
	
	sequence:Insert(0,trans:DOPath(self.positionTable,0.6,DG.Tweening.PathType.CatmullRom):SetEase(DG.Tweening.Ease.InCirc));
	--sequence:Insert(0,trans:DOMove(arrivePosition,0.3):SetEase(DG.Tweening.Ease.Linear));
	sequence:Insert(0,trans:DOScale(1.5,0.2));
	sequence:Insert(0.2,trans:DOScale(1.2,0.4));
	sequence:InsertCallback(0.61,onComplete);
	--effect.transform:DOMove(self.skillBtn1Position,1):OnComplete(onComplete);
    table.insert(self.lstEffect,effect);
end

function EffectBarView:CloseView()
	-- body
	if(self.onUnitHitFood ~= nil) then
         EventSys.instance:RemoveEvent(EEventType.OnUnitHitItem, self.onUnitHitFood);
         self.onUnitHitFood = nil;
    end
	if(self.mainHeroUpdate ~= nil) then
         EventSys.instance:RemoveEvent(EEventType.OnMainHeroUpdate, self.mainHeroUpdate);
         self.mainHeroUpdate = nil;
    end
	self:ResetMainHero();
	self.onHitFood = nil;
	for i=1,#self.lstEffect do
		EffectManager.instance:Destory(self.lstEffect[i]);
	end
	for i=#self.lstItemModel,1,-1 do
		self:DisposeItemModel(self.lstItemModel[i]);
	end
	self.lstItemModel = {};
	self.lstItemTweener = {};
	self.lstEffect = {};
	self.lstPosition = {};
end

function EffectBarView:DestroyView()
	-- body
	self.go = nil;
end