require "Logic/Fight/HPBarView"
require "Logic/Fight/BubbleBarView"
require "Logic/Fight/OperateView"
require "Logic/Fight/LockBarView"
SkillTestView = class("SkillTestView", SkillTestViewUI);

function SkillTestView:Init()
    self.operateView = OperateView.new();
    self.operateView:InitView(self.operateBars);

    self.lockView = LockBarView.new();
    self.lockView:InitView(self.lockBars);
end

function SkillTestView:OpenView(param)
    Main.AddUpdateFun(SkillTestView.Update, self);
    self.operateView:OpenView(param);
    self.lockView:OpenView(param);
    self.battleChannel = NetSys.instance:GetChannel(EChannelType.EPvpChannel);
end

function SkillTestView:CloseView()
    Main.RemoveUpdateFun(SkillTestView.Update);
    self.operateView:CloseView();
    self.lockView:CloseView();
end

function SkillTestView:Update(deltaTime)
    self.operateView:OnUpdate(deltaTime);
    local nFpsValue = CGameRoot.instance.realFPS;
     local nPingValue = self.battleChannel.ping;
    self.fpsValue.text = string.format("%d", nFpsValue);
    self.pingValue.text = string.format("%d",nPingValue);
end

function SkillTestView:DestroyView()
    self.operateView:DestroyView();
    self.operateView = nil;
    self.lockView:DestroyView();
    self.lockView = nil;
    Main.RemoveUpdateFun(SkillTestView.Update, self);
end
