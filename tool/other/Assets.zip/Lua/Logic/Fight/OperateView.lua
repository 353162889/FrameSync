OperateView = class("OperateView")

function OperateView:InitView(go)
	self.go = go;
	self.transform = self.go.transform;
	--移动遥感
	self.moveJoystickPos = self.transform:Find("moveJoystickPos");
	local joyPrefab = CResourceSys.instance:Load(EResType.EView, "MoveJoystick.prefab");
    local joyObj = UnityEngine.GameObject.Instantiate(joyPrefab);
    self.mMoveJoystick = Joystick();
    self.mMoveJoystick:Init(joyObj, self.moveJoystickPos, true, false, false);

    self.onJoystickMoveStart = function ()
    	self:JoystickMoveStart();
    end
    self.onjoystickMove = function (sDir)
    	self:JoystickMove(sDir);
    end
    self.onJoystickMoveEnd = function ()
    	self:JoystickMoveEnd();
    end
    self.mMoveJoystick.OnMoveStartListener = self.mMoveJoystick.OnMoveStartListener + self.onJoystickMoveStart;
    self.mMoveJoystick.OnMoveListener = self.mMoveJoystick.OnMoveListener + self.onjoystickMove;
    self.mMoveJoystick.OnMoveEndListener = self.mMoveJoystick.OnMoveEndListener + self.onJoystickMoveEnd;

    --技能遥感
    joyPrefab = CResourceSys.instance:Load(EResType.EView, "SkillJoystick.prefab");
    joyObj = UnityEngine.GameObject.Instantiate(joyPrefab);
    self.mSkillJoystick = Joystick();
    self.mSkillJoystick:Init(joyObj, self.go.transform, false, true);


    self.onSkillJoystickMoveStart = function ()
    	self:SkillJoystickMoveStart();
    end
    self.onSkilljoystickMove = function (sDir)
    	self:SkillJoystickMove(sDir);
    end
    self.onSkillJoystickMoveEnd = function ()
    	self:SkillJoystickMoveEnd();
    end
    self.mSkillJoystick.OnMoveStartListener = self.mSkillJoystick.OnMoveStartListener + self.onSkillJoystickMoveStart;
    self.mSkillJoystick.OnMoveListener = self.mSkillJoystick.OnMoveListener + self.onSkilljoystickMove;
    self.mSkillJoystick.OnMoveEndListener = self.mSkillJoystick.OnMoveEndListener + self.onSkillJoystickMoveEnd;
    self.mSkillJoystick:SetActiveWidthRate(0.5, 1.0);
    self.mSkillJoystick:Hide();

    --目标选择遥感
    joyPrefab = CResourceSys.instance:Load(EResType.EView, "SelectJoystick.prefab");
    joyObj = UnityEngine.GameObject.Instantiate(joyPrefab);
    self.mSelectJoystick = Joystick();
    self.mSelectJoystick:Init(joyObj, self.go.transform, false, true);

     self.onSelectJoystickMoveStart = function ()
        self:SelectJoystickMoveStart();
    end
    self.onSelectjoystickMove = function (sDir)
        self:SelectJoystickMove(sDir);
    end
    self.onSelectJoystickMoveEnd = function ()
        self:SelectJoystickMoveEnd();
    end
    self.mSelectJoystick.OnMoveStartListener = self.mSelectJoystick.OnMoveStartListener + self.onSelectJoystickMoveStart;
    self.mSelectJoystick.OnMoveListener = self.mSelectJoystick.OnMoveListener + self.onSelectjoystickMove;
    self.mSelectJoystick.OnMoveEndListener = self.mSelectJoystick.OnMoveEndListener + self.onSelectJoystickMoveEnd;
    self.mSelectJoystick:SetActiveWidthRate(0.5, 1.0);
    self.mSelectJoystick:Hide();

    self.cancelRectTrans = self.transform:Find("cancelRect").transform;
    self.cancelRectTrans.gameObject:SetActive(false);

    self.normalSkillBtn = self.transform:Find("skill/normalSkillBtn").gameObject;
    self.normalSkillMask = self.transform:Find("skill/normalSkillBtn/normalSkillMask"):GetComponent("Image");
    self.skillBtn1 = self.transform:Find("skill/skillBtn1").gameObject;
    self.skillEnergy1 = self.transform:Find("skill/skillBtn1/skillEnergy1"):GetComponent("Image");
    self.imgSkillLeaveTime1 = self.transform:Find("skill/skillBtn1/imgSkillLeaveTime1"):GetComponent("Image");
    self.skillIcon1 = self.transform:Find("skill/skillBtn1/skillIcon1"):GetComponent("Image");
    self.txtSkillBg1 = self.transform:Find("skill/skillBtn1/txtSkillBg1").gameObject;
    self.txtEnergy1 = self.transform:Find("skill/skillBtn1/txtSkillBg1/txtEnergy1"):GetComponent("Text");
    self.skillMask1 = self.transform:Find("skill/skillBtn1/skillMask1"):GetComponent("Image");
    self.cdTime1 = self.transform:Find("skill/skillBtn1/skillMask1/CdTime1"):GetComponent("Text");
    self.skillBtn2 = self.transform:Find("skill/skillBtn2").gameObject;
    self.skillEnergy2 = self.transform:Find("skill/skillBtn2/skillEnergy2"):GetComponent("Image");
    self.imgSkillLeaveTime2 = self.transform:Find("skill/skillBtn2/imgSkillLeaveTime2"):GetComponent("Image");
    self.skillIcon2 = self.transform:Find("skill/skillBtn2/skillIcon2"):GetComponent("Image");
    self.txtSkillBg2 = self.transform:Find("skill/skillBtn2/txtSkillBg2").gameObject;
    self.txtEnergy2 = self.transform:Find("skill/skillBtn2/txtSkillBg2/txtEnergy2"):GetComponent("Text");
    self.skillMask2 = self.transform:Find("skill/skillBtn2/skillMask2"):GetComponent("Image");
    self.cdTime2 = self.transform:Find("skill/skillBtn2/skillMask2/CdTime2"):GetComponent("Text");
    self.skillBtn3 = self.transform:Find("skill/skillBtn3").gameObject;
    self.skillEnergy3 = self.transform:Find("skill/skillBtn3/skillEnergy3"):GetComponent("Image");
    self.imgSkillLeaveTime3 = self.transform:Find("skill/skillBtn3/imgSkillLeaveTime3"):GetComponent("Image");
    self.skillIcon3 = self.transform:Find("skill/skillBtn3/skillIcon3"):GetComponent("Image");
    self.txtSkillBg3 = self.transform:Find("skill/skillBtn3/txtSkillBg3").gameObject;
    self.txtEnergy3 = self.transform:Find("skill/skillBtn3/txtSkillBg3/txtEnergy3"):GetComponent("Text");
    self.skillMask3 = self.transform:Find("skill/skillBtn3/skillMask3"):GetComponent("Image");
    self.cdTime3 = self.transform:Find("skill/skillBtn3/skillMask3/CdTime3"):GetComponent("Text");
end

function OperateView:OpenView(param)
	self.mainHeroUpdate = function (eventId,obj)
        self:OnMainHeroUpdate();
    end
    EventSys.instance:AddEvent(EEventType.OnMainHeroUpdate, self.mainHeroUpdate);

    self.swapActiveSkillPosition = function (index,indexOther,oldSkill,newSkill)
        self:OnSwapActiveSkillPosition(index,indexOther,oldSkill,newSkill);
    end

    self.skillLeaveTimeFunc = function (skill,skillIndex,time,uiEffect)
        self:OnSkillLeaveTime(skill,skillIndex,time,uiEffect);
    end

    if(BattleScene.instance.mainHero ~= nil) then
        self:OnMainHeroUpdate();
    end

     self.expChange = function (consumeType,oldValue,newValue,lmtValue)
        self:OnExpChange(consumeType,oldValue,newValue,lmtValue);
    end
    self:OnExpChange(EConsumeType.ENone,0,0,1);
    self.skillLeaveTimeIndex1 = false;
    self.skillLeaveTime1 = 0;
    self.skillLeaveMaxTime1 = 0;
    self.skillUIEffect1 = nil;

    self.skillLeaveTimeIndex2 = false;
    self.skillLeaveTime2 = 0;
    self.skillLeaveMaxTime2 = 0;
    self.skillUIEffect2 = nil;

    self.skillLeaveTimeIndex3 = false;
    self.skillLeaveTime3 = 0;
    self.skillLeaveMaxTime3 = 0;
    self.skillUIEffect3 = nil;

    self.unitLockComp = BattleInfo.coreGaming:GetSysComp(EGamingSysCompType.UnitLock);
end

function OperateView:OnUpdate(deltaTime)
	self.mMoveJoystick:Update();
    self.mSkillJoystick:Update();
    self.mSelectJoystick:Update();
    if(self.cActiveSkill1 ~= nil) then
        local canSpell = self.mainHero.unitAttack:CanSpell(self.cActiveSkill1);
        if(not canSpell) then canSpell = self.mainHero.unitAttack:CanReceiveInputCast(self.cActiveSkill1); end
        if(self.skillMask1.gameObject.activeSelf ~= not canSpell) then
            self.skillMask1.gameObject:SetActive(not canSpell);
        end
        if(not canSpell) then
            local isCding = self.cActiveSkill1:IsCding();
            if(self.cdTime1.gameObject.activeSelf ~= isCding) then
                self.cdTime1.gameObject:SetActive(isCding);
            end
            if (isCding) then
                self.cdTime1.text = math.ceil((self.cActiveSkill1.cdEndTime - FrameSyncSys.time) / 1000);
            end
        end
    end
    if(self.cActiveSkill2 ~= nil) then
        local canSpell = self.mainHero.unitAttack:CanSpell(self.cActiveSkill2);
        if(not canSpell) then canSpell = self.mainHero.unitAttack:CanReceiveInputCast(self.cActiveSkill2); end
        if(self.skillMask2.gameObject.activeSelf ~= not canSpell) then
            self.skillMask2.gameObject:SetActive(not canSpell);
        end
        if(not canSpell) then
            local isCding = self.cActiveSkill2:IsCding();
            if(self.cdTime2.gameObject.activeSelf ~= isCding) then
                self.cdTime2.gameObject:SetActive(isCding);
            end
            if (isCding) then
                self.cdTime2.text = math.ceil((self.cActiveSkill2.cdEndTime - FrameSyncSys.time) / 1000);
            end
        end
    end
    if(self.cActiveSkill3 ~= nil) then
        local canSpell = self.mainHero.unitAttack:CanSpell(self.cActiveSkill3);
        if(not canSpell) then canSpell = self.mainHero.unitAttack:CanReceiveInputCast(self.cActiveSkill3); end
        if(self.skillMask3.gameObject.activeSelf ~= not canSpell) then
            self.skillMask3.gameObject:SetActive(not canSpell);
        end
        if(not canSpell) then
            local isCding = self.cActiveSkill3:IsCding();
            if(self.cdTime3.gameObject.activeSelf ~= isCding) then
                self.cdTime3.gameObject:SetActive(isCding);
            end
            if (isCding) then
                self.cdTime3.text = math.ceil((self.cActiveSkill3.cdEndTime - FrameSyncSys.time) / 1000);
            end
        end
    end
    if(self.mainHero ~= nil) then
         local canSpell = not self.mainHero.unitBuff:CheckActionState(EBuffActionType.EBanNormalSpell);
         if(self.normalSkillMask.gameObject.activeSelf ~= not canSpell) then
            self.normalSkillMask.gameObject:SetActive(not canSpell);
        end
    end
    if(self.skillLeaveTimeIndex1) then
        self.imgSkillLeaveTime1.fillAmount = self.skillLeaveTime1 / self.skillLeaveMaxTime1;
        self.skillLeaveTime1 = self.skillLeaveTime1 - deltaTime;
        if(self.skillLeaveTime1 <= 0) then
            self.skillLeaveTimeIndex1 = false;
            self.imgSkillLeaveTime1.gameObject:SetActive(false);
            if(self.skillUIEffect1 ~= nil) then
                EffectManager.instance:Destory(self.skillUIEffect1);
                self.skillUIEffect1 = nil;
            end
        end
    end
    if(self.skillLeaveTimeIndex2) then
        self.imgSkillLeaveTime2.fillAmount = self.skillLeaveTime2 / self.skillLeaveMaxTime2;
        self.skillLeaveTime2 = self.skillLeaveTime2 - deltaTime;
        if(self.skillLeaveTime2 <= 0) then
            self.skillLeaveTimeIndex2 = false;
            self.imgSkillLeaveTime2.gameObject:SetActive(false);
            if(self.skillUIEffect2 ~= nil) then
                EffectManager.instance:Destory(self.skillUIEffect2);
                self.skillUIEffect2 = nil;
            end
        end
    end
    if(self.skillLeaveTimeIndex3) then
        self.imgSkillLeaveTime3.fillAmount = self.skillLeaveTime3 / self.skillLeaveMaxTime3;
        self.skillLeaveTime3 = self.skillLeaveTime3 - deltaTime;
        if(self.skillLeaveTime3 <= 0) then
            self.skillLeaveTimeIndex3 = false;
            self.imgSkillLeaveTime3.gameObject:SetActive(false);
            if(self.skillUIEffect3 ~= nil) then
                EffectManager.instance:Destory(self.skillUIEffect3);
                self.skillUIEffect3 = nil;
            end
        end
    end
end

function OperateView:CloseView()
	if(self.mainHeroUpdate ~= nil) then
         EventSys.instance:RemoveEvent(EEventType.OnMainHeroUpdate, self.mainHeroUpdate);
         self.mainHeroUpdate = nil;
    end
    self:ResetMainHero();
    if(self.energySequence1 ~= nil) then self.energySequence1:Kill(true);self.energySequence1 = nil; end
    if(self.energySequence2 ~= nil) then self.energySequence2:Kill(true);self.energySequence2 = nil; end
    if(self.energySequence3 ~= nil) then self.energySequence3:Kill(true);self.energySequence3 = nil; end
    self.swapActiveSkillPosition = nil;
    self.skillLeaveTimeFunc = nil;
    self.expChange = nil;
    self.cNormalSkill = nil;
    self.cActiveSkill1 = nil;
    self.cActiveSkill2 = nil;
    self.cActiveSkill3 = nil;
    self.unitLockComp = nil;
end

function OperateView:DestroyView()
	-- body
	self.mMoveJoystick:Clear();
	self.mSkillJoystick:Clear();
    self.mSelectJoystick:Clear();
	self.mMoveJoystick = nil;
	self.mSkillJoystick = nil;
    self.mSelectJoystick = nil;
end

function OperateView:OnSkillLeaveTime(skill,skillIndex,time,uiEffect)
    -- body
    time = time / 1000.0;
    local index = skillIndex;
    if(index == 0) then
        self.skillLeaveTimeIndex1 = time > 0;
        self.skillLeaveTime1 = time;
        self.skillLeaveMaxTime1 = time;
        self.imgSkillLeaveTime1.gameObject:SetActive(self.skillLeaveTimeIndex1);
        self.skillUIEffect1 = self:SetSkillUIEffectVisiable(self.skillUIEffect1,uiEffect,self.imgSkillLeaveTime1.gameObject,self.skillLeaveTimeIndex1 and uiEffect ~= "")
    elseif(index == 1) then
        self.skillLeaveTimeIndex2 = time > 0;
        self.skillLeaveTime2 = time;
        self.skillLeaveMaxTime2 = time;
        self.imgSkillLeaveTime2.gameObject:SetActive(self.skillLeaveTimeIndex2);
        self.skillUIEffect2 = self:SetSkillUIEffectVisiable(self.skillUIEffect2,uiEffect,self.imgSkillLeaveTime2.gameObject,self.skillLeaveTimeIndex2 and uiEffect ~= "")
    elseif(index == 2) then
        self.skillLeaveTimeIndex3 = time > 0;
        self.skillLeaveTime3 = time;
        self.skillLeaveMaxTime3 = time;
        self.imgSkillLeaveTime3.gameObject:SetActive(self.skillLeaveTimeIndex3);
        self.skillUIEffect3 = self:SetSkillUIEffectVisiable(self.skillUIEffect3,uiEffect,self.imgSkillLeaveTime3.gameObject,self.skillLeaveTimeIndex3 and uiEffect ~= "")
    end
end

function OperateView:SetSkillUIEffectVisiable(oldEffect,strUIEffect,parent,visiable)
    if(visiable) then
        if(oldEffect == nil) then
            local go = EffectManager.instance:Create(strUIEffect,false,nil);
            UIViewUtil.AddUIEffect(parent,go);
            return go;
        else
            return oldEffect;
        end
    else
        if(oldEffect ~= nil) then
            EffectManager.instance:Destory(oldEffect);
        end
        return nil;
    end
end

function OperateView:OnSwapActiveSkillPosition(index,indexOther,oldSkill,newSkill)
    if(SkillIndicator.instance:IsUsing() and SkillIndicator.instance.skill.id == oldSkill.id) then
        SkillIndicator.instance:Hide();
        self.mSkillJoystick:Hide();
    end
    local skill = newSkill;
    local btnTrigger = nil;
    local skillIcon = nil;
    if(index == 0) then
        self.cActiveSkill1 = skill;
        skillIcon = self.skillIcon1;
        btnTrigger = EventTriggerListener.Get(self.skillBtn1);
    elseif(index == 1) then
        self.cActiveSkill2 = skill;
        skillIcon = self.skillIcon2;
        btnTrigger = EventTriggerListener.Get(self.skillBtn2);
    elseif(index == 2) then
        self.cActiveSkill3 = skill;
        skillIcon = self.skillIcon3;
        btnTrigger = EventTriggerListener.Get(self.skillBtn3);
    end
    if(skill ~= nil and skillIcon ~= nil and btnTrigger ~= nil) then
        btnTrigger:Clear();
        skillIcon.enabled = true;
        skillIcon.sprite = CResourceSys.instance:Load(EResType.EIcon,"Skill/"..skill.id..".png");
        self:AddSkillCastEvent(skill,btnTrigger);
    end

end

function OperateView:OnMainHeroUpdate()
    self:ResetMainHero();
    self.mainHero = BattleScene.instance.mainHero;

    local normalBtnTrigger = EventTriggerListener.Get(self.normalSkillBtn);
    normalBtnTrigger:Clear();
    local skillBtn1Trigger = EventTriggerListener.Get(self.skillBtn1);
    skillBtn1Trigger:Clear();
    local skillBtn2Trigger = EventTriggerListener.Get(self.skillBtn2);
    skillBtn2Trigger:Clear();
    local skillBtn3Trigger = EventTriggerListener.Get(self.skillBtn3);
    skillBtn3Trigger:Clear();

    if(self.mainHero ~= nil) then
        self.cNormalSkill = self.mainHero.unitAttack:GetNormalSkillByIdx(0);
        self.cActiveSkill1 = self.mainHero.unitAttack:GetActiveSkillByIdx(0);
        self.cActiveSkill2 = self.mainHero.unitAttack:GetActiveSkillByIdx(1);
        self.cActiveSkill3 = self.mainHero.unitAttack:GetActiveSkillByIdx(2);
        if(self.cNormalSkill ~= nil) then
            self:AddSkillCastEvent(self.cNormalSkill,normalBtnTrigger);
        end
        if(self.cActiveSkill1 ~= nil) then
            self.skillIcon1.enabled = true;
            self.skillIcon1.sprite = CResourceSys.instance:Load(EResType.EIcon,"Skill/"..self.cActiveSkill1.id..".png");
            self:AddSkillCastEvent(self.cActiveSkill1,skillBtn1Trigger);
            self.cActiveSkill1.OnExpChange = self.cActiveSkill1.OnExpChange + self.expChange;
        else
            self.skillIcon1.enabled = false;
        end
        if(self.cActiveSkill2 ~= nil) then
            self.skillIcon2.enabled = true;
            self.skillIcon2.sprite = CResourceSys.instance:Load(EResType.EIcon,"Skill/"..self.cActiveSkill2.id..".png");
             self:AddSkillCastEvent(self.cActiveSkill2,skillBtn2Trigger);
             self.cActiveSkill2.OnExpChange = self.cActiveSkill2.OnExpChange + self.expChange;
        else
            self.skillIcon2.enabled = false;
        end
        if(self.cActiveSkill3 ~= nil) then
            self.skillIcon3.enabled = true;
            self.skillIcon3.sprite = CResourceSys.instance:Load(EResType.EIcon,"Skill/"..self.cActiveSkill3.id..".png");
            self:AddSkillCastEvent(self.cActiveSkill3,skillBtn3Trigger);
            self.cActiveSkill3.OnExpChange = self.cActiveSkill3.OnExpChange + self.expChange;
        else
            self.skillIcon3.enabled = false;
        end
        self.mainHero.unitAttack.OnSwapActiveSkillPosition = self.mainHero.unitAttack.OnSwapActiveSkillPosition + self.swapActiveSkillPosition;
        self.mainHero.unitAttack.OnSkillLeaveTime = self.mainHero.unitAttack.OnSkillLeaveTime + self.skillLeaveTimeFunc;
        self.resHero = HeroTable[self.mainHero.resId];
    end
     self:OnExpChange(EConsumeType.ENone,0,0,1);
end

function OperateView:AddSkillCastEvent(skill,eventTrigger)
    -- body
    local castType = skill.castType;
    local onClick = function (go)
        local realSkill = skill;
        if(skill.isNormalSkill) then
            realSkill = skill.owner:GetSkill(skill.id);
        end
        --先派发事件
        self:ReceiveInputCast(realSkill,ECastType.EClick);
        if(castType == ECastType.EClick) then
            --普通攻击，选择目标时不释放技能（最终由选择目标这边释放）
            if(not realSkill.isNormalSkill or not self.mSelectJoystick.startMove) then
                self:CastSkill(realSkill);
            end
        end
    end
    eventTrigger.onClick = eventTrigger.onClick + onClick;
    --其他点击派发事件
    local onDown = function (go)
        local realSkill = skill;
        if(skill.isNormalSkill) then
            self.mSelectJoystick:Show(eventTrigger.transform.position);
            self.mSelectJoystick:SetRenderActive(false);
            realSkill = skill.owner:GetSkill(skill.id);
        end
         self:ReceiveInputCast(realSkill,ECastType.EClickDown);
        if realSkill.owner.unitAttack:CanSpell(realSkill) then
            if(realSkill.isDirectIndicator) then
                self.mSkillJoystick:Show(eventTrigger.transform.position);
                self.mSkillJoystick:SetRenderActive(false);
            end
            SkillIndicator.instance:Show(realSkill);
        end
        if(castType == ECastType.EClickDown) then
            --普通攻击，选择目标时不释放技能（最终由选择目标这边释放）
            if(not realSkill.isNormalSkill or not self.mSelectJoystick.startMove) then
                self:CastSkill(realSkill);
            end
        end
    end
    eventTrigger.onDown = eventTrigger.onDown + onDown;
    local onUp = function (go)
        local realSkill = skill;
        if(skill.isNormalSkill) then
            realSkill = skill.owner:GetSkill(skill.id);
        end
        self:ReceiveInputCast(realSkill,ECastType.EClickUp);
        if(castType == ECastType.EClickUp) then
            --普通攻击，选择目标时不释放技能（最终由选择目标这边释放）
            if(not realSkill.isNormalSkill or not self.mSelectJoystick.startMove) then
                if(not self.mSkillJoystick:IsShow() or not self.mSkillJoystick:IsCurScreenPosInRect(self.cancelRectTrans)) then
                    self:CastSkill(realSkill);
                end
            end
        end 
        if(not self.mSkillJoystick.startMove)then
            self.mSkillJoystick:Hide();
        end
        if(not self.mSelectJoystick.startMove) then
            self.mSelectJoystick:Hide();
        end
        if(not realSkill.isNormalSkill or not self.mSelectJoystick.startMove) then
             SkillIndicator.instance:Hide();
        end
        self.cancelRectTrans.gameObject:SetActive(false);
        EventSys.instance:DispatchLua(GameEvent.RankViewVisiable,true);
    end
    eventTrigger.onUp = eventTrigger.onUp + onUp;
end

function OperateView:ReceiveInputCast(cActiveSKill,castType)
    -- body
    local cMainHero = BattleScene.instance.mainHero;
    cMainHero:ReqReceiveInputCast(cActiveSKill.id, castType);
end

function OperateView:CastSkill(cActiveSKill)
	if(self.mainHero == nil)then return end;
    local cMainHero = self.mainHero;
    local realSkill = cMainHero:GetSkill(cActiveSKill.id);
    --获取遥感指令
    local unitId,resultPos,resultForward;
    if(realSkill.isDirectIndicator and SkillIndicator.instance:IsUsing()) then
        unitId = SkillIndicator.instance:GetTargetUnitId();
        resultPos = SkillIndicator.instance:GetTargetPosition();
        resultForward = SkillIndicator.instance:GetTargetForward();
    else
        local curForward = cMainHero.curForward;
        if(not cMainHero.unitLock.isLock and self.joystickMoveDir ~= nil and self.joystickMoveDir ~= Vector3.zero) then
            curForward = SVector3(self.joystickMoveDir);
        end
        local targetPosition =cMainHero.curPosition + realSkill.attackDis * curForward / 1000;
        local resultUnit = nil;
        resultUnit,resultPos,resultForward = realSkill:UseAimAssist(nil, targetPosition, curForward);
        unitId = 0;
        if(resultUnit ~= nil) then
            unitId = resultUnit.id;
        end
    end

    cMainHero:ReqCastSpell(realSkill.id, unitId, resultPos, resultForward,ESkillFromType.EPlayer);

 --    local castSpellDirect = true;
 --    local curSelectUnit = BattleScene.instance:GetUnit(unitId);
 --    local dis = 0;
 --    if(curSelectUnit ~= nil) then
 --    	dis = (curSelectUnit.curPosition - cMainHero.curPosition).magnitudeXz;
 --    	if(realSkill.attackDis < dis) then
 --    		castSpellDirect = false;
 --    	end
 --    end
 --    if(castSpellDirect) then
 --    	cMainHero:ReqCastSpell(realSkill.id, unitId, resultPos, resultForward);
	-- else
	-- 	cMainHero:ReqCastSpellGuide(realSkill.id, unitId, resultPos);
	-- end
end

function OperateView:ResetMainHero()
    if self.cActiveSkill1 ~= nil then
        self.cActiveSkill1.OnExpChange = self.cActiveSkill1.OnExpChange - self.expChange;
    end
    if self.cActiveSkill2 ~= nil then
        self.cActiveSkill2.OnExpChange = self.cActiveSkill2.OnExpChange - self.expChange;
    end
    if self.cActiveSkill3 ~= nil then
        self.cActiveSkill3.OnExpChange = self.cActiveSkill3.OnExpChange - self.expChange;
    end
    if(self.mainHero ~= nil) then
        self.mainHero.unitAttack.OnSwapActiveSkillPosition = self.mainHero.unitAttack.OnSwapActiveSkillPosition - self.swapActiveSkillPosition;
        self.mainHero.unitAttack.OnSkillLeaveTime = self.mainHero.unitAttack.OnSkillLeaveTime - self.skillLeaveTimeFunc;
    end
    self.resHero = nil;
    self.mainHero = nil;
    self.cActiveSkill1 = nil;
    self.cActiveSkill2 = nil;
    self.cActiveSkill3 = nil;
end

function OperateView:IsSkillConsume(skill,attrType)
    if(skill.consumeType == EConsumeType.ENone) then
        return false;
    end
    if (skill.consumeType == attrType) then
        return true;
    end
    return false;
end

--能量属性变更
function OperateView:OnExpChange(energyType,oldValue,newValue,lmtValue)
    if(self.mainHero ~= nil and energyType ~= EConsumeType.ENone) then
        if(self.cActiveSkill1 ~= nil) then
            if(self:IsSkillConsume(self.cActiveSkill1,energyType)) then
                if(self.energySequence1 ~= nil) then self.energySequence1:Kill(true) end
                self.energySequence1 = DG.Tweening.DOTween.Sequence();
                self:TweenFillAmount(self.energySequence1,self.skillEnergy1,oldValue,newValue,self.cActiveSkill1.levelExp);
                self.txtEnergy1.text = "" ..self.cActiveSkill1.level;
                self.txtSkillBg1:SetActive(self.cActiveSkill1.level < self.cActiveSkill1.maxLevel);
            end
        else
            self.skillEnergy1.fillAmount = 0;
            self.txtSkillBg1:SetActive(false);
        end
        if(self.cActiveSkill2 ~= nil) then
            if(self:IsSkillConsume(self.cActiveSkill2,energyType)) then
                if(self.energySequence2 ~= nil) then self.energySequence2:Kill(true) end
                self.energySequence2 = DG.Tweening.DOTween.Sequence();
                self:TweenFillAmount(self.energySequence2,self.skillEnergy2,oldValue,newValue,self.cActiveSkill2.levelExp);
                self.txtEnergy2.text = "" ..self.cActiveSkill2.level;
                self.txtSkillBg2:SetActive(self.cActiveSkill2.level < self.cActiveSkill2.maxLevel);
            end
        else
            self.skillEnergy2.fillAmount = 0;
            self.txtSkillBg2:SetActive(false);
        end
        if(self.cActiveSkill3 ~= nil) then
            if(self:IsSkillConsume(self.cActiveSkill3,energyType)) then
                if(self.energySequence3 ~= nil) then self.energySequence3:Kill(true) end
                self.energySequence3 = DG.Tweening.DOTween.Sequence();
                self:TweenFillAmount(self.energySequence3,self.skillEnergy3,oldValue,newValue,self.cActiveSkill3.levelExp);
                self.txtEnergy3.text = "" ..self.cActiveSkill3.level;
                self.txtSkillBg3:SetActive(self.cActiveSkill3.level < self.cActiveSkill3.maxLevel);
            end
        else
            self.skillEnergy3.fillAmount = 0;
            self.txtSkillBg3:SetActive(false);
        end
    else
        self.skillEnergy1.fillAmount = 0;
        self.txtSkillBg1:SetActive(false);
        self.skillMask1.gameObject:SetActive(false);
        self.skillEnergy2.fillAmount = 0;
        self.txtSkillBg2:SetActive(false);
        self.skillMask2.gameObject:SetActive(false);
        self.skillEnergy3.fillAmount = 0;
        self.txtSkillBg3:SetActive(false);
        self.skillMask3.gameObject:SetActive(false);
    end
end

function OperateView:TweenFillAmount(sequence,img,oldValue,newValue,perValue)
    local oldPercent = oldValue / perValue;
    local oldA,oldB = math.modf(oldPercent);
    local newPercent = newValue / perValue;
    local newA,newB = math.modf(newPercent);
    local offset = math.abs(newPercent - oldPercent);
    local offsetA,offsetB = math.modf(offset);
    local totalTime = offset * 0.8;
    local perTime = totalTime / offset;
    
    sequence:SetEase(DG.Tweening.Ease.Linear);
    if(newValue > oldValue) then
        if(offset >= 1 or newB < oldB) then
            sequence:Append(img:DOFillAmount(1,perTime * (1 - img.fillAmount)):SetEase(DG.Tweening.Ease.Linear));
            sequence:AppendCallback(function () img.fillAmount = 0; end);
            sequence:AppendInterval(0.001);
            local loopTime = offsetA;
            if(oldB < newB or (oldB == newB and oldB == 0))then loopTime = loopTime -1;end
            for i=1,loopTime do
                sequence:Append(img:DOFillAmount(1,perTime):SetEase(DG.Tweening.Ease.Linear));
                sequence:AppendCallback(function () img.fillAmount = 0; end);
                sequence:AppendInterval(0.001);
            end
            sequence:Append(img:DOFillAmount(newB,perTime * newB):SetEase(DG.Tweening.Ease.Linear));
        else
            sequence:Append(img:DOFillAmount(newB,perTime * (newB - img.fillAmount)):SetEase(DG.Tweening.Ease.Linear));
        end
    else
        img.fillAmount = newB;
    end
end


function OperateView:JoystickMoveStart()
    SkillIndicator.instance:OnJoyMoveStart(self.mMoveJoystick,false);
    if(nil ~= BattleScene.instance.mainHero) then
        BattleScene.instance.mainHero:ReqStopCastSpellGuide();
    end
end

function OperateView:JoystickMove(sDir)
    if(nil ~= BattleScene.instance.mainHero) then
        BattleScene.instance.mainHero:ReqMoveForward(SVector3(sDir));
    end
    self.joystickMoveDir = sDir;
    SkillIndicator.instance:OnJoyMove(self.mMoveJoystick,false);
end

function OperateView:JoystickMoveEnd()
    if(nil ~= BattleScene.instance.mainHero) then
        BattleScene.instance.mainHero:ReqStopMoveForward();
    end
    self.joystickMoveDir = Vector3.zero;
    SkillIndicator.instance:OnJoyMoveEnd(self.mMoveJoystick,false);
end

function OperateView:SkillJoystickMoveStart()
    self.mSkillJoystick:SetRenderActive(true);
    self.cancelRectTrans.gameObject:SetActive(true);
    EventSys.instance:DispatchLua(GameEvent.RankViewVisiable,false);
    SkillIndicator.instance:OnJoyMoveStart(self.mSkillJoystick,true);
end

function OperateView:SkillJoystickMove()
    SkillIndicator.instance:OnJoyMove(self.mSkillJoystick,true);
end

function OperateView:SkillJoystickMoveEnd()
    SkillIndicator.instance:OnJoyMoveEnd(self.mSkillJoystick,true);
    self.mSkillJoystick:Hide();
end


function OperateView:SelectJoystickMoveStart()
    self.cancelRectTrans.gameObject:SetActive(true);
    EventSys.instance:DispatchLua(GameEvent.RankViewVisiable,false);
    self.mSelectJoystick:SetRenderActive(true);
    if(not SkillIndicator.instance:IsUsing() and self.cNormalSkill ~= nil and self.mainHero ~= nil) then
        local realSkill = self.mainHero:GetSkill(self.cNormalSkill.id);
        SkillIndicator.instance:Show(realSkill);
    end
end

local lockHalfWidth = 2000;
function OperateView:SelectJoystickMove(sDir)
    if(self.mainHero ~= nil) then
        if(sDir == Vector3.zero) then
            if(UnitLockIndicator.instance.show) then
                UnitLockIndicator.instance:Hide();
            end
        else
            if(not UnitLockIndicator.instance.show) then
                UnitLockIndicator.instance:Show(self.mainHero,lockHalfWidth * 2 / 1000.0,self.resHero.lock_radius/1000.0);
            end
            UnitLockIndicator.instance:Update(sDir);
        end
    else
        if(UnitLockIndicator.instance.show) then
            UnitLockIndicator.instance:Hide();
        end
    end
end

function OperateView:SelectJoystickMoveEnd()
    if(not self.mSelectJoystick:IsShow() or not self.mSelectJoystick:IsCurScreenPosInRect(self.cancelRectTrans)) then
        if(self.mainHero ~= nil) then
            local dir = self.mSelectJoystick.joyDir;
            local sDir = SVector3(dir);
            if(sDir == SVector3.zero)then return end
            local unit = self.unitLockComp:SelectLockTarget(self.mainHero,sDir,lockHalfWidth,self.resHero.lock_radius / 2);
             self:SelectJoystickCastSkill(unit,sDir);
            if(unit ~= nil) then
                local succ = self.unitLockComp:ReqUnitUpdateLockTarget(self.mainHero.id,unit.id);
            end
            -- if(SkillIndicator.instance:IsUsing()) then
            --     SkillIndicator.instance:UpdateTarget(unit);
            -- end
            -- if(self.cNormalSkill ~= nil) then
            --     self:CastSkill(self.cNormalSkill);
            -- end
        end
    end
    
    if(UnitLockIndicator.instance.show) then
        UnitLockIndicator.instance:Hide();
    end
    SkillIndicator.instance:Hide();
    self.mSelectJoystick:Hide();
end

function OperateView:SelectJoystickCastSkill(targetUnit,sDir)
    if(self.cNormalSkill ~= nil) then
        local cActiveSKill = self.cNormalSkill;
        local cMainHero = self.mainHero;
        local realSkill = cMainHero:GetSkill(cActiveSKill.id);
        --获取遥感指令
        local unitId = 0;
        local resultPos = self.mainHero.curPosition;
        local resultForward = self.mainHero.curForward;
        if(targetUnit ~= nil) then
            unitId = targetUnit.id;
        end
        -- if(targetUnit ~= nil) then
        --     unitId = targetUnit.id;
        --     resultPos = targetUnit.curPosition;
        --     offsetPos = resultPos - cMainHero.curPosition;
        --     resultForward = offsetPos.normalizedXz;
        -- else
            resultForward = sDir.normalizedXz;
            resultPos =cMainHero.curPosition + realSkill.attackDis * resultForward / 1000;
        -- end
        cMainHero:ReqCastSpell(realSkill.id, unitId, resultPos, resultForward,ESkillFromType.EPlayerLock);

        -- local castSpellDirect = true;
        -- local dis = (offsetPos).magnitudeXz;
        -- if(realSkill.attackDis < dis) then
        --     castSpellDirect = false;
        -- end
        -- if(castSpellDirect) then
        --     cMainHero:ReqCastSpell(realSkill.id, unitId, resultPos, resultForward);
        -- else
        --     cMainHero:ReqCastSpellGuide(realSkill.id, unitId, resultPos);
        -- end
        
    end
end