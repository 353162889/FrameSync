require "Logic/Fight/UIMapItem"
MapView = class("MapView")

function MapView:InitView(go)
	self.go = go;
	self.template = self.go.transform:Find("Template").gameObject;
	self.template:SetActive(false);
	LuaHelper.SetLocalPos(self.template,100000,0,0);
	self.lstMapItem = {};
	self.lstPool = {};
	self.mainHeroId = -1;
	self.maxCoinHero = nil;
end

function MapView:OpenView(param)
	self.gameRank = BattleInfo.coreGaming:GetSysComp(EGamingSysCompType.Rank);

	self.resSession = SessionTable[BattleInfo.sessionId];
	--主玩家
	 self.mainHeroUpdate = function (eventId,obj)
        self:UpdateMainHeroItem();
    end
    EventSys.instance:AddEvent(EEventType.OnMainHeroUpdate, self.mainHeroUpdate);

    self.unitRemove = function (eventId,unit)
    	self:DestroyMapItem(unit.id,MapItemType.Hero);
    	if(unit == self.maxCoinHero) then
    		self:ResetMaxCoinHero();
    	end
    end
    EventSys.instance:AddEvent(EEventType.OnUnitRemove,self.unitRemove);

    if(BattleScene.instance.mainHero ~= nil) then
        self:UpdateMainHeroItem();
    end

    --排行榜第一名
	self.onRankUpdate = function (eventId,obj)
		self:UpdateMaxCoinHeroItem();
	end
	EventSys.instance:AddEvent(EEventType.OnRankUpdate,self.onRankUpdate)

	self.onCoinChange = function (oldValue,newValue)
		self:UpdateMaxCoinHeroItem();
	end
	self:UpdateMaxCoinHeroItem();
	
end

function MapView:CloseView()
	-- body
	if(self.mainHeroUpdate ~= nil) then
         EventSys.instance:RemoveEvent(EEventType.OnMainHeroUpdate, self.mainHeroUpdate);
         self.mainHeroUpdate = nil;
    end

    if(self.unitRemove ~= nil) then
         EventSys.instance:RemoveEvent(EEventType.OnUnitRemove, self.unitRemove);
         self.unitRemove = nil;
    end

    if(self.onRankUpdate ~= nil) then
		EventSys.instance:RemoveEvent(EEventType.OnRankUpdate,self.onRankUpdate)
		self.onRankUpdate = nil;
	end

	self:ResetMaxCoinHero();

	self.onCoinChange = nil;

	self.mainHeroId = -1;
	self.gameRank = nil;

	for i=1,#self.lstMapItem do
		self:DisposeItem(self.lstMapItem[i]);
	end
	self.lstMapItem = {};
end

function MapView:DestroyView()
	-- body
end

function MapView:UpdateMainHeroItem()
	self:DestroyMapItem(self.mainHeroId,MapItemType.Hero);
	self.mainHeroId = -1;
	self.mainHero = nil;
	local hero = BattleScene.instance.mainHero;
	if(hero ~= nil) then
		self.mainHeroId = hero.id;
		self.mainHero = hero;
		local item = self:GetItem();
		local heroKey = MapHeroKey.MainHero;
		if(hero.isCaptain) then
			heroKey = MapHeroKey.Captain;
		end
		item:SetFollow(self.mainHeroId,MapItemType.Hero,heroKey,hero.unitView.transform);
		table.insert(self.lstMapItem,item);
	end
end

function MapView:UpdateMaxCoinHeroItem()
	if(self.gameRank.lstRankunit.Count > 0) then
		local hero = self.gameRank.lstRankunit[0];
		--自己的时候不显示
		if(nil ~= BattleScene.instance.mainHero and hero.id == BattleScene.instance.mainHero.id) then
			if(self.maxCoinHero ~= nil) then
				self:DestroyMapItem(self.maxCoinHero.id,MapItemType.Hero);
			end
			self:ResetMaxCoinHero();
			return;
		end
		--积分少于一定分数时不显示
		if(hero.unitAttr.coin < self.resSession.map_show_coin) then
			if(self.maxCoinHero ~= nil) then
				self:DestroyMapItem(self.maxCoinHero.id,MapItemType.Hero);
			end
			self:ResetMaxCoinHero();
			return;
		end
		if(self.maxCoinHero == hero) then return; end
		if(self.maxCoinHero ~= nil) then
			self:DestroyMapItem(self.maxCoinHero.id,MapItemType.Hero);
		end
		self:ResetMaxCoinHero();
		self.maxCoinHero = hero;
		self.maxCoinHero.unitAttr.OnCoinChange = self.maxCoinHero.unitAttr.OnCoinChange + self.onCoinChange;
		local item = self:GetItem();
		item:SetFollow(self.maxCoinHero.id,MapItemType.Hero,MapHeroKey.MaxCoinHero,hero.unitView.transform);
		table.insert(self.lstMapItem,item);
	else
		if(self.maxCoinHero ~= nil) then
			self:DestroyMapItem(self.maxCoinHero.id,MapItemType.Hero);
		end
		self:ResetMaxCoinHero();
	end
end

function MapView:ResetMaxCoinHero()
	if(self.maxCoinHero ~= nil) then
		self.maxCoinHero.unitAttr.OnCoinChange = self.maxCoinHero.unitAttr.OnCoinChange - self.onCoinChange;
		self.maxCoinHero = nil;
	end
end

function MapView:GetItem()
	if(#self.lstPool > 0) then
		local item = self.lstPool[1];
		table.remove(self.lstPool,1)
		return item;
	else
		local go = UnityEngine.GameObject.Instantiate(self.template);
		go:SetActive(true);
		GameObjectUtil.AddChild(self.template.transform.parent.gameObject,go)
     	--go.transform:SetParent(self.template.transform.parent);
     	local item = UIMapItem.new();
     	item:Init(go);
     	LuaHelper.SetLocalPos(go,100000,0,0);
     	return item;
	end
end

function MapView:DestroyMapItem(id,itemType)
	for i=#self.lstMapItem,1,-1 do
		if(self.lstMapItem[i].id == id and self.lstMapItem[i].itemType == itemType) then
			local item = self.lstMapItem[i];
			table.remove(self.lstMapItem,i);
			self:DisposeItem(item);
			break;
		end
	end
end

function MapView:IsMapItemShow(id,itemType)
	for i=#self.lstMapItem,1,-1 do
		if(self.lstMapItem[i].id == id and self.lstMapItem[i].itemType == itemType) then
			return true;
		end
	end
	return false;
end

function MapView:DisposeItem(item)
	item:Reset();
	LuaHelper.SetLocalPos(item.go,100000,0,0);
	table.insert(self.lstPool,item);
end