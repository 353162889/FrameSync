require "Logic/EquipmentShop/EquipmentShopManager"
QuickBuyEquipView = class("QuickBuyEquipView")

local this

local leftEquipInfo
local rightEquipInfo

--提示维持时间
local tipShowTime = 3

--提示购买装备Item 的 table
local quickBuyItemTable = {}

function QuickBuyEquipView:InitView(go)
    this = self
    self.go = go
    self.transform = self.go.transform
    self.buyEquipItem = self.transform:Find("buyEquipItem").gameObject

    self:RegeditEvent()
    self:RefreshQuickBuy()
end

function QuickBuyEquipView:RegeditEvent()
    EventSys.instance:AddEvent(EEventType.OnUnitEquipDress,self.OnEquipDress)

    local mainHero = BattleScene.instance.mainHero
    if(mainHero ~= nil) then
        local coinChange = function(oldValue,newValue)
            this:RefreshQuickBuy(newValue)
        end
        mainHero.unitAttr.OnCoinChange = mainHero.unitAttr.OnCoinChange + coinChange
    end

end

function QuickBuyEquipView:OnEquipDress()
    this:RefreshQuickBuy()
end

function QuickBuyEquipView:RefreshQuickBuy(money)
    local money = money or BattleScene.instance.mainHero.unitAttr.coin --经验值
    --可快捷购买装备数据
    local equipDataTable = EquipmentShopManager:GetQuickBuyEquipData(money)

    for k,v in pairs(quickBuyItemTable) do
        v.go:SetActive(false)
    end

    for index,equipInfo in pairs(equipDataTable) do
        local objData = {}
        if quickBuyItemTable[index] then
            objData = quickBuyItemTable[index]
        else
            if index == 1 then
                objData.go = this.buyEquipItem
            else
                objData.go = UnityEngine.GameObject.Instantiate(this.buyEquipItem);
                objData.go.transform:SetParent(self.transform, false)
            end
            objData.btn_buyItem = objData.go.transform:Find("btn_buyItem").gameObject
            objData.img_equipIcon = objData.btn_buyItem.transform:Find("Mask/img_equipIcon"):GetComponent("Image")
            objData.txt_itemName = objData.go.transform:Find("txt_itemName"):GetComponent("Text")
            objData.txt_itemCost = objData.go.transform:Find("txt_itemCost"):GetComponent("Text")
            quickBuyItemTable[index] = objData
        end

        objData.go:SetActive(true)
        local quickBuyEquip = function()
            print("点击购买|equipID:"..equipInfo.id)
            EquipmentShopManager:BuyEquipByID(equipInfo.id)
        end
        EventButtonListerer.RemoveAllListeners(objData.btn_buyItem)
        EventButtonListerer.Get(objData.btn_buyItem, quickBuyEquip)
        objData.txt_itemName.text = equipInfo.name
        objData.txt_itemCost.text = "-"..equipInfo.exp_cost.."经验"
        UIUtil.SetSpriteByPath(objData.img_equipIcon, equipInfo.icon, true)
    end

end

function QuickBuyEquipView:OpenView(param)
	
end

function QuickBuyEquipView:CloseView()
	
end

function QuickBuyEquipView:DestroyView()

end