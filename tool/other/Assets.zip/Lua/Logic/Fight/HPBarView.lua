require "Logic/Fight/UIHPBar"

HPBarView = class("HPBarView")

function HPBarView:InitView(go)
	self.go = go;
	self.template = self.go.transform:Find("Template").gameObject;
	self.template:SetActive(false);
	LuaHelper.SetLocalPos(self.template,100000,0,0);
	self.lstHpBar = {};
	self.lstPool = {};
end

function HPBarView:GetColor(str)
	local succ,color = UnityEngine.ColorUtility.TryParseHtmlString(str,nil)
	return color;
end

function HPBarView:OpenView(param)
	self.hpSelfColor = self:GetColor("#ffffff");
	self.hpTeamColor = self:GetColor("#ffffff");
	self.hpEnemyColor = self:GetColor("#ff0a0a");
	self.hpNeutralColor = self:GetColor("#4dacdb");
	self.normalColor = self:GetColor("#bfbfbf");

	self.teamBlueColor = self:GetColor("#48e7f5");
	self.teamRedColor = self:GetColor("#ff4c4c");
	self.teamNeutralColor = self:GetColor("#4dacdb");
	self.lstColor = {self:GetColor("#ff4c4c"),self:GetColor("#fefc2f")
					 -- self:GetColor("#ff4c4c"),self:GetColor("#fefc2f"),
					 -- self:GetColor("#48f589"),self:GetColor("#48e7f5"),
					 -- self:GetColor("#ffa94d"),self:GetColor("#ffffff"),
					 -- self:GetColor("#7bf34c"),self:GetColor("#c197ff"),
					 -- self:GetColor("#ff68ba"),self:GetColor("#ff97b2")
					 };
	self.dicColor = {}

	Util.LogColor("#ff0000","HPBarView:OpenView")
	self.onUnitDie = function (eventId,damageInfo)
		if(damageInfo ~= nil) then
			self:OnUnitDie(eventId,damageInfo.defence);
		end
	end
	EventSys.instance:AddEvent(EEventType.OnUnitDie,self.onUnitDie);
	self.onUnitAdd = function (eventId,unit)
		self:OnUnitAdd(eventId,unit)
	end
	EventSys.instance:AddEvent(EEventType.OnUnitAdd,self.onUnitAdd);
	self.onUnitRemove = function (eventId,unit)
		self:OnUnitRemove(eventId,unit)
	end
	EventSys.instance:AddEvent(EEventType.OnUnitRemove,self.onUnitRemove);
	self.onUnitRevive = function (eventId,unit)
		self:OnUnitRevive(eventId,unit)
	end
	EventSys.instance:AddEvent(EEventType.OnUnitRevive,self.onUnitRevive);
	self.onMainHeroUpdate = function (eventId,unit)
		self:OnMainHeroUpdate()
	end
	EventSys.instance:AddEvent(EEventType.OnMainHeroUpdate,self.onMainHeroUpdate);

	self.onTeamChange = function (eventId,unit)
		self:OnTeamChange(eventId,unit)
	end
	EventSys.instance:AddEvent(EEventType.OnUnitTeamChange,self.onTeamChange);

	local blueBattleCamp = BattleScene.instance:GetBattleCamp(ECamp.EBlue);
	if blueBattleCamp ~= nil then
		local count = blueBattleCamp.mLstHero.Count;
		for i=0,count - 1 do
	    	self:CreateHPBar(blueBattleCamp.mLstHero[i]);
	    end
	    count = blueBattleCamp.mLstSoldier.Count;
		for i=0,count - 1 do
	    	self:CreateHPBar(blueBattleCamp.mLstSoldier[i]);
	    end
	end

	EventSys.instance:AddEvent(EEventType.OnUnitVisible, HPBarView.OnUnitVisible);

	local redBattleCamp = BattleScene.instance:GetBattleCamp(ECamp.ERed);
	if redBattleCamp ~= nil then
	    count = redBattleCamp.mLstHero.Count;
		for i=0,count - 1 do
	    	self:CreateHPBar(redBattleCamp.mLstHero[i]);
	    end
	    count = redBattleCamp.mLstSoldier.Count;
		for i=0,count - 1 do
	    	self:CreateHPBar(redBattleCamp.mLstSoldier[i]);
	    end
	end

	local neutralBattleCamp = BattleScene.instance:GetBattleCamp(ECamp.ENeutral);
	if neutralBattleCamp ~= nil then
	    count = neutralBattleCamp.mLstHero.Count;
		for i=0,count - 1 do
	    	self:CreateHPBar(neutralBattleCamp.mLstHero[i]);
	    end
	    count = neutralBattleCamp.mLstSoldier.Count;
		for i=0,count - 1 do
	    	self:CreateHPBar(neutralBattleCamp.mLstSoldier[i]);
	    end
	end
	
end

function HPBarView:OnUnitDie(eventId,unit)
	-- body
	self:DestroyHPBar(unit);
end

function HPBarView:OnUnitAdd(eventId,unit)
	-- body
	self:CreateHPBar(unit);
end

function HPBarView:OnUnitRemove(eventId,unit)
	-- body
	self:DestroyHPBar(unit);
end

function HPBarView:OnUnitRevive(eventId,unit)
	-- body
	self:CreateHPBar(unit);
end

function HPBarView:OnMainHeroUpdate()
	-- body
	if(BattleScene.instance.mainHero == nil) then return end;
	self:DestroyHPBar(BattleScene.instance.mainHero);
	self:CreateHPBar(BattleScene.instance.mainHero);
end

function HPBarView:OnTeamChange(eventId,unit)
	local hpBar = self:GetUnitBar(unit);
	self:SetColor(hpBar,unit);
	self:SetCaptain(hpBar,unit);
end

function HPBarView:SetColor(hpBar,unit)
	if(hpBar ~= nil) then
		local color = self.normalColor;
		if(unit.hasTeam) then
			-- local teamId = unit.teamId;
			-- if(self.dicColor[teamId] == nil and #self.lstColor > 0) then
			-- 	self.dicColor[teamId] = self.lstColor[1];
			-- 	table.remove(self.lstColor,1);
			-- end
			-- if(self.dicColor[teamId] ~= nil) then
			-- 	color = self.dicColor[teamId];
			-- end
			if(unit.camp == ECamp.EBlue) then
				color = self.teamBlueColor;
			elseif(unit.camp == ECamp.ERed) then
				color = self.teamRedColor;
			elseif(unit.camp == ECamp.ENeutral) then
				color = self.teamNeutralColor;
			end
		end
		local hpColor = nil;
		if(BattleScene.instance.mainHero == unit) then
			hpColor = self.hpSelfColor;
		elseif(BattleScene.instance.mainHero ~= nil and BattleScene.instance.mainHero.hasTeam and unit.teamId == BattleScene.instance.mainHero.teamId) then
			hpColor = self.hpTeamColor;
		elseif(unit.camp == ECamp.ENeutral) then
		 	hpColor = self.hpNeutralColor;
		else
			hpColor = self.hpEnemyColor;
		end
		--Util.LogColor("#ff0000","SetColor",color)
		hpBar:SetColor(color);
		hpBar:SetHpProgressColor(hpColor);
	end
end

function HPBarView:SetCaptain(hpBar,unit)
	if(hpBar ~= nil) then
		local isSelf = false;
		if(unit.hasTeam and BattleScene.instance.mainHero ~= nil and BattleScene.instance.mainHero.teamId == unit.teamId) then
			isSelf = true;
		end
		hpBar:SetCaptain(unit.isCaptain,isSelf);
	end
end

function HPBarView:OnUpdate()
	for i=1,#self.lstHpBar do
		self.lstHpBar[i]:OnUpdate();
	end
end

function HPBarView:CreateHPBar(unit)
	if(unit.isDie) then return end;
	local bar = self:GetBar();
	bar:SetUnit(unit)
	self:SetColor(bar,unit);
	self:SetCaptain(bar,unit);
	table.insert(self.lstHpBar,bar);
end

function HPBarView:GetUnitBar(unit)
	for i=#self.lstHpBar,1,-1 do
		if(self.lstHpBar[i].unit.id == unit.id) then
			return self.lstHpBar[i];
		end
	end
	return nil;
end

function HPBarView:GetBar()
	if(#self.lstPool > 0) then
		local item = self.lstPool[1];
		table.remove(self.lstPool,1)
		return item;
	else
		local go = UnityEngine.GameObject.Instantiate(self.template);
		go:SetActive(true);
		GameObjectUtil.AddChild(self.template.transform.parent.gameObject,go)
     	--go.transform:SetParent(self.template.transform.parent);
     	local bar = UIHPBar.new();
     	bar:Init(go);
     	LuaHelper.SetLocalPos(go,100000,0,0);
     	return bar;
	end
end

function HPBarView:DestroyHPBar(unit)
	for i=#self.lstHpBar,1,-1 do
		if(self.lstHpBar[i].unit.id == unit.id) then
			local bar = self.lstHpBar[i];
			table.remove(self.lstHpBar,i);
			self:DisposeBar(bar);
			break;
		end
	end
end

function HPBarView:DisposeBar(bar)
	bar:Reset();
	LuaHelper.SetLocalPos(bar.go,100000,0,0);
	table.insert(self.lstPool,bar);
end

function HPBarView:CloseView()
	-- body
	if(self.onUnitDie ~= nil) then
		EventSys.instance:RemoveEvent(EEventType.OnUnitDie,self.onUnitDie);
		self.onUnitDie = nil;
	end
	if(self.onUnitAdd ~= nil) then
		EventSys.instance:RemoveEvent(EEventType.OnUnitAdd,self.onUnitAdd);
		self.onUnitAdd = nil;
	end
	if(self.onUnitRemove ~= nil) then
		EventSys.instance:RemoveEvent(EEventType.OnUnitRemove,self.onUnitRemove);
		self.onUnitRemove = nil;
	end
	if(self.onUnitRevive ~= nil) then
		EventSys.instance:RemoveEvent(EEventType.OnUnitRevive,self.onUnitRevive);
		self.onUnitRevive = nil;
	end
	if(self.onMainHeroUpdate ~= nil) then
		EventSys.instance:RemoveEvent(EEventType.OnMainHeroUpdate,self.onMainHeroUpdate);
		self.onMainHeroUpdate = nil;
	end
	if(self.onTeamChange ~= nil) then
		EventSys.instance:RemoveEvent(EEventType.OnUnitTeamChange,self.onTeamChange);
		self.onTeamChange = nil;
	end
	for i=1,#self.lstHpBar do
		self:DisposeBar(self.lstHpBar[i]);
	end
	self.lstHpBar = {};
end

function HPBarView:DestroyView()
	for i=1,#self.lstHpBar do
		self:DisposeBar(self.lstHpBar[i]);
	end
	self.lstHpBar = {};
	for i=1,#self.lstPool do
		GameObject.Destroy(self.lstPool[i].go);
	end
	self.lstPool = {};
end

function HPBarView.OnUnitVisible(eventId, unit)
	local bIsActive = unit.unitView:IsActive();
	local cUnitBar = HPBarView:GetUnitBar(unit);
	if(cUnitBar == nil) then return end;
	if bIsActive then
		cUnitBar:Show();
	else
		cUnitBar:Hide();
	end 
end