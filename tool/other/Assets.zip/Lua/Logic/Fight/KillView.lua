KillView = class("KillView")

function KillView:InitView(go)
	self.go = go;
	self.transform = self.go.transform;
	self.revive_Center = self.transform:Find("Revive_Center").gameObject;
    self.txtReliveTime = self.transform:Find("Revive_Center/txtReliveTime"):GetComponent("Text");
    self.kill_CenterUp = self.transform:Find("Kill_CenterUp");
    self.selfIcon = self.transform:Find("Kill_CenterUp/SelfIcon").gameObject;
    self.iconKillSelf = self.transform:Find("Kill_CenterUp/SelfIcon/iconKillSelf"):GetComponent("Image");
    self.frontbg = self.transform:Find("Kill_CenterUp/SelfIcon/frontbg"):GetComponent("Image");
    self.txtKillSelfName = self.transform:Find("Kill_CenterUp/SelfIcon/txtKillSelfName"):GetComponent("Text");
    self.iconKillSelfMask = self.transform:Find("Kill_CenterUp/SelfIcon/iconKillSelfMask").gameObject;
    self.iconKillSelfCross = self.transform:Find("Kill_CenterUp/SelfIcon/iconKillSelfCross").gameObject;
    self.enemyIcon = self.transform:Find("Kill_CenterUp/EnemyIcon").gameObject;
    self.iconKillHero = self.transform:Find("Kill_CenterUp/EnemyIcon/iconKillHero"):GetComponent("Image");
    self.frontbg = self.transform:Find("Kill_CenterUp/EnemyIcon/frontbg"):GetComponent("Image");
    self.txtKillHeroName = self.transform:Find("Kill_CenterUp/EnemyIcon/txtKillHeroName"):GetComponent("Text");
    self.iconKillHeroMask = self.transform:Find("Kill_CenterUp/EnemyIcon/iconKillHeroMask").gameObject;
    self.iconKillHeroCross = self.transform:Find("Kill_CenterUp/EnemyIcon/iconKillHeroCross").gameObject;
    self.txtKillDesc = self.transform:Find("Kill_CenterUp/txtKillDesc"):GetComponent("Text");
    self.kill_Count = self.transform:Find("kill_Count");
    self.txtKill = self.transform:Find("kill_Count/txtKill"):GetComponent("Text");
    self.bgKillSplash = self.transform:Find("kill_Count/bgKillSplash"):GetComponent("Image");

    self.dieTime = 0;
    self.dieTotalTime = 0;
end

function KillView:OpenView(param)
    self.onUnitDie = function (eventId,damageInfo)
    	local mainHero = BattleScene.instance.mainHero;
    	if(mainHero == nil) then return end;
        if(damageInfo ~= nil) then
            if(damageInfo.defence.id == mainHero.id) then
                self:OnMainHeroDie(damageInfo);
            end
            if(damageInfo.attack ~= nil and damageInfo.attack.id == mainHero.id and damageInfo.defence.unitType == EUnitType.EHero) then
                self:OnMainKill(damageInfo);
            end
        end
    end
    EventSys.instance:AddEvent(EEventType.OnUnitDie,self.onUnitDie);

     self.onUnitRevive = function (eventId,unit)
        if(BattleScene.instance.mainHero ~= nil and unit.id == BattleScene.instance.mainHero.id) then
            self.revive_Center:SetActive(false);
        end
    end
    EventSys.instance:AddEvent(EEventType.OnUnitRevive,self.onUnitRevive);

    self.revive_Center:SetActive(BattleScene.instance.mainHero ~= nil and BattleScene.instance.mainHero.isDie);
    LuaHelper.SetLocalScale(self.kill_Count,0,0,0);
    LuaHelper.SetLocalScale(self.kill_CenterUp,0,0,0);
    self.dieTime = 0;
end

function KillView:OnUpdate(deltaTime)
	 if(self.dieTime > 0) then
        self.txtReliveTime.text = tostring(math.ceil(self.dieTime));
        self.dieTime = self.dieTime - deltaTime;
    end
end

function KillView:CloseView()
    if(self.onUnitDie ~= nil) then
        EventSys.instance:RemoveEvent(EEventType.OnUnitDie,self.onUnitDie);
        self.onUnitDie = nil;
    end

    if(self.onUnitRevive ~= nil) then
        EventSys.instance:RemoveEvent(EEventType.OnUnitRevive,self.onUnitRevive);
        self.onUnitRevive = nil;
    end

    if(self.killCountSequence ~= nil) then
       self.killCountSequence:Kill(true);
       self.killCountSequence=nil;
    end
    if(self.killCenterUpSequence ~= nil) then
        self.killCenterUpSequence:Kill(true);
        self.killCenterUpSequence=nil;
    end
end

function KillView:DestroyView()
	-- body
end

function KillView:OnMainKill(damageInfo)
	local mainHero = BattleScene.instance.mainHero;
    AudioSys.instance:Play(AudioDefine.MainHeroKill);
    local statisticsComp = BattleInfo.coreGaming:GetSysComp(EGamingSysCompType.Statistics);
    local statics = statisticsComp:GetStatisticsData(mainHero.id);
    self.txtKill.text = tostring(statics.kill);
    LuaHelper.SetLocalScale(self.kill_Count,0.5,0.5,0.5);
    LuaHelper.SetImageColor(self.bgKillSplash,1,1,1,0);
    if(self.killCountSequence ~= nil) then
        self.killCountSequence:Kill(false);
    end
    
    self.killCountSequence = DG.Tweening.DOTween.Sequence();
    self.killCountSequence:Append(self.kill_Count:DOScale(1,0.3):SetEase(DG.Tweening.Ease.OutBack));
    self.killCountSequence:Insert(0.15,self.bgKillSplash:DOFade(1,0.1));
    self.killCountSequence:Insert(0.25,self.bgKillSplash:DOFade(0,0.1));
    self.killCountSequence:AppendInterval(0.8);
    local onComplate = function ()
        -- body
        LuaHelper.SetLocalScale(self.kill_Count,0,0,0);
        self.killCountSequence = nil;
    end
    self.killCountSequence:AppendCallback(onComplate);

    self:ShowKillHeroInfo(mainHero,damageInfo.defence,false);
end


function KillView:OnMainHeroDie(damageInfo)
	local mainHero = BattleScene.instance.mainHero;
    if(mainHero.unitAttr.coin > 0) then
        self.revive_Center:SetActive(true);
        self.dieTime = mainHero.totalDieTime / 1000.0;
        if(self.dieTime > 0) then
            self.txtReliveTime.text = tostring(math.ceil(self.dieTime));
        end
        if(damageInfo ~= nil and damageInfo.attack ~= nil) then
            self:ShowKillHeroInfo(mainHero,damageInfo.attack,true);
        end
    end
end

function KillView:ShowKillHeroInfo(heroA,heroB,isADie)
    -- body
    local resIconA = nil;
    if(heroA.unitType == EUnitType.EHero) then
        resIconA = HeroTable[heroA.resId].icon;
    else
        resIconA = SoldierTable[heroA.resId].icon;
    end
    self.iconKillSelf.sprite = CResourceSys.instance:Load(EResType.EIcon,resIconA);
    self.txtKillSelfName.text = heroA.name;
    self.iconKillSelfMask:SetActive(isADie);
    self.iconKillSelfCross:SetActive(isADie);

    local resIconB = nil;
    if(heroB.unitType == EUnitType.EHero) then
        resIconB = HeroTable[heroB.resId].icon;
    else
        resIconB = SoldierTable[heroB.resId].icon;
    end
    self.iconKillHero.sprite = CResourceSys.instance:Load(EResType.EIcon,resIconB);
    self.txtKillHeroName.text = heroB.name;
    self.iconKillHeroMask:SetActive(not isADie);
    self.iconKillHeroCross:SetActive(not isADie);

    if(isADie) then
        self.txtKillDesc.text = "Killed By";
    else
        self.txtKillDesc.text = "Kill";
    end

    LuaHelper.SetLocalScale(self.kill_CenterUp,0.5,0.5,0.5);
    if(self.killCenterUpSequence ~= nil) then
        self.killCenterUpSequence:Kill(false);
    end
    self.killCenterUpSequence = DG.Tweening.DOTween.Sequence();
    self.killCenterUpSequence:Append(self.kill_CenterUp:DOScale(1,0.3):SetEase(DG.Tweening.Ease.OutBack));
    self.killCenterUpSequence:AppendInterval(3);
    local onComplate = function ()
        -- body
        LuaHelper.SetLocalScale(self.kill_CenterUp,0,0,0);
        self.killCenterUpSequence = nil;
    end
    self.killCenterUpSequence:AppendCallback(onComplate);
end
