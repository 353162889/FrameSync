UIHPBar = class("UIHPBar")

function UIHPBar:Init(go)
	self.go = go;
	self.trans = self.go.transform;
	self.progressGO = self.trans:Find("HpProgress/Progress").gameObject;
	self.progressImg = self.progressGO:GetComponent(typeof(UnityEngine.UI.Image));
	self.progress = GameObjectUtil.AddComponentOnce(self.progressGO,typeof(UIProgress));
	self.progress:Init();
	self.txtName = self.trans:Find("Name"):GetComponent("Text");
	self.scoreGO = 	self.trans:Find("Score").gameObject;
	self.score = GameObjectUtil.AddComponentOnce(self.scoreGO,typeof(UIProgress));
	self.imgScore = self.scoreGO:GetComponent(typeof(UnityEngine.UI.Image));
	self.txtLevel = self.trans:Find("Level"):GetComponent("Text");
	self.imgCaptainSelf = self.trans:Find("imgCaptainSelf"):GetComponent(typeof(UnityEngine.UI.Image));
	self.imgCaptainEnemy = self.trans:Find("imgCaptainEnemy"):GetComponent(typeof(UnityEngine.UI.Image));
	self.energyProgress = self.trans:Find("HpProgress/energyProgress"):GetComponent(typeof(UnityEngine.UI.Image));
	self.isEnable = false;
end

function UIHPBar:SetUnit(unit)

	if(self.unit ~= nil and self.onHpChange ~= nil and self.onScaleChange ~= nil and self.onCoinchage) then
		self.unit.unitAttr.OnHpChange = self.unit.unitAttr.OnHpChange - self.onHpChange;
		self.unit.OnScaleUpdate = self.unit.OnScaleUpdate - self.onScaleChange;
		self.unit.unitAttr.OnCoinChange = self.unit.unitAttr.OnCoinChange -self.onCoinchage;
		self.unit.unitAttr.OnEnergyChange = self.unit.unitAttr.OnEnergyChange - self.onEnergyChange;
		self.onHpChange = nil;
		self.onCoinchage = nil;
		self.onScaleChange = nil;
		self.unit = nil;
	end

	self.unit = unit;

	self.onHpChange = function (oldValue,newValue)
		self:HpChange(oldValue,newValue);
	end
	self.onEnergyChange = function(oldValue,newValue)
		self:EnergyChange(oldValue,newValue);
	end
	self.onCoinchage = function(oldValue,newValue)
	    self:CoinChange(oldValue,newValue);
    end
    self.onCoinLevelIDChange = function(oldValue,newValue)
	    self:CoinLevelIDChange(oldValue,newValue);
    end
	self.onScaleChange = function (unit)
		self:ScaleChange(unit);
	end
	
	self.txtName.text = self.unit.name;
	self:HpChange(self.unit.unitAttr.hp,self.unit.unitAttr.hp);
	self:CoinChange(self.unit.unitAttr.coin,self.unit.unitAttr.coin);
	self:CoinLevelIDChange(self.unit.unitAttr.coinLevelID,self.unit.unitAttr.coinLevelID);
	-- self.progressImg.color = Color(0,1,0.2);
	-- if BattleScene.instance.mainHero ~= nil and (BattleScene.instance.mainHero.id == self.unit.id or self.unit.) then
	-- 	self.progressImg.color = Color(1,1,1);
	-- else
	-- 	self.progressImg.color = Color(1,0.1,0.1);
	-- end
	self:CheckAndAddFollower();
	self:UpdateProgress();
	
	self.unit.unitAttr.OnHpChange = self.unit.unitAttr.OnHpChange + self.onHpChange;
	self.unit.unitAttr.OnEnergyChange = self.unit.unitAttr.OnEnergyChange + self.onEnergyChange;
	self.unit.unitAttr.OnCoinChange = self.unit.unitAttr.OnCoinChange + self.onCoinchage;
	self.unit.unitAttr.OnCoinLevelIDChange = self.unit.unitAttr.OnCoinLevelIDChange + self.onCoinLevelIDChange;
	self.unit.OnScaleUpdate = self.unit.OnScaleUpdate + self.onScaleChange;
	self.showHP = true;
	self:CheckUpdateVisiable();

end

function UIHPBar:SetHpProgressColor(color)
	self.progressImg.color = color;
end

function UIHPBar:SetColor(color)
	self.imgScore.color = color;
	self.txtLevel.color = color;
	self.txtName.color = color;
end

function UIHPBar:SetCaptain(isCaptain,isSelf)
	self.imgCaptainSelf.enabled = (isCaptain and isSelf);
	self.imgCaptainEnemy.enabled = (isCaptain and not isSelf);
end

function UIHPBar:CheckUpdateVisiable()
	if(self.showHP and self.unit.unitView:IsActive()) then
		self:Show();
	else
		self:Hide();
	end
end

function UIHPBar:Show()
	if(not self.isEnable) then
		self.isEnable = true;
		if(self.follower ~= nil) then
			self.follower.enabled = true;
		end
	end
end

function UIHPBar:Hide()
	if(self.isEnable) then
		self.isEnable = false;
		if(self.follower ~= nil) then
			self.follower.enabled = false;
		end
	end
	LuaHelper.SetLocalPos(self.go,100000,0,0)
end

function UIHPBar:OnUpdate()
	--[[ if(self.unit.unitAttr.energy~=self.unit.unitAttr.energyLmt)then 
		self:AddEnergy();
	end
	 ]]
	-- if(Time.time - self.showTime > 5)then
	-- 	self.showHP = false;
	-- 	self:CheckAndAddFollower();
	-- end
end

function UIHPBar:HpChange(oldValue,newValue)
	self:UpdateProgress();
	self.showHP = true;
	self:CheckAndAddFollower();
end

function UIHPBar:EnergyChange(oldValue,newValue)
	if( self.unit~=nil)then 
		local percent = self.unit.unitAttr.energy / self.unit.unitAttr.energyLmt;
		self.energyProgress.fillAmount = percent;
	end
end

function UIHPBar:EnergyRateChange(oldValue,newValue)
	
end

function UIHPBar:AddEnergy()
--[[ 	print(self.unit.unitAttr.energy);
	print(self.unit.unitAttr.energyLmt);
	print(self.unit.unitAttr.energyRate); ]]
	self.unit.unitAttr.energy=self.unit.unitAttr.energy+self.unit.unitAttr.energyRate;
end

function UIHPBar:CoinChange(oldValue,newValue)
	self.score:UpdateProgress(0);
	local coinLevelID = self.unit.unitAttr.coinLevelID;
	if(coinLevelID > 0) then
		local resInfo = ResCoinLevelTable[coinLevelID];
		local subCoin = resInfo.up_coin - self.unit.unitAttr.coin;
		local preCoin = 0;
		if(resInfo.level > 1) then
			local preResInfo = ResCoinLevelTable[resInfo.id - 1];
			preCoin = preResInfo.up_coin;
		end
		local totalCoin = resInfo.up_coin - preCoin;
		if(totalCoin == 0) then
			self.score:UpdateProgress(1);
		else
			self.score:UpdateProgress(1 - subCoin * 1.0 / totalCoin);
		end
	else
		self.score:UpdateProgress(0);
	end
end

function UIHPBar:CoinLevelIDChange(oldValue,newValue)
	-- body
	if(newValue > 0) then
		local resInfo = ResCoinLevelTable[newValue];
		self.txtLevel.text = tostring(resInfo.level);
		local subCoin = resInfo.up_coin - self.unit.unitAttr.coin;
		local preCoin = 0;
		if(resInfo.level > 1) then
			local preResInfo = ResCoinLevelTable[resInfo.id - 1];
			preCoin = preResInfo.up_coin;
		end
		local totalCoin = resInfo.up_coin - preCoin;
		if(totalCoin == 0) then
			self.score:UpdateProgress(1);
		else
			self.score:UpdateProgress(1 - subCoin * 1.0 / totalCoin);
		end
		
	else
		self.txtLevel.text = "1"; 
		self.score:UpdateProgress(0);
	end
	
end

function UIHPBar:ScaleChange(unit)
	local scale = unit.localScale / 1000.0;
	LuaHelper.SetLocalScale(self.trans,scale,scale,scale);
end

function UIHPBar:CheckAndAddFollower()
	if(self.unit ~= nil) then
		self.follower = GameObjectUtil.AddComponentOnce(self.go,typeof(UIFollower));
		local hangPoint = nil;
		if(self.unit.unitView.unitHangPoint ~= nil) then
			hangPoint = self.unit.unitView.unitHangPoint:GetTransform("Head")
		end
		if hangPoint == nil then
			hangPoint = self.unit.unitView.transform;
		end
		self.follower:SetTarget(ChaseCamera.instance.mainCamera,hangPoint,false,false);
		self.follower.enabled = self.isEnable;
	end
end

function UIHPBar:UpdateProgress()
	if(self.unit ~= nil) then
		local percent = self.unit.unitAttr.hp / self.unit.unitAttr.hpLmt;
		self.progress:UpdateProgress(percent);
	end
	-- body
end

function UIHPBar:Reset()
	LuaHelper.SetLocalScale(self.trans,1,1,1);
	if(self.unit ~= nil and self.onHpChange ~= nil and self.onScaleChange ~= nil) then
		self.unit.unitAttr.OnHpChange = self.unit.unitAttr.OnHpChange - self.onHpChange;
		self.unit.unitAttr.OnCoinChange = self.unit.unitAttr.OnCoinChange -self.onCoinchage;
		self.unit.unitAttr.OnCoinLevelIDChange = self.unit.unitAttr.OnCoinLevelIDChange - self.onCoinLevelIDChange;
		self.unit.OnScaleUpdate = self.unit.OnScaleUpdate - self.onScaleChange;
		self.unit = nil;
		self.onHpChange = nil;
		self.onScaleChange = nil;
		self.onCoinchage = nil;
		self.onCoinLevelIDChange = nil;
	end
	self.progress:UpdateProgress(0)
	self.showHP = false;
	if(self.follower ~= nil) then
		self.follower:Dispose();
		self.follower.enabled = false;
		self.follower = nil;
	end
end