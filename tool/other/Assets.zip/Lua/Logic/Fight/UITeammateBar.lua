UITeammateBar = class("UITeammateBar")
function UITeammateBar:Init(go)
	self.go = go;
	self.trans = self.go.transform;
	self.layoutElement = self.go:GetComponent(typeof(UnityEngine.UI.LayoutElement));
	self.progressGO = self.trans:Find("HpProgress/Progress").gameObject;
	self.progress = GameObjectUtil.AddComponentOnce(self.progressGO,typeof(UIProgress));
	self.iconHero = self.trans:Find("iconTeammate"):GetComponent(typeof(UnityEngine.UI.Image));
	self.iconHeroMask = self.trans:Find("iconTeammateMask"):GetComponent(typeof(UnityEngine.UI.Image));
	self.iconCaptain = self.trans:Find("imgCaptain"):GetComponent(typeof(UnityEngine.UI.Image));
	self.dieTime = 0;
    self.dieTotalTime = 0;
end

function UITeammateBar:SetUnit(unit)
	if(self.unit ~= nil and self.onHpChange ~= nil) then
		if(self.onHpChange ~= nil) then
			self.unit.unitAttr.OnHpChange = self.unit.unitAttr.OnHpChange - self.onHpChange;
			self.onHpChange = nil;
		end
		if(self.onUnitDie ~= nil) then
			self.unit.OnUnitDie = self.unit.OnUnitDie - self.onUnitDie;
			self.onUnitDie = nil;
		end
	end
	self.unit = unit;
	self.onHpChange = function (oldValue,newValue)
		self:HpChange(oldValue,newValue);
	end
	self.onUnitDie = function (unit)
		self.dieTotalTime = unit.totalDieTime / 1000.0;
        self.dieTime = self.dieTotalTime;
	end
	self.unit.unitAttr.OnHpChange = self.unit.unitAttr.OnHpChange + self.onHpChange;
	self.unit.OnUnitDie = self.unit.OnUnitDie + self.onUnitDie;
	 local resHero = HeroTable[self.unit.resId];
	self.iconHero.sprite = CResourceSys.instance:Load(EResType.EIcon,resHero.icon);
	self.iconHeroMask.enabled = false;
	self.iconCaptain.enabled = unit.isCaptain;
end

function UITeammateBar:Reset()
	if(self.unit ~= nil) then
		if(self.onHpChange ~= nil) then
			self.unit.unitAttr.OnHpChange = self.unit.unitAttr.OnHpChange - self.onHpChange;
			self.onHpChange = nil;
		end
		if(self.onUnitDie ~= nil) then
			self.unit.OnUnitDie = self.unit.OnUnitDie - self.onUnitDie;
			self.onUnitDie = nil;
		end
		self.unit = nil;
	end
end

function UITeammateBar:SetActive(active)
	-- body
	self.layoutElement.ignoreLayout = not active;
	self.go:SetActive(active);
end

function UITeammateBar:HpChange(oldValue,newValue)
	if(self.unit ~= nil) then
		local percent = self.unit.unitAttr.hp / self.unit.unitAttr.hpLmt;
		self.progress:UpdateProgress(percent);
	end
end

function UITeammateBar:OnUpdate(deltaTime)
	if(self.dieTime > 0) then
        self.iconHeroMask.enabled = true;
        self.iconHeroMask.fillAmount = (self.dieTime / self.dieTotalTime);
        self.dieTime = self.dieTime - deltaTime;
    else
        self.iconHeroMask.enabled = false;
    end
end