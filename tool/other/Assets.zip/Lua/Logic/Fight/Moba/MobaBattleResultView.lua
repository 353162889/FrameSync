require "Logic/Fight/Moba/MobaBattleResultItem"

MobaBattleResultView = class("MobaBattleResultView",MobaBattleResultViewUI)

function MobaBattleResultView:Init()
	-- body
	self.lstBlueItem = {};
	self.lstRedItem = {};
	local blueCount = self.blueParent.childCount;
	for i=0,blueCount - 1 do
		local child = self.blueParent:GetChild(i).gameObject;
		local item = MobaBattleResultItem.new();
		item:Init(child);
		table.insert(self.lstBlueItem,item);
	end

	local redCount = self.redParent.childCount;
	for i=0,redCount - 1 do
		local child = self.redParent:GetChild(i).gameObject;
		local item = MobaBattleResultItem.new();
		item:Init(child);
		table.insert(self.lstRedItem,item);
	end

	self.lstResultStatus = {self.imgWin,self.imgFail,self.imgDeuce};

	local onClickBack = function (go)
		FightManager.ExitToLobby();
	end
	EventTriggerListener.Get(self.btnBack.gameObject).onClick = EventTriggerListener.Get(self.btnBack.gameObject).onClick + onClickBack;

	self.startAnchoredPosX = self.startPosX.anchoredPosition.x;
	Util.LogColor("#ff0000","self.startAnchoredPosX",self.startAnchoredPosX )

end

function MobaBattleResultView:OpenView(param)
	-- body
	local achievement = param.objParam["achievement"];
	self:UpdateCampHeroInfo(ECamp.EBlue,self.lstBlueItem,achievement);
	self:UpdateCampHeroInfo(ECamp.ERed,self.lstRedItem,achievement);
	self:UpdateSelfInfo();
	for i=1,#self.lstRedItem do
		local pos = self.lstRedItem[i].transform.anchoredPosition;
		pos.x = self.startAnchoredPosX;
		self.lstRedItem[i].transform.anchoredPosition = pos;
	end
	for i=1,#self.lstBlueItem do
		local pos = self.lstBlueItem[i].transform.anchoredPosition;
		pos.x = self.startAnchoredPosX;
		self.lstBlueItem[i].transform.anchoredPosition = pos;
	end
	self.btnBack.gameObject:SetActive(false);

	self.sequence = DG.Tweening.DOTween.Sequence();
	local index = 0;
	for i=1,#self.lstRedItem do
		if(self.lstRedItem[i].go.activeSelf) then
			self.sequence:Insert(index * 0.2,self.lstRedItem[i].transform:DOAnchorPosX(0,0.3));
			index = index + 1;
		end
	end
	for i=1,#self.lstBlueItem do
		if(self.lstBlueItem[i].go.activeSelf) then
			self.sequence:Insert(index * 0.2,self.lstBlueItem[i].transform:DOAnchorPosX(0,0.3));
			index = index + 1;
		end
	end
	self.sequence:InsertCallback(index * 0.2,function ()
		self.btnBack.gameObject:SetActive(true);
		self.sequence = nil;
		Util.LogColor("#ff0000","sequence[End]")
	end)
end

function MobaBattleResultView:UpdateCampHeroInfo(camp,lstItem,extInfo)
	local battleCamp = BattleScene.instance:GetBattleCamp(camp);
	if(battleCamp == nil) then
		for i=1,#lstItem do
			lstItem[i]:Hide();
		end
		return;
	end
	local lstHero = battleCamp.mLstHero;
	local blueHeroCount = lstHero.Count;
	for i=1,#lstItem do
		if(i <= blueHeroCount) then
			local hero = lstHero[i-1];
			lstItem[i]:UpdateHeroInfo(hero,extInfo);
		else
			lstItem[i]:Hide();
		end
	end
end

function MobaBattleResultView:UpdateSelfInfo()
	local mainHero = BattleScene.instance.mainHero;
	local occupyComp = BattleInfo.coreGaming:GetSysComp(EGamingSysCompType.MobaOccupy);
	local blueOccupy = occupyComp.blueScore;
	local redOccupy = occupyComp.redScore;
	--输赢状态 1胜利，2失败,3平局
	local resultStatus;
	if(blueOccupy == redOccupy) then
		resultStatus = 3;
	elseif(blueOccupy > redOccupy) then
		if(mainHero.camp == ECamp.EBlue) then
			resultStatus = 1;
		else
			resultStatus = 2;
		end
	else
		if(mainHero.camp == ECamp.EBlue) then
			resultStatus = 2;
		else
			resultStatus = 1;
		end
	end
	for i=1,#self.lstResultStatus do
		self.lstResultStatus[i]:SetActive(false);
	end
	if(resultStatus <= #self.lstResultStatus) then
		self.lstResultStatus[resultStatus]:SetActive(true);
	end

	--个人的击杀与死亡数
	local statisticsComp = BattleInfo.coreGaming:GetSysComp(EGamingSysCompType.Statistics);
	local statistics = statisticsComp:GetStatisticsData(mainHero.id);
	local killCount = statistics.kill;
	local dieCount = statistics.die;
	self.txtSelfKill.text = tostring(killCount);
	self.txtSelfDie.text = tostring(dieCount);
end

function MobaBattleResultView:CloseView()
	-- body
	if(self.sequence ~= nil) then
		self.sequence:Kill(true);
		self.sequence = nil;
	end
end

function MobaBattleResultView:DestroyView()
	for i=1,#self.lstBuleItem do
		self.lstBuleItem[i]:Dispose();
	end
	for i=1,#self.lstRedItem do
		self.lstRedItem[i]:Dispose();
	end
	self.lstBuleItem = {}
	self.lstRedItem = {}
end
