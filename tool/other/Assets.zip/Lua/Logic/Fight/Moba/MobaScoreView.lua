﻿
MobaScoreView = class(MobaScoreView)

local this
function MobaScoreView:InitView(go)
    this = self
	self.go = go
	self.transform = self.go.transform
	self.txt_remainingTime = self.transform:Find("CampIconBg/txt_remainingTime"):GetComponent("Text")
	self.slider_occupyBlue = self.transform:Find("ScoreSliderContainer/slider_occupyBlue"):GetComponent("Slider")
	self.slider_occupyRed = self.transform:Find("ScoreSliderContainer/slider_occupyRed"):GetComponent("Slider")
	self.txt_blueOccupy = self.transform:Find("ScoreSliderContainer/slider_occupyBlue/txt_blueOccupy"):GetComponent("Text")
	self.txt_redOccupy = self.transform:Find("ScoreSliderContainer/slider_occupyRed/txt_redOccupy"):GetComponent("Text")
	self.blueEffectParent = self.slider_occupyBlue.transform:Find("FillArea/Fill/blueEffectParent")
    self.redEffectParent = self.slider_occupyRed.transform:Find("FillArea/Fill/redEffectParent")
    self.blueTailEffect = self.slider_occupyBlue.transform:Find("FillArea/Fill/blueTailEffect").gameObject
    self.redTailEffect = self.slider_occupyRed.transform:Find("FillArea/Fill/redTailEffect").gameObject
    self.img_blueWin = self.transform:Find("ScoreSliderContainer/slider_occupyBlue/img_blueWin").gameObject
    self.img_redWin = self.transform:Find("ScoreSliderContainer/slider_occupyRed/img_redWin").gameObject
    self.blueEndEffect = false
    self.redEndEffect = false
    print("MobaScoreView.InitView")

end

function MobaScoreView:OpenView()
    self.img_blueWin:SetActive(false)
    self.img_redWin:SetActive(false)

    self:RefreshSocreProgress()
    self:RefreshCircleStatus()
    EventSys.instance:AddEvent(EEventType.OnOccupyScoreChange,self.RefreshSocreProgress)
	EventSys.instance:AddEvent(EEventType.OnOccupyPercentChange, self.RefreshFlagStatus)
	EventSys.instance:AddEvent(EEventType.OnOccupyStatusChange, self.OnStatusChange)
    Main.AddUpdateFun(this.RefreshRemainingTime, this, {interval = 1, callAtOnce = true})
end

function MobaScoreView:CloseView()
    EventSys.instance:RemoveEvent(EEventType.OnOccupyScoreChange,self.RefreshSocreProgress);    
    EventSys.instance:RemoveEvent(EEventType.OnOccupyPercentChange,self.RefreshFlagStatus);    
    EventSys.instance:RemoveEvent(EEventType.OnOccupyStatusChange,self.OnStatusChange);    
    Main.RemoveUpdateFun(this.RefreshRemainingTime)
end

function MobaScoreView:RefreshCircleStatus()
    local mobaGamingOccupy = BattleInfo.coreGaming:GetSysComp(EGamingSysCompType.MobaOccupy);
    local battleAreaList = mobaGamingOccupy.battleAreaList
    for i = 0,battleAreaList.Count - 1 do
        local area = battleAreaList[i]
        local view = area.cView
        local curStatus = area.curStatus
        if view then
            local whiteEffect = view.transform:Find("eff_quan_white").gameObject
            local blueEffect = view.transform:Find("eff_quan_blue").gameObject
            local redEffect = view.transform:Find("eff_quan_red").gameObject
            whiteEffect:SetActive(false)
            blueEffect:SetActive(false)
            redEffect:SetActive(false)
    
            if curStatus == OccupyStatus.Blue then
                blueEffect:SetActive(true)
            elseif curStatus == OccupyStatus.Red then
                redEffect:SetActive(true)
            else
                whiteEffect:SetActive(true)
            end
        end
    end
end

--旗子状态变化
function MobaScoreView:OnStatusChange(args)
    -- print("旗子状态改变")
    local view = args[0]
    local curStatus = args[1]
    if view then
        local whiteEffect = view.transform:Find("eff_quan_white").gameObject
        local blueEffect = view.transform:Find("eff_quan_blue").gameObject
        local redEffect = view.transform:Find("eff_quan_red").gameObject
        whiteEffect:SetActive(false)
        blueEffect:SetActive(false)
        redEffect:SetActive(false)

        if curStatus == OccupyStatus.Blue then
            blueEffect:SetActive(true)
            EffectManager.instance:Create("eff_public_flag02_blue",true,view.transform);
        elseif curStatus == OccupyStatus.Red then
            redEffect:SetActive(true)
            EffectManager.instance:Create("eff_public_flag02_red",true,view.transform);
        else
            whiteEffect:SetActive(true)
        end

    end
end

--刷新旗子进度状态
function MobaScoreView:RefreshFlagStatus(args)
    -- print(MBBattleArea.maxOccupyPrecent)
    -- print("刷新旗子进度")
    local mobaGamingOccupy = BattleInfo.coreGaming:GetSysComp(EGamingSysCompType.MobaOccupy);

    local blueNum = mobaGamingOccupy:GetAreaNumByType(OccupyStatus.Blue)
    local redNum = mobaGamingOccupy:GetAreaNumByType(OccupyStatus.Red)

    local showTailEffectNum = 4

    if blueNum >= showTailEffectNum then
        this.blueTailEffect:SetActive(true)
    else
        this.blueTailEffect:SetActive(false)
    end

    if redNum >= showTailEffectNum then
        this.redTailEffect:SetActive(true)
    else
        this.redTailEffect:SetActive(false)
    end

    local view = args[0]
    if view then
        local bluePrecent = args[1]
        local curStatus = args[2]
        local blueCount = args[3]
        local redCount = args[4]

        local blueEffect = view.transform:Find("eff_public_flag01_blue").gameObject
        local redEffect = view.transform:Find("eff_public_flag01_red").gameObject
       
        if bluePrecent == MBBattleArea.maxOccupyPrecent or bluePrecent == 0 or blueCount == redCount then
            --属于某一方  没有燃烧特效
            blueEffect:SetActive(false)
            redEffect:SetActive(false)
        elseif bluePrecent == MBBattleArea.maxOccupyPrecent/2 and curStatus == OccupyStatus.None and blueCount == 0 and redCount == 0 then
            --初始完全中立  没有特效
            blueEffect:SetActive(false)
            redEffect:SetActive(false)
        else
            if curStatus == OccupyStatus.Blue then
                if blueCount > redCount then
                    blueEffect:SetActive(true)
                    redEffect:SetActive(false)
                end
            elseif curStatus == OccupyStatus.Red then
                if redCount > blueCount then
                    redEffect:SetActive(true)
                    blueEffect:SetActive(false)
                end
            else
                if blueCount > redCount then
                    blueEffect:SetActive(true)
                    redEffect:SetActive(false)
                else
                    redEffect:SetActive(true)
                    blueEffect:SetActive(false)
                end
            end
        end

       

        local flagMesh = view.transform:Find("Plane"):GetComponent("MeshRenderer")
        
        local halfMaxOccupyPrecent = MBBattleArea.maxOccupyPrecent / 2
        bluePrecent = bluePrecent - halfMaxOccupyPrecent
        local rate = -(bluePrecent/halfMaxOccupyPrecent)
        flagMesh.material:DOFloat(rate, "_amount", 0.1)
        -- flagMesh.material:SetFloat("_amount", rate)
    end
end

--刷新剩余时间
function MobaScoreView:RefreshRemainingTime()
    if BattleInfo.coreGaming then
        this.txt_remainingTime.text= TimeHelper.GetFormatTime(BattleInfo.coreGaming.leaveGameTime);
    end
end

function MobaScoreView:RefreshSocreProgress()
    local mobaGamingOccupy = BattleInfo.coreGaming:GetSysComp(EGamingSysCompType.MobaOccupy);
    if not mobaGamingOccupy then
        error("mobaGamingOccupy 组件不存在")
        return
    end

    local time = 0.1
	local blueScore = mobaGamingOccupy.blueScore;
    local redScore = mobaGamingOccupy.redScore;
    this.slider_occupyBlue:DOValue(blueScore,time)
    this.slider_occupyRed:DOValue(redScore,time)
	this.txt_blueOccupy.text = blueScore.."分"
    this.txt_redOccupy.text = redScore.."分"

    if blueScore == mobaGamingOccupy.maxOccupySocre then
        EffectManager.instance:Create("eff_ui_jdb_blue", true, this.blueEffectParent)
        this.img_blueWin:SetActive(true)
    end
    
    if redScore == mobaGamingOccupy.maxOccupySocre then
        EffectManager.instance:Create("eff_ui_jdb_red", true, this.redEffectParent)
        this.img_redWin:SetActive(true)
    end
    
end

function MobaScoreView:DestroyView()

end

function MobaScoreView:RegeditEvent()

end