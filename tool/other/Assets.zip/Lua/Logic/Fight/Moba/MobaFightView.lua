
require "Logic/Fight/EffectBarView"
require "Logic/Fight/Moba/MobaMapView"
require "Logic/Fight/ScreenEffectView"
require "Logic/Fight/TeamBarView"
require "Logic/Fight/OperateView"
require "Logic/Fight/KillView"
require "Logic/Fight/LockBarView"
require "Logic/Fight/Moba/MobaScoreView"
MobaFightView = class("MobaFightView", MobaFightViewUI);
local _this;

function MobaFightView:Init()
    _this = self;
    if(self.ani_skillIcon~=nil)then
        self.ani_skillIconObj:SetActive(false);
        self.ani_skillIcon:GetComponent("AnimationEventHelper").PlayEndCallBack=function()
            MobaFightView.OnSkillReplaceOver();
        end
    end
    self.operateView = OperateView.new();
    self.operateView:InitView(self.operateBars);
    self.killView = KillView.new();
    self.killView:InitView(self.killBars);
    self.effectBarView = EffectBarView.new();
    self.effectBarView:InitView(self.effectBars,self.operateView.skillBtn1.transform.position,self.operateView.skillBtn2.transform.position,self.operateView.skillBtn3.transform.position);
    self.mapView = MobaMapView.new();
    self.mapView:InitView(self.map);
    self.screenEffectView = ScreenEffectView.new();
    self.screenEffectView:InitView(self.screenEffect);
    self.teamBarView = TeamBarView.new();
    self.teamBarView:InitView(self.team);
    self.lockView = LockBarView.new();
    self.lockView:InitView(self.lockBars);
    self.mobaScoreView = MobaScoreView.new()
    self.mobaScoreView:InitView(self.mobaSocreContainer)

    self.dieTime = 0;
    self.dieTotalTime = 0;
    self.dynamicTxtCoinCount = GameObjectUtil.AddComponentOnce(self.txtCoinCount.gameObject,typeof(DynamicNumber));
    
    EventButtonListerer.Get(self.btn_openBattleInfo, self.OpenBattleInfo)
    VoiceHelper:Init(self.objVoice:GetComponent("VoiceCtrlUI"));
end

function MobaFightView:OpenView(param)
    self.coreGamingSys = BattleInfo.coreGaming;
    self.mobaGamingOccupy = self.coreGamingSys:GetSysComp(EGamingSysCompType.MobaOccupy);
    Main.AddUpdateFun(MobaFightView.Update, self);
    self.effectBarView:OpenView(param);
    self.mapView:OpenView(param);
    self.screenEffectView:OpenView(param);
    self.teamBarView:OpenView(param);
    self.operateView:OpenView(param);
    self.killView:OpenView(param);
    self.lockView:OpenView(param);
    self.mobaScoreView:OpenView()

    self.coinChange = function (oldValue,newValue)
         self.dynamicTxtCoinCount:SetNumberAtStart(oldValue,newValue,1);
    end
    self.mainHeroUpdate = function (eventId,obj)
        self:OnMainHeroUpdate();
    end
    EventSys.instance:AddEvent(EEventType.OnMainHeroUpdate, self.mainHeroUpdate);

    self.onUnitRevive = function (eventId,unit)
        if(self.mainHero ~= nil and unit.id == self.mainHero.id) then
            self:OnMainHeroRevive();
        end
    end
    EventSys.instance:AddEvent(EEventType.OnUnitRevive,self.onUnitRevive);

    self.onUnitDie = function (eventId,damageInfo)
        if(damageInfo ~= nil and self.mainHero ~= nil) then
            local resInfo = nil;
            --区分英雄和小兵（野怪）
            if(damageInfo.defence.unitType == EUnitType.EHero) then
                resInfo = HeroTable[damageInfo.defence.resId];
            else
                resInfo = SoldierTable[damageInfo.defence.resId];
            end
            if(damageInfo.defence.id == self.mainHero.id) then
                AudioSys.instance:PlayByTrans(resInfo.die_audio,AudioSys.instance.AudioListenerObj.transform);
                self:OnMainHeroDie(damageInfo);
            else
                AudioSys.instance:PlayByPosLmt(resInfo.die_audio,self.mainHero.unitView.transform.position, damageInfo.defence.unitView.transform.position);
            end
            -- if(damageInfo.attack ~= nil and damageInfo.attack.id == self.mainHero.id) then
            --     EffectManager.instance:Create(EffectDefine.KillGetCoin,true,self.iconSelfHeroEffect);
            -- end
        end
    end
    EventSys.instance:AddEvent(EEventType.OnUnitDie,self.onUnitDie);

    

    if(BattleScene.instance.mainHero ~= nil) then
        self:OnMainHeroUpdate();
        BattleScene.instance.mainHero.unitAttack.OnSkillCDStateUpdate =  BattleScene.instance.mainHero.unitAttack.OnSkillCDStateUpdate+MobaFightView.CDEnd;
    end

    self.onGameEnd = function (eventId,obj)
        local param = ViewParam();
        param.objParam = {};
        param.objParam["gameEndType"] = obj;
        self:OnGameEnd(param);
    end
    EventSys.instance:AddEvent(EEventType.OnBattleEnd,self.onGameEnd);
    self.isGameEnd = false;

    self.battleChannel = NetSys.instance:GetChannel(EChannelType.EPvpChannel);

    VoiceHelper:Refresh(self.objVoice:GetComponent("VoiceCtrlUI"));
    EventSys.instance:AddEvent(EEventType.OnSkillReplace, MobaFightView.OnReceiveSkillReplace);
end

function MobaFightView:OpenBattleInfo()
    -- ViewSys.instance:Open("PlayerRankView")
    ViewSys.instance:Open("MobaBattleInfoView")
end

function MobaFightView:OnGameEnd(param)
    self.isGameEnd = true;
    local time = ConstTable["game_end_time_scale_time"].p_int / 1000.0;
    local scale = ConstTable["game_end_time_scale"].p_int / 1000.0;
    self.deltaEndTime = time * scale;
    LuaHelper.SetTimeScale(scale);
    self.gameEndParam = param;
end

function MobaFightView:CloseView()
    self.isGameEnd = false;
    LuaHelper.SetTimeScale(1);
    Main.RemoveUpdateFun(MobaFightView.Update);
    self.effectBarView:CloseView();
    self.mapView:CloseView();
    self.screenEffectView:CloseView();
    self.teamBarView:CloseView();
    self.operateView:CloseView();
    self.killView:CloseView();
    self.lockView:CloseView();
    self.mobaScoreView:CloseView()
    ViewSys.instance:Close("MobaBattleInfoView")
    if(self.mainHeroUpdate ~= nil) then
         EventSys.instance:RemoveEvent(EEventType.OnMainHeroUpdate, self.mainHeroUpdate);
         self.mainHeroUpdate = nil;
    end

     if(self.onUnitRevive ~= nil) then
        EventSys.instance:RemoveEvent(EEventType.OnUnitRevive,self.onUnitRevive);
        self.onUnitRevive = nil;
    end

     if(self.onUnitDie ~= nil) then
        EventSys.instance:RemoveEvent(EEventType.OnUnitDie,self.onUnitDie);
        self.onUnitDie = nil;
    end

    if(self.onBlueOccupyChange ~= nil) then
    	EventSys.instance:RemoveEvent(EEventType.OnOccupyScoreChange,self.onBlueOccupyChange);    
    	self.onBlueOccupyChange = nil;
    end

    if(self.onGameEnd ~= nil) then
        EventSys.instance:RemoveEvent(EEventType.OnBattleEnd,self.onGameEnd);
        self.onGameEnd = nil;
    end

    self:ResetMainHero();
    self.coinChange = nil;
    EventSys.instance:RemoveEvent(EEventType.OnSkillReplace, MobaFightView.OnReceiveSkillReplace);
    BattleScene.instance.mainHero.unitAttack.OnSkillCDStateUpdate =  BattleScene.instance.mainHero.unitAttack.OnSkillCDStateUpdate-MobaFightView.CDEnd;
end

function MobaFightView:Update(deltaTime)
    if(self.isGameEnd) then
        self.deltaEndTime = self.deltaEndTime - deltaTime;
        if(self.deltaEndTime < 0) then
            self.isGameEnd = false;
            LuaHelper.SetTimeScale(1);
            FightManager.ShowMobaBattleResult(self.gameEndParam);
        end
    end
   
    self.teamBarView:OnUpdate(deltaTime);
    self.operateView:OnUpdate(deltaTime);
    self.killView:OnUpdate(deltaTime);
    
    local nFpsValue = CGameRoot.instance.realFPS;
    local nPingValue = self.battleChannel.ping;
    self.fpsValue.text = string.format("%d", nFpsValue);
    self.pingValue.text = string.format("%d",nPingValue);
    if(self.dieTime > 0) then
        self.iconSelfHeroMask.enabled = true;
        self.iconSelfHeroMask.fillAmount = (self.dieTime / self.dieTotalTime);
        self.dieTime = self.dieTime - deltaTime;
    else
        self.iconSelfHeroMask.enabled = false;
    end
end

function MobaFightView:DestroyView()
     self.effectBarView:DestroyView();
     self.mapView:DestroyView();
     self.screenEffectView:DestroyView();
     self.teamBarView:DestroyView();
     self.operateView:DestroyView();
     self.killView:DestroyView();
     self.lockView:DestroyView();
     Main.RemoveUpdateFun(FightView.Update, self);
end

function MobaFightView:OnBlueOccupyChange()
    local time = 0.1
	local blueScore = self.mobaGamingOccupy.blueScore;
    local redScore = self.mobaGamingOccupy.redScore;
    self.slider_occupyBlue:DOValue(blueScore,time)
    self.slider_occupyRed:DOValue(redScore,time)
	self.txtBlueOccupy.text = blueScore.."分"
    self.txtRedOccupy.text = redScore.."分"

    EffectManager.instance:Create("eff_ui_jdb_blue", true, self.blueEffectParent)
    -- EffectManager.instance:Create("eff_ui_jdb_red", true, self.redEffectParent)
end

function MobaFightView:OnMainHeroDie(damageInfo)
    if(self.mainHero.unitAttr.coin > 0) then
        self.dieTotalTime = self.mainHero.totalDieTime / 1000.0;
        self.dieTime = self.dieTotalTime;
        if(damageInfo ~= nil and damageInfo.attack ~= nil) then
            ChaseCamera.instance:SetFllower(damageInfo.attack, 1);
            ChaseCamera.instance:SetOrthoSize(ChaseCamera.instance.cameraOrthoSize + 5, 1);
        end
        -- if(damageInfo ~= nil and damageInfo.attack ~= nil) then
        --     EffectManager.instance:Create(EffectDefine.DieLostCoin,true,self.iconEnemyHeroEffect);
        -- end
    end
end

function MobaFightView:OnMainHeroRevive()
     ChaseCamera.instance:SetFllower(self.mainHero, 1);
     ChaseCamera.instance:SetOrthoSize(ChaseCamera.instance.cameraOrthoSize, 1);
end

function MobaFightView:OnMainHeroUpdate()
    self:ResetMainHero();
    self.mainHero = BattleScene.instance.mainHero;
    if(self.mainHero ~= nil) then
        self.iconSelfHero.sprite = CResourceSys.instance:Load(EResType.EIcon,HeroTable[self.mainHero.resId].icon);
        self.mainHero.unitAttr.OnCoinChange = self.mainHero.unitAttr.OnCoinChange + self.coinChange;
        self.txtCoinCount.text = tostring(self.mainHero.unitAttr.coin);
    end
end

function MobaFightView:ResetMainHero()
    if(self.mainHero ~= nil) then
        self.mainHero.unitAttr.OnCoinChange = self.mainHero.unitAttr.OnCoinChange - self.coinChange;
    end
    self.mainHero = nil;
end


function MobaFightView.OnReceiveSkillReplace(eventId, obj)
    print("技能改变"..obj);
    local strs =  Util.Split( obj,"|" )
    local mainHero = BattleScene.instance.mainHero;
    local skill = mainHero.unitAttack:GetActiveSkillByIdx(strs[1]);
    local cdTime = math.ceil((skill.cdEndTime - FrameSyncSys.time) / 1000)
    if(strs[1] =="0")then 
        _this.ani_skillIconObj.transform.position = _this.skillBtn1.transform.position;
        if(cdTime==0)then
            MobaFightView.RotateSkill_1(false)
        else
            _this.skillIcon1.transform.localEulerAngles = Vector3(0,0,-30);
        end
    end
    if(strs[1] =="1")then 
        _this.ani_skillIconObj.transform.position = _this.skillBtn2.transform.position;
        if(cdTime==0)then
            MobaFightView.RotateSkill_2(false)
        else
            _this.skillIcon2.transform.localEulerAngles = Vector3(0,0,-30);
        end
    end
    _this.ani_skillIcon.sprite = CResourceSys.instance:Load(EResType.EIcon,"Skill/"..strs[2]..".png");
    _this.ani_skillIconObj.gameObject:SetActive(true);

end

function MobaFightView.CDEnd(skill)
    print("技能CD结束");
    print(skill.id);
    print(BattleScene.instance.mainHero.unitAttack:GetActiveSkillByIdx(0).id);
    local mainHero = BattleScene.instance.mainHero;
    local cdTime = math.ceil((skill.cdEndTime - FrameSyncSys.time) / 1000)
    print(tostring(cdTime));
    if(skill.id ==mainHero.unitAttack:GetActiveSkillByIdx(0).id)then 
        if(cdTime==0)then 
            print("技能CD结束32222");
            MobaFightView.RotateSkill_1(true);
        end
    end
    if(skill.id == BattleScene.instance.mainHero.unitAttack:GetActiveSkillByIdx(1).id)then 
        if(cdTime==0)then
            print("技能CD结束123123"); 
            MobaFightView.RotateSkill_2(true);
        end
    end
end

function MobaFightView.RotateSkill_1(isRotate)
    if(isRotate==false)then 
        _this.skillIcon1.transform.localEulerAngles = Vector3(0,0,-30);
    end
    local tween = _this.skillIcon1.transform:DORotate(Vector3.zero,0.3);
    tween:OnComplete(function()
        print("转动结束");
    end)
end

function MobaFightView.RotateSkill_2(isRotate)
    if(isRotate==false)then 
        _this.skillIcon2.transform.localEulerAngles = Vector3(0,0,-30);
    end
    local tween = _this.skillIcon2.transform:DORotate(Vector3.zero,0.3);
    tween:OnComplete(function()
        print("转动结束");
    end)
end


function MobaFightView.OnSkillReplaceOver()
    print("技能替换动画播放结束")
    _this.ani_skillIconObj.gameObject:SetActive(false);
end