require "Logic/Fight/UIMapItem"
MobaMapView = class("MobaMapView")

function MobaMapView:InitView(go)
	self.go = go;
	self.template = self.go.transform:Find("Template").gameObject;
	self.template:SetActive(false);
	LuaHelper.SetLocalPos(self.template,100000,0,0);
	self.lstMapItem = {};
	self.lstPool = {};
	self.mainHeroId = -1;
end

function MobaMapView:OpenView(param)
	self.resSession = SessionTable[BattleInfo.sessionId];
	--主玩家
	 self.mainHeroUpdate = function (eventId,obj)
        self:UpdateMainHeroItem();
    end
    EventSys.instance:AddEvent(EEventType.OnMainHeroUpdate, self.mainHeroUpdate);

     self.unitRemove = function (eventId,unit)
     	self:DestroyMapItem(unit.id,MapItemType.Hero);
    end
    EventSys.instance:AddEvent(EEventType.OnUnitRemove,self.unitRemove);

	--队伍变更
	self.unitTeamChange = function (eventId,unit)
		self:UpdateTeamHeroItem(unit);
	end
	EventSys.instance:AddEvent(EEventType.OnUnitTeamChange, self.unitTeamChange);

	self.unitUpdateBattleArea = function (eventId,unit)
		self:UpdateBattleAreaHeroItem(unit);
	end
	EventSys.instance:AddEvent(EEventType.OnUnitJoinBattleArea, self.unitUpdateBattleArea);
	EventSys.instance:AddEvent(EEventType.OnUnitLeaveBattleArea, self.unitUpdateBattleArea);
	
	if(BattleScene.instance.mainHero ~= nil) then
        self:UpdateMainHeroItem();

        local mainHero = BattleScene.instance.mainHero;
        if(mainHero.hasTeam) then
	        local lst = BattleScene.instance.lstHero;
			local count = lst.Count;
			for i=0,count - 1 do
				local unit = lst[i];
				if(mainHero.teamId == unit.teamId) then
					self:UpdateTeamHeroItem(unit);
				else
					self:UpdateBattleAreaHeroItem(unit);
				end
			end
		end
    end
end

function MobaMapView:CloseView()
	-- body
	if(self.mainHeroUpdate ~= nil) then
         EventSys.instance:RemoveEvent(EEventType.OnMainHeroUpdate, self.mainHeroUpdate);
         self.mainHeroUpdate = nil;
    end

    if(self.unitRemove ~= nil) then
         EventSys.instance:RemoveEvent(EEventType.OnUnitRemove, self.unitRemove);
         self.unitRemove = nil;
    end

	if(self.unitTeamChange ~= nil) then
		EventSys.instance:RemoveEvent(EEventType.OnUnitTeamChange, self.unitTeamChange);
		self.unitTeamChange = nil;
	end

	if(self.unitUpdateBattleArea ~= nil) then
		EventSys.instance:RemoveEvent(EEventType.OnUnitJoinBattleArea, self.unitUpdateBattleArea);
		EventSys.instance:RemoveEvent(EEventType.OnUnitLeaveBattleArea, self.unitUpdateBattleArea);
		self.unitUpdateBattleArea = nil;
	end

	self.mainHeroId = -1;
	self.mainHero = nil;

	for i=1,#self.lstMapItem do
		self:DisposeItem(self.lstMapItem[i]);
	end
	self.lstMapItem = {};
end

function MobaMapView:DestroyView()
	-- body
end

function MobaMapView:UpdateMainHeroItem()
	self:DestroyMapItem(self.mainHeroId,MapItemType.Hero);
	self.mainHeroId = -1;
	self.mainHero = nil;
	local hero = BattleScene.instance.mainHero;
	if(hero ~= nil) then
		self.mainHeroId = hero.id;
		self.mainHero = hero;
		local item = self:GetItem();
		local heroKey = MapHeroKey.MainHero;
		if(hero.isCaptain) then
			heroKey = MapHeroKey.Captain;
		end
		item:SetFollow(self.mainHeroId,MapItemType.Hero,heroKey,hero.unitView.transform);
		table.insert(self.lstMapItem,item);
	end
end

function MobaMapView:UpdateBattleAreaHeroItem(unit)
	local hero = BattleScene.instance.mainHero;
	if(hero ~= nil and hero.teamId ~= unit.teamId) then

		-- local isInBattleArea = BattleScene.instance:InMobaBattleArea(unit)
		-- print("isInBattleArea : ")
		-- print(isInBattleArea)

		if(BattleScene.instance:InMobaBattleArea(unit)) then
			local item = self:GetItem();
			local keyType = MapHeroKey.Enemy;
			item:SetFollow(unit.id,MapItemType.Hero,keyType,unit.unitView.transform);
			table.insert(self.lstMapItem,item);
		else
			self:DestroyMapItem(unit.id,MapItemType.Hero);
		end
	end
end

function MobaMapView:UpdateTeamHeroItem(unit)
	if(not self.mainHero.hasTeam) then return end;
	if(unit.id == self.mainHeroId) then
		for i=#self.lstMapItem,1,-1 do
			if(self.lstMapItem[i].id ~= unit.id and self.lstMapItem[i].itemType == MapItemType.Hero) then
				local item = self.lstMapItem[i];
				table.remove(self.lstMapItem,i);
				self:DisposeItem(item);
			end
		end
		local battleTeam = BattleScene.instance:GetBattleTeam(unit.teamId);
		local teamCount = battleTeam.teamCount
		for i=0,teamCount - 1 do
			local teammate = battleTeam.lstTeam[i];
			if(teammate.id ~= unit.id) then
				local item = self:GetItem();
				local heroKey = MapHeroKey.Teammate;
				if(teammate.isCaptain) then
					heroKey = MapHeroKey.Captain;
				end
				item:SetFollow(teammate.id,MapItemType.Hero,heroKey,teammate.unitView.transform);
				table.insert(self.lstMapItem,item);
			end
		end
		self:UpdateMainHeroItem();
	else
		self:DestroyMapItem(unit.id,MapItemType.Hero);
		if(self.mainHero.teamId == unit.teamId) then
			local item = self:GetItem();
			local keyType = MapHeroKey.Teammate;
			if(unit.isCaptain) then
				keyType = MapHeroKey.Captain;
			end
			item:SetFollow(unit.id,MapItemType.Hero,keyType,unit.unitView.transform);
			table.insert(self.lstMapItem,item);
		end
	end
end

function MobaMapView:GetItem()
	if(#self.lstPool > 0) then
		local item = self.lstPool[1];
		table.remove(self.lstPool,1)
		return item;
	else
		local go = UnityEngine.GameObject.Instantiate(self.template);
		go:SetActive(true);
		GameObjectUtil.AddChild(self.template.transform.parent.gameObject,go)
     	--go.transform:SetParent(self.template.transform.parent);
     	local item = UIMapItem.new();
     	item:Init(go);
     	LuaHelper.SetLocalPos(go,100000,0,0);
     	return item;
	end
end

function MobaMapView:DestroyMapItem(id,itemType)
	for i=#self.lstMapItem,1,-1 do
		if(self.lstMapItem[i].id == id and self.lstMapItem[i].itemType == itemType) then
			local item = self.lstMapItem[i];
			table.remove(self.lstMapItem,i);
			self:DisposeItem(item);
			break;
		end
	end
end

function MobaMapView:DisposeItem(item)
	item:Reset();
	LuaHelper.SetLocalPos(item.go,100000,0,0);
	table.insert(self.lstPool,item);
end