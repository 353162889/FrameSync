MobaBattleResultItem = class("MobaBattleResultItem")
function MobaBattleResultItem:Init(go)
	self.go = go;
	self.transform = self.go.transform;
	self.imgIcon = self.transform:Find("imgIcon"):GetComponent("Image");
	self.txtName = self.transform:Find("txtName"):GetComponent("Text");
	self.txtKill = self.transform:Find("txtKill"):GetComponent("Text");
	self.txtDie = self.transform:Find("txtDie"):GetComponent("Text");
	self.txtOccupyTime = self.transform:Find("txtOccupyTime"):GetComponent("Text");
	self.txtCoin = self.transform:Find("txtCoin"):GetComponent("Text");
	self.goKD = self.transform:Find("imgKD").gameObject;
	self.goMVP = self.transform:Find("imgMVP").gameObject;
	self.goACE = self.transform:Find("imgACE").gameObject;
	self.goSelf = self.transform:Find("imgSelf").gameObject;
end

--extInfo {"aceUserId"=userId,"kdUserId"=userId,"mvpUserId"=userId}
function MobaBattleResultItem:UpdateHeroInfo(hero,extInfo)
	-- body
	if(not self.go.activeSelf) then
		self.go:SetActive(true);
	end
	local statisticsComp = BattleInfo.coreGaming:GetSysComp(EGamingSysCompType.Statistics);
	local statistics = statisticsComp:GetStatisticsData(hero.id);
	if(statistics == nil) then return end
	local resHero = HeroTable[hero.resId];
	self.imgIcon.sprite = CResourceSys.instance:Load(EResType.EIcon,resHero.icon);
	self.txtName.text = hero.name;
	self.txtKill.text = tostring(statistics.kill);
	self.txtDie.text = tostring(statistics.die);

	local occupyTime = statistics.occupyTime / 1000.0;
	local min = math.floor(occupyTime / 60);
	local second = math.ceil(occupyTime % 60);
	if(min < 10) then min = "0"..min; end
	if(second < 10) then second = "0"..second;end;
	self.txtOccupyTime.text = tostring(min).."''"..tostring(second);

	-- self.txtOccupyTime.text = tostring(statistics.occupyTime);
	self.txtCoin.text = tostring(hero.unitAttr.coin);
	local heroUserId = tostring(hero.userId);
	self.goKD:SetActive(extInfo["kdUserId"] == heroUserId);
	self.goMVP:SetActive(extInfo["mvpUserId"] == heroUserId);
	self.goACE:SetActive(extInfo["aceUserId"] == heroUserId);
	self.goSelf:SetActive(hero == BattleScene.instance.mainHero);
end

function MobaBattleResultItem:Hide()
	self.go:SetActive(false);
end

function MobaBattleResultItem:Dispose()
	self.go = nil;
	self.transform = nil;
end