--管理战斗部分的一些逻辑与数据
FightManager = {}
--是否有历史帧数据
FightManager.hasHistoryFrameData = false;
--是否已经创建主英雄
FightManager.hasCreateMainHero = false;
--战斗结算界面参数
FightManager.battleResultParam = nil;
--服务器是否已计算完毕
FightManager.battleOver = false;
--战斗结算奖励界面参数
FightManager.battleResultBornParam = nil;
FightManager.achievementParam = nil;

function FightManager.Init()
	EventSys.instance:AddEvent(EEventType.EReconnect,FightManager.OnReconnect);	
	--后端发送的战斗结算完毕协议(大乱斗)
	NetSys.instance:AddMsgCallback(EChannelType.EWorldChannel, S2C_GameOver, FightManager.S2C_GameOverData, nil);
	--Moba玩法战斗结算
	NetSys.instance:AddMsgCallback(EChannelType.EWorldChannel, S2C_TeamGameOver, FightManager.S2C_TeamGameOverData, nil);

end

function FightManager.ClearData()
	FightManager.hasHistoryFrameData = false;
	FightManager.hasCreateMainHero = false;
	FightManager.battleResultParam = nil;
	FightManager.battleOver = false;
	FightManager.battleResultBornParam = nil;
	FightManager.achievementParam = nil;
end

function FightManager.OpenFightView(gameType)
	if(gameType == EStateType.CoreGaming) then
		ViewSys.instance:Open("FightBarView");
		ViewSys.instance:Open("FightView");
	elseif(gameType == EStateType.MobaGaming) then
		ViewSys.instance:Open("FightBarView");
		ViewSys.instance:Open("MobaFightView");
	end
end

function FightManager.CloseFightView(gameType)
	if(gameType == EStateType.CoreGaming) then
		ViewSys.instance:Close("FightBarView");
		ViewSys.instance:Close("FightView");
	elseif(gameType == EStateType.MobaGaming) then
		ViewSys.instance:Close("FightBarView");
		ViewSys.instance:Close("MobaFightView");
	end
end

---------------显示大乱斗界面开始-------------
function FightManager.ShowBattleResult(param)
	FightManager.battleResultParam = param;
	FightManager.CloseFightView(BattleInfo.gameType);
	if(param.objParam["gameEndType"] == GameEndType.ENormal) then
		FightManager.CheckShowBattleResult()
	else
		ViewSys.instance:Open("BattleResultView",FightManager.battleResultParam); 
		FightManager.battleResultParam = nil;
	end
end

function FightManager.CheckShowBattleResult()
	-- body
	if(FightManager.battleResultParam ~= nil and FightManager.battleOver) then
		FightManager.battleResultParam.objParam["achievement"] = FightManager.achievementParam;
		print("FightManager.battleResultParam",FightManager.battleResultParam)
		ViewSys.instance:Open("BattleResultView",FightManager.battleResultParam); 
		FightManager.battleResultParam = nil;
		if(FightManager.battleResultBornParam ~= nil) then
			ViewSys.instance:Open("BattleResultBornView",FightManager.battleResultBornParam);
		end
		FightManager.battleResultBornParam = nil;
	end
end
---------------显示大乱斗界面结束-------------

---------------显示moba界面开始-------------
function FightManager.ShowMobaBattleResult(param)
	FightManager.battleResultParam = param;
	FightManager.CloseFightView(BattleInfo.gameType);
	FightManager.CheckShowMobaBattleResult();
end

function FightManager.CheckShowMobaBattleResult()
	if(FightManager.battleResultParam ~= nil and FightManager.battleOver) then
		FightManager.battleResultParam.objParam["achievement"] = FightManager.achievementParam;
		ViewSys.instance:Open("MobaBattleInfoView",FightManager.battleResultParam); 
		-- ViewSys.instance:Open("MobaBattleResultView",FightManager.battleResultParam); 
		FightManager.battleResultParam = nil;
		if(FightManager.battleResultBornParam ~= nil) then
			ViewSys.instance:Open("BattleResultBornView",FightManager.battleResultBornParam);
		end
		FightManager.battleResultBornParam = nil;
	end
end

---------------显示moba界面结束-------------


--战斗服务器重连
function FightManager.OnReconnect(eventId,arr)
	local channelType = arr[0];
	local reconnectCode = arr[1];
	if(channelType ~= EChannelType.EPvpChannel) then return end
	if(reconnectCode ~= Error_None) then
		if(reconnectCode == Error_AuthCheckFaild) then
		 	Util.LogError("重连服务器失败!(验证失败)")
		 	TipMgr.ShowTipType2("Server disconnected, please re-enter the game",function ()
				CGameRoot.instance:ApplicationExit();
			end,false);
		elseif(reconnectCode == Error_GameNotExist) then
			Util.LogError("重连服务器失败!(战斗已结束)");
			if(CGameRoot.CurState == EStateType.CoreGaming) then
				FightManager.ExitToLobby();
			end
		else
			TipMgr.ShowTipType2("Server disconnected, please re-enter the game",function ()
				CGameRoot.instance:ApplicationExit();
			end,false);
			Util.LogError("重连服务器失败!")
		end
		return;
	end
	--如果正在loading中，返回
	if(BattleSceneLoad.isLoading) then return end
	FightManager.hasHistoryFrameData = false;
	FightManager.hasCreateMainHero = false;
	Util.Log("请求准备战斗数据")
	local data = C2S_PrepareBattleData(); 
    NetSys.instance:SendPvpMsg(data:SerializeToString(), C2S_PrepareBattle, S2C_StartBattle, FightManager.S2C_StartBattleData, nil); 
end

--返回到大厅
function FightManager.ExitToLobby()
	ViewSys.instance:Close("MobaBattleInfoView"); 
	ViewSys.instance:Close("BattleResultView"); 
	ViewSys.instance:Close("MobaBattleResultView"); 
    ViewSys.instance:Close("FightView"); 
    ViewSys.instance:Close("FightBarView"); 

    NetSys.instance:CloseConnect(EChannelType.EPvpChannel); 

    SceneLoad:Load("empty"); 
	
	BattleInfo.Clear();
	--停止语音
	VoiceHelper:Logout();
	CGameRoot.SwitchToState(EStateType.Lobby); 
	ViewSys.instance:Open("MainLobbyView"); 
	EventSys.instance:DispatchLua(GameEvent.FightFinish);
end

function FightManager.S2C_StartBattleData(obj,objMsg)
	-- body
	Util.Log("开始战斗")
	--清除帧数据
	local channel = NetSys.instance:GetChannel(EChannelType.EPvpChannel);
	local curFrame = NetSys.instance.netFrameId;
	channel:ClearFrameData(curFrame);
	local msg = S2C_StartBattleData()
    msg:ParseFromString(objMsg);
    FightManager.hasHistoryFrameData = msg.has_histroy_data;
	FightManager.hasCreateMainHero = msg.has_create_entity;
	Util.Log("是否有历史帧",FightManager.hasHistoryFrameData,"是否有主角",FightManager.hasCreateMainHero);
	if(FightManager.hasHistoryFrameData) then
		local data = C2S_RequestFrameIndexData(); 
	    data.frameIndexReq = curFrame; 
	    Util.Log("请求帧数据",curFrame)
	     --监听服务器历史帧消息的回复
	    NetSys.instance:AddMsgCallback(EChannelType.EPvpChannel, S2C_BattleHistroySendComplete, FightManager.S2C_BattleHistroySendCompleteData, nil,true); 
	    NetSys.instance:SendPvpMsg(data:SerializeToString(), C2S_RequestFrameIndex); 
	end
end

function FightManager.S2C_BattleHistroySendCompleteData(obj,objMsg)
	Util.Log("请求帧数据成功")
	if(not FightManager.hasCreateMainHero) then
		--发送创建玩家消息
		local data = C2S_RequestCreateEntityData(); 
        NetSys.instance:SendPvpMsg(data:SerializeToString(), C2S_RequestCreateEntity); 
        Util.Log("创建主玩家")
	end
end

function FightManager.S2C_GameOverData(obj,objMsg)
	Util.LogColor("#ff0000","S2C_GameOverData");
	local msg = S2C_GameOverData();
	msg:ParseFromString(objMsg);
	if(msg.is_any_reward and BattleInfo.coreGaming ~= nil) then
	    local money = {}
	    local moneyId = nil;
	    print("money_type",msg.money_type)
	    if(msg.money_type == HumanResouceType_Silver) then
	    	moneyId = SpecialItem_Silver;
	    elseif(msg.money_type == HumanResouceType_Gold) then
	    	moneyId = SpecialItem_Gold;
	    end
	    if(moneyId ~= nil) then
	    	print("moneyId",moneyId,"moneyCount",msg.money)
	    	table.insert(money,{ItemTable[moneyId],msg.money});
	    end

	    local items = {};
	    for k,v in ipairs(msg.item_list) do
	    	print("id",v.config_id)
	    	table.insert(items,{ItemTable[v.config_id],v.count});
	    end

	    local param = ViewParam();
	    param.objParam = {moneyItems = money,itemItems = items,aceUserId = tostring(msg.kill_most_user_id),kdUserId = tostring(msg.pick_most_user_id),mvpUserId = tostring(msg.damage_most_user_id)};
	    FightManager.battleResultBornParam = param;
    end
	FightManager.achievementParam = {aceUserId = tostring(msg.kill_most_user_id),kdUserId = tostring(msg.pick_most_user_id),mvpUserId = tostring(msg.damage_most_user_id)};
	FightManager.battleOver = true;
	FightManager.CheckShowBattleResult();
end

--moba战斗结算数据消息
function FightManager.S2C_TeamGameOverData(obj,objMsg)
	Util.LogColor("#ff0000","S2C_TeamGameOverData");
	local msg = S2C_TeamGameOverData();
	msg:ParseFromString(objMsg);
	if(msg.is_any_reward and BattleInfo.coreGaming ~= nil) then
	    local money = {}
	    local moneyId = nil;
	    print("money_type",msg.money_type)
	    if(msg.money_type == HumanResouceType_Silver) then
	    	moneyId = SpecialItem_Silver;
	    elseif(msg.money_type == HumanResouceType_Gold) then
	    	moneyId = SpecialItem_Gold;
	    end
	    if(moneyId ~= nil) then
	    	print("moneyId",moneyId,"moneyCount",msg.money)
	    	table.insert(money,{ItemTable[moneyId],msg.money});
	    end

	    local items = {};
	    for k,v in ipairs(msg.item_list) do
	    	print("id",v.config_id)
	    	table.insert(items,{ItemTable[v.config_id],v.count});
	    end

	    local param = ViewParam();
	    param.objParam = {moneyItems = money,itemItems = items,aceUserId = tostring(msg.ace_user_id),kdUserId = tostring(msg.kd_user_id),mvpUserId = tostring(msg.mvp_user_id)};
	    FightManager.battleResultBornParam = param;
    end
	FightManager.achievementParam = {aceUserId = tostring(msg.ace_user_id),kdUserId = tostring(msg.kd_user_id),mvpUserId = tostring(msg.mvp_user_id)};
	FightManager.battleOver = true;
	FightManager.CheckShowMobaBattleResult();
end