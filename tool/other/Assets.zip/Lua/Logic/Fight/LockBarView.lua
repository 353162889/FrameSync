LockBarView = class("LockBarView")

function LockBarView:InitView(go)
	self.go = go;
	self.transform = self.go.transform;
	self.normalLock = self.transform:Find("NormalLock").gameObject;
	self.normalLockImg = self.transform:Find("NormalLock/Img"):GetComponent("Image");

	self.curLock = self.transform:Find("CurLock").gameObject;
	self.curLockImg = self.transform:Find("CurLock/Img"):GetComponent("Image");
end

function LockBarView:OpenView(param)

	self.normalLockTweener = self.normalLockImg.transform:DOScale(0.9,0.2);
    self.normalLockTweener:SetAutoKill(false);
    self.normalLockTweener:SetEase(DG.Tweening.Ease.Linear):SetLoops(-1,DG.Tweening.LoopType.Yoyo);
    self.normalLockTweener:Pause();

    self.curLockTweener = self.curLockImg.transform:DOScale(0.9,0.2);
    self.curLockTweener:SetAutoKill(false);
    self.curLockTweener:SetEase(DG.Tweening.Ease.Linear):SetLoops(-1,DG.Tweening.LoopType.Yoyo);
    self.curLockTweener:Pause();

     self.mainHeroLock = function (unit,targetUnit)
    	self:OnMainHeroLock(unit,targetUnit);
    end

	self.mainHeroUpdate = function (eventId,obj)
        self:OnMainHeroUpdate();
    end
    EventSys.instance:AddEvent(EEventType.OnMainHeroUpdate, self.mainHeroUpdate);
    if(BattleScene.instance.mainHero ~= nil) then
        self:OnMainHeroUpdate();
    end

    self.onTargetChange = function (eventId,obj)
    	local unit = obj;
    	self:OnTargetChange(unit);
    end
    EventSys.instance:AddEvent(EEventType.OnUnitLockIndicatorTargetChange,self.onTargetChange);
    self:OnTargetChange(nil);
end

function LockBarView:OnMainHeroLock(unit,targetUnit)
	if(targetUnit ~= nil) then
		self.normalLock:SetActive(true);
		self.normalLockfollower = GameObjectUtil.AddComponentOnce(self.normalLock,typeof(UIFollower));
		local hangPoint = targetUnit.unitView.transform;
		self.normalLockfollower:SetTarget(ChaseCamera.instance.mainCamera,hangPoint,false,false);
		self.normalLockfollower.enabled = true;
		self.normalLockTweener:Play();
	else
		self.normalLock:SetActive(false);
		if(self.normalLockfollower ~= nil) then
			self.normalLockfollower:Dispose();
			self.normalLockfollower.enabled = false;
			self.normalLockfollower = nil;
		end
		self.normalLockTweener:Pause();
	end
end

function LockBarView:OnTargetChange(targetUnit)
	if(targetUnit ~= nil) then
		self.curLock:SetActive(true);
		self.curLockfollower = GameObjectUtil.AddComponentOnce(self.curLock,typeof(UIFollower));
		local hangPoint = targetUnit.unitView.transform;
		self.curLockfollower:SetTarget(ChaseCamera.instance.mainCamera,hangPoint,false,false);
		self.curLockfollower.enabled = true;
		self.curLockTweener:Play();
	else
		self.curLock:SetActive(false);
		if(self.curLockfollower ~= nil) then
			self.curLockfollower:Dispose();
			self.curLockfollower.enabled = false;
			self.curLockfollower = nil;
		end
		self.curLockTweener:Pause();
	end
end

function LockBarView:CloseView()
	if(self.mainHeroUpdate ~= nil) then
         EventSys.instance:RemoveEvent(EEventType.OnMainHeroUpdate, self.mainHeroUpdate);
         self.mainHeroUpdate = nil;
    end
    self:ResetMainHero();
    if(self.normalLockfollower ~= nil) then
		self.normalLockfollower:Dispose();
		self.normalLockfollower.enabled = false;
		self.normalLockfollower = nil;
	end
    if(nil ~= self.normalLockTweener) then
    	self.normalLockTweener:Kill();
    	self.normalLockTweener = nil;
	end

	if(self.curLockfollower ~= nil) then
		self.curLockfollower:Dispose();
		self.curLockfollower.enabled = false;
		self.curLockfollower = nil;
	end
    if(nil ~= self.curLockTweener) then
    	self.curLockTweener:Kill();
    	self.curLockTweener = nil;
	end

	 EventSys.instance:RemoveEvent(EEventType.OnUnitLockIndicatorTargetChange,self.onTargetChange);
end

function LockBarView:ResetMainHero()
	if(self.normalLockfollower ~= nil) then
		self.normalLockfollower:Dispose();
		self.normalLockfollower.enabled = false;
		self.normalLockfollower = nil;
	end
	if(self.mainHero ~= nil) then
		self.mainHero.unitLock.OnUnitLock = self.mainHero.unitLock.OnUnitLock - self.mainHeroLock;
	end
    self.mainHero = nil;
end

function LockBarView:OnMainHeroUpdate()
    self:ResetMainHero();
    self.mainHero = BattleScene.instance.mainHero;
    if(self.mainHero ~= nil) then
    	self.mainHero.unitLock.OnUnitLock = self.mainHero.unitLock.OnUnitLock + self.mainHeroLock;
    	self:OnMainHeroLock(self.mainHero,self.mainHero.unitLock.target);
    end
end

function LockBarView:DestroyView()
	-- body
end