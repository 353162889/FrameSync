require "Logic/Fight/UITeammateBar"

TeamBarPool = class("TeamBarPool")
function TeamBarPool:Init(template)
	self.template = template;
	self.lstBar = {};
	self.lstPool = {};
end

function TeamBarPool:GetBar()
	local result = nil;
	if(#self.lstPool > 0) then
		local item = self.lstPool[1];
		table.remove(self.lstPool,1)
		result = item;
	else
		local go = UnityEngine.GameObject.Instantiate(self.template);
		GameObjectUtil.AddChild(self.template.transform.parent.gameObject,go)
     	--go.transform:SetParent(self.template.transform.parent);
     	local bar = UITeammateBar.new();
     	bar:Init(go);
     	result = bar;
	end
	result:SetActive(true);
	table.insert(self.lstBar,result);
	return result;
end

function TeamBarPool:HideBar(bar)
	bar:Reset();
	bar:SetActive(false);	
	for i=#self.lstBar,1,-1 do
		if(self.lstBar[i] == bar) then
			table.remove(self.lstBar,i)
			break;
		end
	end
	table.insert(self.lstPool,bar);
end

function TeamBarPool:ResetBar()
	for i=#self.lstBar,1,-1 do
		self:HideBar(self.lstBar[i]);
	end
	self.lstBar = {};
end

TeamBarView = class("TeamBarView")

function TeamBarView:InitView(go)
	-- body
	self.go = go;
	self.templateIcon = self.go.transform:Find("TeamGrid/Template").gameObject;
	self.templateIcon:SetActive(false);
	self.teamBarPool = TeamBarPool.new();
	self.teamBarPool:Init(self.templateIcon);
end

function TeamBarView:OpenView(param)
	self.teamBarPool:ResetBar();
	self.onTeamChange = function (eventId,unit)
		self:OnTeamChange(eventId,unit)
	end
	EventSys.instance:AddEvent(EEventType.OnUnitTeamChange,self.onTeamChange);

	self.onMainHeroUpdate = function (eventId,unit)
		self:OnMainHeroUpdate()
	end
	EventSys.instance:AddEvent(EEventType.OnMainHeroUpdate,self.onMainHeroUpdate);
	if(BattleScene.instance.mainHero ~= nil) then
        self:OnMainHeroUpdate();
    end
    local lst = BattleScene.instance.lstHero;
    local count = lst.Count;
    for i=0,count - 1 do
    	self:OnTeamChange(0,lst[i]);
    end
end

function TeamBarView:OnTeamChange(eventId,unit)
	if(self.mainHero.id == unit.id) then
		self.teamBarPool:ResetBar();
		--如果我进入队伍
		if(self.mainHero.hasTeam) then
			local battleTeam = BattleScene.instance:GetBattleTeam(self.mainHero.teamId);
			local count = battleTeam.teamCount;
			for i=0,count - 1 do
				local unit = battleTeam.lstTeam[i];
				local bar = self.teamBarPool:GetBar();
	 			bar:SetUnit(unit);
			 end 
		end
	else
		if(self.mainHero.hasTeam) then
			if(self.mainHero.teamId == unit.teamId) then
				--变成我队友的话添加
				local bar = self:GetBarByUnit(unit)
				if(bar == nil) then
					local bar = self.teamBarPool:GetBar();
					bar:SetUnit(unit);
				end
			else
				--查找当前队友是否有他，如果有，删除
				local bar = self:GetBarByUnit(unit);
				if(bar ~= nil) then
					self.teamBarPool:HideBar(bar);
				end
			end
		end
	end
	
end

function TeamBarView:OnMainHeroUpdate(eventId,unit)
	self.mainHero = BattleScene.instance.mainHero;
	if(self.mainHero == nil) then return end;
	--获取到前一个主玩家的图标，重新初始化
	local bar = self:GetBarByUnit(unit);
	if(bar ~= nil) then
		self.teamBarPool:HideBar(bar);
	end
	 if(self.mainHero.hasTeam) then
	 	local bar = self.teamBarPool:GetBar();
	 	bar:SetUnit(self.mainHero);
	 end 
end

function TeamBarView:GetBarByUnit(unit)
	for i=#self.teamBarPool.lstBar,1,-1 do
		if(self.teamBarPool.lstBar[i].unit.id == unit.id) then
			return self.teamBarPool.lstBar[i];
		end
	 end
	 return nil;
end

function TeamBarView:OnUpdate(deltaTime)
	for i=#self.teamBarPool.lstBar,1,-1 do
		self.teamBarPool.lstBar[i]:OnUpdate(deltaTime);
	 end
end

function TeamBarView:CloseView()
	if(self.onTeamChange ~= nil) then
		EventSys.instance:RemoveEvent(EEventType.OnUnitTeamChange,self.onTeamChange);
		self.onTeamChange = nil;
	end
	if(self.onMainHeroUpdate ~= nil) then
		EventSys.instance:RemoveEvent(EEventType.OnMainHeroUpdate,self.onMainHeroUpdate);
		self.onMainHeroUpdate = nil;
	end
	self.teamBarPool:ResetBar();
	self.mainHero = nil;
end

function TeamBarView:DestroyView()
	-- body
end