require "Logic/Fight/UIBubbleBar"

BubbleBarPool = class("BubbleBarPool")
function BubbleBarPool:Init(template)
	self.template = template;
	self.lstBubbleBar = {};
	self.lstPool = {};
end

function BubbleBarPool:GetBar()
	local result = nil;
	if(#self.lstPool > 0) then
		local item = self.lstPool[1];
		table.remove(self.lstPool,1)
		result = item;
	else
		local go = UnityEngine.GameObject.Instantiate(self.template);
		go:SetActive(true);
		GameObjectUtil.AddChild(self.template.transform.parent.gameObject,go)
     	--go.transform:SetParent(self.template.transform.parent);
     	local bar = UIBubbleBar.new();
     	bar:Init(go);
     	LuaHelper.SetLocalPos(go,100000,0,0);
     	result = bar;
	end
	table.insert(self.lstBubbleBar,result);
	return result;
end

function BubbleBarPool:HideBar(bar)
	bar:Reset();
	LuaHelper.SetLocalPos(bar.go,100000,0,0);
	for i=#self.lstBubbleBar,1,-1 do
		if(self.lstBubbleBar[i] == bar) then
			table.remove(self.lstBubbleBar,i);
			break;
		end
	end
	table.insert(self.lstPool,bar);
end

function BubbleBarPool:ResetBar()
	for i=#self.lstBubbleBar,1,-1 do
		self:HideBar(self.lstBubbleBar[i]);
	end
	self.lstBubbleBar = {};
end

BubbleBarView = class("BubbleBarView")

function BubbleBarView:InitView(go)
	-- body
	self.go = go;
	self.templateDamage = self.go.transform:Find("TemplateDamage").gameObject;
	self.templateDamage:SetActive(false);
	LuaHelper.SetLocalPos(self.templateDamage,100000,0,0);
	self.bubbleBarDamagePool = BubbleBarPool.new();
	self.bubbleBarDamagePool:Init(self.templateDamage);

	self.templateCoin = self.go.transform:Find("TemplateCoin").gameObject;
	self.templateCoin:SetActive(false);
	LuaHelper.SetLocalPos(self.templateCoin,100000,0,0);
	self.bubbleBarCoinPool = BubbleBarPool.new();
	self.bubbleBarCoinPool:Init(self.templateCoin);
end

function BubbleBarView:OpenView(param)
	self.onCoinChange = function (oldValue,newValue)
		self:OnCoinChange(oldValue,newValue);
	end

	-- body
	self.onUnitHurt = function (eventId,damageInfo)
		self:OnUnitHurt(damageInfo);
	end
	EventSys.instance:AddEvent(EEventType.OnUnitHurt,self.onUnitHurt);	

	 self.mainHeroUpdate = function (eventId,obj)
        self:OnMainHeroUpdate();
    end
    EventSys.instance:AddEvent(EEventType.OnMainHeroUpdate, self.mainHeroUpdate);
    if(BattleScene.instance.mainHero ~= nil) then
        self:OnMainHeroUpdate();
    end
end

function BubbleBarView:OnUnitHurt(damageInfo)
	if(damageInfo.attack == self.mainHero or damageInfo.defence == self.mainHero) then
		local damage1,damage2 = math.modf(damageInfo.damage / 1000);
		if(damage2 > 0.5) then damage1 = damage1 + 1 end
		local bar = self.bubbleBarDamagePool:GetBar();
		bar:Show(self.bubbleBarDamagePool,damageInfo.defence,tostring(damage1),UIBubbleBarAnimType.Scale);
	end
end

function BubbleBarView:OnCoinChange(oldValue,newValue)
	if(oldValue > newValue) then
		local value = newValue - oldValue;
		local bar = self.bubbleBarCoinPool:GetBar();
		bar:Show(self.bubbleBarCoinPool,self.mainHero,tostring(value),UIBubbleBarAnimType.Up);
	end
end

function BubbleBarView:OnUpdate()
end

function BubbleBarView:CloseView()
	Util.LogColor("#ff0000","BubbleBarView:CloseView")
	if(self.onUnitHurt ~= nil) then
		EventSys.instance:RemoveEvent(EEventType.OnUnitHurt,self.onUnitHurt);
		self.onUnitHurt = nil;	
	end
	self:ResetMainHero();
	self.onCoinChange = nil;
	 if(self.mainHeroUpdate ~= nil) then
         EventSys.instance:RemoveEvent(EEventType.OnMainHeroUpdate, self.mainHeroUpdate);
         self.mainHeroUpdate = nil;
    end

	self.bubbleBarDamagePool:ResetBar();
	self.bubbleBarCoinPool:ResetBar();
end

function BubbleBarView:OnMainHeroUpdate()
    self:ResetMainHero();
    self.mainHero = BattleScene.instance.mainHero;
    if(self.mainHero ~= nil) then
    	self.mainHero.unitAttr.OnCoinChange = self.mainHero.unitAttr.OnCoinChange + self.onCoinChange;
    end
end

function BubbleBarView:ResetMainHero()
	if(self.mainHero ~= nil) then
		self.mainHero.unitAttr.OnCoinChange = self.mainHero.unitAttr.OnCoinChange - self.onCoinChange;
    	self.mainHero = nil;
	end
end

function BubbleBarView:DestroyView()
	-- body
end
