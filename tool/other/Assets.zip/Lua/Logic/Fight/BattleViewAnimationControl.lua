--From Lua Script Create
--ClassName: BattleViewAnimationControl
--Author:    hukiry
--CreateTime:2018-3-27

BattleViewAnimationControl = class(BattleViewAnimationControl)

local _this; 

local _template_rank_path = "template/tamplate_rank.prefab"; 
local _template_rank_up_path = "template/tamplate_rank_up.prefab"; 

function BattleViewAnimationControl:Init(this)

    _this = self; 

    this.killNum.text = ""; 

    this.sumNum.text = ""; 
    
    self.isAnimDone = false;

    self.transform=this.transform;

    self.beforetime = self.Realtime(); 

    self.isAnimation = true; 

    self.sumTime = 0; 

    self.goDicTable = {}; 

    self.strName = "titleImage,selectImage,bgImageList,upRank,downRank,right,aniNum,aniIconTime,ImageKill,killNum,ImageTotal,sumNum,btnBack"; 

    self.goNamTable = string.split(self.strName, ','); 

    self.isScale = false; 

    self:CollectObject(this, self.goDicTable, false); 

    self.funTable = {}; 
    
    --------------------------------------------------------数字
    local statisticsComp = BattleInfo.coreGaming:GetSysComp(EGamingSysCompType.Statistics);
    local statics = statisticsComp:GetStatisticsData(BattleScene.instance.mainHero.id);
    self.killNum = statics.kill; --BattleScene.instance.getKillNum; 

    self.sumNum = BattleScene.instance.mainHero.unitAttr.coin; -- BattleScene.instance.getTotalScore; 

    self.waitTimeKill = 0; 

    self.waitTimeTotal = 0; 

    table.insert(self.funTable, {funName = self.NumberAnimation, isEnable = true}); 

    table.insert(self.funTable, {funName = self.EffectAnimation, isEnable = true}); 

    self.goDicTable.aniNum.transform.localScale = Vector3(2.5, 2.5, 2.5); 

    table.insert(self.funTable, {funName = self.ScaleAnimation, isEnable = true}); 

    local img = self.goDicTable.backgroud:GetComponent("Image"); 

    img.color = Color(0, 0, 0, 0); 

    --table.insert(self.funTable, {funName = self.AlphaAnimation, isEnable = true}); 

    table.insert(self.funTable, {funName = self.ShowAnimation, isEnable = true}); 

    --table.insert(self.funTable, {funName = self.SelectAnimation, isEnable = true}); 

    local img = self.goDicTable.bgImageList:GetComponent("Image"); 

    img.fillAmount = 0; 

    table.insert(self.funTable, {funName = self.StretchAnimation, isEnable = true}); 

    Main.AddUpdateFun(self.UpdateAnimation, self); 

    self:InitDataTamplateRank(); 

    self.index = 0; 

end

function BattleViewAnimationControl:CollectObject(this, goTable, isShow)
    
    for i = 1, this.transform.childCount do

        local go = this.transform:GetChild(i - 1).gameObject; 

        goTable[go.name] = go; 

        goTable[go.name]:SetActive(isShow); 

        if go.transform.childCount > 0 then

            self:CollectObject(go.transform, goTable); 

        end

    end

end

--更新所有的动画，整体动画
function BattleViewAnimationControl:UpdateAnimation()

    if self.isAnimation then

        local realtime = self.Realtime(); 

        if self.beforetime ~= realtime then

            self.sumTime = self.sumTime + (realtime - self.beforetime); 

            if self.AlphaAnimation(self.sumTime) then

                if (self.sumTime - 0.5) > 3 then

                    self.goDicTable.selectImage:SetActive(true); 

                    self.isAnimation = false; 
                end

                for i, v in ipairs(self.funTable) do

                    if v.isEnable then

                        v.funName(self.sumTime - 0.5, v); 

                    end

                end
            end

            self.beforetime = self.Realtime(); 

        end
    end

    self:SelectAnimation(self.sumTime); 
end

--数字动画
function BattleViewAnimationControl.NumberAnimation(t, go)

    local deltaKill = math.ceil(_this.killNum / 10); 

    local deltaScore = math.ceil(_this.sumNum / 100); 

    local killNum = _this.goDicTable.killNum:GetComponent("Text"); 
    
    local sumNum = _this.goDicTable.sumNum:GetComponent("Text"); 

    if t - _this.waitTimeKill > 0.2 then--20次，2秒钟

        _this.waitTimeKill = t; 

        killNum.text = killNum.text == "" and tostring(deltaKill) or (tonumber(killNum.text) + deltaKill); 

        if tonumber(killNum.text) >= tonumber(_this.killNum) then

            killNum.text = tostring(_this.killNum); 

        end
    end

    if t - _this.waitTimeTotal > 0.1 then

        _this.waitTimeTotal = t; 

        sumNum.text = sumNum.text == "" and tostring(deltaScore) or (tonumber(sumNum.text) + deltaScore); 

        if tonumber(sumNum.text) >= tonumber(_this.sumNum) then

            sumNum.text = tostring(_this.sumNum); 

        end

    else
        sumNum.text = tostring(_this.sumNum);
    end

end

--特效动画
function BattleViewAnimationControl.EffectAnimation(t, go)

end

--缩放动画
function BattleViewAnimationControl.ScaleAnimation(t, go)

    local transform = _this.goDicTable.aniNum.transform; 

    if t > 0.8 and t < 1 then

        _this.goDicTable.aniNum:SetActive(true); 
        local gameRank = BattleInfo.coreGaming:GetSysComp(EGamingSysCompType.Rank);
        local myRank = gameRank:GetRank(BattleScene.instance.mainHero.id);
        if myRank < 10 then
            _this.goDicTable.ranking1:SetActive(true);
             _this.goDicTable.ranking2:SetActive(false);
        else
            _this.goDicTable.ranking1:SetActive(false);
             _this.goDicTable.ranking2:SetActive(true);
        end
        _this.goDicTable.ranking3:SetActive(true);
       -- _this.goDicTable.rankingbase:SetActive(true); 
        

    elseif t >= 1 then

        local deltaT = (t / 1) * 1.5; 

        transform.localScale = Vector3.Lerp(transform.localScale, Vector3(1, 1, 1), deltaT); 

        if t > 2.5 then
            _this.goDicTable.aniIconTime:SetActive(true); 
        end

        if t >= 1.4 then

            _this.goDicTable.effectImage:SetActive(true); 

            local img = _this.goDicTable.effectImage:GetComponent("Image"); 

            local numIndex = math.floor(((t - 1.4) % 1.7) * 10); 

            if numIndex < 1 then

                numIndex = 1; 

            elseif numIndex >= 16 then

                numIndex = 16

            end


            local path = "BattleEffect/eff_common_crit_000"..numIndex..".png"; 

            if numIndex > 9 then

                path = "BattleEffect/eff_common_crit_00"..numIndex..".png"; 

            end 

            --print(numIndex, numIndex, path); 
            img.sprite = CResourceSys.instance:Load(EResType.EIcon, path); 
            
        end
    end
    
end

--优先变暗
function BattleViewAnimationControl.AlphaAnimation(t, go)

    if t < 0.5 then

        local img = _this.goDicTable.backgroud:GetComponent("Image"); 

        img.color = Color.Lerp(img.color, Color(0, 0, 0, 0.6), 0.1); 

        return false; 
    else
        return true; 
    end
end

--延时显示项
function BattleViewAnimationControl.ShowAnimation(t, go)

    local funShow = function (t)

        local tm = math.floor((t - 1) * 10); 
        local gameRank = BattleInfo.coreGaming:GetSysComp(EGamingSysCompType.Rank);
        if _this.upRankTable ~= nil then
            local i = tm % 3 + 1; 
            if i <= gameRank.lstRankunit.Count then
                _this.upRankTable[i].num:SetActive(true); 
            end
        end

        if _this.upRankTable[3].go.activeSelf then

            if _this.downRankTable ~= nil and tm - 3 >= 0 then

                local i = (tm - 3) % 7 + 1; 
                if i <= (gameRank.lstRankunit.Count - 3) then
                    _this.downRankTable[i].num:SetActive(true); 
                end
            end
        end
    end

    local funVisible = function (t)

        local tm = math.floor((t - 2) * 10); 
        local gameRank = BattleInfo.coreGaming:GetSysComp(EGamingSysCompType.Rank);
        if _this.upRankTable ~= nil then
            local i = tm % 3 + 1;
            if i <= gameRank.lstRankunit.Count then
                _this.SetVisible(_this.upRankTable[i]);
            end
        end

        if _this.upRankTable[3].totalNum.activeSelf then

            if _this.downRankTable ~= nil and tm - 3 >= 0 then 
                local i = (tm - 3) % 7 + 1; 
                if i <= (gameRank.lstRankunit.Count - 3) then
                     _this.SetVisible(_this.downRankTable[i]);  
                end

            end
        end
    end

    if t < 0.2 then

        _this.goDicTable.titleImage:SetActive(true); 

        _this.goDicTable.backgroud:SetActive(true); 

    elseif t < 0.5 and t >= 0.2 then

        _this.goDicTable.bgImageList:SetActive(true); 

        _this.goDicTable.right:SetActive(true); 

        _this.goDicTable.upRank:SetActive(true); 

        _this.goDicTable.downRank:SetActive(true); 

    elseif t < 0.6 and t >= 0.5 then

        _this.goDicTable.ImageKill:SetActive(true); 

    elseif t < 0.9 and t >= 0.6 then

        _this.goDicTable.btnBack:SetActive(true); 

        _this.goDicTable.ImageTotal:SetActive(true); 

    elseif t < 1 and t >= 0.9 then

        _this.goDicTable.killNum:SetActive(true); 

        _this.goDicTable.sumNum:SetActive(true); 

    elseif t < 2 and t >= 1 then

        funShow(t); 

    elseif t < 3 and t >= 2 then 

        funVisible(t); 
        
    else
        go.isEnable = false; 
        _this.isAnimDone = true;
    end
end

--拉伸显示项
function BattleViewAnimationControl.StretchAnimation(t, go)

    if t > 0.5 then

        local img = _this.goDicTable.bgImageList:GetComponent("Image"); 

        img.fillAmount = Mathf.Lerp(img.fillAmount, 1, 0.2); 
    end
end

--当前选中动画（自己的排名项）
function BattleViewAnimationControl:SelectAnimation(t)

    if t > 3.5 then

        self.isScale = not self.isScale; 

        local transform = self.goDicTable.selectImage.transform; 
        transform.gameObject:SetActive(false);
        
        if self.playTransform ~= nil then--52

            transform:SetParent(self.playTransform); 
            transform.gameObject:SetActive(true);

            transform.localPosition = Vector3(transform.localPosition.x, 0, transform.localPosition.z); 

            transform.localScale = Vector3(1, 1, 0); 

            self.playTransform = nil; 

        end

        if self.isScale then

            transform.localScale = Vector3(0.99, 0.99, 1); 

        else

            transform.localScale = Vector3(1, 1, 1); 

        end
    end
end

function BattleViewAnimationControl.Realtime()

    return TimeHelper.realtimeSinceStartup; 

end

function BattleViewAnimationControl:GetAnimationState()
    -- body
    if self.isAnimation == nil then
        --do
        return false; 
    end

    return self.isAnimation; 
end

function BattleViewAnimationControl:InitDataTamplateRank()

    self.downRankTable = {}; 
    local prefab = nil;
    local go = nil;
    for i = 1, 7 do

        local temp = {}; 

        prefab = CResourceSys.instance:Load(EResType.EView, _template_rank_path); 
        go = UnityEngine.GameObject.Instantiate(prefab); 

        go.name = tostring(i + 3); 

        go.transform:SetParent(self.goDicTable.downRank.transform); 
        go.transform.localScale = Vector3(1,1,1);
        go.transform.localPosition = Vector3(0, 0, 0); 

        self:CollectObject(go, temp, false); 

        temp.num:GetComponent("Text").text = tostring(i + 3); 

        temp["spHead"] = go.transform:Find("heroIcon"):GetComponent("Image");
        temp["txtName"] = go.transform:Find("name"):GetComponent("Text");
        temp["txtKill"] = go.transform:Find("killNum"):GetComponent("Text");
        temp["txtDead"] = go.transform:Find("deadNum"):GetComponent("Text");
        temp["txtCoin"] = go.transform:Find("totalNum"):GetComponent("Text");

        go:SetActive(true); 

        temp.go = go; 

        table.insert(self.downRankTable, temp); 
    end

    self.upRankTable = {}; 

    for i = 1, 3 do

        local temp = {}; 

        prefab = CResourceSys.instance:Load(EResType.EView, _template_rank_up_path); 
        go = UnityEngine.GameObject.Instantiate(prefab);

        go.name = tostring(i); 

        go.transform:SetParent(self.goDicTable.upRank.transform); 

        go.transform.localScale = Vector3(1, 1, 0); 

        go.transform.localPosition = Vector3(0, 0, 0); 
        
        self:CollectObject(go, temp, false); 

        temp.num:GetComponent("Image").sprite = CResourceSys.instance:Load(EResType.EIcon, "Battle/res_icon_rank_0"..i..".png"); 
        temp.go = go; 

        go:SetActive(true); 

        table.insert(self.upRankTable, temp); 
    end

end

--刷新排行榜数据
function BattleViewAnimationControl:RefreshRankData(achievement)

    local playerName = BattleInfo.nickName; --昵称或者id
    local gameRank = BattleInfo.coreGaming:GetSysComp(EGamingSysCompType.Rank);
    local rankList = gameRank.lstRankunit;
    --更新前3
    for i, v in ipairs(self.upRankTable) do
        if((tonumber(v.go.name) - 1) < rankList.Count) then
            self.SetRankData(v, rankList[tonumber(v.go.name) - 1],achievement); 

            if playerName == v.name then
               self.playTransform = v.go.transform; 
            end
        end
    end
    --更新后7
    for i, v in ipairs(self.downRankTable) do
        if tonumber(v.go.name) > 3 then
            if((tonumber(v.go.name) - 1) < rankList.Count) then
                self.SetRankData(v, rankList[tonumber(v.go.name) - 1],achievement); 
                if playerName == v.name then
                    self.playTransform = v.go.transform; 
                end
            end
        end

    end
end

function BattleViewAnimationControl.SetRankData(rankTable, data,achievement)
    local resHero = HeroTable[data.resId];
    rankTable.go.transform:Find("heroIcon"):GetComponent("Image").sprite = CResourceSys.instance:Load(EResType.EIcon,resHero.icon); 

    rankTable.go.transform:Find("name"):GetComponent("Text").text = data.name; 

    local isAce = false;
    local isKd = false;
    local isMvp = false;
    if(achievement ~= nil) then
        local userId = tostring(data.userId);
        isMvp = (achievement["mvpUserId"] == userId);
        isAce = (achievement["aceUserId"] == userId);
        isKd = (achievement["kdUserId"] == userId);
    end 
    rankTable.go.transform:Find("achievement/imgAce").gameObject:SetActive(isAce)
    rankTable.go.transform:Find("achievement/imgKd").gameObject:SetActive(isKd)
    rankTable.go.transform:Find("achievement/imgMvp").gameObject:SetActive(isMvp)

    local statisticsComp = BattleInfo.coreGaming:GetSysComp(EGamingSysCompType.Statistics);
    local statics = statisticsComp:GetStatisticsData(data.id);
    rankTable.go.transform:Find("killNum"):GetComponent("Text").text = statics.kill; 

    rankTable.go.transform:Find("deadNum"):GetComponent("Text").text = statics.die; 

    rankTable.go.transform:Find("totalNum"):GetComponent("Text").text = data.unitAttr.coin; 
end

function BattleViewAnimationControl.SetVisible(temp)

    temp.num:SetActive(true); 

    temp.heroIcon:SetActive(true); 

    temp.achievement:SetActive(true);

    -- temp.imgAce:SetActive(true);
    -- temp.imgKd:SetActive(true);
    -- temp.imgMvp:SetActive(true);

    temp.mark:SetActive(true); 

    temp.name:SetActive(true); 

    temp.killNum:SetActive(true); 

    temp.deadNum:SetActive(true); 

    temp.totalNum:SetActive(true); 
    
end

function BattleViewAnimationControl:Close()

    local transform = self.goDicTable.selectImage.transform; 

    transform:SetParent(self.transform); 
    
    if self.goDicTable.upRank ~= nil then

        for i = 1, self.goDicTable.upRank.transform.childCount do

            local go = self.goDicTable.upRank.transform:GetChild(i - 1).gameObject; 

            UnityEngine.GameObject.Destroy(go); 

        end

    end

    if self.goDicTable.downRank ~= nil then

        for i = 1, self.goDicTable.downRank.transform.childCount do

            local go = self.goDicTable.downRank.transform:GetChild(i - 1).gameObject; 

            UnityEngine.GameObject.Destroy(go); 

        end

    end
    
end
