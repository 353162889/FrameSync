MapItemType = {}
MapItemType.Hero = 1;
MapItemType.Food = 2;

MapHeroKey = {}
MapHeroKey.MainHero = 1;
MapHeroKey.Teammate = 2;
MapHeroKey.Captain = 3;
MapHeroKey.Enemy = 4;

MapHeroKey.MaxCoinHero = 10;

UIMapItem = class("UIMapItem")

function UIMapItem:Init(go)
	self.go = go;
	self.trans = self.go.transform;
	self.img = self.go:GetComponent(typeof(UnityEngine.UI.Image));
	self.id = nil;
	self.itemType = nil;
end

function UIMapItem:SetFollow(id,itemType,itemKey,mapTransform)
	self.id = id;
	self.itemType = itemType;
	self.follower = GameObjectUtil.AddComponentOnce(self.go,typeof(UIMapFollower));
	local resScene = SceneTable[BattleInfo.sceneId];
	local width = resScene.width / 1000.0;
	local height = resScene.height / 1000.0;
	self.follower:SetTarget(mapTransform,UnityEngine.Rect(-width / 2,-height / 2,width,height));
	if(self.itemType ~= MapItemType.Food) then
		self.img.sprite = CResourceSys.instance:Load(EResType.EIcon,"Map/Hero_"..itemKey..".png");
	else
		self.img.sprite = CResourceSys.instance:Load(EResType.EIcon,"Map/Food_"..itemKey..".png");
	end
	self.img:SetNativeSize();
end


function UIMapItem:Reset()
	self.img.sprite = nil;
	self.id = nil;
	self.itemType = nil;
	if(self.follower ~= nil) then
		self.follower:Dispose();
	end
	self.follower = nil;
end