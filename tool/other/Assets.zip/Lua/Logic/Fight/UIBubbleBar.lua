UIBubbleBarAnimType = {}
UIBubbleBarAnimType.Scale = 1;
UIBubbleBarAnimType.Up = 2;

UIBubbleBar = class("UIBubbleBar")

function UIBubbleBar:Init(go)
	self.go = go;
	self.rectTrans = self.go.transform:Find("rangeRect");
	self.minX = self.rectTrans.rect.min.x;
	self.maxX = self.rectTrans.rect.max.x;
	self.minY = self.rectTrans.rect.min.y;
	self.maxY = self.rectTrans.rect.max.y;
	self.operateTrans = self.go.transform:Find("rangeRect/txt");
	self.txt = self.operateTrans:GetComponent("Text");
end

function UIBubbleBar:Show(parentPool,unit,desc,animType)
	self.txt.text = desc;
	self.follower = GameObjectUtil.AddComponentOnce(self.go,typeof(UIFollower));
	local hangPoint = nil;
	if(unit.unitView.unitHangPoint ~= nil) then
		hangPoint = unit.unitView.unitHangPoint:GetTransform("Head")
	end
	if hangPoint == nil then
		hangPoint = unit.unitView.transform;
	end
	self.follower:SetTarget(ChaseCamera.instance.mainCamera,hangPoint,false,false);
	self.follower.enabled = true;

	local onComplete = function ()
		self.tweener = nil;
		parentPool:HideBar(self);
	end
	local randomX = self.minX + (self.maxX - self.minX) * math.random();
	local randomY = self.minY + (self.maxY - self.minY) * math.random();
	LuaHelper.SetAnchoredPos(self.operateTrans,randomX,randomY);
	--LuaHelper.SetLocalScale(self.operateTrans,randomX,randomY);
	if(animType == UIBubbleBarAnimType.Scale) then
		self.tweener = self.operateTrans:DOScale(0.6,0.3):SetEase(DG.Tweening.Ease.Linear):OnComplete(onComplete);
	elseif(animType == UIBubbleBarAnimType.Up) then
		local endPos = self.operateTrans.anchoredPosition;
		endPos.y = endPos.y + 30;
		self.tweener = self.operateTrans:DOAnchorPos(endPos,0.6):SetEase(DG.Tweening.Ease.Linear):OnComplete(onComplete);
	end
end

function UIBubbleBar:Reset()
	self.txt.text = "";
	if(self.follower ~= nil) then
		self.follower:Dispose();
		self.follower.enabled = false;
		self.follower = nil;
	end
	if(self.tweener ~= nil) then
		self.tweener:Kill(false);
		self.tweener = nil;
	end
	LuaHelper.SetLocalScale(self.operateTrans,1,1,1);
end

function UIBubbleBar:OnUpdate()
end