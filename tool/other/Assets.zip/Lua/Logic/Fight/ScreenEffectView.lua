ScreenEffectView = class("ScreenEffectView")

function ScreenEffectView:InitView(go)
	self.go = go;
	self.transform = self.go.transform;
	self.imgFlashScreen = self.transform:Find("imgFlashScreen"):GetComponent("Image");
    self.imgHurtScreen = self.transform:Find("imgHurtScreen"):GetComponent("Image");
end

function ScreenEffectView:OpenView(param)
	local color = self.imgFlashScreen.color;
	self.imgFlashScreen.color = Color(color.r,color.g,color.b,0);
	local color = self.imgHurtScreen.color;
	self.imgHurtScreen.color = Color(color.r,color.g,color.b,0);
	self.hpChange = function (oldValue,newValue)
		self:OnHpChange(oldValue,newValue);
	end
	self.heroDie = function ( unit )
		self:StopFlashScreen();
		self:StopHurtScreen();
	end
	self.hurtComplete = function ()
		self:StopHurtScreen();
	end
	 self.mainHeroUpdate = function (eventId,obj)
        self:OnMainHeroUpdate();
    end
    EventSys.instance:AddEvent(EEventType.OnMainHeroUpdate, self.mainHeroUpdate);
    if(BattleScene.instance.mainHero ~= nil) then
        self:OnMainHeroUpdate();
    end
end

function ScreenEffectView:OnHpChange(oldValue,newValue)
	local curHpPercent = newValue / self.mainHero.unitAttr.hpLmt;
	if(curHpPercent < ConstTable["red_blood_flash_screen_rate"].p_int / 10000.0) then
		self:PlayFlashScreen();
	else
		self:StopFlashScreen();
	end

	if(newValue < oldValue) then
		self:PlayHurtScreen();
	end
end

function ScreenEffectView:PlayFlashScreen()
	if(self.flashScreenTweener == nil) then
		local color = self.imgFlashScreen.color;
		self.imgFlashScreen.color = Color(color.r,color.g,color.b,0.5);
		self.flashScreenTweener = self.imgFlashScreen:DOFade(1,0.5):SetAutoKill(false);
		self.flashScreenTweener:SetEase(DG.Tweening.Ease.Linear):SetLoops(-1,DG.Tweening.LoopType.Yoyo):Pause();
	end
	if(not self.flashScreenTweener:IsPlaying()) then
		self.flashScreenTweener:Restart();
		AudioSys.instance:Play(AudioDefine.HeatBeat);
	end
end

function ScreenEffectView:StopFlashScreen()
	if(self.flashScreenTweener ~= nil and self.flashScreenTweener:IsPlaying()) then
		self.flashScreenTweener:Pause();
		local color = self.imgFlashScreen.color;
		self.imgFlashScreen.color = Color(color.r,color.g,color.b,0);
		AudioSys.instance:Stop(AudioDefine.HeatBeat);
	end
end

function ScreenEffectView:PlayHurtScreen()
	self:StopHurtScreen();
	if(self.hurtScreenTweener == nil) then
		local color = self.imgHurtScreen.color;
		self.imgHurtScreen.color = Color(color.r,color.g,color.b,0.9);
		self.hurtScreenTweener = self.imgHurtScreen:DOFade(1,0.3):SetAutoKill(false);
		self.hurtScreenTweener:SetEase(DG.Tweening.Ease.Linear):SetLoops(2,DG.Tweening.LoopType.Yoyo):OnComplete(self.hurtComplete):Pause();
	end
	self.hurtScreenTweener:Restart();
end

function ScreenEffectView:StopHurtScreen()
	if(self.hurtScreenTweener ~= nil) then
		self.hurtScreenTweener:Pause();
		local color = self.imgHurtScreen.color;
		self.imgHurtScreen.color = Color(color.r,color.g,color.b,0);
	end
end

function ScreenEffectView:CloseView()
	self:ResetMainHero();
	 if(self.mainHeroUpdate ~= nil) then
         EventSys.instance:RemoveEvent(EEventType.OnMainHeroUpdate, self.mainHeroUpdate);
         self.mainHeroUpdate = nil;
    end
    if(self.flashScreenTweener ~= nil) then
    	self.flashScreenTweener:Kill(false);
    	self.flashScreenTweener = nil;
    end
    AudioSys.instance:Stop(AudioDefine.HeatBeat);
    if(self.hurtScreenTweener ~= nil) then
    	self.hurtScreenTweener:Kill(true);
    	self.hurtScreenTweener = nil;
    end
    self.hpChange = nil;
    self.heroDie = nil;
    self.hurtComplete = nil;
end

function ScreenEffectView:OnMainHeroUpdate()
    self:ResetMainHero();
    self.mainHero = BattleScene.instance.mainHero;
    if(self.mainHero ~= nil) then
    	self.mainHero.unitAttr.OnHpChange = self.mainHero.unitAttr.OnHpChange + self.hpChange;
    	self.mainHero.OnUnitDie = self.mainHero.OnUnitDie + self.heroDie;
    end
end

function ScreenEffectView:ResetMainHero()
	if(self.mainHero ~= nil) then
		self.mainHero.unitAttr.OnHpChange = self.mainHero.unitAttr.OnHpChange - self.hpChange;
		self.mainHero.OnUnitDie = self.mainHero.OnUnitDie - self.heroDie;
    	self.mainHero = nil;
	end
end

function ScreenEffectView:DestroyView()
end