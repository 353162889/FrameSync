﻿
--查看排行榜奖励界面
PlayerRankRewardBoxView = class("PlayerRankRewardBoxView",PlayerRankRewardBoxViewUI)

local this

local rewardItemList = {}
local curOpenRewardType = PlayerRankManager.boxType.courage

function PlayerRankRewardBoxView:Init()
	this = self
	self:RegeditEvent()
end

--刷新奖励道具
function PlayerRankRewardBoxView:RefreshRewardItem()
	for i = 1,3 do
		if not rewardItemList[i] then
			local data = {}
			if i == 1 then
				data.go = this.rewardItem
			else
				data.go = UnityEngine.GameObject.Instantiate(this.rewardItem)
				data.go.transform:SetParent(this.rewardLayout, false)
				local txt_rankNum = data.go.transform:Find("txt_rankNum"):GetComponent("Text")
				txt_rankNum.text = PlayerRankManager.GetRankStrByRankNum(i)
			end
			data.baseItemLayout = data.go.transform:Find("baseItemLayout")
			rewardItemList[i] = data
		end

	end
	
	for index,v in pairs(rewardItemList) do
		if not v.baseItemTable then 
			v.baseItemTable = {}
		end

		local reward = PlayerRankManager.GetRewardBoxData(curOpenRewardType,index)

		for rewardIndex,rewardData in pairs(reward) do
			local itemCode = rewardData.itemCode
			local itemNum = rewardData.itemNum
			local baseItem = v.baseItemTable[rewardIndex]
			if not baseItem then
				baseItem = IconItem.Create(v.baseItemLayout.gameObject)
				baseItem.go.transform.localScale = Vector3.New(0.8,0.8,0.8)
				v.baseItemTable[rewardIndex] = baseItem
			end
			-- print(itemCode)
			local configData = ItemTable[itemCode]
			baseItem:UpdateByCfg(configData, itemNum)
		end
		
	end
	
end

function PlayerRankRewardBoxView:OpenView(params)
	curOpenRewardType = params.intParam
	this:RefreshRewardItem()
	this:RefreshDescStr()
end

--刷新描述和标题
function PlayerRankRewardBoxView:RefreshDescStr()
	this.txt_title.text = ResAmusementTable[curOpenRewardType].reward_title
	this.txt_rewardTitle.text = PlayerRankManager.GetBoxDescByType(curOpenRewardType)
end	

function PlayerRankRewardBoxView:CloseView()

end


function PlayerRankRewardBoxView:DestroyView()

end

function PlayerRankRewardBoxView:ClosePanel()
	ViewSys.instance:Close("PlayerRankRewardBoxView")
end

function PlayerRankRewardBoxView:RegeditEvent()
	EventButtonListerer.Get(self.btn_sure, self.ClosePanel)
	local onClickClose = function (go)
		this:ClosePanel()
	end
	EventTriggerListener.Get(self.mask).onClick = EventTriggerListener.Get(self.mask).onClick + onClickClose

end