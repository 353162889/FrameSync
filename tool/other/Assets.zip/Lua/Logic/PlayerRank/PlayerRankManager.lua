﻿
PlayerRankManager = class(PlayerRankManager)

--排行榜类型 (对应活动类型)
PlayerRankManager.rankType = {}

--宝箱类型
PlayerRankManager.boxType = {}

--我的排行榜数据
PlayerRankManager.myRankData = {}

--其他玩家排行数据
PlayerRankManager.otherPlayerRankData = {}

--排行奖励数据
PlayerRankManager.rankRewardData = {}

--缓存玩家名字
PlayerRankManager.CachePlayerName = {}

PlayerRankManager.isGetRemainingData = false

function PlayerRankManager:Init()
	--排行榜类型  对应活动配置ID
	PlayerRankManager.rankType.maxKill = 1   --单局最大击杀
	PlayerRankManager.rankType.totalKill = 2   --总击杀

	PlayerRankManager.boxType.master = PlayerRankManager.rankType.maxKill  --大师宝箱
	PlayerRankManager.boxType.courage = PlayerRankManager.rankType.totalKill  --勇气宝箱

	--我的排行数据
	PlayerRankManager.myRankData[PlayerRankManager.rankType.maxKill] = {}
	PlayerRankManager.myRankData[PlayerRankManager.rankType.totalKill] = {}

	--其他玩家排行数据
	PlayerRankManager.otherPlayerRankData[PlayerRankManager.rankType.maxKill] = {}
	PlayerRankManager.otherPlayerRankData[PlayerRankManager.rankType.totalKill] = {}

	--宝箱奖励数据
	PlayerRankManager.rankRewardData[PlayerRankManager.rankType.maxKill] = {}
	PlayerRankManager.rankRewardData[PlayerRankManager.rankType.totalKill] = {}

	NetSys.instance:AddMsgCallback(EChannelType.EWorldChannel, S2C_AmusementActiveList, PlayerRankManager.S2C_AmusementActiveListRes, self)
	NetSys.instance:AddMsgCallback(EChannelType.EWorldChannel, S2C_AmusementKillCountInfoCallback, PlayerRankManager.S2C_AmusementKillCountInfoCallbackRes, self)
	NetSys.instance:AddMsgCallback(EChannelType.EWorldChannel, S2C_AmusementKillCountTopInfo, PlayerRankManager.S2C_AmusementKillCountTopInfoRes, self)
	NetSys.instance:AddMsgCallback(EChannelType.EWorldChannel, S2C_AmusementFetchRewardCallback, PlayerRankManager.S2C_AmusementFetchRewardCallbackRes, self)
end


-------------------------------------协议处理------------------------------------------------
--
function PlayerRankManager:S2C_AmusementActiveListRes(objMsg)
	print("S2C_AmusementActiveListRes")
	-- print(objMsg)
end

--个人信息
function PlayerRankManager:S2C_AmusementKillCountInfoCallbackRes(objMsg)
	print("排行榜个人信息推送")

	local msg = S2C_AmusementKillCountInfoCallbackData()
	msg:ParseFromString(objMsg)
	PlayerRankManager.myRankData[msg.amusement_id].data = msg
	EventSys.instance:DispatchLua(GameEvent.GetMyRankInfoRes)

	PlayerRankManager.isGetRemainingData = true

	if msg.amusement_id == AmusementType_Single_Kill_Count then
		LuaHelper.MarkNowTime(4,tostring(msg.next_time))
	elseif msg.amusement_id == AmusementType_Single_Total_Kill_Count then
		LuaHelper.MarkNowTime(3,tostring(msg.next_time))
	end

	-- print(msg.amusement_id)
	-- print(msg.next_time)   --剩余时间 (秒)
	-- print(msg.run_times)  --奖励周期数(活动开放次数)
	-- print(msg.curr_info.user_id)
	-- print(msg.curr_info.kill_count)
	print("本周排名:"..msg.curr_info.ranking)
	print("上周排名 : "..msg.last_info.ranking)
	-- print("是否已经领取过奖励:"..msg.last_info.fetch_reward_time)
end

--排行榜信息
function PlayerRankManager:S2C_AmusementKillCountTopInfoRes(objMsg)
	print("排行榜其他玩家信息推送")
	local msg = S2C_AmusementKillCountTopInfoData()
	msg:ParseFromString(objMsg)
	
	PlayerRankManager.otherPlayerRankData[msg.amusement_id] = msg.rank_list
	EventSys.instance:DispatchLua(GameEvent.GetOtherRankInfoRes)

	local ids = {}
	for k,v in ipairs(msg.rank_list) do
		if not PlayerRankManager.CachePlayerName[v.user_id] then
			-- print("排行榜-玩家ID:"..v.user_id)
			table.insert(ids, v.user_id)
		end
	end

	local OnCallBack = function(dataTable)
		for k,v in pairs(dataTable) do
			PlayerRankManager.CachePlayerName[v.user_id] = v.user_name
			-- print("ID:"..v.user_id)
			-- print("名字:"..v.user_name)
		end
		EventSys.instance:DispatchLua(GameEvent.GetRankOtherPlayerNameRes)
	end
	
	if #ids > 0 then
		FriendManager.QueryUserInfoFromID(ids,OnCallBack)
	end

	-- print("排行榜信息:")
	-- for k,v in ipairs(msg.rank_list) do
	-- 	print(v.user_id)
	-- 	print(v.kill_count)
	-- 	print(v.ranking)
	-- 	print(v.fetch_reward_time)
	-- end

	-- print(msg.rank_list)
	-- print(objMsg)
end

--获取奖励回复
function PlayerRankManager:S2C_AmusementFetchRewardCallbackRes(objMsg)
	print("获取奖励回复")

	local msg = S2C_AmusementFetchRewardCallbackData()
	msg:ParseFromString(objMsg)

	PlayerRankManager.rankRewardData[msg.amusement_id] = msg

	local data = ViewParam.New()
	data.intParam = msg.amusement_id
	ViewSys.instance:Open("PlayerRankGetRewardView",data)

	-- print(msg.amusement_id)
	-- print(msg.amusement_ranking)
	-- print(msg.reward_item_list)

	-- print("奖励:")
	-- print("长度:"..#msg.reward_item_list)
	--奖励:
	-- for k,v in ipairs(msg.reward_item_list) do
	-- 	print(v.config_id)
	-- 	print(v.count)
	-- end
	-- print("-------------")
end


-------------------------------------通用处理------------------------------------------------

--是否可以领取宝箱
function PlayerRankManager.IsCanGetBoxByType(type)
	local isCanGet = false

	local rankData = PlayerRankManager.myRankData[type].data
	if rankData and rankData.last_info.fetch_reward_time == 0 then
		-- print("排名 : "..rankData.last_info.ranking)
		local data = PlayerRankManager.GetRewardBoxData(type, rankData.last_info.ranking)
		-- print("奖励数量:"..#data)
		if #data > 0 then
			isCanGet = true
		end
	end

	-- if isCanGet then
	-- 	print("有奖励")
	-- else
	-- 	print("无奖励")
	-- end
	
	return isCanGet
end

--根据类型 获取自身排行数据
function PlayerRankManager.GetMyRankInfoByType(type)
	local data = {}
	data.rankNum = 0
	data.name = ""
	data.value = 0
	
	local rankData = PlayerRankManager.myRankData[type].data

	if rankData then
		-- print("存在信息")
		data.rankNum = rankData.curr_info.ranking
		data.name = MainLobbyManager.playerBaseInfo.name
		data.value = rankData.curr_info.kill_count
	end
	
	return data
end

--根据类型 获取排行榜所有玩家数据(策划配置数量)
function PlayerRankManager.GetRankListByType(type)
	local dataTable = {}

	local otherRankList = PlayerRankManager.otherPlayerRankData[type]
	for k,v in ipairs(otherRankList) do
		local data = {}
		data.rankNum = v.ranking
		data.name = PlayerRankManager.CachePlayerName[v.user_id] or ""
		data.value = v.kill_count
		table.insert(dataTable,data)
	end

	return dataTable
end

--获取排行榜标题名
function PlayerRankManager.GetRankTypeStrByType(type)
	local titleTypeStr = ""
	if type == PlayerRankManager.rankType.totalKill then
		titleTypeStr = "总击杀"
	elseif type == PlayerRankManager.rankType.maxKill then
		titleTypeStr = "单局最高击杀"
	end

	return titleTypeStr
end

--根据排名和类型 获取数据
function PlayerRankManager.GetRankDataByTypeAndIndex(type,index)
	local data = {}

	local dataList = PlayerRankManager.GetRankListByType(type)
	data = dataList[index]

	if not data then
		error("不存在排行数据 | type:"..type.."| index:"..index)
	end

	return data
end

----------------------
--获取排名显示字符串
function PlayerRankManager.GetRankStrByRankNum(rankNum)
	local rankStr = ""
	if rankNum == 1 then
		rankStr = "1st"
	elseif rankNum == 2 then
		rankStr = "2nd"
	elseif rankNum == 3 then
		rankStr = "3rd"
	end
	return rankStr
end

--获取宝箱描述信息
function PlayerRankManager.GetBoxDescByType(type)
	local descStr = ""
	if type == PlayerRankManager.boxType.courage then
		descStr = ResDescTable[1002].desc
	elseif type == PlayerRankManager.boxType.master then
		descStr = ResDescTable[1003].desc
	end
	return descStr
end

--获取自身奖励  可能为nil
function PlayerRankManager.GetMyRewardDataByType(type)
	local data = {}
	local rankNum = 0
	local rewardData = PlayerRankManager.rankRewardData[type]

	if rewardData then
		rankNum = rewardData.amusement_ranking
		for k,v in ipairs(rewardData.reward_item_list) do
			table.insert(data,{itemCode = v.config_id,itemNum = v.count})
		end
	end

	return data,rankNum
end

--排行榜宝箱奖励
function PlayerRankManager.GetRewardBoxData(type, rankNum)
	local data = {}

	local rewardTime = 1
	-- print("GetRewardBoxData type:"..type)
	local configData = ResAmusementTable[type]
	for index,v in ipairs(configData.ranking_setting) do
		if not string.find(v, "-") then
			if rankNum == tonumber(v) then
				local rewardID = configData.ranking_reward[index]
				local rewardData = ResAmusementRewardTable[tonumber(rewardID)]
				local rewardStr = rewardData.reward_list[rewardTime]
				local dataArr = rewardStr:split("#")
				for k,v in pairs(dataArr) do
					local rewardArr = v:split("|")
					local itemCode = tonumber(rewardArr[1])
					local itemNum = tonumber(rewardArr[2])
					table.insert(data,{itemCode = itemCode,itemNum = itemNum})
				end

			end
		end
	end

	return data
end