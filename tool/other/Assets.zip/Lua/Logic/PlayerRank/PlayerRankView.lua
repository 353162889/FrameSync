﻿

require "Logic/PlayerRank/PlayerRankTipView"
PlayerRankView = class("PlayerRankView",PlayerRankViewUI)

local this

--默认值
local rankItemSize = 60   --排行榜Item尺寸
local spacing = 10  --间隔距离

--当前选中查看排行类型
local curSelectRankType = PlayerRankManager.rankType.totalKill

--切换排行按钮table
local switchImageTable = {}

--排行榜对象
local rankObjList = {}

local enhancedScroll
local scroll_rankScroll
local rect_rankScroll
local playerRankTipView

function PlayerRankView:Init()
	this = self
	self:InitReference()  --初始化引用
	self:InitStatus() --初始化状态
	self:RegeditEvent()   --注册点击事件
end

--初始化引用
function PlayerRankView:InitReference()
	switchImageTable[PlayerRankManager.rankType.totalKill] = {
		txt_switchName = this.fightListBtn.transform:Find("txt_switchName").gameObject:GetComponent("Text"),
		select = this.fightListBtn.transform:Find("Select"),
		normal = this.fightListBtn.transform:Find("Normal")}

	switchImageTable[PlayerRankManager.rankType.maxKill] = {
		txt_switchName = this.rankListBtn.transform:Find("txt_switchName").gameObject:GetComponent("Text"),
		select = this.rankListBtn.transform:Find("Select"),
		normal = this.rankListBtn.transform:Find("Normal")}

	enhancedScroll = this.rankScroll:GetComponent("CommonEnhancedScroller")
	scroll_rankScroll = this.rankScroll:GetComponent("ScrollRect")
	rect_rankScroll = this.rankScroll:GetComponent("RectTransform")
	
end

--初始化状态
function PlayerRankView:InitStatus()
	this.txt_courageBoxName.text = ResAmusementTable[PlayerRankManager.boxType.courage].reward_title
	this.txt_masterBoxName.text = ResAmusementTable[PlayerRankManager.boxType.master].reward_title
	this.tipContainer:SetActive(false)
end

--刷新选中状态
function PlayerRankView:RefreshRankSelectStatus()
	for type,v in pairs(switchImageTable) do 
		if type == curSelectRankType then
			v.select.gameObject:SetActive(true)
			v.normal.gameObject:SetActive(false)
			-- v.txt_switchName.fontSize = 30
		else
			v.select.gameObject:SetActive(false)
			v.normal.gameObject:SetActive(true)
			-- v.txt_switchName.fontSize = 26
		end
	end
end

function PlayerRankView:RefreshRemainingTimeStr()
	if PlayerRankManager.isGetRemainingData == true then
		local str = ""
		if curSelectRankType == PlayerRankManager.rankType.maxKill then
			str = LuaHelper.GetTimeStr(4)
		elseif curSelectRankType == PlayerRankManager.rankType.totalKill then
			str = LuaHelper.GetTimeStr(3)
		end

		if not str then
			str = "00:00:00"
			-- this:GetRankInfoReq()
		end

		-- print("时间显示 : "..str)

		this.txt_remainingTime.text = str
	end
	
end

function PlayerRankView:OpenView()
	EventSys.instance:AddLuaEvent(GameEvent.GetMyRankInfoRes,this.RefreshAllRankInfo)
	EventSys.instance:AddLuaEvent(GameEvent.GetRankOtherPlayerNameRes,this.RefreshRankList)
	EventSys.instance:AddLuaEvent(GameEvent.GetOtherRankInfoRes,this.RefreshRankList)
	Main.AddUpdateFun(this.RefreshRemainingTimeStr, self, {interval = 1,callAtOnce = true})
	this:GetRankInfoReq()
	--全部状态刷新
	self:RefreshAllRankInfo()
end

function PlayerRankView:CloseView()
	EventSys.instance:RemoveLuaEvent(GameEvent.GetMyRankInfoRes,this.RefreshAllRankInfo)
	EventSys.instance:RemoveLuaEvent(GameEvent.GetRankOtherPlayerNameRes,this.RefreshRankList)
	EventSys.instance:RemoveLuaEvent(GameEvent.GetOtherRankInfoRes,this.RefreshRankList)
	Main.RemoveUpdateFun(this.RefreshRemainingTimeStr)
end

--请求排行榜信息
function PlayerRankView:GetRankInfoReq()
	for _,type in pairs(PlayerRankManager.rankType) do
		print("请求Type:"..type)
		local data = C2S_AmusementQueryInfoData()
		data.amusement_id = type
		NetSys.instance:SendWorldMsg(data:SerializeToString(), C2S_AmusementQueryInfo)
	end
end

--请求获取奖励
function PlayerRankView:GetBoxRewardByType(type)
	print("请求获取奖励")
	local data = C2S_AmusementFetchRewardData()
	data.amusement_id = type
	NetSys.instance:SendWorldMsg(data:SerializeToString(), C2S_AmusementFetchReward)
end

function PlayerRankView:DestroyView()

end

--刷新我的排行榜信息
function PlayerRankView:RefreshMyRankInfo()
	local data = PlayerRankManager.GetMyRankInfoByType(curSelectRankType)
	
	this:RefreshRankObjByRankNum(this.myRankInfo,data,true)
end

--刷新排行榜列表
function PlayerRankView:RefreshRankList()
	--排行列表数据
	local rankListDataTable = PlayerRankManager.GetRankListByType(curSelectRankType)

	local RefreshSingleRankByIndex = function(obj,index)
		local data = PlayerRankManager.GetRankDataByTypeAndIndex(curSelectRankType,index + 1)
		if data then
			this:RefreshRankObjByRankNum(obj,data)
		end
	end

	enhancedScroll:SetRefreshLuaFunc(RefreshSingleRankByIndex)
	enhancedScroll:InitEnhancedScroller(#rankListDataTable, rankItemSize)
end

--重新设置列表位置
function PlayerRankView:ResetRankListPosition()
	local showPos = 0
	local rankListDataTable = PlayerRankManager.GetRankListByType(curSelectRankType)
	local myData = PlayerRankManager.GetMyRankInfoByType(curSelectRankType)

	if myData.rankNum < #rankListDataTable then
		showPos = (myData.rankNum - 1) * (rankItemSize + spacing)
		local scrollHeight = scroll_rankScroll.content.rect.height
		local maxHight = scrollHeight - rect_rankScroll.rect.height
		-- print("scrollHeight : "..scrollHeight)
		if scrollHeight > 0 then
			if showPos > maxHight then
				showPos = maxHight
			end
		end
	end

	enhancedScroll:SetScrollPosition(showPos)
end

--刷新排行榜数据显示
function PlayerRankView:RefreshRankObjByRankNum(obj, data, isMyself)
	local img_rankIcon = obj.transform:Find("img_rankIcon").gameObject
	local txt_rankNum = obj.transform:Find("txt_rankNum"):GetComponent("Text")
	local txt_playerName = obj.transform:Find("txt_playerName"):GetComponent("Text")
	local txt_playerValue = obj.transform:Find("txt_playerValue"):GetComponent("Text")
	local myInfoBg = obj.transform:Find("myInfoBg").gameObject
	local otherInfoBg = obj.transform:Find("otherInfoBg").gameObject

	local color = Color.New(147/255,140/255,103/255,255)
	if isMyself then
		color = Color.New(1,1,1,1)
		myInfoBg:SetActive(true)
		otherInfoBg:SetActive(false)
	else
		myInfoBg:SetActive(false)
		otherInfoBg:SetActive(true)
	end
	txt_rankNum.color = color
	txt_playerName.color = color
	txt_playerValue.color = color

	txt_rankNum.text = data.rankNum
	txt_playerName.text = data.name
	txt_playerValue.text = data.value

	-- print(data.rankNum)
	if data.rankNum > 3 then
		img_rankIcon:SetActive(false)
		return
	else
		img_rankIcon:SetActive(true)
	end

	local image = img_rankIcon:GetComponent("Image")
	local sprite
	if data.rankNum == 1 then
		sprite = this.img_rank1.sprite
	elseif data.rankNum == 2 then
		sprite = this.img_rank2.sprite
	elseif data.rankNum == 3 then
		sprite = this.img_rank3.sprite
	end

	if sprite then
		image.sprite = sprite
		image:SetNativeSize()
	end
end



--刷新所有信息 (排行信息和选中状态)
function PlayerRankView:RefreshAllRankInfo()
	--刷新选中状态
	this:RefreshRankSelectStatus()

	--刷新我的排行榜信息
	this:RefreshMyRankInfo()

	--刷新排行榜列表
	this:RefreshRankList()

	--重新设置列表位置
	this:ResetRankListPosition()

	--刷新排行榜排行类型标题
	this:RefreshRankTitle()

	--刷新剩余时间倒计时
	this:RefreshRemainingTimeStr()

	--刷新宝箱状态
	this:RefreshRewardBoxStatus()
end

--刷新宝箱状态
function PlayerRankView:RefreshRewardBoxStatus()
	if PlayerRankManager.IsCanGetBoxByType(PlayerRankManager.boxType.courage) then
		this.eff_ui_couragebox:SetActive(true)
	else
		this.eff_ui_couragebox:SetActive(false)
	end

	if PlayerRankManager.IsCanGetBoxByType(PlayerRankManager.boxType.master) then
		this.eff_ui_masterBox:SetActive(true)
	else
		this.eff_ui_masterBox:SetActive(false)
	end
end

function PlayerRankView:RefreshRankTitle()
	this.txt_valueType.text = PlayerRankManager.GetRankTypeStrByType(curSelectRankType)
end

function PlayerRankView:ShowFightList()
	if curSelectRankType == PlayerRankManager.rankType.totalKill then
		return
	end
	curSelectRankType = PlayerRankManager.rankType.totalKill
	this:RefreshAllRankInfo()
end

function PlayerRankView:ShowRankList()
	if curSelectRankType == PlayerRankManager.rankType.maxKill then
		return
	end
	curSelectRankType = PlayerRankManager.rankType.maxKill
	this:RefreshAllRankInfo()
end

--显示提示信息
function PlayerRankView:ShowRankTips()
	-- print("点击")
	if not playerRankTipView then
		playerRankTipView = PlayerRankTipView.new()
		playerRankTipView:Init(this.tipContainer)
	end

	playerRankTipView:OpenView()
end

function PlayerRankView:ShowCourageBox()
	this:HandleClickBox(PlayerRankManager.boxType.courage)
end

function PlayerRankView:ShowMasterBox()
	this:HandleClickBox(PlayerRankManager.boxType.master)
end

--处理点击宝箱
function PlayerRankView:HandleClickBox(boxType)
	local data = ViewParam.New()
	data.intParam = boxType
	if PlayerRankManager.IsCanGetBoxByType(boxType) then
		this:GetBoxRewardByType(boxType)
		
	else
		ViewSys.instance:Open("PlayerRankRewardBoxView",data)
	end
end

function PlayerRankView:ClosePanel(params)
	ViewSys.instance:Close("PlayerRankView")
end

function PlayerRankView:RegeditEvent()
	EventButtonListerer.Get(self.closeBtn, self.ClosePanel)
	EventButtonListerer.Get(self.fightListBtn, self.ShowFightList)
	EventButtonListerer.Get(self.rankListBtn, self.ShowRankList)
	EventButtonListerer.Get(self.tipsBtn, self.ShowRankTips)
	EventButtonListerer.Get(self.btn_courageBox, self.ShowCourageBox)
	EventButtonListerer.Get(self.btn_masterBox, self.ShowMasterBox)
end