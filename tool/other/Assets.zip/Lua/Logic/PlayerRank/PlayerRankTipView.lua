﻿
PlayerRankTipView = class("PlayerRankTipView",ItemTipViewUI)

local this
function PlayerRankTipView:Init(go)
	this = self
	this.go = go
	this.transform = go.transform
	this.tipsBg = this.transform:Find("tipsBg")
	this.txt_tipStr = this.transform:Find("tipsBg/txt_tipStr"):GetComponent("Text")

	this.txt_tipStr.text = ResDescTable[1001].desc

	local onClickClose = function (go)
		this:CloseView()
	end
	EventTriggerListener.Get(self.go).onClick = EventTriggerListener.Get(self.go).onClick + onClickClose
end

function PlayerRankTipView:OpenView()
	

	this.go:SetActive(true)
	this.tipsBg.localScale = Vector3.New(0,0,0)

	local mySequence = DG.Tweening.DOTween.Sequence()
	mySequence:Append(this.tipsBg:DOScale(1.1,0.12))
	mySequence:Append(this.tipsBg:DOScale(1,0.07))
	mySequence:Play()
end

function PlayerRankTipView:CloseView()
	this.go:SetActive(false)
end

function PlayerRankTipView:DestroyView()
	
end
