﻿
--领取排行榜奖励界面
PlayerRankGetRewardView = class("PlayerRankGetRewardView",PlayerRankGetRewardViewUI)

local this

local curOpenRewardType = PlayerRankManager.boxType.courage
local rewardItemTable = {}

function PlayerRankGetRewardView:Init()
	this = self
	self:RegeditEvent()
end

function PlayerRankGetRewardView:OpenView(params)
	curOpenRewardType = params.intParam

	local rewardData,rankNum = PlayerRankManager.GetMyRewardDataByType(curOpenRewardType)

	local rewardTitleStr = ResAmusementTable[curOpenRewardType].reward_title .."-".. PlayerRankManager.GetRankStrByRankNum(rankNum)
	this.txt_rewardTitle.text = rewardTitleStr

	-- print(curOpenRewardType)
	for k,v in pairs(rewardItemTable) do
		v.go:SetActive(false)
	end
	-- print("OpenView")
	
	for index,v in pairs(rewardData) do
		local itemCode = v.itemCode
		local itemNum = v.itemNum
		local baseItem = rewardItemTable[index]
		if not baseItem then
			baseItem = IconItem.Create(this.rewardLayout)
			rewardItemTable[index] = baseItem
		end

		baseItem.go:SetActive(true)
		local configData = ItemTable[itemCode]
		baseItem:UpdateByCfg(configData, itemNum)

		-- print(v.itemCode)
	end
end

function PlayerRankGetRewardView:CloseView()

end


function PlayerRankGetRewardView:DestroyView()

end

function PlayerRankGetRewardView:ClosePanel()
	ViewSys.instance:Close("PlayerRankGetRewardView")
end

function PlayerRankGetRewardView:RegeditEvent()

	EventButtonListerer.Get(self.btn_sure, self.ClosePanel)
	local onClickClose = function (go)
		this:ClosePanel()
	end
	EventTriggerListener.Get(self.mask).onClick = EventTriggerListener.Get(self.mask).onClick + onClickClose

end