GameEvent = {}

--使用方法
GameEvent.EventLst = 
{
	"OnBagUpdate",--背包更新
	"OnItemUpdate",--物品更新
	"PlayerResourcesUpdate",--人物属性变更
	"MatchResult",--匹配结果
	"CancelMatch",--取消匹配成功
	"StartMatch",--开始进入协议
	"Rename",--重命名成功
	"LoginDataInitComplete",--登录数据初始化完成
	"HeroSync",	--英雄更新
	"TimeRewardUpdate",
	"LoginSuccess",--登入成功
	"UpdateFriendData",--好友数据更新
	"FightFinish",--战斗结束
	"HeadPictureChange",--头像更新
	"RankViewVisiable",--排行榜隐藏显示
	"GetMyRankInfoRes",--排行榜获取自己信息回调
	"GetOtherRankInfoRes",--排行榜获取其他玩家信息回调
	"GetRankOtherPlayerNameRes",--排行榜获取其他玩家信息回调
};


for k,v in pairs(GameEvent.EventLst) do
	GameEvent[v] = k;
end