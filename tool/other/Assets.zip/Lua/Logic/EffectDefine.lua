EffectDefine = {}

EffectDefine.KillGetCoin = "eff_getCoin";	--击杀获取金币
EffectDefine.DieLostCoin = "eff_LoseCoin";	--死亡丢失金币