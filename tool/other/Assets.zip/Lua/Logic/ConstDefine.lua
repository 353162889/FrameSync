ConstDefine = {}

-- ConstDefine.GoldId = 900001;
-- ConstDefine.SilverId = 900002;