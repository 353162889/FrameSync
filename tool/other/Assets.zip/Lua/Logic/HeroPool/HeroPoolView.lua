require "Logic/HeroPool/HeroPoolItem"

HeroPoolView = class("HeroPoolView", HeroPoolViewUI);

local _this = nil;

function HeroPoolView:Init()
    _this = self;
    self.mHeroItemTable = {};
    self.mFilterShowHave = false;
    self.mFilterShowClose = false;
    self.mFilterShowRemote = false;
    self.mFilterShowAll = true;
    self.mfilterCurrentToggleOn = nil;

    local allHeroIDs = Util.Split(ConstTable["lobby_fight_hero"].p_string, ',');
    for i = 1, #allHeroIDs do
        local nResId = tonumber(allHeroIDs[i]);
        self:AddItem(nResId);
    end

    self.toggleHave.isOn = self.mFilterIsHave;
    self.toggleHave.onValueChanged:AddListener(self.OnToggleHaveChange);

    self.toggleClose.isOn = false;
    self.toggleClose.onValueChanged:AddListener(self.OnToggleCloseChange);

    self.toggleRemote.isOn = false;
    self.toggleRemote.onValueChanged:AddListener(self.OnToggleRemoteChange);

    self.toggleAll.isOn = true;
    self.toggleAll.onValueChanged:AddListener(self.OnToggleAllChange);
    self.mfilterCurrentToggleOn =  self.toggleAll;

    EventButtonListerer.Get(self.btnReturn, self.OnBack);
end

function HeroPoolView:OpenView()
    self:Refresh();
end

function HeroPoolView:AddItem(nResId)
    local cPrefab = CResourceSys.instance:Load(EResType.EView, "HeroPool/HeroPoolItem.prefab");
    local cObject = CGameObjectPool.instance:Get(cPrefab);
    local cItem = HeroPoolItem.new();

    cItem:InitView(cObject);
    cItem:InitItem(self.content, nResId);
    table.insert(self.mHeroItemTable, cItem);
end

function HeroPoolView:Refresh()
    for k, cItem in ipairs(self.mHeroItemTable) do
        local bCanShow = cItem:CanShow(self.mFilterShowHave, self.mFilterShowClose, self.mFilterShowRemote,self.mFilterShowAll);
        if bCanShow then
            cItem:Refresh();
            if cItem.mIsHave then
                cItem.transform:SetAsFirstSibling();
            end
        end
        cItem.gameObject:SetActive(bCanShow);
    end
end

function HeroPoolView:GetHeroIdx(nResId)
    for k, cItem in ipairs(self.mHeroItemTable) do
        if (nResId == cItem.mResId) then
            return k;
        end
    end
    return 0;
end

function HeroPoolView:GetLeftHeroId(nResId)
    local nIdx = self:GetHeroIdx(nResId);
    local nNewIdx = nIdx - 1;
    if nNewIdx <= 0 then
        nNewIdx = #self.mHeroItemTable;
    end
    return self.mHeroItemTable[nNewIdx].mResId;
end

function HeroPoolView:GetRightHeroId(nResId)
    local nIdx = self:GetHeroIdx(nResId);
    local nNewIdx = nIdx + 1;
    if nNewIdx > #self.mHeroItemTable then
        nNewIdx = 1;
    end
    return self.mHeroItemTable[nNewIdx].mResId;
end

function HeroPoolView:GetHeroPieceCount(heroID)
	local resHero = HeroTable[heroID];
	if(resHero ~= nil) then
		local lstItems = ItemMgr.GetItemsByConfigId(resHero.piece_type);
		if(#lstItems > 0) then
			return lstItems[1]:GetCount();
		else
			return 0;
		end
	end
	return 0;	
end

function HeroPoolView.OnBack()
    ViewSys.instance:Close();
end

function HeroPoolView.OnToggleHaveChange(bEnable)
    HeroPoolView.mFilterShowHave = bEnable;
    HeroPoolView:Refresh();
end

function HeroPoolView.OnToggleCloseChange(bEnable)
    print("近战"..tostring(bEnable));
    _this.mfilterCurrentToggleOn.isOn = false;
    _this.mfilterCurrentToggleOn = _this.toggleClose;
    _this.mFilterShowClose = bEnable;
    HeroPoolView.OnSetToggleCanClick(_this.toggleClose,not bEnable)
    HeroPoolView:Refresh();
end

function HeroPoolView.OnToggleRemoteChange(bEnable)
    print("远程"..tostring(bEnable));
    _this.mfilterCurrentToggleOn.isOn = false;
    _this.mfilterCurrentToggleOn = _this.toggleRemote;
    _this.mFilterShowRemote = bEnable;
    HeroPoolView.OnSetToggleCanClick(_this.toggleRemote,not bEnable)
    HeroPoolView:Refresh();
end


function HeroPoolView.OnToggleAllChange(bEnable)
    print("全部"..tostring(bEnable));
    _this.mfilterCurrentToggleOn.isOn = false;
    _this.mfilterCurrentToggleOn = _this.toggleAll;
    _this.mFilterShowAll = bEnable;
    HeroPoolView.OnSetToggleCanClick(_this.toggleAll,not bEnable)
    HeroPoolView:Refresh();
end
                                                                                                                     
function HeroPoolView.OnSetToggleCanClick(Toggle,isCan)
    local img1 =  Toggle.transform:GetChild(0):GetComponent("Image");
    local img2 = img1.transform:GetChild(0):GetComponent("Image");
    img1.raycastTarget = isCan;
    img2.raycastTarget = isCan;
end