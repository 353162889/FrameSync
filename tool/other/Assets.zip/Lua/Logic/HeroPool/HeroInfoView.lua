require "Logic/HeroPool/HeroSkinItem"

HeroInfoView = class("HeroInfoView", HeroInfoViewUI);

function HeroInfoView:Init()
    self.mHeroResId = 0;
    self.mHeroSkinId = 0;
    self.mSkinItemTable = {};
    self.mSkinItemPool = {};

    HeroInfoView.widgetStory:SetActive(false);
    HeroInfoView.widgetSkin:SetActive(false);
    self.toggleSkill.onValueChanged:AddListener(self.OnToggleSkillChange);
    self.toggleStory.onValueChanged:AddListener(self.OnToggleStoryChange);
    self.toggleSkin.onValueChanged:AddListener(self.OnToggleSkinChange);
    self.toggleSkill.isOn = true;

    EventButtonListerer.Get(self.btnReturn, self.OnBack);
    EventButtonListerer.Get(self.btnUnlock, self.OnBuy);
    EventButtonListerer.Get(self.btnBuy, self.OnBuy);

    EventButtonListerer.Get(self.btnHeroLeft, self.OnLeftHero);
    EventButtonListerer.Get(self.btnHeroRight, self.OnRightHero);

    self:UpdatePlayerResources();
    EventSys.instance:AddLuaEvent(GameEvent.PlayerResourcesUpdate, HeroInfoView.UpdatePlayerResources);
end

function HeroInfoView:DestroyView()
    EventSys.instance:RemoveLuaEvent(GameEvent.PlayerResourcesUpdate, HeroInfoView.UpdatePlayerResources);
end

function HeroInfoView:ClearView()
    self.mHeroResId = 0;
    self.mHeroSkinId = 0;
end

function HeroInfoView:Refresh()
    self:RefreshSkinInfo();
    self:RefreshRightView(self.mHeroSkinId);
end

function HeroInfoView:RefreshHeroInfo(nResId)
    self:ClearView();

    self.mHeroResId = nResId;
    self:RefreshSkillInfo();
    self:RefreshStoryInfo();
    self:RefreshSkinInfo();
    self:RefreshRightView(self.mHeroResId);
end

function HeroInfoView:RefreshSkillInfo()
    local resSkill = SkillTable[self.mHeroResId];
    self.txtNormalAtkTitle.text = "普通攻击";
    self.txtNormalAtkContent.text = resSkill.attack1 .. "\n" .. resSkill.attack2;

    local nSkillId = HeroTable[self.mHeroResId].active_skill[3];
    self.txtSkillContent.text = resSkill.skill;
    self.iconSkill.sprite = CResourceSys.instance:Load(EResType.EIcon, "Skill/" .. nSkillId .. ".png");
    local skillData = SkillDataMgr.instance:Get(nSkillId);
    self.txtSkillTitle.text = skillData.mName;
end

function HeroInfoView:RefreshStoryInfo()
    local resHeroData = HeroTable[self.mHeroResId];
    self.txtStoryContent.text = resHeroData.describe;
    self.txtStoryTitle.text = resHeroData.describe_title;
end

function HeroInfoView:RefreshSkinInfo()
    for i = #self.mSkinItemTable, 1, -1 do
        local cItem = self.mSkinItemTable[i];
        cItem.gameObject:SetActive(false);
        table.remove(self.mSkinItemTable,i)
        table.insert(self.mSkinItemPool, cItem);
    end

    local arrSkin = HeroTable[self.mHeroResId].avatar_skin;
    for k, v in ipairs(arrSkin) do
        local cItem = self:CreateSkinItem();
        cItem:InitItem(self.skinContent, v);
    end
end

function HeroInfoView:CreateSkinItem()
    local cItem = nil;
    if #self.mSkinItemPool > 0 then
        cItem = table.remove(self.mSkinItemPool, 1);
        cItem.gameObject:SetActive(true);
    else
        cItem = HeroSkinItem.new();
        local cPrefab = CResourceSys.instance:Load(EResType.EView, "HeroPool/HeroSkinItem.prefab");
        local cObject = CGameObjectPool.instance:Get(cPrefab);
        cItem:InitView(cObject);
    end

    table.insert(self.mSkinItemTable, cItem);
    return cItem;
end

function HeroInfoView:RefreshRightView(nSkinId)
    self.mHeroSkinId = nSkinId;

    local resData = HeroTable[self.mHeroResId];
    self.txtSkinName.text = resData.hero_name;
    self.iconHeroSkin.sprite = CResourceSys.instance:Load(EResType.EIcon, "HeroIcon/"..resData.id..".png")

    self.objRemote:SetActive(not resData.is_remote);
    self.objClose:SetActive(resData.is_remote);

    local bIsHave = MainLobbyManager.IsSkinHave(self.mHeroResId, nSkinId)
    self.objSkinHave:SetActive(bIsHave);
    self.objBuyInfo:SetActive(not bIsHave);

    if not bIsHave then
        local nCurPiece = HeroPoolView:GetHeroPieceCount(self.mHeroResId);
        self.txtPieceValue.text = nCurPiece;
        self.txtPieceMax.text = resData.piece_amount;
        self.txtSkinMoney.text = math.ceil(resData.unlock_amount * ((resData.piece_amount - nCurPiece) / resData.piece_amount));

        self.btnUnlock:SetActive(resData.piece_amount == nCurPiece);
        self.btnBuy:SetActive(resData.piece_amount ~= nCurPiece);

        local strIconName = ItemTable[resData.piece_type].icon;
        self.iconHeroHead.sprite = CResourceSys.instance:Load(EResType.EIcon, strIconName)
    end
end

function HeroInfoView.UpdatePlayerResources()
	HeroInfoView.txtSilverValue.text = MainLobbyManager.playerBaseInfo.silver;
	HeroInfoView.txtGoldValue.text = MainLobbyManager.playerBaseInfo.gold;
end

function HeroInfoView.OnBack()
    ViewSys.instance:Close();
end

function HeroInfoView.OnToggleSkillChange(bEnable)
    HeroInfoView.widgetSkill:SetActive(bEnable);
    HeroInfoView.txtPageValue.text = "1";
end

function HeroInfoView.OnToggleStoryChange(bEnable)
    HeroInfoView.widgetStory:SetActive(bEnable);
    HeroInfoView.txtPageValue.text = "2";
end

function HeroInfoView.OnToggleSkinChange(bEnable)
    HeroInfoView.widgetSkin:SetActive(bEnable);
    HeroInfoView.txtPageValue.text = "3";
end

function HeroInfoView.OnBuy()
    if HeroInfoView.mHeroSkinId <= 0 then
        return;
    end

    local isHeroBuy = MainLobbyManager.IsHeroBuy(HeroInfoView.mHeroSkinId);
	if isHeroBuy ~= true then
		--买英雄
		local data = C2S_BuyHeroData();
	    data.hero_id = HeroInfoView.mHeroSkinId;
	    NetSys.instance:SendWorldMsg(data:SerializeToString(), C2S_BuyHero); 
	else 
		--买皮肤
		local data1 = C2S_BuyHeroSkinData();
	    data1.skin_id = HeroInfoView.mHeroSkinId;
	    NetSys.instance:SendWorldMsg(data1:SerializeToString(), C2S_BuyHeroSkin); 
	end
end

function HeroInfoView.OnLeftHero()
    HeroInfoView:RefreshHeroInfo(HeroPoolView:GetLeftHeroId(HeroInfoView.mHeroResId));
end

function HeroInfoView.OnRightHero()
    HeroInfoView:RefreshHeroInfo(HeroPoolView:GetRightHeroId(HeroInfoView.mHeroResId));
end
