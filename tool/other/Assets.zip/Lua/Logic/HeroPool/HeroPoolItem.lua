require "Generate/HeroPoolItemUI"

HeroPoolItem = class("HeroPoolItem", HeroPoolItemUI);

function HeroPoolItem:Init()
    self.funClick = function() self:OnClick(); end
    EventButtonListerer.Get(self.gameObject, self.funClick);
    self.mResId = 0;
    self.mIsRemote = false;
    self.mIsClose = false;
    self.mIsHave = false;
end

function HeroPoolItem:InitItem(transParent, nResId)
    self.mResId = nResId;
    print(self.nResId);
    self.transform:SetParent(transParent); 
    self.transform.localScale = Vector3.one;

    local resData = HeroTable[nResId];
    self.mIsRemote = resData.is_remote;
    self.mIsClose = not self.mIsRemote;

    self:Refresh();
end

function HeroPoolItem:CanShow(bShowHave, bShowClose, bShowRemote,bShowAll)
    if (not MainLobbyManager.IsHeroBuy(self.mResId) and bShowHave) then
        return false;
    end

    print("name:"..HeroTable[self.mResId].hero_name.."--bShowAll:"..tostring(bShowAll).."--bShowClose:"..tostring(bShowClose).."--bShowRemote:"..tostring(bShowRemote));

    if (self.mIsClose and  bShowClose) then
        return true;
    end

    if (self.mIsRemote and bShowRemote) then
        return true;
    end
  
    return bShowAll;
end

function HeroPoolItem:OnClick()
    ViewSys.instance:Open("HeroInfoView");
    HeroInfoView:RefreshHeroInfo(self.mResId);
end

function HeroPoolItem:Refresh()
    local resData = HeroTable[self.mResId];
    self.name.text = resData.hero_name;
    self.icon.sprite = CResourceSys.instance:Load(EResType.EIcon, resData.bigIcon);

    self.mIsHave = MainLobbyManager.IsHeroBuy(self.mResId);
    self.mask:SetActive(not self.mIsHave);

    local nCurPiece = HeroPoolView:GetHeroPieceCount(self.mResId);
    self.spot:SetActive(nCurPiece == resData.piece_amount);
end