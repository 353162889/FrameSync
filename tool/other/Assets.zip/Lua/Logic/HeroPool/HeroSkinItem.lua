require "Generate/HeroSkinItemUI"

HeroSkinItem = class("HeroSkinItem", HeroSkinItemUI);

function HeroSkinItem:Init()
    self.funClick = function() self:OnClick(); end
    EventButtonListerer.Get(self.gameObject, self.funClick);
    self.mResId = 0;
end

function HeroSkinItem:InitItem(transParent, nResId)
    self.mResId = nResId;
    self.transform:SetParent(transParent); 
    self.transform.localScale = Vector3.one;

    local resData = HeroTable[nResId];
    self.icon.sprite = CResourceSys.instance:Load(EResType.EIcon, resData.bigIcon);

    local bIsHave = MainLobbyManager.IsSkinHave(self.mResId, self.mResId)
    self.have:SetActive(bIsHave);
    self.notHave:SetActive(not bIsHave);
end

function HeroSkinItem:OnClick()
    HeroInfoView:RefreshRightView(self.mResId);
end