TimeRewardMgr = {}
TimeRewardMgr.times = 0;
TimeRewardMgr.maxTimes = 0;
TimeRewardMgr.leaveTime = 0;

function TimeRewardMgr.Init()
	-- body
	for k,v in pairs(MediaTable) do
		if(v.times > TimeRewardMgr.maxTimes) then
			TimeRewardMgr.maxTimes = v.times;
		end
	end
	NetSys.instance:AddMsgCallback(EChannelType.EWorldChannel, S2C_TimeRewardInfo, TimeRewardMgr.S2C_TimeRewardInfoData, nil);
	NetSys.instance:AddMsgCallback(EChannelType.EWorldChannel, S2C_ReceiveTimeRewardResult, TimeRewardMgr.S2C_ReceiveTimeRewardResultData, nil);
	Main.AddUpdateFun(TimeRewardMgr.Update,nil);
end

function TimeRewardMgr.OpenRewardView()
	if(TimeRewardMgr.HasRewardCanGet()) then
		ViewSys.instance:Open("TimeRewardView");
	else
		TipMgr.ShowTipType2("你今天的奖励已经全部领取",nil);
	end
end

function TimeRewardMgr.HasRewardCanGet()
	return TimeRewardMgr.times < TimeRewardMgr.maxTimes;
end

function TimeRewardMgr.CanReceiveReward()
	if(TimeRewardMgr.leaveTime <= 0 and TimeRewardMgr.HasRewardCanGet()) then
		return true;
	end
	return false;
end

function TimeRewardMgr.ReceiveReward()
	if(not TimeRewardMgr.CanReceiveReward()) then
		Util.LogColor("#ff0000","剩余次数或剩余时间条件没达到","TimeRewardMgr.leaveTime",TimeRewardMgr.leaveTime,"TimeRewardMgr.times",TimeRewardMgr.times);	 
		return
	end
	local data = C2S_ReceiveTimeRewardData();
	NetSys.instance:SendWorldMsg(data:SerializeToString(), C2S_ReceiveTimeReward);
	Util.LogColor("#ff0000","TimeRewardMgr.ReceiveReward");
end

function TimeRewardMgr.Update(obj,deltaTime)
	if(TimeRewardMgr.leaveTime > 0) then
		TimeRewardMgr.leaveTime = TimeRewardMgr.leaveTime - deltaTime;
		if(TimeRewardMgr.leaveTime <= 0) then
			TimeRewardMgr.leaveTime = 0;
			--派发可以领奖励时间
			EventSys.instance:DispatchLua(GameEvent.TimeRewardUpdate);
		end
	end
end

function TimeRewardMgr.S2C_TimeRewardInfoData(obj,objMsg)
	local msg = S2C_TimeRewardInfoData();
	msg:ParseFromString(objMsg);
	TimeRewardMgr.times = msg.times;
	TimeRewardMgr.leaveTime = msg.rewardTime;
	EventSys.instance:DispatchLua(GameEvent.TimeRewardUpdate);
	Util.LogColor("#ff0000","S2C_TimeRewardInfoData","TimeRewardMgr.times",TimeRewardMgr.times,"TimeRewardMgr.leaveTime",TimeRewardMgr.leaveTime);
end

function TimeRewardMgr.S2C_ReceiveTimeRewardResultData(obj,objMsg)
	Util.LogColor("#ff0000","S2C_ReceiveTimeRewardResultData");
	local msg = S2C_ReceiveTimeRewardResultData();
	msg:ParseFromString(objMsg);
	if(msg.error_num ~= Error_None) then
		TipMgr.ShowTipType2("领取奖励失败",nil);
		Util.LogColor("#ff0000","领取奖励失败",msg.error_num);
	else
		EventSys.instance:DispatchLua(GameEvent.TimeRewardUpdate);
	end
end