TimeRewardView = class("TimeRewardView",TimeRewardViewUI)

function TimeRewardView:Init()
	local onClickYes = function (go)
		self:OnClickYes();
	end
	EventTriggerListener.Get(self.yesBtn).onClick = EventTriggerListener.Get(self.yesBtn).onClick + onClickYes;

	local onClickClose = function (go)
		self:OnClickClose();
	end
	EventTriggerListener.Get(self.mask).onClick = EventTriggerListener.Get(self.mask).onClick + onClickClose;

	self.lstReward = {};
end

function TimeRewardView:OpenView(param)
	Main.AddUpdateFun(TimeRewardView.Update,self);
	self:UpdateDesc();
	self:UpdateReward();
end

function TimeRewardView:Update(deltaTime)
	self:UpdateDesc();
end

function TimeRewardView:UpdateDesc()
	-- body
	if(TimeRewardMgr.leaveTime > 0) then
		local min = math.floor(TimeRewardMgr.leaveTime / 60);
		local second = math.ceil(TimeRewardMgr.leaveTime % 60);
		if(min < 10) then min = "0"..min; end
		if(second < 10) then second = "0"..second;end;
		self.titleContent.text = tostring(min)..":"..tostring(second).."后领取奖励";
	else
		self.titleContent.text = "领取奖励";
	end
end

function TimeRewardView:UpdateReward()
	for i=1,#self.lstReward do
		self.lstReward[i]:SetActive(false);
	end
	local borns = nil;
	if(TimeRewardMgr.HasRewardCanGet()) then
		for k,v in pairs(MediaTable) do
			if(v.times == TimeRewardMgr.times + 1) then
				borns = {};
				local items = v.items;
				local itemCount = #items;
				for i=1,itemCount do
					local strItem = items[i];
					local strArrItem = Util.Split(strItem,"|");
					local id = tonumber(strArrItem[1]);
					local count = tonumber(strArrItem[2]);
					table.insert(borns,{ItemTable[id],count})
				end
				break;
			end
		end
	end
	if(borns == nil) then return end
	local index = 1;
	for i=1,#borns do
		local cfg = borns[i][1];
		local count = borns[i][2];
		if(#self.lstReward < i) then
			local iconItem = IconItem.Create(self.itemContent);
			table.insert(self.lstReward,iconItem);
		end
		print("----------------------------------------count"..count)
		self.lstReward[i]:UpdateByCfg(cfg,count);
		self.lstReward[i]:SetActive(true);
		index = index + 1;
	end
	for i=index,#self.lstReward do
		self.lstReward[i]:SetActive(false);
	end
end

function TimeRewardView:CloseView()
	Main.RemoveUpdateFun(TimeRewardView.Update);
end

function TimeRewardView:OnClickYes()
	TimeRewardMgr.ReceiveReward();
	self:OnClickClose();
end

function TimeRewardView:OnClickClose()
	ViewSys.instance:Close("TimeRewardView");
end

function TimeRewardView:DestroyView()
	for i=1,#self.lstReward do
		self.lstReward[i]:Destroy();
	end
	self.lstReward = {};
end