﻿--From Lua Script Create
--ClassName: SignInSystem
--Author:    hukiry
--CreateTime:2018-6-27

SignInSystem={}

local viewControl={};

local ItemLists={};

function SignInSystem.Init(view)
	print("签到系统初始化");
	viewControl=view;
	SignInSystem.RegisterBtnEvent();
	SignInSystem.InitItem();
	SignInSystem.ViewUpdate(ActiveSystemManager.receiveCount,ActiveSystemManager.isTodayReceived);
end

function SignInSystem.Open()
	print("签到系统打开");
	viewControl.SetTitle("签到");
	
end

function SignInSystem.Close()
	print("签到系统关闭");
	
end

function SignInSystem.RegisterBtnEvent()
	print("签到系统注册按钮事件")
	EventButtonListerer.Get(viewControl.signInBtn, SignInSystem.OnSignInClick)
end

function SignInSystem.OnSignInClick()
	print("SignIn按钮点击")
	if(ActiveSystemManager.isTodayReceived==true)then
		print("今天已被领取");
	else
		print("请求领取");
		local data = C2S_FetchSignOnRewardData();
		NetSys.instance:SendWorldMsg(data:SerializeToString(), C2S_FetchSignOnReward); 
	end
end


function SignInSystem.ViewUpdate(receiveCount,isTodayReceived)
	local count=0;
	if(isTodayReceived==false) then 
		count = receiveCount+1;
	else
		count = receiveCount
	end
	icon = ItemTable[ItemLists[count].id].icon;
	print(icon)
	viewControl.rewardIcon.sprite = CResourceSys.instance:Load(EResType.EIcon,icon);
	viewControl.rewardNumberText.text = ItemLists[count].number;
	
	for i=1,#ItemLists do
		if i<count  then
			SignInSystem.UpdateItem(ItemLists[i],true,false,i);
		else if i==count then
			SignInSystem.UpdateItem(ItemLists[i],isTodayReceived,true,i);
		else
			SignInSystem.UpdateItem(ItemLists[i],false,false,i);
		end
	end
end
end

function SignInSystem.UpdateItem(item,hadReceive,isToday,day)
	item.dayText.text="第"..tostring(day).."天";
	item.hadReceiveBg:SetActive(not isToday);
	item.canReceiveBg:SetActive(isToday);
	item.selectObj:SetActive(isToday);
	item.mask:SetActive((not isToday) and (hadReceive));
	item.hadReceiveIcon:SetActive(hadReceive);
	item.effObj:SetActive((isToday) and (not hadReceive));
end

function SignInSystem.InitItem()
	--初始化31天的Item数据
	for i=1,31  do
		print(i);
		print(SignInTable[i]);
		print(SignInTable[i].reward_list[1])
		if	SignInTable[i].reward_list[1]~=nil then
			str = SignInTable[i].reward_list[1]
			tab =split(str,"|")
			id = tonumber(tab[1])
			number = tab[2]
			local iconItem = IconItem.Create(viewControl.content.gameObject,"_signIn")
			local cfg = ItemTable[id]
			iconItem:UpdateByIcon(cfg.icon,number)
			iconItem.id = id;
			iconItem.number = number;
			iconItem.hadReceiveBg = iconItem.go.transform:Find("HadReceiveBg").gameObject;
			iconItem.canReceiveBg = iconItem.go.transform:Find("CanReceiveBg").gameObject;
			iconItem.selectObj = iconItem.go.transform:Find("SelectObj").gameObject;
			iconItem.mask =iconItem.go.transform:Find("Mask").gameObject; 
			iconItem.hadReceiveIcon = iconItem.go.transform:Find("HadReceiveIcon").gameObject; 
			iconItem.dayText = iconItem.go.transform:Find("DayText"):GetComponent("Text");
			iconItem.effObj = iconItem.go.transform:Find("eff_ui_qiandao").gameObject;
			table.insert(ItemLists,iconItem)
		end
	end
end

