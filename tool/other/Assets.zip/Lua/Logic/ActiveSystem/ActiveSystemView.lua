﻿--From Lua Script Create
--ClassName: ActiveSystemView
--Author:    TanZiYe
--CreateTime:2018-6-26
require "Logic/ActiveSystem/SignInSystem"

ActiveSystemView = class("ActiveSystemView", ActiveSystemViewUI)

local _this;
ActiveSystemView._currentPanel=nil;


function ActiveSystemView:Init()
	print("初始化活动系统按钮事件")
	_this = self;
	self.RegisterBtnEvent();
	self._currentPanel = SignInSystem;
	SignInSystem.Init(self);
end

function ActiveSystemView:OpenView()
	print("打开活动系统");
	self._currentPanel.Open();
end

function ActiveSystemView:CloseView()
	print("关闭活动系统");
	self._currentPanel.Close();
end

function ActiveSystemView.OnCloseClick()
	print("点击关闭活动系统");
	ViewSys.instance:Close("ActiveSystemView");
end

function ActiveSystemView.SetTitle(title)
	_this.titleText.text=title;
end

function ActiveSystemView.RegisterBtnEvent()
	print("注册活动系统按钮点击事件");
	EventButtonListerer.Get(_this.closeBtn, _this.OnCloseClick)
end