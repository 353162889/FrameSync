--From Lua Script Create
--ClassName: ActiveSystemManager
--Author:    hukiry
--CreateTime:2018-7-12

ActiveSystemManager = class(ActiveSystemManager)

ActiveSystemManager.receiveCount = 0;
ActiveSystemManager.isTodayReceived = false;

function ActiveSystemManager.Init()
	NetSys.instance:AddMsgCallback(EChannelType.EWorldChannel, S2C_SignRewardInfo, ActiveSystemManager.OnSignRewardInfo, nil);
end

function ActiveSystemManager.OnSignRewardInfo(this, objMsg)
	print("更新签到信息")
	local msg = S2C_SignRewardInfoData(); 
	msg:ParseFromString(objMsg); 
	ActiveSystemManager.receiveCount = msg.sign_reward_fetch_count;
	ActiveSystemManager.isTodayReceived = msg.sign_reward_fetch_today;
	print("被领取天数："..tostring(ActiveSystemManager.receiveCount))
	print("今天是否能呗领取"..tostring(ActiveSystemManager.isTodayReceived))
	if(SignInSystem~=nil)then
		SignInSystem.ViewUpdate(ActiveSystemManager.receiveCount,ActiveSystemManager.isTodayReceived)
	end
end