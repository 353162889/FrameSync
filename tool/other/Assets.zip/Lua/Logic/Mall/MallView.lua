--[[
名称：商店
模块：UI
--]]
MallView = class("MallView", MallViewUI);

function MallView:Init()
	print("初始化商城")
	self:RegisterBtnEvent()
	self:InitRewardShow()
end

function MallView:OpenView(param)
	print("打开商城界面")
	self:RegisterNetEvent()
	self:UpdateTopBar()
	MallView:UpdateVipInfo(MainLobbyManager.isHadBuyYueKa)
end


function MallView:CloseView()
	print("关闭商城界面")
	self:RemoveNetEvent()
end

function MallView.BackToLobby()
	print("返回Lobby")
	ViewSys.instance:Open("MainLobbyView");
	ViewSys.instance:Close("MallView");
end

function MallView.OnYueKaBuy()
	print("点击购买")
	TipMgr.ShowTipType1( MallTable[1].buyDes,function()
		if(MainLobbyManager.playerBaseInfo.rmb>10) then
			print("直接买月卡")
			MallView.PayMoneyToBuy()
		else 
			--SDKManager.instance:BeginPay(1000)
			MainLobbyManager.SetYueKaInfo(true)
			MallView:UpdateVipInfo(true)
			local callback = function()
				print("返回月卡购买界面")
			end
			TipMgr.ShowRewardTip(MallTable[1].rewardDes,MallTable[1].rewardIds,MallTable[1].numbers,callback)
		end
	end,nil,nil)
end

function MallView.PayMoneyToBuy()
	local data = C2S_MallBuyGoodsData(); 
	data.goodsId = 1;  --暂时随便填
	NetSys.instance:SendWorldMsg(data:SerializeToString(), C2S_MallBuyGoods); 
end

function MallView.S2C_MallBuyGoodsResult(this, objMsg)
	local msg = S2C_MallBuyGoodsResultData(); 
	msg:ParseFromString(objMsg); 
	if(msg.error_num~=0) then 
		print("购买:"..msg.goodsId.."失败")
		TipMgr.ShowTipType2(MallTable[1].payFailDes,nil,nil)
	else
		print("购买:"..msg.goodsId.."成功")
		MainLobbyManager.SetYueKaInfo(true)
		MallView:UpdateVipInfo(true)
		local callback = function()
			print("返回月卡购买界面")
		end
		TipMgr.ShowRewardTip(MallTable[1].rewardDes,MallTable[1].rewardIds,MallTable[1].numbers,callback)
	end
end

function MallView:RegisterBtnEvent()
	print("初始化按钮事件")
	EventButtonListerer.Get(self.backLobbyBtn, self.BackToLobby)
	EventButtonListerer.Get(self.buyYueKaBtn,self.OnYueKaBuy)
end

function MallView:RegisterNetEvent()
	print("初始化服务端事件")
	EventSys.instance:AddEvent(EEventType.EPaySuccess, self.PaySucces);
	EventSys.instance:AddEvent(EEventType.EPayFailure, self.PayFailure);
	NetSys.instance:AddMsgCallback(EChannelType.EWorldChannel, S2C_MallBuyGoodsResult, MallView.S2C_MallBuyGoodsResult, nil);
end

function MallView:RemoveNetEvent()
	print("移除服务端事件")
	EventSys.instance:RemoveEvent(EEventType.EPaySuccess, self.PaySucces);
	EventSys.instance:RemoveEvent(EEventType.EPayFailure, self.PayFailure);
	NetSys.instance:RemoveMsgCallback(EChannelType.EWorldChannel,S2C_MallBuyGoodsResult,MallView.S2C_MallBuyGoodsResult)
end

function MallView:UpdateTopBar()
	self.txtSliver.text = MainLobbyManager.playerBaseInfo.silver;
	self.txtGold.text = MainLobbyManager.playerBaseInfo.gold;
end

function MallView:PaySucces(eventId,obj)
	print("支付成功，发起购买月卡请求")
	MallView.PayMoneyToBuy()
end

function MallView:PayFailure(eventId,obj)
	print("支付失败")
	TipMgr.ShowTipType2(MallTable[1].payFailDes,nil,nil)
end

function MallView:InitRewardShow()
	local RewardIds = MallTable[1].rewardIds
	local RewardNumbers = MallTable[1].numbers
	self.icon1.sprite = CResourceSys.instance:Load(EResType.EIcon,ItemTable[RewardIds[1]].icon);
	self.icon2.sprite = CResourceSys.instance:Load(EResType.EIcon,ItemTable[RewardIds[2]].icon);
	self.numberText1.text = RewardNumbers[1]
	self.numberText2.text = RewardNumbers[2]
end

function MallView:UpdateVipInfo(isBuy)
	MallView.buyYueKaBtn:SetActive(not isBuy)
	MallView.notBuyYueKaIcon:SetActive(isBuy)
	MallView:UpdateTopBar()
end
