PreLoadBase = class("PreLoadBase"); 

function PreLoadBase:Load()
    self:Clear();
    Main.AddUpdateFun(PreLoadBase.Update, self); 

    --击杀获取金币特效
    self:CacheEffect(EffectDefine.KillGetCoin,1);
    --死亡丢失金币特效
    self:CacheEffect(EffectDefine.DieLostCoin,1);
    --角色升级特效
    self:CacheEffect(ConstTable["hero_level_up_effect"].p_string,3);
    --场景内部的一些特效
    for k,resArea in pairs(AreaTable) do
        if(resArea.scene_id == BattleInfo.sceneId) then
            for i=1,#resArea.join_effect do
                 self:CacheEffect(resArea.join_effect[i],1);
            end
            for i=1,#resArea.leave_effect do
                 self:CacheEffect(resArea.leave_effect[i],1);
            end
            
            if(resArea.prefab ~= nil and resArea.prefab ~= "") then
                self:CacheEffect(resArea.prefab,1);
            end
            for k,v in pairs(resArea.friend_buff_ids) do
            if(type(v) == "number") then
                local buffId = v;
                self:CacheBuffEffect(buffId,2);
            end
            end
            for k,v in pairs(resArea.enemy_buff_ids) do
                if(type(v) == "number") then
                    local buffId = v;
                    self:CacheBuffEffect(buffId,2);
                end
            end
        end
    end
    self:OnLoad();
end

function PreLoadBase:CacheBuffEffect(buffId,count)
    local resBuff = BuffTable[buffId];
    if(resBuff == nil) then return end
    local buffStr = resBuff.start_effect_name;
    if(buffStr ~= nil and buffStr ~= "") then
        self:CacheEffect(buffStr,count);
    end
end

function PreLoadBase:Clear()
    self.finish = false;
    self.percent = 0;
end

function PreLoadBase:Update()
    self:OnUpdate();
end

function PreLoadBase:LoadDone()
    Main.RemoveUpdateFun(PreLoadBase.Update); 
    self.finish = true; 
    self.percent = 100;
    self:OnLoadDone();
end

function PreLoadBase:CacheEffect(strEffectName, nCount)
    strEffectName = strEffectName .. ".prefab";
    local cPrefab = CResourceSys.instance:Load(EResType.EEffect, strEffectName); 
    CGameObjectPool.instance:Cache(cPrefab, nCount);
end

function PreLoadBase:OnLoad()
end

function PreLoadBase:OnUpdate()
end

function PreLoadBase:OnLoadDone()
end
