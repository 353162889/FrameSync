SceneLoad = class("SceneLoad"); 
SceneLoad.percent = 0;
SceneLoad.finish = false;

function SceneLoad:Load(strSceneName)
    self:Clear();
    self.mAsyncOpera = UnityEngine.SceneManagement.SceneManager.LoadSceneAsync(strSceneName); 
    Main.AddUpdateFun(SceneLoad.Update, self); 
end

function SceneLoad:Clear()
    self.finish = false;
    self.percent = 0;
end

function SceneLoad:Update()
    self.percent = SceneLoad.mAsyncOpera.progress * 111.1;
    self.percent = math.ceil(self.percent);
    if self.percent > 100 then
        self.percent = 100;
    end

    if self.mAsyncOpera.isDone then
        SceneLoad:LoadDone();
    end
end

function SceneLoad:LoadDone()
    self.percent = 100;
    self.finish = true;
    Main.RemoveUpdateFun(SceneLoad.Update);
end
