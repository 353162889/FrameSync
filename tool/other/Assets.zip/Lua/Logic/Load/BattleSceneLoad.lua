require "Logic/Load/Cmd/ConnectBattleServer_Cmd"
require "Logic/Load/Cmd/BattleInfoPrepare_Cmd"
require "Logic/Load/Cmd/LoadBattleScene_Cmd"
require "Logic/Load/Cmd/BattlePreload_Cmd"
require "Logic/Load/Cmd/StartBattle_Cmd"

require "Logic/Load/Cmd/LastLoadingWait_Cmd"
require "Logic/Load/Cmd/HistoryFrameData_Cmd"
require "Logic/Load/Cmd/CreateMainHero_Cmd"

BattleSceneLoad = {}
BattleSceneLoad.hasHistoryFrameData = false;
BattleSceneLoad.hasCreateMainHero = false;
BattleSceneLoad.isLoading = false;
BattleSceneLoad.maxFrameIndex = 0;

BattleSceneLoad.GameTypeMap = {}
BattleSceneLoad.GameTypeMap[1] = EStateType.CoreGaming;
BattleSceneLoad.GameTypeMap[2] = EStateType.MobaGaming;

BattleSceneLoad.cmdPreload = nil;

function BattleSceneLoad.GetLoadResourcePercent()
	local result = SceneLoad.percent * 0.2;
	if BattleSceneLoad.cmdPreload then
		result = result + BattleSceneLoad.cmdPreload:GetPercent() * 0.41;
	end
	if(result > 61) then result = 61 end
	return result;
end

function BattleSceneLoad.GetLoadHistoryPercent(percent)
	local result = 61 + percent * 40;
	if(result > 100) then result = 100 end
	return result;
end

--战斗进入流程管理(开始初始化BattleInfo信息)
--进入战斗流程的所有用的到数据从BattleInfo中获取，不予许从其他地方获取（有可能是重连，必须保证进入战斗的时候能获取到一些数据）
function BattleSceneLoad.Load()
	if(BattleSceneLoad.isLoading) then return end
	BattleSceneLoad.mMapHeroResId = {};
	EventSys.instance:RemoveEvent(EEventType.EMainHeroInited, BattleSceneLoad.OnMainHeroInit);
	BattleSceneLoad.Clear();
	BattleInfo.Clear();
	FightManager.ClearData();

	PreLoad:Clear();
	SceneLoad:Clear();
	BattleSceneLoad.isLoading = true;

	local resSession = SessionTable[MatchInfo.sessionId];

	BattleInfo.gameType = BattleSceneLoad.GameTypeMap[resSession.game_type];
	local isStandAlone = CGameRoot.instance.isStandAlone;
	if(isStandAlone) then
		BattleInfo.userId = 1;
	else
		BattleInfo.userId = LoginInfo.userId;
	end
	BattleInfo.nickName = MainLobbyManager.playerBaseInfo.name;
	BattleInfo.isStandAlone = isStandAlone;
	BattleInfo.serverIp = MatchInfo.battleServerIP;
	BattleInfo.serverTcpPort = MatchInfo.battleServerTcpPort;
	BattleInfo.serverUdpPort = MatchInfo.battleServerUdpPort;
	BattleInfo.kcpConv= MatchInfo.kcpId;
	BattleInfo.useTcp = not CGameRoot.instance.mUseUdp;
	BattleInfo.authCode = MatchInfo.battleAuthCode;
	BattleInfo.sessionId = MatchInfo.sessionId;
	BattleInfo.sceneId = resSession.scene_id;

	Util.LogColor("#ff0000","userId",BattleInfo.userId,"isStandAlone",BattleInfo.isStandAlone,
		"serverIp",BattleInfo.serverIp,"serverTcpPort",BattleInfo.serverTcpPort,"serverUdpPort",BattleInfo.serverUdpPort,
		"kcpConv",BattleInfo.kcpConv,"useTcp",BattleInfo.useTcp,"authCode",BattleInfo.authCode,
		"sceneId",BattleInfo.sceneId,"sessionId",BattleInfo.sessionId);

	--命令流
	local sequence = CommandSequence.new();
	BattleSceneLoad.sequence = sequence;
	local cmdConnectServer = ConnectBattleServer_Cmd.new();
	local cmdBattleInfoPrepare = BattleInfoPrepare_Cmd.new();
	local cmdLoadScene = LoadBattleScene_Cmd.new();
	cmdPreload = BattlePreload_Cmd.new();
	local cmdStartBattle = StartBattle_Cmd.new();
	sequence:AddSubCommand(cmdConnectServer);
	sequence:AddSubCommand(cmdBattleInfoPrepare);
	sequence:AddSubCommand(cmdLoadScene);
	sequence:AddSubCommand(cmdPreload);
	sequence:AddSubCommand(cmdStartBattle);

	sequence:AddDoneFunc(BattleSceneLoad.OnLoadDone)
	ViewSys.instance:CloseAll();
	ViewSys.instance:Open("LoadView");
	sequence:Execute({});

	Main.AddUpdateFun(BattleSceneLoad.Update, nil); 
end

BattleSceneLoad.test = {};
function BattleSceneLoad.AddHeroResId(nResId)
	table.insert(BattleSceneLoad.mMapHeroResId, nResId);
end

function BattleSceneLoad.Update(obj,deltaTime)
	if(BattleSceneLoad.sequence ~= nil) then
		BattleSceneLoad.sequence:OnUpdate(deltaTime);
	end
	if(BattleSceneLoad.frameSquence ~= nil) then
		BattleSceneLoad.frameSquence:OnUpdate(deltaTime);
	end
end

--结束
function BattleSceneLoad.OnLoadDone(cmd)
	Util.Log("BattleSceneLoad:OnLoadDone");
	if(cmd.state == CmdExecuteState.Success) then
		--监听客户端认为游戏结束事件
	    EventSys.instance:AddEvent(EEventType.OnBattleEnd,BattleSceneLoad.OnBattleEnd);
		--开始游戏
		CGameRoot.instance.SwitchToState(BattleInfo.gameType); 
		if(BattleSceneLoad.CheckExtraFrameData()) then
			BattleSceneLoad.HandleExtraFrameData()
		else
			 BattleSceneLoad.HandleNoExtraFrameData();
		end

		SDKManager.instance:OnTDEvent("首次进入战斗");
		if(BattleInfo.selectHeroSkinId > 0) then
			SDKManager.instance:OnTDEvent("英雄" .. BattleInfo.selectHeroSkinId .. "使用次数");
		end
	else
		Util.LogError("进入战斗场景失败");
		ViewSys.instance:Close("LoadView");
		BattleSceneLoad.Clear();
		TipMgr.ShowTipType2("Unknown Error! please re-enter the game!",function () CGameRoot.instance:ApplicationExit(); end,false)
	end
	BattleSceneLoad.sequence = nil;
	BattleSceneLoad.cmdPreload = nil;
end

--是否有多余的帧数据
function BattleSceneLoad.CheckExtraFrameData()
	return BattleSceneLoad.hasHistoryFrameData;
end
--处理没有多余帧数据流程
function BattleSceneLoad.HandleNoExtraFrameData()
	local frameSquence = CommandSequence.new();
	BattleSceneLoad.frameSquence = frameSquence;
	local cmdLastLoadingWait = LastLoadingWait_Cmd.new();
	frameSquence:AddSubCommand(cmdLastLoadingWait);

	frameSquence:AddDoneFunc(BattleSceneLoad.OnHandleExtraFrameLoadDone)
	frameSquence:Execute({});
end

--处理多余的帧数据
function BattleSceneLoad.HandleExtraFrameData()
	local frameSquence = CommandSequence.new();
	BattleSceneLoad.frameSquence = frameSquence;
	local cmdHistoryFrame = HistoryFrameData_Cmd.new();
	local cmdCreateHero = CreateMainHero_Cmd.new();
	frameSquence:AddSubCommand(cmdHistoryFrame);
	frameSquence:AddSubCommand(cmdCreateHero);

	frameSquence:AddDoneFunc(BattleSceneLoad.OnHandleExtraFrameLoadDone)
	frameSquence:Execute({});
end

function BattleSceneLoad.OnHandleExtraFrameLoadDone(cmd)
	if(cmd.state ~= CmdExecuteState.Success) then
		Util.LogError("进入战斗场景失败");
		TipMgr.ShowTipType2("Unknown Error! please re-enter the game!",function () CGameRoot.instance:ApplicationExit(); end)
	else
		if(BattleScene.instance.mainHero == nil) then
			EventSys.instance:AddEvent(EEventType.EMainHeroInited, BattleSceneLoad.OnMainHeroInit);
		else
			FightManager.OpenFightView(BattleInfo.gameType);
			ViewSys.instance:Close("LoadView");
		end
	end
	BattleSceneLoad.Clear();
	BattleSceneLoad.frameSquence = nil;
end

function BattleSceneLoad.OnMainHeroInit(eventId,obj)
	EventSys.instance:RemoveEvent(EEventType.EMainHeroInited, BattleSceneLoad.OnMainHeroInit);
	FightManager.OpenFightView(BattleInfo.gameType);
	ViewSys.instance:Close("LoadView");
end

function BattleSceneLoad.OnBattleEnd(eventId,arg)
	BattleSceneLoad.Clear();
	TipMgr.ShowTipType2("游戏已结束，请重新开始游戏")
	FightManager.ExitToLobby();
	ViewSys.instance:Close("LoadView");
end

function BattleSceneLoad.Clear()
	EventSys.instance:RemoveEvent(EEventType.OnBattleEnd, BattleSceneLoad.OnBattleEnd);
	 Main.RemoveUpdateFun(BattleSceneLoad.Update); 
	if(nil ~= BattleSceneLoad.sequence) then
		BattleSceneLoad.sequence:OnDestroy();
		BattleSceneLoad.sequence = nil;
	end
	if(nil ~= BattleSceneLoad.frameSquence) then
		BattleSceneLoad.frameSquence:OnDestroy();
		BattleSceneLoad.frameSquence = nil;
	end
	BattleSceneLoad.hasHistoryFrameData = false;
	BattleSceneLoad.needCreateMainHero = false;
	BattleSceneLoad.isLoading = false;
	BattleSceneLoad.maxFrameIndex = 0;
end