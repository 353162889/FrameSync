require "Logic/Load/PreLoadBase"

MobaPreLoad = class("PreLoad", PreLoadBase); 

function MobaPreLoad:OnLoad()
    self.mCurUnitId = 0;
    self.mMapHeroResId = BattleSceneLoad.mMapHeroResId;
    Util.LogColor("#00ff00", "BeginLoad:", #self.mMapHeroResId);
end

function MobaPreLoad:OnUpdate()
    self.mCurUnitId = self.mCurUnitId + 1;
    if(self.mCurUnitId <= #self.mMapHeroResId) then
        local resHeroData = HeroTable[self.mMapHeroResId[self.mCurUnitId]];
        for i, v in pairs(resHeroData.normal_skill) do
            if type(v) == "number" then
                SkillDataMgr.instance:PreLoadSkill(v);
            end
        end
        for i, v in pairs(resHeroData.active_skill) do
            if type(v) == "number" then
                SkillDataMgr.instance:PreLoadSkill(v);
            end
        end
        local cPrefab = CResourceSys.instance:Load(EResType.EUnit, resHeroData.prefab_name); 
        CGameObjectPool.instance:Cache(cPrefab, 1);
    end
    self.percent = 100 * self.mCurUnitId / #self.mMapHeroResId;
    self.percent = math.ceil(self.percent);
    if self.percent >= 100 then
        self:LoadDone();
    end
end

function MobaPreLoad:OnLoadDone()
    self.mMapHeroResId = nil;
end
