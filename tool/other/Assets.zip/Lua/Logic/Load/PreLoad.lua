require "Logic/Load/PreLoadBase"

PreLoad = class("PreLoad", PreLoadBase); 

function PreLoad:OnLoad()
    self.maxPlayerCount = ConstTable["battle_max_player_count"].p_int;
    if(BattleInfo.sessionId > 0) then
        self.maxPlayerCount = SessionTable[BattleInfo.sessionId].max_people;
    end
    local heroIdStr = ConstTable["lobby_fight_hero"].p_string;
    local heroIdArr = Util.Split( heroIdStr,",");

    self.preLoadSkill = {};
    self.curPreSkillIdx = 1;

    self.arrUnitResId = {};
    self.curPreUnitIdx = 1;
    if(heroIdArr ~= nil) then
        for k,v in pairs(heroIdArr) do
            table.insert(self.arrUnitResId,tonumber(v));
        end
    end
    local nSkillCount = 0;
    local nCount = self.maxPlayerCount / 2;
    nCount = nCount / (#self.arrUnitResId);
    for k = 1, nCount, 1 do
        for i, v in pairs(self.arrUnitResId) do  
            local resHeroData = HeroTable[v];
            for i2, v2 in pairs(resHeroData.normal_skill) do
                if type(v2) == "number" then
                    self.preLoadSkill[nSkillCount + 1] = v2;
                    nSkillCount = nSkillCount + 1;
                end
            end
            for i2, v2 in pairs(resHeroData.active_skill) do
                if type(v2) == "number" then
                    self.preLoadSkill[nSkillCount + 1] = v2;
                    nSkillCount = nSkillCount + 1;
                end
            end
        end
    end
end

function PreLoad:OnUpdate()
    if self.curPreSkillIdx <= #self.preLoadSkill then
        SkillDataMgr.instance:PreLoadSkill(self.preLoadSkill[self.curPreSkillIdx]);
    end
    if(self.curPreUnitIdx <= #self.arrUnitResId) then
        local resHeroData = HeroTable[self.arrUnitResId[self.curPreUnitIdx]];
        local prefab = CResourceSys.instance:Load(EResType.EUnit,resHeroData.prefab_name); 
        CGameObjectPool.instance:Cache(prefab,5);
    end
    self.curPreSkillIdx = self.curPreSkillIdx + 1;
    self.curPreUnitIdx = self.curPreUnitIdx + 1;
    self.percent = 100 * (self.curPreSkillIdx + self.curPreUnitIdx) / (#self.preLoadSkill + #self.arrUnitResId);
    self.percent = math.ceil(self.percent);
    if self.percent >= 100 then
        self:LoadDone();
    end
end
