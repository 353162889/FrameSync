--向服务器请求战斗需要的一些数据
BattleInfoPrepare_Cmd = class("BattleInfoPrepare_Cmd",CommandBase)
--连接战斗服，并验证
function BattleInfoPrepare_Cmd:Execute(context)
	BattleInfoPrepare_Cmd.super.Execute(self,context);
	if(BattleInfo.isStandAlone) then
		self:OnExecuteDone(CmdExecuteState.Success);
	else
		Util.Log("开始向服务器请求战斗消息")
		local data = C2S_RequestBattlePlayerData();
		NetSys.instance:SendPvpMsg(data:SerializeToString(), C2S_RequestBattlePlayer,S2C_BattlePlayerInfoList,self.S2C_BattlePlayerInfoListData, self); 
		--做重连处理
		self.onReconnect = function ( eventId,arr)
			local channelType = arr[0];
			local reconnectCode = arr[1];
			if(channelType == EChannelType.EPvpChannel and reconnectCode == Error_None) then
				self:OnReconnect();
			end
		end
		EventSys.instance:AddEvent(EEventType.EReconnect,self.onReconnect);	 
	end
end

function BattleInfoPrepare_Cmd:OnReconnect()
	Util.Log("重连之后---开始向服务器请求战斗消息")
	local data = C2S_RequestBattlePlayerData();
	NetSys.instance:SendPvpMsg(data:SerializeToString(), C2S_RequestBattlePlayer,S2C_BattlePlayerInfoList,self.S2C_BattlePlayerInfoListData, self); 
end

function BattleInfoPrepare_Cmd:S2C_BattlePlayerInfoListData(objMsg)
	Util.Log("向服务器请求战斗消息成功")
	local msg = S2C_BattlePlayerInfoListData()
    msg:ParseFromString(objMsg)
	local lstPlayerInfo = msg.player_info_list;
	for i,v in ipairs(lstPlayerInfo) do
    	if(tostring(v.user_id) == tostring(BattleInfo.userId)) then
    		BattleInfo.selectHeroDefineId = v.hero_id;
    		BattleInfo.selectHeroSkinId = v.appearance_id;
    		BattleInfo.lastExitFrameIndex = v.exit_frame_index;
    		break;
    	end
    	
    end
	for i,v in ipairs(lstPlayerInfo) do
		BattleSceneLoad.AddHeroResId(v.hero_id);
    	Util.LogColor("#ff0000","帧序列---------------------",v.hero_id, v.user_id,v.exit_frame_index,"BattleInfo.userId",BattleInfo.userId)
    end
    self:OnExecuteDone(CmdExecuteState.Success);
end

function BattleInfoPrepare_Cmd:OnDestroy()
	if(self.onReconnect ~= nil) then
		EventSys.instance:RemoveEvent(EEventType.EReconnect,self.onReconnect);	
		self.onReconnect = nil;
	end
	NetSys.instance:RemoveMsgCallback(EChannelType.EPvpChannel,S2C_BattlePlayerInfoList,self.S2C_BattlePlayerInfoListData);
	BattleInfoPrepare_Cmd.super.OnDestroy(self);
end