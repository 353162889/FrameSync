ConnectBattleServer_Cmd = class("ConnectBattleServer_Cmd",CommandBase)
--连接战斗服，并验证
function ConnectBattleServer_Cmd:Execute(context)
	ConnectBattleServer_Cmd.super.Execute(self,context);
	 if not BattleInfo.isStandAlone then
        local nPort = 0; 
        if BattleInfo.useTcp then
            --do
            nPort = BattleInfo.serverTcpPort;
        else
            nPort = BattleInfo.serverUdpPort; 
        end
        self.connectBattleResult = function (succ)
         	if(succ) then
        		self:OnConnectBattleResult()
        	else
        		Util.LogError("连接战斗服务器失败",BattleInfo.serverIp,nPort);
        		self:OnExecuteDone(CmdExecuteState.Fail);
        	end
        end
        NetSys.instance:ConnectServer(EChannelType.EPvpChannel, BattleInfo.serverIp, nPort, self.connectBattleResult); 
        Util.Log("开始连接服务器",BattleInfo.serverIp, nPort)
        
    else
        self:OnExecuteDone(CmdExecuteState.Success);
    end
end

function ConnectBattleServer_Cmd:OnConnectBattleResult()
     Util.Log("连接服务器成功")
    local onAutCheckResult = function (result)
        if result == Error_None then--进入场景加载
             Util.Log("检测服务器成功")
             --战斗服务器开启心跳包检测断线
             local channel = NetSys.instance:GetChannel(EChannelType.EPvpChannel);
             channel:StartHeartBeat(true);
            self:OnExecuteDone(CmdExecuteState.Success);
        else
            Util.LogError("检测战斗服务器失败 错误码："..result); 
            self:OnExecuteDone(CmdExecuteState.Fail);
        end
    end
     Util.Log("BattleInfo.userId",BattleInfo.userId,"BattleInfo.authCode",BattleInfo.authCode)
    NetSys.instance:CheckCode(EChannelType.EPvpChannel,BattleInfo.userId,BattleInfo.authCode,onAutCheckResult);
   
	-- local data = C2S_AuthCheckData(); 
 --    --这里不能使用BattleInfo.userId(应为lua是将long作为userData,而pbc将long作为number处理)
 --    --toString处理后似乎没问题了
 --    data.actID = tostring(BattleInfo.userId);
 --    data.authCode = BattleInfo.authCode; 
 --    NetSys.instance:SendPvpMsg(data:SerializeToString(), C2S_AuthCheck, S2C_AuthCheckResult, self.S2C_AuthCheckResult, self); 
end

-- function ConnectBattleServer_Cmd:S2C_AuthCheckResult(objMsg)
-- 	local msg = S2C_AuthCheckResultData(); 
--     msg:ParseFromString(objMsg); 
--     if msg.result == Error_None then--进入场景加载
--          Util.Log("检测服务器成功")
--         self:OnExecuteDone(CmdExecuteState.Success);
--     else
--         Util.LogError("检测战斗服务器失败 错误码："..msg.result); 
--         self:OnExecuteDone(CmdExecuteState.Fail);
--     end
-- end

function ConnectBattleServer_Cmd:OnDestroy()
	NetSys.instance:RemoveConnectServerCallback(EChannelType.EPvpChannel);
    NetSys.instance:RemoveCheckCodeCallback(EChannelType.EPvpChannel);
	--NetSys.instance:RemoveMsgCallback(EChannelType.EPvpChannel,S2C_AuthCheckResult,self.S2C_AuthCheckResult);
	self.connectBattleResult = nil;
	ConnectBattleServer_Cmd.super.OnDestroy(self);
end
