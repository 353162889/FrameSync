
LastLoadingWait_Cmd = class("LastLoadingWait_Cmd",CommandBase)
--连接战斗服，并验证
function LastLoadingWait_Cmd:Execute(context)
	LastLoadingWait_Cmd.super.Execute(self,context);
	Util.Log("最终进度条等待")
	self.totalWaitTime = 0.5;
	self.waitTime = self.totalWaitTime;
end

function LastLoadingWait_Cmd:OnUpdate(deltaTime)
	self.waitTime = self.waitTime - deltaTime;
	local percent = (self.totalWaitTime - self.waitTime) / self.totalWaitTime;
	if(percent > 1) then percent = 1; end
	LoadView:UpdateProgress(BattleSceneLoad.GetLoadHistoryPercent(percent));
	if(self.waitTime < 0) then
		self:OnExecuteDone(CmdExecuteState.Success);	
	end
end
