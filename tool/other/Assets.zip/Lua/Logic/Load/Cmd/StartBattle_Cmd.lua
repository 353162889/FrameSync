require "Logic/Voice/VoiceHelper"

StartBattle_Cmd = class("StartBattle_Cmd",CommandBase)
--连接战斗服，并验证
function StartBattle_Cmd:Execute(context)
	StartBattle_Cmd.super.Execute(self,context);
	if(BattleInfo.isStandAlone) then
		math.randomseed(tostring(os.time()):reverse():sub(1, 7))
        BattleInfo.randomSeed = math.random(1,100); 
		self:OnExecuteDone(CmdExecuteState.Success);
	else
		Util.Log("发送请求准备战斗数据")
		local data = C2S_PrepareBattleData(); 
        NetSys.instance:SendPvpMsg(data:SerializeToString(), C2S_PrepareBattle, S2C_StartBattle, self.S2C_StartBattleData, self); 

        --做重连处理
		self.onReconnect = function ( eventId,arr)
			local channelType = arr[0];
			local reconnectCode = arr[1];
			if(channelType == EChannelType.EPvpChannel and reconnectCode == Error_None) then
				self:OnReconnect();
			end
		end
		EventSys.instance:AddEvent(EEventType.EReconnect,self.onReconnect);	 
	end
end

function StartBattle_Cmd:OnReconnect()
	Util.Log("重连之后----发送请求准备战斗数据")
	local data = C2S_PrepareBattleData(); 
    NetSys.instance:SendPvpMsg(data:SerializeToString(), C2S_PrepareBattle, S2C_StartBattle, self.S2C_StartBattleData, self); 
end

function StartBattle_Cmd:S2C_StartBattleData(objMsg)
	-- body
	Util.Log("开始战斗")
	local msg = S2C_StartBattleData()
    msg:ParseFromString(objMsg)
    BattleInfo.randomSeed = msg.randomSeed;
    Util.LogColor("#ff0000","S2C_StartBattleData[randomseed]",msg.randomSeed);
    BattleSceneLoad.hasHistoryFrameData = msg.has_histroy_data;
	BattleSceneLoad.hasCreateMainHero = msg.has_create_entity;
	Util.Log("是否有历史帧",BattleSceneLoad.hasHistoryFrameData,"是否有主角",BattleSceneLoad.hasCreateMainHero);
	self:OnExecuteDone(CmdExecuteState.Success);

	if not VoiceHelper.mIslogin then
		print(LoginInfo.userId)
		VoiceHelper:LoginRoom(LoginInfo.userId, msg.chat_channel_id);
	end
end

function StartBattle_Cmd:OnDestroy()
	if(self.onReconnect ~= nil) then
		EventSys.instance:RemoveEvent(EEventType.EReconnect,self.onReconnect);	
		self.onReconnect = nil;
	end
	NetSys.instance:RemoveMsgCallback(EChannelType.EPvpChannel,S2C_StartBattle,self.S2C_StartBattleData);
	StartBattle_Cmd.super.OnDestroy(self);
end