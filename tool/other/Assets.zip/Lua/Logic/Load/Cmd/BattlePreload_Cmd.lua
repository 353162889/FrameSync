require "Logic/Load/PreLoad"
require "Logic/Load/MobaPreLoad"

BattlePreload_Cmd = class("BattlePreload_Cmd",CommandBase)
--连接战斗服，并验证
function BattlePreload_Cmd:Execute(context)
	BattlePreload_Cmd.super.Execute(self,context);
	if(not ViewSys.instance:IsOpen("LoadView")) then
		ViewSys.instance:Open("LoadView");
	end
	Util.Log("开始预加载数据")
	self.mPreLoad = nil;
	local resSession = SessionTable[BattleInfo.sessionId];
	if resSession.game_type == 2 then
		self.mPreLoad = MobaPreLoad;
	else
		self.mPreLoad = PreLoad;
	end
	self.mPreLoad:Load();
end

function BattlePreload_Cmd:OnUpdate(deltaTime)
	LoadView:UpdateProgress(BattleSceneLoad.GetLoadResourcePercent());
	if self.mPreLoad.finish then
		Util.Log("预加载数据成功")
		self:OnExecuteDone(CmdExecuteState.Success);	
    end
end

function BattlePreload_Cmd:OnDestroy()
	--预加载和场景加载停止处理
	BattlePreload_Cmd.super.OnDestroy(self);
	self.mPreLoad = nil;
end

function BattlePreload_Cmd:GetPercent()
    return self.mPreLoad.percent;
end