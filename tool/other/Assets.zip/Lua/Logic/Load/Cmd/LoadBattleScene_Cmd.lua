LoadBattleScene_Cmd = class("LoadBattleScene_Cmd",CommandBase)
--连接战斗服，并验证
function LoadBattleScene_Cmd:Execute(context)
	LoadBattleScene_Cmd.super.Execute(self,context);
	if(not ViewSys.instance:IsOpen("LoadView")) then
		ViewSys.instance:Open("LoadView");
	end
	Util.Log("开始加载场景")
	local resScene = SceneTable[BattleInfo.sceneId];
	SceneLoad:Load(resScene.name); 
end

function LoadBattleScene_Cmd:OnUpdate(deltaTime)
	LoadView:UpdateProgress(BattleSceneLoad.GetLoadResourcePercent());
	if SceneLoad.finish then
		Util.Log("加载场景数据成功")
		self:OnExecuteDone(CmdExecuteState.Success);	
    end
end

function LoadBattleScene_Cmd:OnDestroy()
	--场景加载停止处理
	LoadBattleScene_Cmd.super.OnDestroy(self);
end