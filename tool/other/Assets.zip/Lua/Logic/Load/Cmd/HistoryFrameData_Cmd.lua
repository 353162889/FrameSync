HistoryFrameData_Cmd = class("HistoryFrameData_Cmd",CommandBase)
--连接战斗服，并验证
function HistoryFrameData_Cmd:Execute(context)
	HistoryFrameData_Cmd.super.Execute(self,context);
	Util.Log("请求帧数据")
	local channel = NetSys.instance:GetChannel(EChannelType.EPvpChannel);
	channel:SetOutOfTime(60.0);
	FrameSyncSys.instance:SetShowView(false);
	local timeScale = ConstTable["join_battle_load_time_scale"].p_int / 1000.0;
	FrameSyncSys.instance:StartTimeScale(timeScale);
	AudioSys.instance.enableAudio = false;
	self.canCheckStopTimeScale = false;
	local data = C2S_RequestFrameIndexData(); 
    data.frameIndexReq = 0; 
    NetSys.instance:SendPvpMsg(data:SerializeToString(), C2S_RequestFrameIndex,S2C_RequestConfirm,self.S2C_RequestConfirmData, self); 
    --监听服务器历史帧消息的回复
     NetSys.instance:AddMsgCallback(EChannelType.EPvpChannel, S2C_BattleHistroySendComplete, HistoryFrameData_Cmd.S2C_BattleHistroySendCompleteData, self); 
     
     --断线重连处理
     self.onReconnect = function ( eventId,arr)
			local channelType = arr[0];
			local reconnectCode = arr[1];
			if(channelType == EChannelType.EPvpChannel and reconnectCode == Error_None) then
				self:OnReconnect();
			end
		end
	EventSys.instance:AddEvent(EEventType.EReconnect,self.onReconnect);	 
end

function HistoryFrameData_Cmd:OnReconnect()
	Util.Log("重连之后----请求帧数据")
	local channel = NetSys.instance:GetChannel(EChannelType.EPvpChannel);
	local curFrame = NetSys.instance.netFrameId;
	channel:ClearFrameData(curFrame);

	local data = C2S_RequestFrameIndexData(); 
    data.frameIndexReq = curFrame; 
	Util.Log("请求帧数据",curFrame)
    NetSys.instance:SendPvpMsg(data:SerializeToString(), C2S_RequestFrameIndex,S2C_RequestConfirm,self.S2C_RequestConfirmData, self); 
end

function HistoryFrameData_Cmd:S2C_RequestConfirmData(objMsg)
	local msg = S2C_RequestConfirmData()
    msg:ParseFromString(objMsg)
    BattleSceneLoad.maxFrameIndex = msg.frameIndexMax;
    Util.Log("历史帧数:",BattleSceneLoad.maxFrameIndex);
    self:UpdatePercent();
end

--收到服务器发送完毕历史帧数据后
function HistoryFrameData_Cmd:S2C_BattleHistroySendCompleteData(objMsg)
	Util.Log("请求帧数据成功")
	self.canCheckStopTimeScale = true;
end

function HistoryFrameData_Cmd:OnUpdate(deltaTime)
	-- body
	self:UpdatePercent();
	if(self.canCheckStopTimeScale) then
		if(not FrameSyncSys.instance.hasLeaveFrame) then
			Util.Log("剩余的帧数据执行完毕")
			self:OnExecuteDone(CmdExecuteState.Success);
		end
	end
end

function HistoryFrameData_Cmd:UpdatePercent()
	local percent = 0;
	if(BattleSceneLoad.maxFrameIndex > 0) then
		percent = FrameSyncSys.instance.curFrame / BattleSceneLoad.maxFrameIndex;
	end
	if(percent > 1) then percent = 1;end
	LoadView:UpdateProgress(BattleSceneLoad.GetLoadHistoryPercent(percent));
end

function HistoryFrameData_Cmd:OnDestroy()
	--移除消息
	if(self.onReconnect ~= nil) then
		EventSys.instance:RemoveEvent(EEventType.EReconnect,self.onReconnect);	
		self.onReconnect = nil;
	end
	if(self.onBattleEnd ~= nil) then
		EventSys.instance:RemoveEvent(EEventType.OnBattleEnd,self.onBattleEnd);	
		self.onBattleEnd = nil;
	end
	 NetSys.instance:RemoveMsgCallback(EChannelType.EPvpChannel, S2C_BattleHistroySendComplete, HistoryFrameData_Cmd.S2C_BattleHistroySendCompleteData); 
	 NetSys.instance:RemoveMsgCallback(EChannelType.EPvpChannel, S2C_RequestConfirm,HistoryFrameData_Cmd.S2C_RequestConfirmData); 
	--停止快速播放
	FrameSyncSys.instance:StopTimeScale();
	AudioSys.instance.enableAudio = true;
	if(not AudioSys.instance.isMusicPlay and AudioSys.instance.enableBg) then
		AudioSys.instance:Play(ConstTable["battle_bg_id"].p_int);
	end
	FrameSyncSys.instance:SetShowView(true);
	local channel = NetSys.instance:GetChannel(EChannelType.EPvpChannel);
	channel:SetOutOfTime(5.0);
	HistoryFrameData_Cmd.super.OnDestroy(self);
end