
CreateMainHero_Cmd = class("CreateMainHero_Cmd",CommandBase)
--连接战斗服，并验证
function CreateMainHero_Cmd:Execute(context)
	CreateMainHero_Cmd.super.Execute(self,context);
	local data = C2S_ClientLoadingCompleteData(); 
	NetSys.instance:SendPvpMsg(data:SerializeToString(), C2S_ClientLoadingComplete); 
	if(not BattleSceneLoad.hasCreateMainHero) then
		--监听玩家变更消息
		self.mainHeroUpdate = function (eventId,obj)
			Util.Log("主玩家创建完毕")
			self:OnExecuteDone(CmdExecuteState.Success);
		end
		EventSys.instance:AddEvent(EEventType.OnMainHeroUpdate, self.mainHeroUpdate);
		--发送创建玩家消息
		data = C2S_RequestCreateEntityData(); 
        NetSys.instance:SendPvpMsg(data:SerializeToString(), C2S_RequestCreateEntity); 
        Util.Log("创建主玩家")
	else
		self:OnExecuteDone(CmdExecuteState.Success);
	end
end

function CreateMainHero_Cmd:OnDestroy()
	if(self.mainHeroUpdate ~= nil) then
		EventSys.instance:RemoveEvent(EEventType.OnMainHeroUpdate, self.mainHeroUpdate);
		self.mainHeroUpdate = nil;
	end
	CreateMainHero_Cmd.super.OnDestroy(self);
end