

LoadView = class("LoadView", LoadUI);

function LoadView:Init()
    self.uiProgress = self.progress:AddComponent(typeof(UIProgress));
end

function LoadView:OpenView(param)
    self.uiProgress:UpdateProgress(0);
end

function LoadView:UpdateProgress(progress)
    self.txtLoading.text = "LOADING..." .. math.ceil(progress) .. "%";
    self.uiProgress:UpdateProgress(progress / 100);
end
