NameMgr = {}
NameMgr.nameTable = {}
function NameMgr.Init()
	local txtAsset = CResourceSys.instance:Load(EResType.EConfig,"NameConfig/lastName.txt");
	local arr = Util.Split(txtAsset.text,",");
	for i=1,#arr do
		arr[i] = Util.Trim(arr[i]);
		if(arr[i] ~= "" and arr[i] ~= "\n")then
			table.insert(NameMgr.nameTable,arr[i]);
		end
	end
end

function NameMgr.RandomName()
    local index = math.random(0,#NameMgr.nameTable);
    return NameMgr.nameTable[index];
end