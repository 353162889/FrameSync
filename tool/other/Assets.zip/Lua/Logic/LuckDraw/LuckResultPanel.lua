﻿--From Lua Script Create
--ClassName: LuckResultPanel
--Author:    hukiry
--CreateTime:2018-7-25

require "Logic/LuckDraw/LuckSelectPanel"

LuckResultPanel = {}
LuckResultPanel.TenItemList ={};
LuckResultPanel.OneItem =nil;
LuckResultPanel.CurrentType =nil;

local CurrentId={};
local CurrentObjs={};
local CurrentData={};
local _this;
local movingIntervalTime = 0.1;--多个Item的移动间隔时间
local movingSpendTime = 0.5;--移动花费时间
local upTime = 0.2;
local normalUpPos = nil;

--观子移动相关
local GuanZiObjs = {};
local normalPosAndSize = {};
local currentObjs={}
local isMove = false;--开场管子飞行
local guanZiMovingSpendTime=0.5--管子飞行时间
local lidMoveTime =0.6;--盖子移动时间
local OnOnceMoreCallBack=nil;
local isTenItem;
local isHadJarMove=false;--罐子是否移动
local isHadLidMove = false;--盖子是否移动

local animator = nil;

function LuckResultPanel.Init(view)
	print("初始化抽奖结果界面");
	_this=view;
	LuckResultPanel.RegeditEvent();
	LuckResultPanel.InitAnimationEvent()
	_this.resultPanel:SetActive(false);
	LuckResultPanel.InitEvent();
	normalUpPos =  _this.normalUpPos.position;
	GuanZiObjs.UpTra = _this.imgUp:GetComponent("RectTransform");
	normalPosAndSize.UpPos = GuanZiObjs.UpTra.position;
	normalPosAndSize.UpSize = GuanZiObjs.UpTra.sizeDelta;
	GuanZiObjs.MiddleTra = _this.imgMiddle:GetComponent("RectTransform");
	normalPosAndSize.MiddlePos = GuanZiObjs.MiddleTra.position;
	normalPosAndSize.MiddleSize = GuanZiObjs.MiddleTra.sizeDelta;
	GuanZiObjs.DownTra = _this.taizi:GetComponent("RectTransform");
	normalPosAndSize.DownPos = GuanZiObjs.DownTra.position;
	normalPosAndSize.DownSize = GuanZiObjs.DownTra.sizeDelta;

	local parent = _this.resultLeft.parent;
	local index = 1;
	for i=1,parent.childCount do
		for j=1,parent:GetChild(i-1).childCount do
			local item = {};
			local tra = parent:GetChild(i-1):GetChild(j-1);
			item.tra = tra;
			item.obj = tra.transform.gameObject;
			item.obj:SetActive(false);
			item.img = tra:Find("imgIcon"):GetComponent("Image");
			item.txtNumber = tra:Find("txtNumber"):GetComponent("Text");
			item.targetPos = tra.position;
			item.normalPos = _this.normalPosObj.position;
			item.obj.transform.position = item.normalPos;

			item.index = index;
			item.SetUI = function(id,number)
				item.img.sprite = CResourceSys.instance:Load(EResType.EIcon,ItemTable[id].icon);
				item.txtNumber.text = tostring(number);
			end

			item.OnMoveCallBack = function()
				print("通知Index=="..tostring(item.index+1).."开始移动")
				LuckResultPanel.TenItemList[item.index+1].OnStartMove();
			end

			item.OnStartMove = function()
				print(tostring(item.index).."开始移动");
				item.obj:SetActive(true);
				item.ToMove();
			end

			item.ToMove = function ()
				item.tra.position = normalUpPos;
				item.tra.localScale = Vector3.zero;
				item.tra:DOMove(_this.normalPosObj.position,upTime);
				local ScaleTween=item.tra:DOScale(Vector3.one,upTime);
				ScaleTween:OnComplete(function()
					if(item.index~=10)then
						item.OnMoveCallBack();
					end
					local MoveTween=item.tra:DOMove(item.targetPos,movingSpendTime);		
					MoveTween:OnComplete(function()
						if(item.index==10)then
							LuckResultPanel.TenItemMoveEnd();
						end
					end)
				end)
			end

			item.clear = function()
				item.obj:SetActive(false);
			end
			table.insert(LuckResultPanel.TenItemList,item)
			index=index+1;
		end
	end
	
end
--[[ datas.itemIds = {};
datas.itemNums = {}; ]]
function LuckResultPanel.SetOpenData(id,objs,isTen,callBack)
	print(id);
	CurrentId = id;
	currentObjs = objs;
	isTenItem = isTen;
	local config = LuckDrawTable[id];
	local cost =nil;
	if(isTenItem)then
		cost = config.ten_cost;
	else
		cost = config.once_cost;
	end
	_this.txtOnceMoreGold.text = tostring(cost);
	OnOnceMoreCallBack = callBack;
	_this.imgMiddle.sprite = CResourceSys.instance:Load(EResType.EIcon,LuckDrawTable[id].pipeIcon);
	_this.imgUp.sprite = CResourceSys.instance:Load(EResType.EIcon,LuckDrawTable[id].lidIcon);
end

function LuckResultPanel.JarMoveFinish()
	--[[ print(CurrentData.itemIds); ]]
	print("罐子移动结束")
	isHadJarMove = true;
	LuckResultPanel.ToLidMove()
end

function LuckResultPanel.InitAnimationEvent()
	_this.animator_Play:GetComponent("AnimationEventHelper").PlayEndCallBack = function()
		LuckResultPanel.AllMoveFinish();
	end
end

function LuckResultPanel.LidMoveFinish()
	print("盖子移动结束")
	isHadLidMove = true;
	_this.objWater:SetActive(true);
	_this.objLight:SetActive(true);
	_this.objFire:SetActive(true);
	_this.animator_Play:GetComponent("Animator"):SetTrigger("Play");
	--[[ LuckResultPanel.AllMoveFinish() ]]

end

function LuckResultPanel.TenItemMoveEnd()
	print("十个Item移动结束");
	LuckResultPanel.SetBtnsActive(true);
end

function LuckResultPanel.OnceItemMoveEnd()
	print("一个Item移动结束");
	LuckResultPanel.SetBtnsActive(true);
end

function LuckResultPanel.AllMoveFinish()
	print("所有移动结束后")
	print(isTenItem);
	if(isTenItem)then 
		LuckResultPanel.OpenTenPanel(CurrentData);
	else
		LuckResultPanel.OpenOncePanel(CurrentData)
	end
end

function LuckResultPanel.ToLidMove()
	if(isHadLidMove==false)then
		print("盖子开始移动");
		local tween=_this.imgUp.transform:DOMove(_this.lidMoveEndPos.position,lidMoveTime);
		LuckResultPanel.LidMoveFinish();
	else
		print("盖子移动结束");
		LuckResultPanel.LidMoveFinish();
	end
end

function LuckResultPanel.ToJarMove()
	if(isHadJarMove == false)then 
		print("罐子开始移动");
		GuanZiObjs.UpTra.position = currentObjs.UpTra.position;
		GuanZiObjs.UpTra.sizeDelta = currentObjs.UpTra.sizeDelta;
		GuanZiObjs.MiddleTra.position = currentObjs.MiddleTra.position;
		GuanZiObjs.MiddleTra.sizeDelta = currentObjs.MiddleTra.sizeDelta;
		GuanZiObjs.DownTra.position = currentObjs.DownTra.position;
		GuanZiObjs.DownTra.sizeDelta = currentObjs.DownTra.sizeDelta;
		GuanZiObjs.UpTra:DOMove(normalPosAndSize.UpPos,guanZiMovingSpendTime);
		GuanZiObjs.UpTra:DOSizeDelta(normalPosAndSize.UpSize,guanZiMovingSpendTime);
		GuanZiObjs.MiddleTra:DOMove(normalPosAndSize.MiddlePos,guanZiMovingSpendTime);
		GuanZiObjs.MiddleTra:DOSizeDelta(normalPosAndSize.MiddleSize,guanZiMovingSpendTime);
		GuanZiObjs.DownTra:DOMove(normalPosAndSize.DownPos,guanZiMovingSpendTime);
		local tween=GuanZiObjs.DownTra:DOSizeDelta(normalPosAndSize.DownSize,guanZiMovingSpendTime);
		tween:OnComplete(function()
			print("********");
			LuckResultPanel.JarMoveFinish()
		end);	
	else
		LuckResultPanel.JarMoveFinish()
	end
end

function LuckResultPanel.RefreshData(data)
	print("刷新当前界面数据");
	LuckResultPanel.Clear();
	LuckSelectPanel.Close();
	_this.resultPanel:SetActive(true);
	LuckResultPanel.CloseResultPanelView();
	LuckResultPanel.SetBtnsActive(false)
	CurrentData = data;
	local objs = currentObjs;
	local id = CurrentId;
	LuckResultPanel.ToJarMove();
end

function LuckResultPanel.Clear()
	_this.objWater:SetActive(false);
	_this.objLight:SetActive(false);
	_this.objFire:SetActive(false);
	LuckResultPanel.SetBtnsActive(false);
	for i =1 ,#LuckResultPanel.TenItemList do 
		LuckResultPanel.TenItemList[i].clear();
	end
end

function LuckResultPanel.Close()
	LuckResultPanel.Clear();
	isHadJarMove = false;
	isHadLidMove = false;
	_this.resultPanel:SetActive(false);
end

function LuckResultPanel.InitEvent()
	EventButtonListerer.Get(_this.btnOnceMore,LuckResultPanel.OnOnceMoreClick);
	EventButtonListerer.Get(_this.btnSureClick,LuckResultPanel.OnSureClick);
end

function LuckResultPanel.OpenTenPanel(data)
	print("十个Item显示");
	LuckResultPanel.SetIsTenResultView(true);
	LuckResultPanel.SetBtnsActive(false);
	for i=1,#data.itemIds do
		LuckResultPanel.TenItemList[i].SetUI(data.itemIds[i],data.itemNums[i]);
	end
	LuckResultPanel.TenItemList[1].OnStartMove()
end



function LuckResultPanel.OpenOncePanel(data)
	print("1个Item显示");
	LuckResultPanel.SetIsTenResultView(false);
	LuckResultPanel.SetBtnsActive(false);
	local id = data.itemIds[1];
	_this.txtOnceNumber.text =tostring(data.itemNums[1]);
	_this.imgOnceIcon.sprite=CResourceSys.instance:Load(EResType.EIcon,ItemTable[id].icon);
	_this.onceItem.position = normalUpPos;
	_this.onceItem.localScale = Vector3.zero;
	_this.onceItem:DOMove(_this.normalPosObj.position,upTime);
	local ScaleTween=_this.onceItem:DOScale(Vector3.one,upTime);
	ScaleTween:OnComplete(function()
		print("********");
		LuckResultPanel.OnceItemMoveEnd()
	end);
end

function LuckResultPanel.SetBtnsActive(isActive)
	_this.btns_result:SetActive(isActive);
end

function LuckResultPanel.SetIsTenResultView(isTen)
	_this.tenResultPanel.gameObject:SetActive(isTen);
	_this.onceResultPanel.gameObject:SetActive(not isTen);
end

function LuckResultPanel.CloseResultPanelView()
	_this.tenResultPanel.gameObject:SetActive(false);
	_this.onceResultPanel.gameObject:SetActive(false);
end

function LuckResultPanel.RegeditEvent()
	EventButtonListerer.Get(_this.btnOnceMore,LuckResultPanel.OnOnceMoreClick);
	EventButtonListerer.Get(_this.btnSureClick,LuckResultPanel.OnSureClick);
end

function LuckResultPanel.OnOnceMoreClick()
	print("再来一次");
	if(OnOnceMoreCallBack~=nil)then 
		OnOnceMoreCallBack();
	end
	--[[ LuckResultPanel.SetBtnsActive(false);
	LuckResultPanel.CloseResultPanelView(); ]]
end

function LuckResultPanel.OnSureClick()
	print("确定");
	LuckResultPanel.Close();
	LuckSelectPanel.Open();
end