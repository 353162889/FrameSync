﻿--From Lua Script Create
--ClassName: LuckDrawView
--Author:    hukiry
--CreateTime:2018-7-25
require "Logic/LuckDraw/LuckItemsPanel"
require "Logic/LuckDraw/LuckResultPanel"
require "Logic/LuckDraw/LuckSelectPanel"

LuckDrawView = class("LuckDrawView",LuckDrawViewUI)

local _this;

function LuckDrawView:Init()
	_this=self;
	LuckItemsPanel.Init(_this);
	LuckResultPanel.Init(_this);
	LuckSelectPanel.Init(_this);
end

function LuckDrawView:OpenView()
	LuckSelectPanel.Open();
	Main.AddUpdateFun(LuckDrawView.Update,self);
end

function LuckDrawView:CloseView()
	LuckSelectPanel.Close();
	LuckResultPanel.Close();
	LuckItemsPanel.Close();
	Main.RemoveUpdateFun(LuckDrawView.Update);
end

function LuckDrawView.ShowReward(data)
	LuckResultPanel.RefreshData(data)
end

function LuckDrawView.Update(deltaTime)
	LuckSelectPanel.Update();
end