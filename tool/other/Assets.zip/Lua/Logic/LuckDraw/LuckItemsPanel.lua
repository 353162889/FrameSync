﻿--From Lua Script Create
--ClassName: LuckItemsPanel
--Author:    hukiry
--CreateTime:2018-7-25
require "Logic/LuckDraw/LuckListItem"
LuckItemsPanel = {}

local _this;
local heroDatas = {};
local stuffDatas = {};
local itemlist = {}

function LuckItemsPanel.Init(view)
	print("初始化装备碎片或英雄碎片界面");
	_this=view;
	_this.listItem:SetActive(false);
	_this.itemsPanel:SetActive(false);
	LuckItemsPanel.InitEvent();
	LuckItemsPanel.InitHeroData();
	LuckItemsPanel.InitStuffData();
end

function LuckItemsPanel.InitEvent()
	EventButtonListerer.Get(_this.btnListClose,LuckItemsPanel.OnBtnCloseClick);
end

function LuckItemsPanel.Open(isShowHero)
	_this.itemsPanel:SetActive(true);
	if(isShowHero)then
		LuckItemsPanel.ShowHeroList();
	else
		LuckItemsPanel.ShowZhuangbeiList();
	end
end

function LuckItemsPanel.Close()
	for i=1,#itemlist do
		itemlist[i].obj:SetActive(false);
	end
end

function LuckItemsPanel.InitHeroData()
	print("初始化英雄碎片表数据");
	local allHeroIDs = Util.Split(ConstTable["lobby_fight_hero"].p_string,',');
	for i = 1,#allHeroIDs do
		local id=tonumber(allHeroIDs[i]);
		local data ={};
		data.name = HeroTable[id].hero_name;
		data.icon = ItemTable[HeroTable[id].piece_type].icon;
		data.GetNumberStr = function()
			local max = HeroTable[id].piece_amount;
			local our = 0;
			local lstItems = ItemMgr.GetItemsByConfigId(HeroTable[id].piece_type);
			if(#lstItems > 0) then
				our = lstItems[1]:GetCount();
			else
				our = 0;
			end
			local str = tostring(our).."/"..tostring(max);
			return str;
		end 
		table.insert(heroDatas,data);
	end
end

function LuckItemsPanel.InitStuffData()
	print("初始化材料数据");
	local equipmentIDs = Util.Split(ConstTable["equipment_Fragment"].p_string,',');--装备碎片ID
	local gemIDs = Util.Split(ConstTable["gem_Fragment"].p_string,',');--装备碎片ID
	local addStuffIDs = equipmentIDs;
	for i=1,#equipmentIDs do
		table.insert(addStuffIDs,equipmentIDs[i]);
	end
	for i=1,#gemIDs do
		table.insert(addStuffIDs,gemIDs[i]);
	end
	for i=1,#addStuffIDs do
		local id=tonumber(addStuffIDs[i]);
		local data ={};
		data.name = ItemTable[id].name
		data.icon = ItemTable[id].icon;
		data.GetNumberStr = function()
			local hasNum = ItemMgr.GetItemNumByConfigId(itemCode)
			print(hasNum);
			return hasNum;	
		end
		table.insert(stuffDatas,data);
	end
	
end

function LuckItemsPanel.ShowHeroList()
	print("打开英雄碎片列表");
	LuckItemsPanel.RefreshList(heroDatas);
end

function LuckItemsPanel.ShowZhuangbeiList()

	LuckItemsPanel.RefreshList(stuffDatas);
end

function LuckItemsPanel.RefreshList(datas)
	for i =1 ,#itemlist do
		itemlist[i].obj:SetActive(false);
	end
	for i=1,#datas do
		if(i>#itemlist)then
			local obj = LuckItemsPanel.CreateItem();
			local item = LuckListItem.Init(obj,datas[i]);
			table.insert(itemlist,item);
		else
			itemlist[i]:Refresh(datas[i]);
		end
	end
end



function LuckItemsPanel.GetHeroPieceCount(heroID)
	local resHero = HeroTable[heroID];
	if(resHero ~= nil) then
		local lstItems = ItemMgr.GetItemsByConfigId(resHero.piece_type);
		if(#lstItems > 0) then
			return lstItems[1]:GetCount();
		else
			return 0;
		end
	end
	return 0;	
end

function LuckItemsPanel.CreateItem()
	local obj = UnityEngine.GameObject.Instantiate(_this.listItem);
	obj.gameObject:SetActive(true);
	obj.transform:SetParent(_this.listContent.transform,false);
	return obj;
end


function LuckItemsPanel.OnBtnCloseClick()
	_this.itemsPanel:SetActive(false);
end
