﻿--From Lua Script Create
--ClassName: LuckListItem
--Author:    hukiry
--CreateTime:2018-7-25

LuckListItem = class("LuckListItem")

function LuckListItem.Init(obj,data)
	local item=LuckListItem.new();
	item.obj = obj;
	if(item.img==nil)then 
		item.img = item.obj.transform:Find("imgIcon"):GetComponent("Image")
	end
	if(item.txtTitle==nil)then 
		item.txtTitle = item.obj.transform:Find("txtTitle"):GetComponent("Text")
	end
	if(item.txtNumber==nil)then 
		item.txtNumber = item.obj.transform:Find("txtNumber"):GetComponent("Text")
	end
	item:Refresh(data);
	return item;
end

function LuckListItem:Refresh(data)
	self.img.sprite =  CResourceSys.instance:Load(EResType.EIcon,data.icon)
	self.txtTitle.text = data.name;
	self.txtNumber.text = data.GetNumberStr();
end