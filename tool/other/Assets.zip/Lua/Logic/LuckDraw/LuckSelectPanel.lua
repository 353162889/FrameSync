﻿--From Lua Script Create
--ClassName: LuckSelectPanel
--Author:    hukiry
--CreateTime:2018-7-25

LuckSelectPanel ={}
local YuanYangGuoItem = {};
local MoWanGuoItem = {};
local ZhuangBeiGuoItem={}
local GuanZiObjs = {};

local _this;
local isFree = false;
local noFreePrice = 0;

function LuckSelectPanel.Init(view)
	print("初始化抽奖选择界面");
	_this=view;
	for i = 1,3 do
		print(i);
		local parent = _this.selectLuckDrawPanel.transform:GetChild(i-1);
		local table =nil;
		local helpClick = nil;
		local title = nil;
		local oneCost = nil;
		local tenCost = nil;
		if(i==1)then
			table = YuanYangGuoItem;
			helpClick =function()
				 LuckSelectPanel.OnYYHelpClick()
			end
		end
		if(i==2) then
			table = MoWanGuoItem;
			helpClick =function()
				LuckSelectPanel.OnMWHelpClick()
		    end
		 end
		if(i==3)then
			table = ZhuangBeiGuoItem
			helpClick =function()
				LuckSelectPanel.OnZBHelpClick()
		   end
		end
		title = LuckDrawTable[i].name;
		oneCost = LuckDrawTable[i].once_cost;
		tenCost = LuckDrawTable[i].ten_cost;
		table.id = i;
		table.tra = parent;
		table.btn_help = parent:Find("btn_help").gameObject;
		table.btn_once = parent:Find("btn_once").gameObject;
		table.btn_tenTimes = parent:Find("btn_tenTimes").gameObject;
		table.txtOnceGold = parent:Find("OnceGoldItem/Text"):GetComponent("Text");
		table.txtTenGold = parent:Find("TenGoldItem/Text"):GetComponent("Text");
		table.txtTitle =  parent:Find("Title"):GetComponent("Text");
		table.guanZi = parent:Find("ItemShow/GuanZi");
		table.txtTitle.text = title;
		table.txtOnceGold.text = oneCost;
		if(i==1)then 
			noFreePrice = oneCost;
		end
		table.txtTenGold.text = tenCost;
		table.guanZiObjs = {};
		table.guanZiObjs.UpTra = table.guanZi:Find("Up"):GetComponent("RectTransform");
		table.guanZiObjs.MiddleTra = table.guanZi:Find("Middle"):GetComponent("RectTransform");
		table.guanZiObjs.DownTra = table.guanZi:Find("Down"):GetComponent("RectTransform");
		EventButtonListerer.Get(table.btn_help,helpClick);
	end
	 YuanYangGuoItem.txtTitle.text = "鸳鸯锅";
	 MoWanGuoItem.txtTitle.text = "魔丸锅";
	 ZhuangBeiGuoItem.txtTitle.text = "装备锅";

	 LuckSelectPanel.RegeditEvent();
	--[[ LuaHelper.MarkNowTime(2,20); ]]
end

function LuckSelectPanel.Open()
	--[[ _this.sss:SetActive(false); ]]
	_this.selectLuckDrawPanel:SetActive(true);
	LuckSelectPanel.SetFree(MainLobbyManager.isLuckDrawFree);
	_this.txtGoldNumber.text = tostring(MainLobbyManager.playerBaseInfo.gold);
end

function LuckSelectPanel.Close()
	_this.selectLuckDrawPanel:SetActive(false);
end

function LuckSelectPanel.Update()
	if(MainLobbyManager.isLuckDrawFree)then
		return
	end
	local time = LuaHelper.GetTimeStr(2);
	if(time==nil)then 
		MainLobbyManager.isLuckDrawFree = true;
		LuckSelectPanel.SetFree(MainLobbyManager.isLuckDrawFree)
		return;
	else
		_this.txtTime.text = time;
	end
end

function LuckSelectPanel.RegeditEvent()
	EventButtonListerer.Get(_this.btnClose,LuckSelectPanel.OnCloseBtnClick);
	EventButtonListerer.Get(_this.btn_Hero,LuckSelectPanel.OnBtnHeroClick);
	EventButtonListerer.Get(_this.btn_Equipment,LuckSelectPanel.OnBtnEquipmentClick);

	EventButtonListerer.Get(YuanYangGuoItem.btn_once,LuckSelectPanel.OnYYOnceClick);
	EventButtonListerer.Get(YuanYangGuoItem.btn_tenTimes,LuckSelectPanel.OnYYTenClick);

	EventButtonListerer.Get(MoWanGuoItem.btn_once,LuckSelectPanel.OnMWOnceClick);
	EventButtonListerer.Get(MoWanGuoItem.btn_tenTimes,LuckSelectPanel.OnMWTenClick);

	EventButtonListerer.Get(ZhuangBeiGuoItem.btn_once,LuckSelectPanel.OnZBOnceClick);
	EventButtonListerer.Get(ZhuangBeiGuoItem.btn_tenTimes,LuckSelectPanel.OnZBTenClick);
end

function LuckSelectPanel.OnCloseBtnClick()
	ViewSys.instance:Open("MainLobbyView");
end

function LuckSelectPanel.OnFinishTimer()
	print("当前免费倒计时时间结束");
	LuckSelectPanel.SetFree(true);
end

function LuckSelectPanel.OnBtnHeroClick()
	print("打开英雄碎片列表");
	LuckItemsPanel.Open(true)
end

function LuckSelectPanel.OnBtnEquipmentClick()
	print("打开材料碎片列表")
	LuckItemsPanel.Open(false)
end

function LuckSelectPanel.SetFree(bfree)
	print("设置当前是否为免费"..tostring(bfree));
	MainLobbyManager.isLuckDrawFree = bfree;
	_this.timeTitleObj:SetActive(not bfree);
	_this.btnFreeIcon:SetActive(bfree);
	if(bfree)then 
		YuanYangGuoItem.txtOnceGold.text = "0";
	else
		YuanYangGuoItem.txtOnceGold.text = noFreePrice;
	end
end

function LuckSelectPanel.OnYYOnceClick()
	print("鸳鸯锅一次");
	LuckSelectPanel.OnRequestDraw(YuanYangGuoItem.id,false);
end

function LuckSelectPanel.OnYYTenClick()
	print("鸳鸯锅十次");
	LuckSelectPanel.OnRequestDraw(YuanYangGuoItem.id,true);
end

function LuckSelectPanel.OnMWOnceClick()
	print("魔丸锅一次");
	LuckSelectPanel.OnRequestDraw(MoWanGuoItem.id,false);
end

function LuckSelectPanel.OnMWTenClick()
	print("魔丸锅十次");
	LuckSelectPanel.OnRequestDraw(MoWanGuoItem.id,true);
end

function LuckSelectPanel.OnZBOnceClick()
	print("装备锅一次");
	LuckSelectPanel.OnRequestDraw(ZhuangBeiGuoItem.id,false);
end

function LuckSelectPanel.OnZBTenClick()
	print("装备锅十次");
	LuckSelectPanel.OnRequestDraw(ZhuangBeiGuoItem.id,true);
end

function LuckSelectPanel.OnHeroClick()
	print("英雄碎片点击");

end

function LuckSelectPanel.OnEquipmentClick()
	print("装备碎片点击");

end

function LuckSelectPanel.OnRequestDraw(id,isTen)
	print("请求抽奖-->"..id..tostring(isTen));
	local objs = {}
	if(id==1)then 
		objs = YuanYangGuoItem.guanZiObjs;
	end
	if(id==2)then
		objs = MoWanGuoItem.guanZiObjs;
	end
	if(id==3)then
		objs = ZhuangBeiGuoItem.guanZiObjs;
	end
	LuckResultPanel.SetOpenData(id,objs,isTen,function()
		LuckSelectPanel.OnRequestDraw(id,isTen);
	end);
	local data = C2S_LuckDrawData();
	data.draw_type = id;
	data.is_ten_times = isTen;
	NetSys.instance:SendWorldMsg(data:SerializeToString(), C2S_LuckDraw);
	
end

function LuckSelectPanel.OnYYHelpClick()
	print("yy说明");
	LuckSelectPanel.OnShowHelpView(1)
end

function LuckSelectPanel.OnMWHelpClick()
	print("MY说明");
	LuckSelectPanel.OnShowHelpView(2)
end

function LuckSelectPanel.OnZBHelpClick()
	print("ZB说明");
	LuckSelectPanel.OnShowHelpView(3)
end

function LuckSelectPanel.OnShowHelpView(id)
	print("显示描述信息"..id)
	TipMgr.ShowHelpView(string.gsub(LuckDrawTable[id].des,"\\n","\n"),nil)
end
