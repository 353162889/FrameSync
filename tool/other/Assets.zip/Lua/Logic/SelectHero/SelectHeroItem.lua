--From Lua Script Create
--ClassName: SelectHeroItem
--Author:    hukiry
--CreateTime:2018-7-12

SelectHeroItem = class("SelectHeroItem")

function SelectHeroItem.Init(obj,data)
	local item = SelectHeroItem.new();
	item.obj = obj;
	item.data = data;
	item.head = obj.transform:Find("HeadBg/HeadIcon"):GetComponent("Image");
	print("icon。。。。。。"..data.icon);
	item.head.sprite = CResourceSys.instance:Load(EResType.EIcon,data.icon)
	item.selectObj = obj.transform:Find("SelectObj").gameObject;
	item.Mask =  obj.transform:Find("Mask").gameObject;
	item.Mask:SetActive(false);
	item:ClearItem();
	local click =function()
			item:ShowActiveState();
		if(SelectHeroView.IsFreeSelectModel==false)then 
			SelectHeroView.OnRequsetMatchSelectHero(item.data.id);
		end
	end
	EventButtonListerer.Get(item.head.gameObject,click)
	return item;
end

function SelectHeroItem:ClearItem()
	self.selectObj:SetActive(false);
end

function SelectHeroItem:RefreshItem(hadBuy)
	self.data.hadBuy = hadBuy;
	self.obj:SetActive(hadBuy);
end

function SelectHeroItem:ShowActiveState()
	SelectHeroView.ClearCurrentItem();
	SelectHeroView.ShowHeroDes(self);
	self.selectObj:SetActive(true);
	
end

function SelectHeroItem:ShowBySelect(isHadSelect)
	self:ShowActiveState()--暂时先这样处理
end