--From Lua Script Create
--ClassName: SelectHeroView
--Author:    hukiry
--CreateTime:2018-7-12

require "Logic/SelectHero/SelectHeroItem"

SelectHeroView = class("SelectHeroView",SelectHeroViewUI)

local _this;

local allHeroIDs;
local HeroItemList ={};
local HeroItemByIdList ={};--通过ID查找生成的Item
local HeroItemDatas={};
local currentItem =nil;
local IsShowHeroState = true;
local MapId = 1;
local hadBuyItemList = {};
local SelectMaxTime =0;
local isLockHero = false;
local selfTeamHeroIconList = {};
local normalIcon =nil;
local normalPos = nil;
local targetPos = nil;
local moveTime = 2;
local moveToTime =0;
local moveBackTime =0;
local isToMove=true;
SelectHeroView.IsFreeSelectModel=false;

function SelectHeroView:Init()
	_this=self;
	_this.RegeditEvent();
	_this.heroItem:SetActive(false);
	SelectHeroView.InitHeroList();
	SelectHeroView.InitSelfTeamHeroIconList();
	EventSys.instance:AddLuaEvent(GameEvent.MatchResult,SelectHeroView.OnMatchResult);
	SelectHeroView.InitArrowMove();

	VoiceHelper:Init(self.objVoice:GetComponent("VoiceCtrlUI"));
end

function SelectHeroView:OpenView(param)
	local objParam = param.objParam;
	MapId = objParam["MatchId"];
	MatchingManager_3V3.MatchId = MapId;
	if(MapId==1 or MapId==2)then 
		SelectHeroView.ToFreeSelectMode()
		self.objVoice:SetActive(false);
	else
		SelectHeroView.ToRankSelectMode()
		self.objVoice:SetActive(true);
		VoiceHelper:Refresh(self.objVoice:GetComponent("VoiceCtrlUI"));
	end
	Main.AddUpdateFun(SelectHeroView.Update,self);
	SelectHeroView.ShowHeroBtn(true);
	SelectHeroView.RefreshHeroList();
	SelectHeroView.ShowBuyBtn(false);
	SelectHeroView.RefreshArrowActive()
	isLockHero =false;
	_this.heroListMask:SetActive(false);
end

function SelectHeroView:CloseView()
	SelectHeroView.ClearHeroList();
	SelectHeroView.ClearSelfTeamHeroIconList()
	Main.RemoveUpdateFun(SelectHeroView.Update);
	currentItem = nil;
end

function SelectHeroView.OnMatchResult(eventId,succ)
	if(succ==true)then 
		print("接收到进入游戏的消息");
		MatchingManager_3V3.isReady = false;
		ViewSys.instance:Close("SelectHeroView");
	end
end

function SelectHeroView.RegeditEvent()
	EventButtonListerer.Get(_this.heroNormalBtn,SelectHeroView.OnHeroBtnClick)
	EventButtonListerer.Get(_this.skinNormalBtn,SelectHeroView.OnSkinBtnClick)
	EventButtonListerer.Get(_this.sureBtn,SelectHeroView.OnSureBtnClick)
	EventButtonListerer.Get(_this.buyBtn,SelectHeroView.OnBuyBtnClick)
	EventButtonListerer.Get(_this.backBtn,SelectHeroView.OnBackBtnClick)
	EventButtonListerer.Get(_this.randomItem,SelectHeroView.OnRandomItemClick)
	NetSys.instance:AddMsgCallback(EChannelType.EWorldChannel, S2C_MatchSelectHeroNotify,SelectHeroView.OnReceiveSelectHero, nil);	
	NetSys.instance:AddMsgCallback(EChannelType.EWorldChannel, S2C_MatchLockHeroNotify,SelectHeroView.OnReceiveLockHero, nil);	
end

function SelectHeroView.InitSelfTeamHeroIconList()
	print("初始化队伍选中英雄的显示列表");
	normalIcon = _this.playerHero_1.sprite;
	table.insert(selfTeamHeroIconList,_this.playerHero_1)
	table.insert(selfTeamHeroIconList,_this.playerHero_2)
	table.insert(selfTeamHeroIconList,_this.playerHero_3)
	table.insert(selfTeamHeroIconList,_this.playerHero_4)
end

function SelectHeroView.ClearSelfTeamHeroIconList()
	print("清理队伍选中英雄的显示列表")
	for i=1,#selfTeamHeroIconList do
		selfTeamHeroIconList[i].sprite = normalIcon;
		selfTeamHeroIconList[i].color = Color(1,1,1,1);
	end
end

function SelectHeroView.ShowLockHeroIcon(index,heroId)
	print("显示玩家锁定的英雄"..tostring(index));
	selfTeamHeroIconList[index].sprite = CResourceSys.instance:Load(EResType.EIcon,"HeroIcon/"..heroId..".png")
	selfTeamHeroIconList[index].color = Color(1,1,1,1);
end

function SelectHeroView.ShowSelectHeroIcon(index,heroId)
	print("显示玩家选中的英雄"..tostring(index));
	selfTeamHeroIconList[index].sprite = CResourceSys.instance:Load(EResType.EIcon,"HeroIcon/"..heroId..".png")
	selfTeamHeroIconList[index].color = Color(1,1,1,0.3);
end

function SelectHeroView.OnRequsetMatchSelectHero(id)
	print("发送选中英雄的消息");
	local data = C2S_MatchSelectHeroData()
	data.hero_id = id;
	NetSys.instance:SendWorldMsg(data:SerializeToString(), C2S_MatchSelectHero);
end

function SelectHeroView.OnRequsetLockHero(id)
	print("发送锁定英雄的消息");
	local data = C2S_MatchLockHeroData()
	data.hero_id = id;
	NetSys.instance:SendWorldMsg(data:SerializeToString(), C2S_MatchLockHero);
end

function SelectHeroView.SelectOrLockToUpdateView(isLock,userId,heroId)
	if(userId==LoginInfo.userId)then 
		print("自己锁定英雄")
		return;
	end
	local selfTeam = false
	local index =nil;
	for i=1,#MatchingManager_3V3.MatchPlayerInfos.selfTeamInfo do
		if(MatchingManager_3V3.MatchPlayerInfos.selfTeamInfo[i]==userId)then 
			selfTeam=true;
			index = i;
		end
	end

	if(selfTeam==false)then 
		for i=1,#MatchingManager_3V3.MatchPlayerInfos.selfRebootInfo do
			if(MatchingManager_3V3.MatchPlayerInfos.selfRebootInfo[i]==userId)then 
				selfTeam=true;
				index = i+#MatchingManager_3V3.MatchPlayerInfos.selfTeamInfo;
			end
		end
	end

	if(selfTeam==true)then 
		if(isLock==true)then 
			print("显示锁定英雄");
			SelectHeroView.ShowLockHeroIcon(index,heroId);
		else
			print("显示选中英雄");
			SelectHeroView.ShowSelectHeroIcon(index,heroId);
		end
	
	end
	--SelectHeroView.ToLockHeroMode();
end

function SelectHeroView.OnReceiveLockHero(this,objMsg)
	print("接收到玩家锁定英雄的消息")
	local msg = S2C_MatchLockHeroNotifyData(); 
	msg:ParseFromString(objMsg); 
	print("user_id"..msg.user_id);
	print("hero_id"..msg.hero_id);
	SelectHeroView.SelectOrLockToUpdateView(true,msg.user_id,msg.hero_id)
	--SelectHeroView.ToLockHeroMode();
end

function SelectHeroView.OnReceiveSelectHero(this,objMsg)
	print("接收到玩家选中英雄的消息")
	local msg = S2C_MatchSelectHeroNotifyData(); 
	msg:ParseFromString(objMsg); 
	if(msg.user_id==LoginInfo.userId)then
		print("自己选中英雄"); 
		return;
	end
	print("user_id"..msg.user_id);
	print("hero_id"..msg.hero_id);
	
	--HeroItemList[HeroItemByIdList[msg.hero_id]]:ShowBySelect(true);
	SelectHeroView.SelectOrLockToUpdateView(false,msg.user_id,msg.hero_id)
end

function SelectHeroView.Update(deltaTime)
	SelectHeroView.UpdateTimer()
	SelectHeroView.UpdateArrow()
end

function SelectHeroView.InitArrowMove()
	normalPos = _this.arrow.position;
	targetPos = Vector3(normalPos.x,normalPos.y-0.5,normalPos.z);
	isToMove=true;
end 

function SelectHeroView.RefreshArrowActive()
	print("根据已购买的英雄数量刷新箭头显示,当前购买英雄为："..tostring(#hadBuyItemList));
	_this.arrow.gameObject:SetActive(#hadBuyItemList+1>9);
end

function SelectHeroView.UpdateArrow()
	if(_this.arrow.gameObject.activeSelf==false)then 
		return;
	end
	SelectHeroView.ArrowMoveTo();
	SelectHeroView.ArrowMoveBack();
end

function SelectHeroView.ArrowMoveTo()
	if(isToMove==false)then 
		return;
	end
	if(_this.arrow.position~=targetPos)then 
		moveBackTime=0;
		moveToTime =  moveToTime + ((1/ moveTime) * UnityEngine.Time.deltaTime);
		_this.arrow.position = Vector3.Lerp(normalPos, targetPos, moveToTime); 
	else
		isToMove = false;
	end
end

function SelectHeroView.ArrowMoveBack()
	if(isToMove==true)then 
		return;
	end
	if(_this.arrow.position~=normalPos)then 
		moveToTime=0;
		moveBackTime =  moveBackTime + ((1/ moveTime) * UnityEngine.Time.deltaTime);
		_this.arrow.position = Vector3.Lerp(targetPos, normalPos, moveBackTime);  
	else
		isToMove = true;
	end
end

function SelectHeroView.UpdateTimer()
	if(SelectMaxTime==0)then 
		return;
	end
	local time = LuaHelper.GetCostTime(-3,SelectMaxTime);
	_this.timeText.text = tostring(time);
	if(time <=0)then 
		print("TODO强制进入游戏");
		SelectMaxTime=0;
	end
end

function SelectHeroView.InitHeroList()
	print("初始化所有英雄");
	allHeroIDs = Util.Split(ConstTable["lobby_fight_hero"].p_string,',');
	for i = 1,#allHeroIDs do
		local id=tonumber(allHeroIDs[i]);
		local data ={};
		data.id = id
		print("allHeroIDs[i]"..allHeroIDs[i])
		data.icon = HeroTable[id].bigIcon;
		data.skillIcon = HeroTable[id].active_skill[3];
		--[[ local attack2 = SkillTable[id].attack2 ]]
		local attackDes = nil;
		attackDes = SkillTable[id].attack1;
		--[[ if attack2~="暂无" then
			attackDes= SkillTable[id].attack1..",第三次攻击"..attack2
		else
			attackDes = SkillTable[id].attack1
		end ]]
		data.name = HeroTable[id].hero_name;
		data.attackDes = attackDes;
		data.skillDes = SkillTable[id].skill
		data.hadBuy =false;
		data.skinIDs = HeroTable[id].avatar_skin;
		data.currentSkinId = data.skinIDs[1];--默认选中皮肤为第一个
		table.insert(HeroItemDatas,data);
	end

	for i = 1,#HeroItemDatas do
		local obj = SelectHeroView.CreatHeroItem();
		local data = HeroItemDatas[i];
		local item =  SelectHeroItem.Init(obj,data);
		HeroItemByIdList[data.id] = i;
		table.insert(HeroItemList,item);
	end
end

function SelectHeroView.RefreshHeroList()
	_this.heroShow.gameObject:SetActive(false);
	IsShowHeroState = true;
	hadBuyItemList={};
	print("刷新英雄列表");
	local hadBuy ;
	for i =1,#HeroItemList do
		hadBuy = MainLobbyManager.IsHeroBuy(HeroItemList[i].data.id);
		HeroItemList[i]:RefreshItem(hadBuy);
		if(hadBuy==true)then 
			table.insert(hadBuyItemList,HeroItemList[i]);
		end
	end
end

function SelectHeroView.ClearHeroList()
	for v,k in pairs(HeroItemList) do
		k:ClearItem();
	end
end

function SelectHeroView.ShowHeroDes(item)
	_this.heroShow.gameObject:SetActive(true);
	local data = item.data;
	currentItem = item;
	_this.nameText.text = data.name;
	_this.attackDes.text = data.attackDes;
	if(IsShowHeroState == true)then 
		_this.heroShow.sprite = CResourceSys.instance:Load(EResType.EIcon,"HeroIcon/"..data.id..".png")
	else
		_this.heroShow.sprite = CResourceSys.instance:Load(EResType.EIcon,"HeroIcon/"..data.currentSkinId..".png");
	end
	_this.skillIcon.sprite = CResourceSys.instance:Load(EResType.EIcon,"Skill/"..data.skillIcon..".png")
	_this.skillDes.text = data.skillDes;
end	

function SelectHeroView.ClearCurrentItem()
	if(currentItem==nil)then 
		return
	end
	currentItem:ClearItem();
end

function SelectHeroView.CreatHeroItem()
	local obj = UnityEngine.GameObject.Instantiate(_this.heroItem);
	obj.gameObject:SetActive(true);
	obj.transform:SetParent(_this.content,false);
	return obj;
end

function SelectHeroView.ShowHeroBtn(isHero)
	_this.heroActiveBtn:SetActive(isHero);
	_this.heroNormalBtn:SetActive(not isHero);
	_this.skinActiveBtn:SetActive(not isHero);
	_this.skinNormalBtn:SetActive(isHero);
end

function SelectHeroView.ShowBuyBtn(isBuy)
	_this.sureBtn:SetActive(not isBuy);
	_this.buyBtn:SetActive(isBuy);
end

function SelectHeroView.OnBuyBtnClick()
	print("购买按钮点击")
	
end

function SelectHeroView.OnSureBtnClick()
	print("确定按钮点击")
	if(currentItem==nil or currentItem.data==nil or currentItem.data.id ==nil)then 
		print("未能获取到选中的英雄信息");
		return;
	end
	local heroId = tonumber(currentItem.data.id);
	local skinId = tonumber(currentItem.data.currentSkinId);
	if(MapId==1 or MapId==2)then 
		MatchMgr.ReqStartMatch(MapId, heroId,  skinId);
	else
		SelectHeroView.OnRequsetLockHero(heroId)
		SelectHeroView.ToLockHeroMode();
	end
end

function SelectHeroView.OnBackBtnClick()
	print("返回按钮点击");
	ViewSys.instance:Open("MainLobbyView");
	ViewSys.instance:Close("SelectHeroView");
end

function SelectHeroView.OnSkinBtnClick()
	print("皮肤按钮点击");
	if(currentItem==nil)then 
		return;
	end
	IsShowHeroState = false;
	SelectHeroView.ShowHeroBtn(false)
	SelectHeroView.ShowBuyBtn(true);
	print(currentItem.data.id);
	print(currentItem.data.skinID);
	_this.heroShow.sprite = CResourceSys.instance:Load(EResType.EIcon,"HeroIcon/"..currentItem.data.currentSkinId..".png");
end

function SelectHeroView.OnHeroBtnClick()
	print("英雄按钮点击");
	if(currentItem==nil)then 
		return;
	end
	IsShowHeroState = true;
	SelectHeroView.ShowHeroBtn(true)
	SelectHeroView.ShowBuyBtn(false);
	if(isLockHero==true)then 
		_this.sureBtn:SetActive(false);
	end
	_this.heroShow.sprite = CResourceSys.instance:Load(EResType.EIcon,"HeroIcon/"..currentItem.data.id..".png");
end

function SelectHeroView.OnRandomItemClick()
	print("随机英雄");
	if(currentItem~=nil)then 
		currentItem:ClearItem();
	end
	local random = math.random(1,#hadBuyItemList);
	print(random);
	hadBuyItemList[random]:ShowActiveState();
end

function SelectHeroView.ToFreeSelectMode()
	print("自由选择模式");
	SelectHeroView.IsFreeSelectModel = true;
	_this.backBtn:SetActive(true);
	_this.playerHeros:SetActive(false);
	_this.timeBg:SetActive(false);
end

function SelectHeroView.ToRankSelectMode()
	print("排摸选择模式");
	SelectHeroView.IsFreeSelectModel = false;
	_this.backBtn:SetActive(false);
	_this.playerHeros:SetActive(true);
	_this.timeBg:SetActive(true);
	LuaHelper.SetMatchingTimer(-3);
	SelectMaxTime=60;
end

function SelectHeroView.ToLockHeroMode()
	print("锁定英雄模式");
	isLockHero =true;
	_this.heroListMask:SetActive(true);
	_this.sureBtn:SetActive(false);
end