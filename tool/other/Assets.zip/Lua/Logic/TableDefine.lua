
function InitTableData(resName)
	require("Pb/Data/"..resName.."_pb")
	
    local arrBytes = CResourceSys.instance:LoadTable("cc_"..resName..".bytes");
	local resTable = loadstring("return "..resName.."_ARRAY()")();
	resTable:ParseFromString(CResourceSys.instance.curData);

    local newTable = {};
	for k, v in pairs(resTable.items) do
	    if nil == v.id then
		    if nil ~= v.name and "_message_descriptor" ~= k then
	            newTable[v.name] = v;
			elseif nil ~= v.key then
				newTable[v.key] = v;
			end
        else
    		newTable[v.id] = v;
		end
	end
	return newTable;
end

UITable = InitTableData("ResUI")
FoodTable = InitTableData("ResFood");
ConstTable = InitTableData("ResConst");
HeroTable = InitTableData("ResHero");
SoldierTable = InitTableData("ResSoldier");
SessionTable = InitTableData("ResSession");
AudioTable = InitTableData("ResAudio");
ResCoinLevelTable = InitTableData("ResCoinLevel");
ItemTable = InitTableData("ResItem");
SkillTable = InitTableData("ResSkill");
MallTable = InitTableData("ResMall");
MediaTable = InitTableData("ResMedia");
SignInTable = InitTableData("ResSignReward");
ShopTable = InitTableData("ResSecretShop");
ShopPriceRefresh = InitTableData("ResSecretShopRefresh");--神秘商店价格刷新表
SceneTable = InitTableData("ResScene");
BuffTable = InitTableData("ResBuff");
HeadPictureTable = InitTableData("HeadPicture");--头像列表
RankLevelTable = InitTableData("RankLevel");
ResEquipTable = InitTableData("ResEquip");--装备配置
AreaTable = InitTableData("ResArea");
LuckDrawTable = InitTableData("ResDraw");
ResDescTable = InitTableData("ResDesc")
ResAmusementTable = InitTableData("ResAmusement")
ResAmusementRewardTable = InitTableData("ResAmusementReward")
