LobbyView = class("LobbyView", LobbyViewUI)

function LobbyView:Init()
    local onClickPlay = function (go)
		self:OnClickLogin();
	end
	EventTriggerListener.Get(self.btnPlay).onClick = EventTriggerListener.Get(self.btnPlay).onClick + onClickPlay;

	local onClickChangeName = function (go)
		local curName = MainLobbyManager.playerBaseInfo.name;
		if(curName == nil or curName == "") then
			ViewSys.instance:Open("LobbyNameView");
		end
	end
	EventTriggerListener.Get(self.btnChangeNickName).onClick = EventTriggerListener.Get(self.btnChangeNickName).onClick + onClickChangeName;
end

function LobbyView:OpenView(param)
	local curName = MainLobbyManager.playerBaseInfo.name;
	if(curName == nil or curName == "") then
		ViewSys.instance:Open("LobbyNameView");
	end

	self.onRename = function ( eventId,obj)
		self:RefreshName();
	end
	EventSys.instance:AddLuaEvent(GameEvent.Rename,self.onRename);

	self:RefreshName();
end

function LobbyView:RefreshName()
	local curName = MainLobbyManager.playerBaseInfo.name;
	if(curName == nil) then curName = "" end;
	self.nickName.text = curName;
end

function LobbyView:CloseView()
	if(self.onRename ~= nil) then
		EventSys.instance:RemoveLuaEvent(GameEvent.Rename,self.onRename);
		self.onRename = nil;
	end
end

function LobbyView:DestroyView()

end

function LobbyView:OnClickLogin(go)
	local curName = MainLobbyManager.playerBaseInfo.name;
	if(curName == nil or curName == "") then
		TipMgr.ShowTipType2("please input name first!",nil);
		return;
	end

	SDKManager.instance:OnTDEvent("创建角色");
	
    ViewSys.instance:Close("LobbyView");
    ViewSys.instance:Open("MainLobbyView");
end

