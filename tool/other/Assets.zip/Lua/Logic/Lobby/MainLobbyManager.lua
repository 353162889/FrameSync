--大厅数据管理层

MainLobbyManager = class(MainLobbyManager)

local allHeros = {};
local ErrorNoticeTable={};
local _curSkinIndex = 0;
MainLobbyManager.playerBaseInfo = nil;
MainLobbyManager.heroList = nil;
MainLobbyManager.isHadBuyYueKa=false;
MainLobbyManager.ShopRewardOverCallBack=nil;
MainLobbyManager.HeadPictureId =1;--头像Id默认为1
MainLobbyManager.isLuckDrawFree=false --抽奖是否免费

function MainLobbyManager.Init()
	EventSys.instance:AddEvent(EEventType.EReconnect,MainLobbyManager.OnReconnect);	
	EventSys.instance:AddLuaEvent(GameEvent.MatchResult,MainLobbyManager.OnMatchResult);
	NetSys.instance:AddMsgCallback(EChannelType.EWorldChannel, S2C_GiveNameResult, MainLobbyManager.S2C_GiveNameResultData, nil); 
    NetSys.instance:AddMsgCallback(EChannelType.EWorldChannel, S2C_LoginAnotherPlace, MainLobbyManager.S2C_LoginAnotherPlaceData, nil); 
    NetSys.instance:AddMsgCallback(EChannelType.EWorldChannel, S2C_PushItemGet, MainLobbyManager.S2C_PushItemGetData, nil); 
	NetSys.instance:AddMsgCallback(EChannelType.EWorldChannel, S2C_PlayerBaseInfo, MainLobbyManager.S2C_PlayerBaseInfoData, nil);
    NetSys.instance:AddMsgCallback(EChannelType.EWorldChannel, S2C_HeroList, MainLobbyManager.S2C_HeroListData, nil);
    NetSys.instance:AddMsgCallback(EChannelType.EWorldChannel, S2C_HeroSync, MainLobbyManager.S2C_HeroSyncData, nil);
    NetSys.instance:AddMsgCallback(EChannelType.EWorldChannel, S2C_BuyHeroResult, MainLobbyManager.S2C_BuyHeroResultData, nil);
    NetSys.instance:AddMsgCallback(EChannelType.EWorldChannel, S2C_BuyHeroSkinResult, MainLobbyManager.S2C_BuyHeroSkinResultData, nil);
	NetSys.instance:AddMsgCallback(EChannelType.EWorldChannel,S2C_UpdateResoucesResult,MainLobbyManager.S2C_UpdateResoucesResultData,nil);
	NetSys.instance:AddMsgCallback(EChannelType.EWorldChannel, S2C_MonthCard, MainLobbyManager.S2C_MonthCardData, nil);
	NetSys.instance:AddMsgCallback(EChannelType.EWorldChannel, S2C_OperatNotice, MainLobbyManager.OnReceiveOperatNotice, nil);--错误提示
	NetSys.instance:AddMsgCallback(EChannelType.EWorldChannel, S2C_LuckDrawRefreshTime, MainLobbyManager.OnReceiveLuckDrawRefreshTime, nil);--免费抽奖刷新时间
	MainLobbyManager.InitErrorTip();
	--初始化声音大小
	local value = ConstTable["audio_volume"].p_int/1000;
	AudioSys.instance:SetAllVol(value);
end

function MainLobbyManager.InitErrorTip()
	ErrorNoticeTable[1070]="对方太忙了";
	ErrorNoticeTable[1071]="重复申请";
	ErrorNoticeTable[1072]="已经是好友了";
	ErrorNoticeTable[1073]="对方没有添加你为好友";
	ErrorNoticeTable[1074]="好友满了";
	ErrorNoticeTable[1075]="对方好友满了";
	ErrorNoticeTable[1076]="你们不是好友";
	ErrorNoticeTable[10100]="已经在队伍里了";
	ErrorNoticeTable[10101]="队伍满了";
	ErrorNoticeTable[10102]="对方已经有队伍了";
	ErrorNoticeTable[10103]="有队伍正在邀请你";
	ErrorNoticeTable[10104]="队伍邀请已过期";
	ErrorNoticeTable[10105]="队伍已经解散";
	ErrorNoticeTable[10106]="你还没有队伍";
	ErrorNoticeTable[10107]="没有人邀请你";
	ErrorNoticeTable[10108]="队伍正在匹配中";
	ErrorNoticeTable[10109]="对方繁忙";

	ErrorNoticeTable[1]="登陆验证失败";
	ErrorNoticeTable[2]="系统错误";
	ErrorNoticeTable[3]="操作过于频繁";
	ErrorNoticeTable[4]="操作无效";
	ErrorNoticeTable[3]="操作过于频繁";
	ErrorNoticeTable[4]="操作无效";
	ErrorNoticeTable[5]="对方不在线";
	ErrorNoticeTable[6]="参数错误";
	ErrorNoticeTable[7]="名字的字符长度在2到7个汉字";

	ErrorNoticeTable[8]="尚未解锁";
	ErrorNoticeTable[9]="禁止带有中文";
	ErrorNoticeTable[10]="禁止带有特殊字符";
	ErrorNoticeTable[11]="名字已经被使用";
	ErrorNoticeTable[12]="已经起过名字了";
	ErrorNoticeTable[13]="还没起名字";	
	ErrorNoticeTable[14]="版本号错误";

	ErrorNoticeTable[100]="系统配置出错";	
	ErrorNoticeTable[101]="不存在此用户";

	ErrorNoticeTable[1018]="银币不足";
	ErrorNoticeTable[1019]="金币不足";
	ErrorNoticeTable[1020]="货币不足";
	ErrorNoticeTable[1021]="英雄皮肤未解锁";
end

function MainLobbyManager.OnReceiveOperatNotice(this,objMsg)
	local msg = S2C_OperatNoticeData();
	msg:ParseFromString(objMsg);
	print("接收到错误提示"..msg.errornum);
	for v,k in pairs(ErrorNoticeTable) do
		if(v==msg.errornum)then 
			MainLobbyManager.ShowErrorPanel(k)
		end
	end
end

function MainLobbyManager.OnReceiveLuckDrawRefreshTime(this,objMsg)
	local msg = S2C_LuckDrawRefreshTimeData();
	msg:ParseFromString(objMsg);
	print("接收到抽奖刷新时间更新："..msg.time_remaining);
	MainLobbyManager.isLuckDrawFree = false;
	LuaHelper.MarkNowTime(2,msg.time_remaining);--假设此时接收到免费倒计时消息
end

function MainLobbyManager.ShowErrorPanel(content)
	TipMgr.ShowTipType2(content,nil,nil)
end

function MainLobbyManager.S2C_MonthCardData(obj, objMsg)
	local msg = S2C_MonthCardData(); 
	msg:ParseFromString(objMsg); 
	print("月卡剩余时间:"..msg.time_remaining)
	--[[ if(msg.time_remaining>0) then
		MainLobbyManager.SetYueKaInfo(true)
	else
		MainLobbyManager.SetYueKaInfo(false)
	end ]]
end

function MainLobbyManager.SetYueKaInfo(had)
	MainLobbyManager.isHadBuyYueKa = had
	--[[ if(ViewSys.instance:IsOpen("MainLobbyView")) then
		MainLobbyView.UpdateYueKaInfo(MainLobbyManager.isHadBuyYueKa)
	end ]]
end

function MainLobbyManager.S2C_LoginAnotherPlaceData(obj, objMsg)
    -- body
    TipMgr.ShowTipType2("The account is logged in from another place",function () CGameRoot.instance:ApplicationExit(); end,false)
    print("在另一个地方登陆"); 
end

function MainLobbyManager.S2C_PushItemGetData(obj, objMsg)
	-- body
	
    local msg = S2C_PushItemGetData();
	msg:ParseFromString(objMsg);
	print("接收到奖品信息"..#msg.item_list);
	local datas = {};
	datas.itemIds = {};
	datas.itemNums = {};
    for k,v in ipairs(msg.item_list) do
		table.insert(datas.itemIds,v.config_id);
		table.insert(datas.itemNums,v.count);
		print(v.config_id);
		print(v.count);
	end
	-- --通过判断来源弹框
	 if(msg.item_get_type == ItemGetType_PersonSecertShop) then  
		local callBack = nil;
		if(MainLobbyManager.ShopRewardOverCallBack~=nil)then 
			callBack = MainLobbyManager.ShopRewardOverCallBack;
		end
		TipMgr.ShowRewardTip(nil,datas.itemIds,datas.itemNums,callBack);
	 end
	 if(msg.item_get_type == ItemGetType_Draw)then 
		--LuckDrawView.ShowReward(data)
		LuckResultPanel.RefreshData(datas);
	 end
	--默认弹获取奖励框
	
	
end

function MainLobbyManager.OnMatchResult(eventId,succ)
	if(succ) then
		ViewSys.instance:Close("MainLobbyView");
		BattleSceneLoad.Load()
	end
end

function MainLobbyManager.S2C_GiveNameResultData(obj, objMsg)
	--取名称
	
	 local msg = S2C_GiveNameResultData(); 
	msg:ParseFromString(objMsg);
	print("接收到改名成功的消息..name:"..tostring(msg.name).."次数:"..msg.modify_name_times);
	MainLobbyManager.playerBaseInfo.name =  msg.name;
	MainLobbyManager.playerBaseInfo.name_modify_times =  msg.modify_name_times;
	EventSys.instance:DispatchLua(GameEvent.Rename);
   --[[  if(msg.error_num == Error_None) then
    	--
    	MainLobbyManager.playerBaseInfo.name = msg.name;
    	
    elseif(msg.error_num == Error_NamedAlready) then
    	TipMgr.ShowTipType2("name format error,Rename Failed!",nil);
    else
    	TipMgr.ShowTipType2("The name already exists,Rename Failed!",nil);
    end ]]
end


function MainLobbyManager.S2C_PlayerBaseInfoData(this, objMsg)
	print("S2C_PlayerBaseInfoData信息改变");
    local msg = S2C_PlayerBaseInfoData(); 
    msg:ParseFromString(objMsg); 
	MainLobbyManager.playerBaseInfo = msg;
	print("MainLobbyManager.playerBaseInfo.name_modify_times"..MainLobbyManager.playerBaseInfo.name_modify_times);
	--modify_name_times
end

function MainLobbyManager.S2C_HeroListData(this, objMsg)
    local msg = S2C_HeroListData(); 
    msg:ParseFromString(objMsg); 
	MainLobbyManager.heroList = msg.hero_list;
	-- print("MainLobbyManager.heroList 收到")
end

function MainLobbyManager.S2C_HeroSyncData(this, objMsg)
    print("MainLobbyManager.S2C_HeroSyncData");
    local msg = S2C_HeroSyncData(); 
    msg:ParseFromString(objMsg); 
    MainLobbyManager.UpdateList(msg.hero_item);
    EventSys.instance:DispatchLua(GameEvent.HeroSync);
end

function MainLobbyManager.S2C_BuyHeroResultData(this, objMsg)
    local msg = S2C_BuyHeroResultData(); 
    msg:ParseFromString(objMsg); 
    if msg.error_num == Error_None then
		HeroInfoView:Refresh();
		SDKManager.instance:OnTDEvent("英雄" .. msg.hero_id .. "解锁次数");
    end
end

function MainLobbyManager.S2C_BuyHeroSkinResultData(this, objMsg)
    local msg = S2C_BuyHeroSkinResultData(); 
    msg:ParseFromString(objMsg); 
    if msg.error_num == Error_None then
        HeroInfoView:Refresh();
    end
end

function MainLobbyManager.S2C_UpdateResoucesResultData(this, objMsg)
	print("角色金币信息更新");
    local msg = S2C_UpdateResoucesResultData()
    msg:ParseFromString(objMsg); 
    if(msg.r_id == HumanResouceType_Silver) then
        MainLobbyManager.playerBaseInfo.silver = msg.num;
    elseif(msg.r_id == HumanResouceType_Gold) then
		MainLobbyManager.playerBaseInfo.gold = msg.num;
	elseif(msg.r_id==HumanResouceType_RMB) then
		MainLobbyManager.playerBaseInfo.rmb = msg.num;
    end
    EventSys.instance:DispatchLua(GameEvent.PlayerResourcesUpdate);
end


function MainLobbyManager.UpdateList(heroInfo)
    --判断当前的英雄是否已经购买
    for i=1,#MainLobbyManager.heroList do
        if tonumber(heroInfo.config_id) == tonumber(MainLobbyManager.heroList[i].config_id) then
            MainLobbyManager.heroList[i] = heroInfo;
            return;
        end
    end
    table.insert(MainLobbyManager.heroList, heroInfo);
end


function MainLobbyManager.OnReconnect(eventId,arr)
	local channelType = arr[0];
	local reconnectCode = arr[1];
	if(channelType ~= EChannelType.EWorldChannel) then return end
	if(reconnectCode ~= Error_None) then
		Util.LogError("服务器重连失败!")
		TipMgr.ShowTipType2("Server disconnected, please re-enter the game",function ()
				CGameRoot.instance:ApplicationExit();
			end,false);
		return;
	end
end

function MainLobbyManager.IsHeroBuy(heroID)
	for i = 1, #MainLobbyManager.heroList do
		if heroID == tonumber(MainLobbyManager.heroList[i].config_id) then
			return true;
		end
	end
	return false;
end

--获取英雄数据
function MainLobbyManager.GetHeroDataByHeroID(heroID)
	local heroData
	for _,v in pairs(MainLobbyManager.heroList) do
		if v.config_id == heroID then
			heroData = v
			break
		end
	end

	if not heroData then
		error("不存在heroID:"..heroID.."的英雄 !")
	end

	return heroData
end

--获取装备ID 
function MainLobbyManager.GetEquipID(heroID, equipIndex)
	local equipID
	local isUnlock = false
	if MainLobbyManager.IsHeroBuy(heroID) == true then
		local heroData = MainLobbyManager.GetHeroDataByHeroID(heroID)
		for _,id in ipairs(heroData.equipment_list) do
			local equipInfo = ResEquipTable[id]
			-- print("ID:"..id)
			-- print(equipInfo.is_base)
			if equipInfo.type == equipIndex and equipInfo.is_base == false then --非基础装备
				equipID = equipInfo.id
				break
			end
		end
	end

	if not equipID then
		-- print("未解锁")
		local heroInfo = HeroTable[heroID]
		for k,v in ipairs(heroInfo.unlock_equipment_list) do
			local equipInfo = ResEquipTable[v]
			if equipInfo.type == equipIndex then 
				equipID = equipInfo.id
			end
		end
	else
		isUnlock = true
	end
	-- print("equipID:"..equipID)
	return equipID,isUnlock
end

function MainLobbyManager.IsSkinHave(heroID, skinID)
	for i = 1, #MainLobbyManager.heroList do
		if heroID == tonumber(MainLobbyManager.heroList[i].config_id) then
			if heroID == skinID then 
				return true;
			else
				if MainLobbyManager.heroList[i].skin_list ~= nil then
					for j=1,#MainLobbyManager.heroList[i].skin_list do
						if skinID ==tonumber(MainLobbyManager.heroList[i].skin_list[j]) then
							return true;
						end
				    end
				end
				return false;
			end
		end
	end
	return false;
end

function MainLobbyManager.GetHeroPriceById(heroID)
	if allHeros[heroID] == nil then
		MainLobbyManager.InitHero(heroID);
	end
	return allHeros[heroID]["gold"];
end

function MainLobbyManager.InitHero(heroID)
	local resHero = HeroTable[heroID];
	local data = {};
	data["gold"] = resHero.unlock_amount;
	data["skins"] = resHero.avatar_skin;
	data["name"] = resHero.hero_name;
	allHeros[heroID] = data;
end

function MainLobbyManager.GetSkinID(heroID)
	if allHeros[heroID] == nil then
		MainLobbyManager.InitHero(heroID);
	end
	local t = allHeros[heroID]["skins"];
	if #t == 1 then
		_curSkinIndex = 0;
	else
		_curSkinIndex = (_curSkinIndex + 1) % #t;
	end
	return tonumber(t[_curSkinIndex + 1]);
end

function MainLobbyManager.GetHeroName(heroID)
	if allHeros[heroID] == nil then
		MainLobbyManager.InitHero(heroID);
	end
	return allHeros[heroID]["name"];
end

function MainLobbyManager.GetHeroDebrisCount(heroID)
	-- body
	local resHero = HeroTable[heroID];
	if(resHero ~= nil) then
		local lstItems = ItemMgr.GetItemsByConfigId(resHero.piece_type);
		if(#lstItems > 0) then
			return lstItems[1]:GetCount();
		else
			return 0;
		end
	end
	return 0;	
end

function MainLobbyManager.GetHeroDebrisMaxCount(heroID)
	-- body
	local resHero = HeroTable[heroID];
	if(resHero ~= nil) then
		return resHero.piece_amount;
	else
		Util.LogError("can not find heroID = "..heroID.." config");
		return 1;
	end
end

function MainLobbyManager.ResetSkinIndex()
	_curSkinIndex = 0;
end
