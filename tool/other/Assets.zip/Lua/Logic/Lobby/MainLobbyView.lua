--[[
名称：大厅界面
模块：UI
--]]
require "Logic/3V3MatchingView/MatchingView_3V3";

MainLobbyView = class("MainLobbyView", MainLobbyViewUI);


local _this;

local MapData=nil;

--银币场
local _silverSession = 1;
--金币场
local _goldSession = 2;
--银币5V5
local _silverTeam = 3;
--金币5V5
local _goldTeam = 4;

local CurrentRankLevel =0--当前记录的段位等级; 

local noramlActiveBtnsWidth = 0 --可移动的按钮默认值

local targetActiveBtnsWidth = 0 --可移动的按钮目标值值

local isMoveClick = false;

local moveCostTime = 1;

local effectObj = nil;

function MainLobbyView:Init()
	print("MainLobbyView")
	_this = self;
	MapData=ViewParam();
	MapData.objParam = {MatchId=1};
	self:RegisterEvent();
	_this.InitUserID();
	_this.rectTra = _this.activeBtns:GetComponent("RectTransform");
	noramlActiveBtnsWidth = _this.rectTra.sizeDelta;
	targetActiveBtnsWidth =Vector2(noramlActiveBtnsWidth.x*(_this.activeBtns:GetChild(0).childCount+1)+50,noramlActiveBtnsWidth.y);
	MatchingView_3V3.Init(self);
end

function MainLobbyView:OpenView(param)
	print("打开主界面");
	EventSys.instance:AddLuaEvent(GameEvent.PlayerResourcesUpdate,MainLobbyView.UpdatePlayerResources);
	-- body
	MainLobbyView.UpdatePlayerResources();
	Main.AddUpdateFun(MainLobbyView.Update, self);
	MainLobbyView.UpdateRankShow();
end

function MainLobbyView.UpdatePlayerResources()
	MainLobbyView.txtSilverValue.text = MainLobbyManager.playerBaseInfo.silver;
	MainLobbyView.txtGoldValue.text = MainLobbyManager.playerBaseInfo.gold;
	MainLobbyView.txtPlayerName.text = MainLobbyManager.playerBaseInfo.name;
	MainLobbyView.UpdateHeadPicture();
	--[[ MainLobbyView.txtId.text = LoginInfo.userId; ]]
end

function MainLobbyView:RegisterEvent()
    EventButtonListerer.Get(self.btnSilver.gameObject, self.OnSilver);
    EventButtonListerer.Get(self.btnGold.gameObject, self.OnGold);
	EventButtonListerer.Get(self.btnTeamSilver,self.OnTeamSilver);
	EventButtonListerer.Get(self.btnTeamGold,self.OnTeamGold);

	EventButtonListerer.Get(self.btnMall, self.OnOpenMall);--商店
	EventButtonListerer.Get(self.btnHeroPool, self.OnOpenHeroPool);--商店
	EventButtonListerer.Get(self.btnTimeReward, self.OnClickTimeReward);
	EventButtonListerer.Get(self.btnForging, self.OnClickStrengthEquip);  --强化装备界面

	EventButtonListerer.Get(self.btnActivity,self.OnClickActivity);
	EventButtonListerer.Get(self.btnFriend,self.OnClickFriend);
	EventButtonListerer.Get(self.btnRank,self.OnRank);
	EventButtonListerer.Get(self.btnSilverDesc.gameObject,self.OnBtnSilverDescClick);
	print(self.btnSilverDesc)
	EventButtonListerer.Get(self.btnGoldDesc.gameObject,self.OnBtnGoldDescClick);
	EventButtonListerer.Get(self.btnSilver5v5Desc.gameObject,self.OnBtnSilver5v5DescClick);
	EventButtonListerer.Get(self.btnGold5v5Desc.gameObject,self.OnBtnGold5V5DescClick);
	EventButtonListerer.Get(self.headIcon,self.OnUserInfoClick);
	EventButtonListerer.Get(self.moveBtn,self.OnMoveClick);
	EventButtonListerer.Get(self.btnLuck,self.OnLuckClick);
	EventSys.instance:AddLuaEvent(GameEvent.Rename,MainLobbyView.OnReceiveRename);
	EventSys.instance:AddLuaEvent(GameEvent.HeadPictureChange,MainLobbyView.UpdateHeadPicture);
end

function MainLobbyView:Update()
	self:UpdateReward();
	MatchingView_3V3.Update();
	--[[ self.OnUpdateMove(); ]]
end

function MainLobbyView.OnLuckClick()
	ViewSys.instance:Open("LuckDrawView");
end

function MainLobbyView.OnMoveClick()
	if(_this.rectTra.sizeDelta==noramlActiveBtnsWidth or _this.rectTra.sizeDelta==targetActiveBtnsWidth)then 
		_this.isMoveClick = false;
	end
	if(_this.isMoveClick == true)then
		return;
	end
	_this.isMoveClick = true;
	local tween=nil;
	if(_this.rectTra.sizeDelta==targetActiveBtnsWidth)then
		tween=_this.rectTra:DOSizeDelta(noramlActiveBtnsWidth,moveCostTime);
	else
		tween=_this.rectTra:DOSizeDelta(targetActiveBtnsWidth,moveCostTime);
	end
	tween:OnComplete(function()
		_this.isMoveClick = false;
		if(_this.rectTra.sizeDelta==noramlActiveBtnsWidth)then
			_this.moveBtn.transform.localRotation = Vector3(0,0,0);
		else
			_this.moveBtn.transform.localRotation = Vector3(0,0,180);
		end
	end)
end

function MainLobbyView.UpdateRankShow()
	print("刷新排位等级表现")
	local level =1;--模拟段位等级为1
	CurrentRankLevel =level;
	_this.fiendImage.sprite = CResourceSys.instance:Load(EResType.EIcon,RankLevelTable[level].fiend_path);
	_this.boilerImage.sprite =  CResourceSys.instance:Load(EResType.EIcon,RankLevelTable[level].boiler_path);
	
	effectObj = EffectManager.instance:Create(RankLevelTable[level].effect_path,false,nil);
	UIViewUtil.AddUIEffect(_this.boilerImage.gameObject,effectObj);
	--[[ RankLevelTable[level].boiler_path  ]]
end

function MainLobbyView.UpdateHeadPicture(eventId,obj)
	print("更新大厅上的好好友头像");
	print(tostring(HeadPictureTable[MainLobbyManager.HeadPictureId].head_file));
	MainLobbyView.headIcon:GetComponent("Image").sprite = CResourceSys.instance:Load(EResType.EIcon,HeadPictureTable[MainLobbyManager.HeadPictureId].head_file);
end

function MainLobbyView:UpdateReward()
	if(TimeRewardMgr.leaveTime > 0) then
		local min = math.floor(TimeRewardMgr.leaveTime / 60);
		local second = math.ceil(TimeRewardMgr.leaveTime % 60);
		if(min < 10) then min = "0"..min; end
		if(second < 10) then second = "0"..second;end;
		self.txtTimeReward.text = tostring(min)..":"..tostring(second);
		self.objRewardEffect:SetActive(false);
	else
		self.txtTimeReward.text = "领取";
		self.objRewardEffect:SetActive(true);
	end
end

function MainLobbyView:CloseView()
	EventSys.instance:RemoveLuaEvent(GameEvent.PlayerResourcesUpdate,MainLobbyView.UpdatePlayerResources);
	Main.RemoveUpdateFun(MainLobbyView.Update);
	if(effectObj ~= nil) then
		EffectManager.instance:Destory(effectObj);
		effectObj = nil;
	end
end

function MainLobbyView.OnReceiveRename()
	print("接收到改名成功的消息"..MainLobbyManager.playerBaseInfo.name);
	MainLobbyView.UpdatePlayerResources();
end

function MainLobbyView.InitUserID()
	_this.txtId.text = "123456";
	--[[ print("初始化角色ID");
	local idStr = tostring(LoginInfo.userId);
	print("ID信息："..idStr);
	idStr = string.sub(idStr,#idStr-6,#idStr);
	_this.txtId.text = idStr; ]]
end

function MainLobbyView.OnUserInfoClick()
	print("打开角色信息面板");
	ViewSys.instance:Open("UserInfoView");
end

function MainLobbyView.OnRank()
	print("Rank");
	ViewSys.instance:Open("PlayerRankView");
end

function MainLobbyView.OnClickFriend()
	ViewSys.instance:Open("FriendView");
end

function MainLobbyView.OnClickActivity()
	ViewSys.instance:Open("ActiveSystemView");
end

function MainLobbyView.OnClickCloseDesc()
	MainLobbyView.goDescMask:SetActive(false);
	MainLobbyView.goGoldDesc:SetActive(false);
	MainLobbyView.goSilverDesc:SetActive(false);
end

function MainLobbyView.OnClickGoldDesc()
	MainLobbyView.goSilverDesc:SetActive(false);
	MainLobbyView.goGoldDesc:SetActive(true);
	MainLobbyView.goDescMask:SetActive(true);
end

function MainLobbyView.OnClickSilverDesc()
	MainLobbyView.goGoldDesc:SetActive(false);
	MainLobbyView.goSilverDesc:SetActive(true);
	MainLobbyView.goDescMask:SetActive(true);
end

function MainLobbyView.OnOpenMall()
    print("打开商店")
    ViewSys.instance:Close("MainLobbyView");
    ViewSys.instance:Open("ShopView");
end

--银币场（现在id默认为1）
function MainLobbyView.OnSilver()
	ViewSys.instance:Close("MainLobbyView");
	MapData.objParam["MatchId"]=_silverSession;
	ViewSys.instance:Open("SelectHeroView",MapData);
end
--金币场（id为2）
function MainLobbyView.OnGold()
	ViewSys.instance:Close("MainLobbyView");
	MapData.objParam["MatchId"]=_goldSession;
	ViewSys.instance:Open("SelectHeroView",MapData);
end
--5V5()
function MainLobbyView.OnTeamSilver()
	MatchingManager_3V3.MatchId=_silverTeam;
	MatchingView_3V3.OpenView();
	--[[ ViewSys.instance:Close("MainLobbyView");
	ViewSys.instance:Open("MatchingView"); ]]
	--[[ ViewSys.instance:Close("MainLobbyView");
	MapData.objParam["MatchId"]=_5v5Map;
	ViewSys.instance:Open("SelectHeroView",MapData); ]]
end

function MainLobbyView.OnTeamGold()
	MatchingManager_3V3.MatchId=_goldTeam;
	MatchingView_3V3.OpenView();
	--[[ ViewSys.instance:Close("MainLobbyView");
	ViewSys.instance:Open("MatchingView"); ]]
	--[[ ViewSys.instance:Close("MainLobbyView");
	MapData.objParam["MatchId"]=_5v5Map;
	ViewSys.instance:Open("SelectHeroView",MapData); ]]
end

function MainLobbyView.OnOpenHeroPool()
	ViewSys.instance:Open("HeroPoolView");
end

function MainLobbyView.OnBtnSilverDescClick()
	MainLobbyView.OnClickShowPlayDes(_silverSession)
end
function MainLobbyView.OnBtnGoldDescClick()
	MainLobbyView.OnClickShowPlayDes(_goldSession)
end
function MainLobbyView.OnBtnSilver5v5DescClick()
	MainLobbyView.OnClickShowPlayDes(_silverTeam)
end
function MainLobbyView.OnBtnGold5V5DescClick()
	MainLobbyView.OnClickShowPlayDes(_goldTeam)
end

function MainLobbyView.OnClickShowPlayDes(id)
	TipMgr.ShowHelpView(string.gsub(SessionTable[id].desc,"\\n","\n"),nil)
end

function MainLobbyView.OnClickTimeReward()
	TimeRewardMgr.OpenRewardView();
end

function MainLobbyView.OnClickStrengthEquip()
	ViewSys.instance:Open("StrengthenEquipmentView")
end