LobbyNameView = class("LobbyNameView", LobbyNameViewUI);

function LobbyNameView:Init()
	print("LobbyNameView:Init")
	local onRandomName = function (go)
		self:OnRandomName();
	end
	EventTriggerListener.Get(self.randormButton).onClick = EventTriggerListener.Get(self.randormButton).onClick + onRandomName;

	local onSetName = function (go)
		self:OnSetName();
	end
	EventTriggerListener.Get(self.okButton).onClick = EventTriggerListener.Get(self.okButton).onClick + onSetName;

	local onClickMask = function (go)
		self:CloseThis();
	end
	EventTriggerListener.Get(self.bgMark).onClick = EventTriggerListener.Get(self.bgMark).onClick + onClickMask;
end

function LobbyNameView:OpenView(param)
	self.onRename = function ( eventId,obj)
		self:OnRename();
	end
	EventSys.instance:AddLuaEvent(GameEvent.Rename,self.onRename);
	if(MainLobbyManager.playerBaseInfo.name == "" or MainLobbyManager.playerBaseInfo.name == nil) then
		self:OnRandomName();
	else
		self.inputField.text = MainLobbyManager.playerBaseInfo.name; 
	end
end

function LobbyNameView:OnRandomName()
	local lastName = NameMgr.RandomName(); 
    self.inputField.text = lastName; 
end

function LobbyNameView:OnSetName()
	local name = self.inputField.text;
	if(name == nil or name == "") then
		TipMgr.ShowTipType2("The input name cannot be empty!",nil);
		return;
	elseif(name == MainLobbyManager.playerBaseInfo.name) then
		self:CloseThis();
	else
		local data = C2S_GiveNameData(); 
	    data.name = name;  
	    NetSys.instance:SendWorldMsg(data:SerializeToString(), C2S_GiveName); 
	end
end

function LobbyNameView:OnRename()
	self:CloseThis();
end

function LobbyNameView:CloseThis()
	ViewSys.instance:Close("LobbyNameView");
end

function LobbyNameView:CloseView()
	if(self.onRename ~= nil) then
		EventSys.instance:RemoveLuaEvent(GameEvent.Rename,self.onRename);
		self.onRename = nil;
	end
end

function LobbyNameView:DestroyView()
end