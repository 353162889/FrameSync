--管理一般物品数据逻辑
ItemMgr = {};

local this = ItemMgr;

--监听数据事件
function this.Init()
	--初始化物品信息
	NetSys.instance:AddMsgCallback(EChannelType.EWorldChannel,S2C_UserBagInfo,this.S2C_UserBagInfoResult,nil);
	--监听物品信息变更
	NetSys.instance:AddMsgCallback(EChannelType.EWorldChannel,S2C_BagSync,this.S2C_BagSyncResult,nil);
end

function this.S2C_UserBagInfoResult(obj,arrData)
	Util.Log("S2C_UserBagInfoResult")
	-- body
	local msg = S2C_UserBagInfoData();
	msg:ParseFromString(arrData);
	BagMgr.UpdateBagSize(BagType.Item,msg.bagSize);
	for i,v in ipairs(msg.itemList) do
		local mo = BagMgr.AddItem(BagType.Item,v);
		Util.LogColor("#ff0000",mo:ToString());
	end
end

function this.S2C_BagSyncResult(obj,arrData)
	-- body
	Util.Log("S2C_BagSyncResult")
	local msg = S2C_BagSyncData();
	msg:ParseFromString(arrData);
	for i,v in ipairs(msg.itemList) do
		local mo = BagMgr.UpdateItem(BagType.Item,v);
		--派发更新物品数据消息
		EventSys.instance:DispatchLua(GameEvent.OnItemUpdate,mo:GetID());
	end
end

--通过系统id获取到物品
--return BaseItemMO
function this.GetItemBySystemId(systemId)
	return BagMgr.GetItemBySystemId(systemId);
end

--通过物品类型获取到物品列表
--return {BaseItemMO,BaseItemMO,...}
function this.GetItemsByItemType(itemType)
	-- body
	local bag = BagMgr.GetBag(BagType.Item);
	local lstItem = bag:GetListAll();
	local result = {};
	for i=1,#lstItem do
		if(lstItem[i]:GetConfig().type == itemType) then
			table.insert(result,lstItem[i]);
		end
	end
	return result;
end

--通过配置id获取到物品列表
--return {BaseItemMO,BaseItemMO,...}
function this.GetItemsByConfigId(configId)
	-- body
	local bag = BagMgr.GetBag(BagType.Item);
	return bag:GetItemMOByConfigId(configId);
end

--获取道具数量 | 参数 : 配置ID
--return int
function ItemMgr.GetItemNumByConfigId(configId)
	--如果参数传入string 转化为 number
	if type(configId) == "string" then
		configId = tonumber(configId)
	end

	--参数错误 返回0
	if type(configId) ~= "number" then
		Debugger.LogWarning("参数应为[Number]类型")
		return 0
	end

	local num = 0

	local dataTable = ItemMgr.GetItemsByConfigId(configId)

	for k,v in pairs(dataTable) do
		num = num + v:GetCount()
	end

	return num
end

-- --通过英雄ID获取到英雄碎片物品
-- --本来这个应该是在碎片管理器中的（因为功能较少，碎片又和物品配置在一起，先在这里添加）
-- --return ItemMO or nil
-- function this.GetHeroDebris(heroId)
-- 	local debris = this.GetItemsByItemType(ItemType_HeroPiece);
-- 	for k,v in pairs(debris) do
-- 		if(v:GetConfig().heroId == heroId) then
-- 			return v
-- 		end
-- 	end
-- 	return nil;
-- end
