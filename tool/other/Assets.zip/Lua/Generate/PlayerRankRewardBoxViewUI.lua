--UI View Gen From GenUITools
--Please Don't Modify!

PlayerRankRewardBoxViewUI = class(PlayerRankRewardBoxViewUI)

function PlayerRankRewardBoxViewUI:InitControl()  
    self.mask = self.transform:Find("mask").gameObject;
    self.txt_title = self.transform:Find("MainContainer/Title/txt_title"):GetComponent("Text");
    self.txt_rewardTitle = self.transform:Find("MainContainer/txt_rewardTitle"):GetComponent("Text");
    self.rewardLayout = self.transform:Find("MainContainer/RewardContainer/rewardLayout");
    self.rewardItem = self.transform:Find("MainContainer/RewardContainer/rewardLayout/rewardItem").gameObject;
    self.btn_sure = self.transform:Find("MainContainer/btn_sure").gameObject;

end 

function PlayerRankRewardBoxViewUI:InitView(objUI)
    if null ~= objUI then
	    self.gameObject = objUI;
		self.transform = self.gameObject.transform;
        self:InitControl(); 
	end
	self:Init();
end

function PlayerRankRewardBoxViewUI:Init()
end