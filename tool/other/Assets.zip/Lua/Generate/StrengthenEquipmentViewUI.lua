--UI View Gen From GenUITools
--Please Don't Modify!

StrengthenEquipmentViewUI = class(StrengthenEquipmentViewUI)

function StrengthenEquipmentViewUI:InitControl()  
    self.mask = self.transform:Find("mask").gameObject;
    self.btn_previous = self.transform:Find("MainContainer/HeroSwitchContainer/btn_previous").gameObject;
    self.heroListContent = self.transform:Find("MainContainer/HeroSwitchContainer/Scroll View/Viewport/heroListContent");
    self.btn_heroIcon = self.transform:Find("MainContainer/HeroSwitchContainer/Scroll View/Viewport/heroListContent/btn_heroIcon").gameObject;
    self.btn_next = self.transform:Find("MainContainer/HeroSwitchContainer/btn_next").gameObject;
    self.equipBreakContainer = self.transform:Find("MainContainer/equipBreakContainer").gameObject;
    self.equipScroll = self.transform:Find("MainContainer/equipBreakContainer/equipScroll").gameObject;
    self.equipBreakItem = self.transform:Find("MainContainer/equipBreakContainer/equipScroll/Viewport/Content/equipBreakItem").gameObject;
    self.img_curEquipIcon = self.transform:Find("MainContainer/equipBreakContainer/equipScroll/Viewport/Content/equipBreakItem/CurEquipIconBg/img_curEquipIcon"):GetComponent("Image");
    self.img_nextEquipIcon = self.transform:Find("MainContainer/equipBreakContainer/equipScroll/Viewport/Content/equipBreakItem/NextEquipIconBg/img_nextEquipIcon"):GetComponent("Image");
    self.pointLayout = self.transform:Find("MainContainer/equipBreakContainer/pointLayout");
    self.img_point = self.transform:Find("MainContainer/equipBreakContainer/pointLayout/img_point").gameObject;
    self.equipSelectContainer = self.transform:Find("MainContainer/equipSelectContainer").gameObject;
    self.btn_equip_1 = self.transform:Find("MainContainer/equipSelectContainer/btn_equip_1").gameObject;
    self.btn_equip_2 = self.transform:Find("MainContainer/equipSelectContainer/btn_equip_2").gameObject;
    self.btn_equip_3 = self.transform:Find("MainContainer/equipSelectContainer/btn_equip_3").gameObject;
    self.btn_equip_4 = self.transform:Find("MainContainer/equipSelectContainer/btn_equip_4").gameObject;
    self.btn_equip_5 = self.transform:Find("MainContainer/equipSelectContainer/btn_equip_5").gameObject;
    self.img_heroEquipIcon = self.transform:Find("MainContainer/equipSelectContainer/img_heroEquipIcon"):GetComponent("Image");
    self.operateContainer = self.transform:Find("MainContainer/operateContainer").gameObject;
    self.img_showEquipIcon = self.transform:Find("MainContainer/operateContainer/Image (2)/EquipmentIconBg/img_showEquipIcon"):GetComponent("Image");
    self.txt_equipName = self.transform:Find("MainContainer/operateContainer/Image (2)/EquipmentIconBg/txt_equipName"):GetComponent("Text");
    self.txt_equipDesc = self.transform:Find("MainContainer/operateContainer/Image (2)/txt_equipDesc"):GetComponent("Text");
    self.txt_costSliver = self.transform:Find("MainContainer/operateContainer/txt_costSliver"):GetComponent("Text");
    self.btn_break = self.transform:Find("MainContainer/operateContainer/btn_break").gameObject;
    self.btn_unlock = self.transform:Find("MainContainer/operateContainer/btn_unlock").gameObject;
    self.btn_switchShowHero = self.transform:Find("MainContainer/btn_switchShowHero").gameObject;
    self.img_select = self.transform:Find("MainContainer/btn_switchShowHero/img_select").gameObject;
    self.btn_close = self.transform:Find("MainContainer/btn_close").gameObject;

end 

function StrengthenEquipmentViewUI:InitView(objUI)
    if null ~= objUI then
	    self.gameObject = objUI;
		self.transform = self.gameObject.transform;
        self:InitControl(); 
	end
	self:Init();
end

function StrengthenEquipmentViewUI:Init()
end