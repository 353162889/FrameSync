--UI View Gen From GenUITools
--Please Don't Modify!

TipViewUI = class(TipViewUI)

function TipViewUI:InitControl()  
    self.mask = self.transform:Find("mask").gameObject;
    self.txtTitle = self.transform:Find("txtTitle"):GetComponent("Text");
    self.txtContent = self.transform:Find("txtContent"):GetComponent("Text");
    self.txtTip = self.transform:Find("txtTip"):GetComponent("Text");
    self.btnConfirm = self.transform:Find("btns/btnConfirm"):GetComponent("Button");
    self.txtConfirm = self.transform:Find("btns/btnConfirm/txtConfirm"):GetComponent("Text");
    self.btnCancel = self.transform:Find("btns/btnCancel"):GetComponent("Button");
    self.txtCancel = self.transform:Find("btns/btnCancel/txtCancel"):GetComponent("Text");
    self.btnClose = self.transform:Find("btnClose"):GetComponent("Button");

end 

function TipViewUI:InitView(objUI)
    if null ~= objUI then
	    self.gameObject = objUI;
		self.transform = self.gameObject.transform;
        self:InitControl(); 
	end
	self:Init();
end

function TipViewUI:Init()
end