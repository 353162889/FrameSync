--UI View Gen From GenUITools
--Please Don't Modify!

HeroPoolViewUI = class(HeroPoolViewUI)

function HeroPoolViewUI:InitControl()  
    self.content = self.transform:Find("Scroll View/Viewport/Content");
    self.btnReturn = self.transform:Find("Left/btnReturn").gameObject;
    self.toggleHave = self.transform:Find("Left/toggleHave"):GetComponent("Toggle");
    self.toggleClose = self.transform:Find("Right/toggleClose"):GetComponent("Toggle");
    self.toggleRemote = self.transform:Find("Right/toggleRemote"):GetComponent("Toggle");
    self.toggleAll = self.transform:Find("Right/toggleAll"):GetComponent("Toggle");

end 

function HeroPoolViewUI:InitView(objUI)
    if null ~= objUI then
	    self.gameObject = objUI;
		self.transform = self.gameObject.transform;
        self:InitControl(); 
	end
	self:Init();
end

function HeroPoolViewUI:Init()
end