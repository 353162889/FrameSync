--UI View Gen From GenUITools
--Please Don't Modify!

MainLobbyViewUI = class(MainLobbyViewUI)

function MainLobbyViewUI:InitControl()  
    self.fiendImage = self.transform:Find("CenterBottom/fiendImage"):GetComponent("Image");
    self.boilerImage = self.transform:Find("CenterBottom/boilerImage"):GetComponent("Image");
    self.btnSilver = self.transform:Find("RightTop/ModeSelect/btnSilver").gameObject;
    self.btnSilverDesc = self.transform:Find("RightTop/ModeSelect/btnSilver/btnSilverDesc").gameObject;
    self.btnGold = self.transform:Find("RightTop/ModeSelect/btnGold").gameObject;
    self.btnGoldDesc = self.transform:Find("RightTop/ModeSelect/btnGold/btnGoldDesc").gameObject;
    self.btnTeamSilver = self.transform:Find("RightTop/ModeSelect/btnTeamSilver").gameObject;
    self.btnSilver5v5Desc = self.transform:Find("RightTop/ModeSelect/btnTeamSilver/btnSilver5v5Desc").gameObject;
    self.btnTeamGold = self.transform:Find("RightTop/ModeSelect/btnTeamGold").gameObject;
    self.btnGold5v5Desc = self.transform:Find("RightTop/ModeSelect/btnTeamGold/btnGold5v5Desc").gameObject;
    self.btnHeroPool = self.transform:Find("RightTop/Widget/btnHeroPool").gameObject;
    self.btnFriend = self.transform:Find("RightTop/Widget/btnFriend").gameObject;
    self.activeBtns = self.transform:Find("RightBottom/activeBtns");
    self.btnRank = self.transform:Find("RightBottom/activeBtns/Btns/btnRank").gameObject;
    self.moveBtn = self.transform:Find("RightBottom/activeBtns/moveBtn").gameObject;
    self.btnActivity = self.transform:Find("RightBottom/FixedBtns/btnActivity").gameObject;
    self.btnForging = self.transform:Find("RightBottom/FixedBtns/btnForging").gameObject;
    self.btnMall = self.transform:Find("RightBottom/FixedBtns/btnMall").gameObject;
    self.txtGoldValue = self.transform:Find("CenterTop/goldWidget/txtGoldValue"):GetComponent("Text");
    self.txtSilverValue = self.transform:Find("CenterTop/silverWidget/txtSilverValue"):GetComponent("Text");
    self.headIcon = self.transform:Find("LeftTop/PlayerInfo/Head/headIcon").gameObject;
    self.txtPlayerName = self.transform:Find("LeftTop/PlayerInfo/txtPlayerName"):GetComponent("Text");
    self.txtId = self.transform:Find("LeftTop/PlayerInfo/ID/txtId"):GetComponent("Text");
    self.btnLuck = self.transform:Find("LeftTop/btnLuck").gameObject;
    self.btnTimeReward = self.transform:Find("LeftBottom/btnTimeReward").gameObject;
    self.txtTimeReward = self.transform:Find("LeftBottom/btnTimeReward/txtTimeReward"):GetComponent("Text");
    self.objRewardEffect = self.transform:Find("LeftBottom/btnTimeReward/objRewardEffect").gameObject;
    self.matchingPanel = self.transform:Find("matchingPanel").gameObject;
    self.teamItem1 = self.transform:Find("matchingPanel/TeamView/teamItem1");
    self.teamItem2 = self.transform:Find("matchingPanel/TeamView/teamItem2");
    self.teamItem3 = self.transform:Find("matchingPanel/TeamView/teamItem3");
    self.btnReady = self.transform:Find("matchingPanel/TeamView/btnReady").gameObject;
    self.btnCancelReady = self.transform:Find("matchingPanel/TeamView/btnCancelReady").gameObject;
    self.btnMatchBack = self.transform:Find("matchingPanel/TeamView/btnMatchBack").gameObject;
    self.matchTimeShow = self.transform:Find("matchingPanel/TeamView/matchTimeShow").gameObject;
    self.txtMatchTime = self.transform:Find("matchingPanel/TeamView/matchTimeShow/txtMatchTime"):GetComponent("Text");
    self.btnExitMatching = self.transform:Find("matchingPanel/TeamView/matchTimeShow/btnExitMatching").gameObject;
    self.objVoice = self.transform:Find("matchingPanel/TeamView/objVoice").gameObject;
    self.btnFriend_3V3 = self.transform:Find("matchingPanel/FriendView/btnFriend_3V3").gameObject;
    self.btnFriendNormal_3V3 = self.transform:Find("matchingPanel/FriendView/btnFriend_3V3/btnFriendNormal_3V3").gameObject;
    self.btnLately = self.transform:Find("matchingPanel/FriendView/btnLately").gameObject;
    self.btnLatelyNoraml = self.transform:Find("matchingPanel/FriendView/btnLately/btnLatelyNoraml").gameObject;
    self.friendContent = self.transform:Find("matchingPanel/FriendView/Scroll View/Viewport/friendContent");
    self.friendItem = self.transform:Find("matchingPanel/FriendView/Scroll View/Viewport/friendContent/friendItem").gameObject;

end 

function MainLobbyViewUI:InitView(objUI)
    if null ~= objUI then
	    self.gameObject = objUI;
		self.transform = self.gameObject.transform;
        self:InitControl(); 
	end
	self:Init();
end

function MainLobbyViewUI:Init()
end