--UI View Gen From GenUITools
--Please Don't Modify!

FightViewUI = class(FightViewUI)

function FightViewUI:InitControl()  
    self.lockBars = self.transform:Find("LockBars").gameObject;
    self.operateBars = self.transform:Find("OperateBars").gameObject;
    self.moveJoystickPos = self.transform:Find("OperateBars/moveJoystickPos");
    self.normalSkillBtn = self.transform:Find("OperateBars/skill/normalSkillBtn").gameObject;
    self.normalSkillMask = self.transform:Find("OperateBars/skill/normalSkillBtn/normalSkillMask"):GetComponent("Image");
    self.skillBtn1 = self.transform:Find("OperateBars/skill/skillBtn1").gameObject;
    self.skillEnergy1 = self.transform:Find("OperateBars/skill/skillBtn1/skillEnergy1"):GetComponent("Image");
    self.imgSkillLeaveTime1 = self.transform:Find("OperateBars/skill/skillBtn1/imgSkillLeaveTime1"):GetComponent("Image");
    self.skillIcon1 = self.transform:Find("OperateBars/skill/skillBtn1/skillIcon1"):GetComponent("Image");
    self.txtSkillBg1 = self.transform:Find("OperateBars/skill/skillBtn1/txtSkillBg1").gameObject;
    self.txtEnergy1 = self.transform:Find("OperateBars/skill/skillBtn1/txtSkillBg1/txtEnergy1"):GetComponent("Text");
    self.skillMask1 = self.transform:Find("OperateBars/skill/skillBtn1/skillMask1"):GetComponent("Image");
    self.cdTime1 = self.transform:Find("OperateBars/skill/skillBtn1/skillMask1/CdTime1"):GetComponent("Text");
    self.skillBtn2 = self.transform:Find("OperateBars/skill/skillBtn2").gameObject;
    self.skillEnergy2 = self.transform:Find("OperateBars/skill/skillBtn2/skillEnergy2"):GetComponent("Image");
    self.imgSkillLeaveTime2 = self.transform:Find("OperateBars/skill/skillBtn2/imgSkillLeaveTime2"):GetComponent("Image");
    self.skillIcon2 = self.transform:Find("OperateBars/skill/skillBtn2/skillIcon2"):GetComponent("Image");
    self.txtSkillBg2 = self.transform:Find("OperateBars/skill/skillBtn2/txtSkillBg2").gameObject;
    self.txtEnergy2 = self.transform:Find("OperateBars/skill/skillBtn2/txtSkillBg2/txtEnergy2"):GetComponent("Text");
    self.skillMask2 = self.transform:Find("OperateBars/skill/skillBtn2/skillMask2"):GetComponent("Image");
    self.cdTime2 = self.transform:Find("OperateBars/skill/skillBtn2/skillMask2/CdTime2"):GetComponent("Text");
    self.skillBtn3 = self.transform:Find("OperateBars/skill/skillBtn3").gameObject;
    self.skillEnergy3 = self.transform:Find("OperateBars/skill/skillBtn3/skillEnergy3"):GetComponent("Image");
    self.imgSkillLeaveTime3 = self.transform:Find("OperateBars/skill/skillBtn3/imgSkillLeaveTime3"):GetComponent("Image");
    self.skillIcon3 = self.transform:Find("OperateBars/skill/skillBtn3/skillIcon3"):GetComponent("Image");
    self.txtSkillBg3 = self.transform:Find("OperateBars/skill/skillBtn3/txtSkillBg3").gameObject;
    self.txtEnergy3 = self.transform:Find("OperateBars/skill/skillBtn3/txtSkillBg3/txtEnergy3"):GetComponent("Text");
    self.skillMask3 = self.transform:Find("OperateBars/skill/skillBtn3/skillMask3"):GetComponent("Image");
    self.cdTime3 = self.transform:Find("OperateBars/skill/skillBtn3/skillMask3/CdTime3"):GetComponent("Text");
    self.ani_skillIconObj = self.transform:Find("OperateBars/skill/ani_skillIconObj").gameObject;
    self.ani_skillIcon = self.transform:Find("OperateBars/skill/ani_skillIconObj/ani_skillIcon"):GetComponent("Image");
    self.killBars = self.transform:Find("KillBars").gameObject;
    self.revive_Center = self.transform:Find("KillBars/Revive_Center").gameObject;
    self.txtReliveTime = self.transform:Find("KillBars/Revive_Center/txtReliveTime"):GetComponent("Text");
    self.kill_CenterUp = self.transform:Find("KillBars/Kill_CenterUp");
    self.selfIcon = self.transform:Find("KillBars/Kill_CenterUp/SelfIcon").gameObject;
    self.iconKillSelf = self.transform:Find("KillBars/Kill_CenterUp/SelfIcon/iconKillSelf"):GetComponent("Image");
    self.frontbg = self.transform:Find("KillBars/Kill_CenterUp/SelfIcon/frontbg"):GetComponent("Image");
    self.txtKillSelfName = self.transform:Find("KillBars/Kill_CenterUp/SelfIcon/txtKillSelfName"):GetComponent("Text");
    self.iconKillSelfMask = self.transform:Find("KillBars/Kill_CenterUp/SelfIcon/iconKillSelfMask").gameObject;
    self.iconKillSelfCross = self.transform:Find("KillBars/Kill_CenterUp/SelfIcon/iconKillSelfCross").gameObject;
    self.enemyIcon = self.transform:Find("KillBars/Kill_CenterUp/EnemyIcon").gameObject;
    self.iconKillHero = self.transform:Find("KillBars/Kill_CenterUp/EnemyIcon/iconKillHero"):GetComponent("Image");
    self.frontbg = self.transform:Find("KillBars/Kill_CenterUp/EnemyIcon/frontbg"):GetComponent("Image");
    self.txtKillHeroName = self.transform:Find("KillBars/Kill_CenterUp/EnemyIcon/txtKillHeroName"):GetComponent("Text");
    self.iconKillHeroMask = self.transform:Find("KillBars/Kill_CenterUp/EnemyIcon/iconKillHeroMask").gameObject;
    self.iconKillHeroCross = self.transform:Find("KillBars/Kill_CenterUp/EnemyIcon/iconKillHeroCross").gameObject;
    self.txtKillDesc = self.transform:Find("KillBars/Kill_CenterUp/txtKillDesc"):GetComponent("Text");
    self.kill_Count = self.transform:Find("KillBars/kill_Count");
    self.txtKill = self.transform:Find("KillBars/kill_Count/txtKill"):GetComponent("Text");
    self.bgKillSplash = self.transform:Find("KillBars/kill_Count/bgKillSplash"):GetComponent("Image");
    self.map = self.transform:Find("Map/map").gameObject;
    self.iconSelfHero = self.transform:Find("SelfInfo/info/iconSelfHero"):GetComponent("Image");
    self.iconSelfHeroMask = self.transform:Find("SelfInfo/info/iconSelfHeroMask"):GetComponent("Image");
    self.icon_energy_progress = self.transform:Find("SelfInfo/info/icon_energybg/icon_energy_progress"):GetComponent("Image");
    self.txtCoinCount = self.transform:Find("SelfInfo/info/txtCoinCount"):GetComponent("Text");
    self.iconSelfHeroEffect = self.transform:Find("SelfInfo/info/iconSelfHeroEffect");
    self.iconEnemyHeroEffect = self.transform:Find("SelfInfo/effPos/iconEnemyHeroEffect");
    self.team = self.transform:Find("Team").gameObject;
    self.icon_timeNum = self.transform:Find("Time_CenterTop/Icon_timeNum"):GetComponent("Text");
    self.rank = self.transform:Find("Rank").gameObject;
    self.heroRankList = self.transform:Find("Rank/heroRankList").gameObject;
    self.rank1 = self.transform:Find("Rank/heroRankList/rank1").gameObject;
    self.rankIcon1 = self.transform:Find("Rank/heroRankList/rank1/rankIcon1"):GetComponent("Image");
    self.rankTxtName1 = self.transform:Find("Rank/heroRankList/rank1/rankTxtName1"):GetComponent("Text");
    self.rankCoin1 = self.transform:Find("Rank/heroRankList/rank1/rankCoin1"):GetComponent("Text");
    self.rank2 = self.transform:Find("Rank/heroRankList/rank2").gameObject;
    self.rankIcon2 = self.transform:Find("Rank/heroRankList/rank2/rankIcon2"):GetComponent("Image");
    self.rankTxtName2 = self.transform:Find("Rank/heroRankList/rank2/rankTxtName2"):GetComponent("Text");
    self.rankCoin2 = self.transform:Find("Rank/heroRankList/rank2/rankCoin2"):GetComponent("Text");
    self.rank3 = self.transform:Find("Rank/heroRankList/rank3").gameObject;
    self.rankIcon3 = self.transform:Find("Rank/heroRankList/rank3/rankIcon3"):GetComponent("Image");
    self.rankTxtName3 = self.transform:Find("Rank/heroRankList/rank3/rankTxtName3"):GetComponent("Text");
    self.rankCoin3 = self.transform:Find("Rank/heroRankList/rank3/rankCoin3"):GetComponent("Text");
    self.rankSelfIcon = self.transform:Find("Rank/rankSelf/rankSelfIcon"):GetComponent("Image");
    self.rankSelfName = self.transform:Find("Rank/rankSelf/rankSelfName"):GetComponent("Text");
    self.rankSelfCoin = self.transform:Find("Rank/rankSelf/rankSelfCoin"):GetComponent("Text");
    self.rankSelfRank = self.transform:Find("Rank/rankSelf/rankSelfRank"):GetComponent("Text");
    self.pingValue = self.transform:Find("SetOrFps_RightTop/pingValue"):GetComponent("Text");
    self.fpsValue = self.transform:Find("SetOrFps_RightTop/fpsValue"):GetComponent("Text");
    self.effectBars = self.transform:Find("EffectBars").gameObject;
    self.screenEffect = self.transform:Find("ScreenEffect").gameObject;
    self.imgFlashScreen = self.transform:Find("ScreenEffect/imgFlashScreen"):GetComponent("Image");
    self.imgHurtScreen = self.transform:Find("ScreenEffect/imgHurtScreen"):GetComponent("Image");
    self.objVoice = self.transform:Find("objVoice").gameObject;

end 

function FightViewUI:InitView(objUI)
    if null ~= objUI then
	    self.gameObject = objUI;
		self.transform = self.gameObject.transform;
        self:InitControl(); 
	end
	self:Init();
end

function FightViewUI:Init()
end