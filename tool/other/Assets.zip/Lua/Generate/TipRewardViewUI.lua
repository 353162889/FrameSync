--UI View Gen From GenUITools
--Please Don't Modify!

TipRewardViewUI = class(TipRewardViewUI)

function TipRewardViewUI:InitControl()  
    self.mask = self.transform:Find("mask").gameObject;
    self.title = self.transform:Find("Title"):GetComponent("Text");
    self.titleContent = self.transform:Find("TitleContent"):GetComponent("Text");
    self.itemContent = self.transform:Find("ItemContent").gameObject;
    self.yesBtn = self.transform:Find("YesBtn").gameObject;

end 

function TipRewardViewUI:InitView(objUI)
    if null ~= objUI then
	    self.gameObject = objUI;
		self.transform = self.gameObject.transform;
        self:InitControl(); 
	end
	self:Init();
end

function TipRewardViewUI:Init()
end