--UI View Gen From GenUITools
--Please Don't Modify!

PlayerRankGetRewardViewUI = class(PlayerRankGetRewardViewUI)

function PlayerRankGetRewardViewUI:InitControl()  
    self.mask = self.transform:Find("mask").gameObject;
    self.txt_rewardTitle = self.transform:Find("MainContainer/txt_rewardTitle"):GetComponent("Text");
    self.rewardLayout = self.transform:Find("MainContainer/rewardLayout").gameObject;
    self.btn_sure = self.transform:Find("MainContainer/btn_sure").gameObject;

end 

function PlayerRankGetRewardViewUI:InitView(objUI)
    if null ~= objUI then
	    self.gameObject = objUI;
		self.transform = self.gameObject.transform;
        self:InitControl(); 
	end
	self:Init();
end

function PlayerRankGetRewardViewUI:Init()
end