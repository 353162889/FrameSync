--UI View Gen From GenUITools
--Please Don't Modify!

LoadUI = class(LoadUI)

function LoadUI:InitControl()  
    self.txtLoading = self.transform:Find("txtLoading"):GetComponent("Text");
    self.progress = self.transform:Find("ProgressBg/progress").gameObject;

end 

function LoadUI:InitView(objUI)
    if null ~= objUI then
	    self.gameObject = objUI;
		self.transform = self.gameObject.transform;
        self:InitControl(); 
	end
	self:Init();
end

function LoadUI:Init()
end