--UI View Gen From GenUITools
--Please Don't Modify!

TipDescViewUI = class(TipDescViewUI)

function TipDescViewUI:InitControl()  
    self.mask = self.transform:Find("mask").gameObject;
    self.btnClose = self.transform:Find("btnClose").gameObject;
    self.txtTitle = self.transform:Find("txtTitle"):GetComponent("Text");
    self.txtContent = self.transform:Find("txtContent"):GetComponent("Text");

end 

function TipDescViewUI:InitView(objUI)
    if null ~= objUI then
	    self.gameObject = objUI;
		self.transform = self.gameObject.transform;
        self:InitControl(); 
	end
	self:Init();
end

function TipDescViewUI:Init()
end