--UI View Gen From GenUITools
--Please Don't Modify!

ItemTipViewUI = class(ItemTipViewUI)

function ItemTipViewUI:InitControl()  
    self.mask = self.transform:Find("mask").gameObject;
    self.bubble = self.transform:Find("bubble");
    self.bgContent = self.transform:Find("bubble/bgContent").gameObject;
    self.txtTitle = self.transform:Find("bubble/bgContent/bg/txtTitle"):GetComponent("Text");
    self.imgIcon = self.transform:Find("bubble/bgContent/bg/imgIcon"):GetComponent("Image");
    self.txtContent = self.transform:Find("bubble/txtContent"):GetComponent("Text");

end 

function ItemTipViewUI:InitView(objUI)
    if null ~= objUI then
	    self.gameObject = objUI;
		self.transform = self.gameObject.transform;
        self:InitControl(); 
	end
	self:Init();
end

function ItemTipViewUI:Init()
end