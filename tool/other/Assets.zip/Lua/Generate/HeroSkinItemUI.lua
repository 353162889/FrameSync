--UI View Gen From GenUITools
--Please Don't Modify!

HeroSkinItemUI = class(HeroSkinItemUI)

function HeroSkinItemUI:InitControl()  
    self.icon = self.transform:Find("icon"):GetComponent("Image");
    self.have = self.transform:Find("have").gameObject;
    self.notHave = self.transform:Find("notHave").gameObject;

end 

function HeroSkinItemUI:InitView(objUI)
    if null ~= objUI then
	    self.gameObject = objUI;
		self.transform = self.gameObject.transform;
        self:InitControl(); 
	end
	self:Init();
end

function HeroSkinItemUI:Init()
end