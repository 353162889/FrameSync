--UI View Gen From GenUITools
--Please Don't Modify!

UserInfoViewUI = class(UserInfoViewUI)

function UserInfoViewUI:InitControl()  
    self.bgBtn = self.transform:Find("BgBtn").gameObject;
    self.infoPanel = self.transform:Find("infoPanel").gameObject;
    self.imgHead = self.transform:Find("infoPanel/LeftUp/headBg/imgHead"):GetComponent("Image");
    self.txtName = self.transform:Find("infoPanel/LeftUp/txtName"):GetComponent("Text");
    self.txtId = self.transform:Find("infoPanel/LeftUp/txtId"):GetComponent("Text");
    self.btnRename = self.transform:Find("infoPanel/LeftUp/btnRename").gameObject;
    self.sliderBgSound = self.transform:Find("infoPanel/Right/Sounds/sliderBgSound").gameObject;
    self.sliderEffectSound = self.transform:Find("infoPanel/Right/Sounds/sliderEffectSound").gameObject;
    self.headListPanel = self.transform:Find("headListPanel").gameObject;
    self.headPictureContent = self.transform:Find("headListPanel/Scroll View/Viewport/headPictureContent");
    self.headPictureItem = self.transform:Find("headListPanel/Scroll View/Viewport/headPictureContent/headPictureItem").gameObject;
    self.btnUpHeadSure = self.transform:Find("headListPanel/Btns/btnUpHeadSure").gameObject;
    self.btnClose = self.transform:Find("btnClose").gameObject;
    self.renamePanel = self.transform:Find("renamePanel").gameObject;
    self.renameTitle = self.transform:Find("renamePanel/renameTitle"):GetComponent("Text");
    self.inputFieldRename = self.transform:Find("renamePanel/inputFieldRename"):GetComponent("InputField");
    self.btnRandomName = self.transform:Find("renamePanel/btnRandomName").gameObject;
    self.btnCancel = self.transform:Find("renamePanel/btnCancel").gameObject;
    self.btnSure = self.transform:Find("renamePanel/btnSure").gameObject;

end 

function UserInfoViewUI:InitView(objUI)
    if null ~= objUI then
	    self.gameObject = objUI;
		self.transform = self.gameObject.transform;
        self:InitControl(); 
	end
	self:Init();
end

function UserInfoViewUI:Init()
end