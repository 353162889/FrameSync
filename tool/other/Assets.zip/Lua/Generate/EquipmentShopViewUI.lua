--UI View Gen From GenUITools
--Please Don't Modify!

EquipmentShopViewUI = class(EquipmentShopViewUI)

function EquipmentShopViewUI:InitControl()  
    self.mask = self.transform:Find("Mask").gameObject;
    self.equipContent = self.transform:Find("MainContainer/EquipScroll/Viewport/equipContent");
    self.singleEquipContainer = self.transform:Find("MainContainer/EquipScroll/Viewport/equipContent/singleEquipContainer").gameObject;
    self.txt_selectEquipName = self.transform:Find("MainContainer/txt_selectEquipName"):GetComponent("Text");
    self.txt_equipmentDesc = self.transform:Find("MainContainer/txt_equipmentDesc"):GetComponent("Text");
    self.btn_buyEquipment = self.transform:Find("MainContainer/btn_buyEquipment").gameObject;
    self.img_isBought = self.transform:Find("MainContainer/img_isBought").gameObject;
    self.equipmentLayout = self.transform:Find("MainContainer/equipmentLayout");
    self.heroEquipItem = self.transform:Find("MainContainer/equipmentLayout/heroEquipItem").gameObject;
    self.img_isEquipLock = self.transform:Find("MainContainer/img_isEquipLock").gameObject;

end 

function EquipmentShopViewUI:InitView(objUI)
    if null ~= objUI then
	    self.gameObject = objUI;
		self.transform = self.gameObject.transform;
        self:InitControl(); 
	end
	self:Init();
end

function EquipmentShopViewUI:Init()
end