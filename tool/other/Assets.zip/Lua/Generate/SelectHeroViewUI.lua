--UI View Gen From GenUITools
--Please Don't Modify!

SelectHeroViewUI = class(SelectHeroViewUI)

function SelectHeroViewUI:InitControl()  
    self.heroActiveBtn = self.transform:Find("TitleBtns/HeroActiveBtn").gameObject;
    self.heroNormalBtn = self.transform:Find("TitleBtns/HeroNormalBtn").gameObject;
    self.skinActiveBtn = self.transform:Find("TitleBtns/SkinActiveBtn").gameObject;
    self.skinNormalBtn = self.transform:Find("TitleBtns/SkinNormalBtn").gameObject;
    self.content = self.transform:Find("HeroList/Viewport/Content");
    self.randomItem = self.transform:Find("HeroList/Viewport/Content/RandomItem").gameObject;
    self.heroItem = self.transform:Find("HeroList/Viewport/Content/HeroItem").gameObject;
    self.heroListMask = self.transform:Find("HeroList/Viewport/HeroListMask").gameObject;
    self.arrow = self.transform:Find("arrow");
    self.heroShow = self.transform:Find("HeroShow"):GetComponent("Image");
    self.timeBg = self.transform:Find("TimeBg").gameObject;
    self.timeText = self.transform:Find("TimeBg/TimeText"):GetComponent("Text");
    self.nameText = self.transform:Find("DesPanel/NameText"):GetComponent("Text");
    self.attackDes = self.transform:Find("DesPanel/AttackDes"):GetComponent("Text");
    self.skillIcon = self.transform:Find("DesPanel/SkillIcon"):GetComponent("Image");
    self.skillDes = self.transform:Find("DesPanel/SkillDes"):GetComponent("Text");
    self.sureBtn = self.transform:Find("SureBtn").gameObject;
    self.buyBtn = self.transform:Find("BuyBtn").gameObject;
    self.playerHeros = self.transform:Find("PlayerHeros").gameObject;
    self.playerHero_1 = self.transform:Find("PlayerHeros/PlayerHero_1"):GetComponent("Image");
    self.playerHero_2 = self.transform:Find("PlayerHeros/PlayerHero_2"):GetComponent("Image");
    self.playerHero_3 = self.transform:Find("PlayerHeros/PlayerHero_3"):GetComponent("Image");
    self.playerHero_4 = self.transform:Find("PlayerHeros/PlayerHero_4"):GetComponent("Image");
    self.backBtn = self.transform:Find("BackBtn").gameObject;
    self.objVoice = self.transform:Find("objVoice").gameObject;

end 

function SelectHeroViewUI:InitView(objUI)
    if null ~= objUI then
	    self.gameObject = objUI;
		self.transform = self.gameObject.transform;
        self:InitControl(); 
	end
	self:Init();
end

function SelectHeroViewUI:Init()
end