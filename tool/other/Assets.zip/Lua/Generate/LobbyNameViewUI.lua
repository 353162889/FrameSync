--UI View Gen From GenUITools
--Please Don't Modify!

LobbyNameViewUI = class(LobbyNameViewUI)

function LobbyNameViewUI:InitControl()  
    self.bgMark = self.transform:Find("centerView/bgMark").gameObject;
    self.inputField = self.transform:Find("centerView/InputField"):GetComponent("InputField");
    self.randormButton = self.transform:Find("centerView/randormButton").gameObject;
    self.okButton = self.transform:Find("centerView/okButton").gameObject;

end 

function LobbyNameViewUI:InitView(objUI)
    if null ~= objUI then
	    self.gameObject = objUI;
		self.transform = self.gameObject.transform;
        self:InitControl(); 
	end
	self:Init();
end

function LobbyNameViewUI:Init()
end