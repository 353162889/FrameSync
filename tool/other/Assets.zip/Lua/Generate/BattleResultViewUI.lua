--UI View Gen From GenUITools
--Please Don't Modify!

BattleResultViewUI = class(BattleResultViewUI)

function BattleResultViewUI:InitControl()  
    self.ranking1 = self.transform:Find("right/aniNum/ranking1"):GetComponent("Image");
    self.ranking2 = self.transform:Find("right/aniNum/ranking2"):GetComponent("Image");
    self.ranking3 = self.transform:Find("right/aniNum/ranking2/ranking3"):GetComponent("Image");
    self.aniIconTime = self.transform:Find("right/aniNum/aniIconTime"):GetComponent("Image");
    self.killNum = self.transform:Find("right/ImageKill/killNum"):GetComponent("Text");
    self.sumNum = self.transform:Find("right/ImageTotal/sumNum"):GetComponent("Text");
    self.btnBack = self.transform:Find("right/btnBack").gameObject;

end 

function BattleResultViewUI:InitView(objUI)
    if null ~= objUI then
	    self.gameObject = objUI;
		self.transform = self.gameObject.transform;
        self:InitControl(); 
	end
	self:Init();
end

function BattleResultViewUI:Init()
end