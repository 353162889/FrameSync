--UI View Gen From GenUITools
--Please Don't Modify!

PlayerRankViewUI = class(PlayerRankViewUI)

function PlayerRankViewUI:InitControl()  
    self.mask = self.transform:Find("mask").gameObject;
    self.img_rank1 = self.transform:Find("img_rank1"):GetComponent("Image");
    self.img_rank2 = self.transform:Find("img_rank2"):GetComponent("Image");
    self.img_rank3 = self.transform:Find("img_rank3"):GetComponent("Image");
    self.txt_valueType = self.transform:Find("MainContainer/ScrollContainer/ScrollTitle/txt_valueType"):GetComponent("Text");
    self.rankScroll = self.transform:Find("MainContainer/ScrollContainer/rankScroll").gameObject;
    self.myRankInfo = self.transform:Find("MainContainer/myRankInfo").gameObject;
    self.txt_rankNum = self.transform:Find("MainContainer/myRankInfo/txt_rankNum"):GetComponent("Text");
    self.txt_playerName = self.transform:Find("MainContainer/myRankInfo/txt_playerName"):GetComponent("Text");
    self.txt_playerValue = self.transform:Find("MainContainer/myRankInfo/txt_playerValue"):GetComponent("Text");
    self.img_rankIcon = self.transform:Find("MainContainer/myRankInfo/img_rankIcon").gameObject;
    self.fightListBtn = self.transform:Find("MainContainer/RewardAndRankTab/FightListBtn").gameObject;
    self.rankListBtn = self.transform:Find("MainContainer/RewardAndRankTab/RankListBtn").gameObject;
    self.btn_courageBox = self.transform:Find("MainContainer/RewardAndRankTab/btn_courageBox").gameObject;
    self.txt_courageBoxName = self.transform:Find("MainContainer/RewardAndRankTab/btn_courageBox/txt_courageBoxName"):GetComponent("Text");
    self.eff_ui_couragebox = self.transform:Find("MainContainer/RewardAndRankTab/btn_courageBox/eff_ui_couragebox").gameObject;
    self.btn_masterBox = self.transform:Find("MainContainer/RewardAndRankTab/btn_masterBox").gameObject;
    self.txt_masterBoxName = self.transform:Find("MainContainer/RewardAndRankTab/btn_masterBox/txt_masterBoxName"):GetComponent("Text");
    self.eff_ui_masterBox = self.transform:Find("MainContainer/RewardAndRankTab/btn_masterBox/eff_ui_masterBox").gameObject;
    self.txt_remainingTime = self.transform:Find("MainContainer/RemainingTimeContainer/Image/txt_remainingTime"):GetComponent("Text");
    self.closeBtn = self.transform:Find("MainContainer/closeBtn").gameObject;
    self.tipsBtn = self.transform:Find("MainContainer/tipsBtn").gameObject;
    self.tipContainer = self.transform:Find("tipContainer").gameObject;
    self.tipsBg = self.transform:Find("tipContainer/tipsBg").gameObject;

end 

function PlayerRankViewUI:InitView(objUI)
    if null ~= objUI then
	    self.gameObject = objUI;
		self.transform = self.gameObject.transform;
        self:InitControl(); 
	end
	self:Init();
end

function PlayerRankViewUI:Init()
end