--UI View Gen From GenUITools
--Please Don't Modify!

LobbyViewUI = class(LobbyViewUI)

function LobbyViewUI:InitControl()  
    self.nickName = self.transform:Find("nickName"):GetComponent("Text");
    self.btnChangeNickName = self.transform:Find("btnChangeNickName").gameObject;
    self.btnPlay = self.transform:Find("btnPlay").gameObject;
    self.namePanel = self.transform:Find("panel/namePanel").gameObject;

end 

function LobbyViewUI:InitView(objUI)
    if null ~= objUI then
	    self.gameObject = objUI;
		self.transform = self.gameObject.transform;
        self:InitControl(); 
	end
	self:Init();
end

function LobbyViewUI:Init()
end