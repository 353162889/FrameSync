--UI View Gen From GenUITools
--Please Don't Modify!

UserNameTipsPanelUI = class(UserNameTipsPanelUI)

function UserNameTipsPanelUI:InitControl()  
    self.btnClose = self.transform:Find("centerView/btnClose").gameObject;

end 

function UserNameTipsPanelUI:InitView(objUI)
    if null ~= objUI then
	    self.gameObject = objUI;
		self.transform = self.gameObject.transform;
        self:InitControl(); 
	end
	self:Init();
end

function UserNameTipsPanelUI:Init()
end