--UI View Gen From GenUITools
--Please Don't Modify!

TestViewUI = class(TestViewUI)

function TestViewUI:InitControl()  
    self.inpCmd = self.transform:Find("InpCmd"):GetComponent("InputField");
    self.dropdown = self.transform:Find("Dropdown"):GetComponent("Dropdown");
    self.btnSendCmd = self.transform:Find("BtnSendCmd"):GetComponent("Button");
    self.txtBtn1 = self.transform:Find("BtnSendCmd/txtBtn1"):GetComponent("Text");
    self.btn1 = self.transform:Find("Btns/Btn1"):GetComponent("Button");
    self.txtBtn1 = self.transform:Find("Btns/Btn1/txtBtn1"):GetComponent("Text");
    self.btn2 = self.transform:Find("Btns/Btn2"):GetComponent("Button");
    self.txtBtn2 = self.transform:Find("Btns/Btn2/txtBtn2"):GetComponent("Text");
    self.btn3 = self.transform:Find("Btns/Btn3"):GetComponent("Button");
    self.txtBtn3 = self.transform:Find("Btns/Btn3/txtBtn3"):GetComponent("Text");
    self.btn4 = self.transform:Find("Btns/Btn4"):GetComponent("Button");
    self.txtBtn4 = self.transform:Find("Btns/Btn4/txtBtn4"):GetComponent("Text");
    self.btn5 = self.transform:Find("Btns/Btn5"):GetComponent("Button");
    self.txtBtn5 = self.transform:Find("Btns/Btn5/txtBtn5"):GetComponent("Text");
    self.btn6 = self.transform:Find("Btns/Btn6"):GetComponent("Button");
    self.txtBtn6 = self.transform:Find("Btns/Btn6/txtBtn6"):GetComponent("Text");
    self.btnClose = self.transform:Find("BtnClose"):GetComponent("Button");
    self.txtBtnClose = self.transform:Find("BtnClose/txtBtnClose"):GetComponent("Text");

end 

function TestViewUI:InitView(objUI)
    if null ~= objUI then
	    self.gameObject = objUI;
		self.transform = self.gameObject.transform;
        self:InitControl(); 
	end
	self:Init();
end

function TestViewUI:Init()
end