--UI View Gen From GenUITools
--Please Don't Modify!

SavDeckTipPanelViewUI = class(SavDeckTipPanelViewUI)

function SavDeckTipPanelViewUI:InitControl()  
    self.titleText = self.transform:Find("centerView/titleText"):GetComponent("Text");
    self.exitNotSaveBtn = self.transform:Find("centerView/ExitNotSaveBtn").gameObject;
    self.exitAndSaveBtn = self.transform:Find("centerView/ExitAndSaveBtn").gameObject;

end 

function SavDeckTipPanelViewUI:InitView(objUI)
    if null ~= objUI then
	    self.gameObject = objUI;
		self.transform = self.gameObject.transform;
        self:InitControl(); 
	end
	self:Init();
end

function SavDeckTipPanelViewUI:Init()
end