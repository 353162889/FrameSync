--UI View Gen From GenUITools
--Please Don't Modify!

HelpViewUI = class(HelpViewUI)

function HelpViewUI:InitControl()  
    self.bgBtn = self.transform:Find("BgBtn").gameObject;
    self.contentText = self.transform:Find("Scroll View/Viewport/Content/ContentText"):GetComponent("Text");
    self.closeBtn = self.transform:Find("CloseBtn").gameObject;

end 

function HelpViewUI:InitView(objUI)
    if null ~= objUI then
	    self.gameObject = objUI;
		self.transform = self.gameObject.transform;
        self:InitControl(); 
	end
	self:Init();
end

function HelpViewUI:Init()
end