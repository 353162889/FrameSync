--UI View Gen From GenUITools
--Please Don't Modify!

ShopViewUI = class(ShopViewUI)

function ShopViewUI:InitControl()  
    self.btnSliverPlus = self.transform:Find("bgIconSliver/btnSliverPlus").gameObject;
    self.txtSliver = self.transform:Find("bgIconSliver/txtSliver"):GetComponent("Text");
    self.btnGoldPlus = self.transform:Find("bgIconGold/btnGoldPlus").gameObject;
    self.txtGold = self.transform:Find("bgIconGold/txtGold"):GetComponent("Text");
    self.backLobbyBtn = self.transform:Find("BackLobbyBtn").gameObject;
    self.refreshBtn = self.transform:Find("RefreshBtn").gameObject;
    self.refreshTimeText = self.transform:Find("RefreshBtn/RefreshTimeText"):GetComponent("Text");
    self.itemPanels = self.transform:Find("ItemPanels").gameObject;
    self.viewport = self.transform:Find("ItemPanels/Viewport").gameObject;
    self.pageItem = self.transform:Find("ItemPanels/Viewport/Content/PageItem").gameObject;
    self.iconItem = self.transform:Find("ItemPanels/Viewport/Content/PageItem/Panel/IconItem").gameObject;
    self.sellOutTitle = self.transform:Find("ItemPanels/Viewport/Content/PageItem/Panel/IconItem/SellOutTitle").gameObject;
    self.toggleGroup = self.transform:Find("ItemPanels/ToggleGroup").gameObject;
    self.toggle = self.transform:Find("ItemPanels/ToggleGroup/Toggle").gameObject;
    self.selectBtns = self.transform:Find("SelectBtns").gameObject;
    self.shenQiBtn = self.transform:Find("SelectBtns/BtnItems/ShenQiBtn").gameObject;
    self.yingXiongSuiPianBtn = self.transform:Find("SelectBtns/BtnItems/YingXiongSuiPianBtn").gameObject;
    self.caiLiaoBtn = self.transform:Find("SelectBtns/BtnItems/CaiLiaoBtn").gameObject;
    self.payPanel = self.transform:Find("PayPanel").gameObject;
    self.maskClick = self.transform:Find("PayPanel/MaskClick").gameObject;
    self.iconSprite = self.transform:Find("PayPanel/Bg/Icon/IconSprite"):GetComponent("Image");
    self.coinTypeIcon = self.transform:Find("PayPanel/Bg/CoinItem/CoinTypeIcon"):GetComponent("Image");
    self.payNumber = self.transform:Find("PayPanel/Bg/CoinItem/PayNumber"):GetComponent("Text");
    self.numberShowText = self.transform:Find("PayPanel/Bg/NumberItem/NumberShowIcon/NumberShowText"):GetComponent("Text");
    self.addBtn = self.transform:Find("PayPanel/Bg/NumberItem/AddBtn").gameObject;
    self.reduceBtn = self.transform:Find("PayPanel/Bg/NumberItem/ReduceBtn").gameObject;
    self.itemTitle = self.transform:Find("PayPanel/Bg/DesItem/ItemTitle"):GetComponent("Text");
    self.desText = self.transform:Find("PayPanel/Bg/DesItem/DesText"):GetComponent("Text");
    self.buyBtn = self.transform:Find("PayPanel/Bg/BuyBtn").gameObject;
    self.closeBtn = self.transform:Find("PayPanel/Bg/CloseBtn").gameObject;

end 

function ShopViewUI:InitView(objUI)
    if null ~= objUI then
	    self.gameObject = objUI;
		self.transform = self.gameObject.transform;
        self:InitControl(); 
	end
	self:Init();
end

function ShopViewUI:Init()
end