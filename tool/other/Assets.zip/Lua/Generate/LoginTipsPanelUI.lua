--UI View Gen From GenUITools
--Please Don't Modify!

LoginTipsPanelUI = class(LoginTipsPanelUI)

function LoginTipsPanelUI:InitControl()  
    self.inputField = self.transform:Find("centerView/InputField"):GetComponent("InputField");
    self.randormButton = self.transform:Find("centerView/randormButton").gameObject;
    self.okButton = self.transform:Find("centerView/okButton").gameObject;

end 

function LoginTipsPanelUI:InitView(objUI)
    if null ~= objUI then
	    self.gameObject = objUI;
		self.transform = self.gameObject.transform;
        self:InitControl(); 
	end
	self:Init();
end

function LoginTipsPanelUI:Init()
end