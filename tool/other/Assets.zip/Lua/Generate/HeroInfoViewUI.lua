--UI View Gen From GenUITools
--Please Don't Modify!

HeroInfoViewUI = class(HeroInfoViewUI)

function HeroInfoViewUI:InitControl()  
    self.btnReturn = self.transform:Find("btnReturn").gameObject;
    self.txtGoldValue = self.transform:Find("RightTop/goldWidget/txtGoldValue"):GetComponent("Text");
    self.txtSilverValue = self.transform:Find("RightTop/silverWidget/txtSilverValue"):GetComponent("Text");
    self.toggleSkill = self.transform:Find("Book/Left/ToggleGroup/toggleSkill"):GetComponent("Toggle");
    self.toggleStory = self.transform:Find("Book/Left/ToggleGroup/toggleStory"):GetComponent("Toggle");
    self.toggleSkin = self.transform:Find("Book/Left/ToggleGroup/toggleSkin"):GetComponent("Toggle");
    self.widgetSkill = self.transform:Find("Book/Left/WidgetSkill").gameObject;
    self.txtNormalAtkTitle = self.transform:Find("Book/Left/WidgetSkill/NormalAtk/txtNormalAtkTitle"):GetComponent("Text");
    self.txtNormalAtkContent = self.transform:Find("Book/Left/WidgetSkill/NormalAtk/txtNormalAtkContent"):GetComponent("Text");
    self.txtSkillTitle = self.transform:Find("Book/Left/WidgetSkill/Skill/txtSkillTitle"):GetComponent("Text");
    self.txtSkillContent = self.transform:Find("Book/Left/WidgetSkill/Skill/txtSkillContent"):GetComponent("Text");
    self.iconSkill = self.transform:Find("Book/Left/WidgetSkill/Skill/iconSkill"):GetComponent("Image");
    self.widgetStory = self.transform:Find("Book/Left/WidgetStory").gameObject;
    self.txtStoryTitle = self.transform:Find("Book/Left/WidgetStory/txtStoryTitle"):GetComponent("Text");
    self.txtStoryContent = self.transform:Find("Book/Left/WidgetStory/txtStoryContent"):GetComponent("Text");
    self.widgetSkin = self.transform:Find("Book/Left/WidgetSkin").gameObject;
    self.skinContent = self.transform:Find("Book/Left/WidgetSkin/Scroll View/Viewport/skinContent");
    self.txtPageValue = self.transform:Find("Book/Left/Page/txtPageValue"):GetComponent("Text");
    self.iconHeroSkin = self.transform:Find("Book/Right/iconHeroSkin"):GetComponent("Image");
    self.objSkinHave = self.transform:Find("Book/Right/objSkinHave").gameObject;
    self.btnHeroLeft = self.transform:Find("Book/Right/btnHeroLeft").gameObject;
    self.btnHeroRight = self.transform:Find("Book/Right/btnHeroRight").gameObject;
    self.txtSkinName = self.transform:Find("Book/Right/txtSkinName"):GetComponent("Text");
    self.objClose = self.transform:Find("Book/Right/Flag/objClose").gameObject;
    self.objRemote = self.transform:Find("Book/Right/Flag/objRemote").gameObject;
    self.objBuyInfo = self.transform:Find("Book/Right/objBuyInfo").gameObject;
    self.txtPieceValue = self.transform:Find("Book/Right/objBuyInfo/Widget/txtPieceValue"):GetComponent("Text");
    self.txtPieceMax = self.transform:Find("Book/Right/objBuyInfo/Widget/txtPieceMax"):GetComponent("Text");
    self.iconHeroHead = self.transform:Find("Book/Right/objBuyInfo/iconHeroHead"):GetComponent("Image");
    self.txtSkinMoney = self.transform:Find("Book/Right/objBuyInfo/Widget/txtSkinMoney"):GetComponent("Text");
    self.btnBuy = self.transform:Find("Book/Right/objBuyInfo/btnBuy").gameObject;
    self.btnUnlock = self.transform:Find("Book/Right/objBuyInfo/btnUnlock").gameObject;

end 

function HeroInfoViewUI:InitView(objUI)
    if null ~= objUI then
	    self.gameObject = objUI;
		self.transform = self.gameObject.transform;
        self:InitControl(); 
	end
	self:Init();
end

function HeroInfoViewUI:Init()
end