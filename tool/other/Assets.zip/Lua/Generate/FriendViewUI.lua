--UI View Gen From GenUITools
--Please Don't Modify!

FriendViewUI = class(FriendViewUI)

function FriendViewUI:InitControl()  
    self.bgBtn = self.transform:Find("BgBtn").gameObject;
    self.panels = self.transform:Find("Panels").gameObject;
    self.searchFriendPanel = self.transform:Find("Panels/SearchFriendPanel").gameObject;
    self.addInputField = self.transform:Find("Panels/SearchFriendPanel/AddInputField"):GetComponent("InputField");
    self.addSearchBtn = self.transform:Find("Panels/SearchFriendPanel/AddSearchBtn").gameObject;
    self.recommendBtn = self.transform:Find("Panels/SearchFriendPanel/RecommendBtn").gameObject;
    self.latelyBtn = self.transform:Find("Panels/SearchFriendPanel/LatelyBtn").gameObject;
    self.searchContent = self.transform:Find("Panels/SearchFriendPanel/Scroll View/Viewport/SearchContent");
    self.searchFriendItem = self.transform:Find("Panels/SearchFriendPanel/Scroll View/Viewport/SearchContent/SearchFriendItem").gameObject;
    self.nameText = self.transform:Find("Panels/SearchFriendPanel/Scroll View/Viewport/SearchContent/SearchFriendItem/NameText"):GetComponent("Text");
    self.friendListPanel = self.transform:Find("Panels/FriendListPanel").gameObject;
    self.listInputField = self.transform:Find("Panels/FriendListPanel/listInputField"):GetComponent("InputField");
    self.listSearchBtn = self.transform:Find("Panels/FriendListPanel/ListSearchBtn").gameObject;
    self.listContent = self.transform:Find("Panels/FriendListPanel/Scroll View/Viewport/ListContent");
    self.listFriendItem = self.transform:Find("Panels/FriendListPanel/Scroll View/Viewport/ListContent/ListFriendItem").gameObject;
    self.nameText = self.transform:Find("Panels/FriendListPanel/Scroll View/Viewport/ListContent/ListFriendItem/NameText"):GetComponent("Text");
    self.closeBtn = self.transform:Find("CloseBtn").gameObject;
    self.addFrendBtn = self.transform:Find("SelectBtns/AddFrendBtn").gameObject;
    self.selectIcon = self.transform:Find("SelectBtns/AddFrendBtn/SelectIcon").gameObject;
    self.friendListBtn = self.transform:Find("SelectBtns/FriendListBtn").gameObject;
    self.selectIcon = self.transform:Find("SelectBtns/FriendListBtn/SelectIcon").gameObject;

end 

function FriendViewUI:InitView(objUI)
    if null ~= objUI then
	    self.gameObject = objUI;
		self.transform = self.gameObject.transform;
        self:InitControl(); 
	end
	self:Init();
end

function FriendViewUI:Init()
end