--UI View Gen From GenUITools
--Please Don't Modify!

LuckDrawViewUI = class(LuckDrawViewUI)

function LuckDrawViewUI:InitControl()  
    self.selectLuckDrawPanel = self.transform:Find("selectLuckDrawPanel").gameObject;
    self.btnFreeIcon = self.transform:Find("selectLuckDrawPanel/YuanYangGuoItem/btn_once/btnFreeIcon").gameObject;
    self.timeTitleObj = self.transform:Find("selectLuckDrawPanel/timeTitleObj").gameObject;
    self.txtTime = self.transform:Find("selectLuckDrawPanel/timeTitleObj/txtTime"):GetComponent("Text");
    self.txtGoldNumber = self.transform:Find("selectLuckDrawPanel/CoinItem/txtGoldNumber"):GetComponent("Text");
    self.btn_Hero = self.transform:Find("selectLuckDrawPanel/btn_Hero").gameObject;
    self.btn_Equipment = self.transform:Find("selectLuckDrawPanel/btn_Equipment").gameObject;
    self.btnClose = self.transform:Find("selectLuckDrawPanel/btnClose").gameObject;
    self.itemsPanel = self.transform:Find("itemsPanel").gameObject;
    self.items = self.transform:Find("itemsPanel/Items").gameObject;
    self.btnListClose = self.transform:Find("itemsPanel/Items/btnListClose").gameObject;
    self.listContent = self.transform:Find("itemsPanel/Items/Scroll View/Viewport/listContent").gameObject;
    self.listItem = self.transform:Find("itemsPanel/Items/Scroll View/Viewport/listContent/listItem").gameObject;
    self.arrow = self.transform:Find("itemsPanel/Items/arrow");
    self.resultPanel = self.transform:Find("resultPanel").gameObject;
    self.guanZiObjs = self.transform:Find("resultPanel/GuanZiObjs");
    self.yuanYangGuanZi = self.transform:Find("resultPanel/GuanZiObjs/yuanYangGuanZi").gameObject;
    self.taizi = self.transform:Find("resultPanel/GuanZiObjs/yuanYangGuanZi/taizi"):GetComponent("Image");
    self.animator_Play = self.transform:Find("resultPanel/GuanZiObjs/yuanYangGuanZi/animator_Play").gameObject;
    self.imgMiddle = self.transform:Find("resultPanel/GuanZiObjs/yuanYangGuanZi/animator_Play/GameObject/imgMiddle"):GetComponent("Image");
    self.objWater = self.transform:Find("resultPanel/GuanZiObjs/yuanYangGuanZi/animator_Play/GameObject/objWater").gameObject;
    self.objLight = self.transform:Find("resultPanel/GuanZiObjs/yuanYangGuanZi/animator_Play/GameObject/objLight").gameObject;
    self.imgUp = self.transform:Find("resultPanel/GuanZiObjs/yuanYangGuanZi/imgUp"):GetComponent("Image");
    self.objFire = self.transform:Find("resultPanel/GuanZiObjs/yuanYangGuanZi/objFire").gameObject;
    self.lidMoveEndPos = self.transform:Find("resultPanel/GuanZiObjs/lidMoveEndPos");
    self.normalUpPos = self.transform:Find("resultPanel/GuanZiObjs/normalUpPos");
    self.normalPosObj = self.transform:Find("resultPanel/Panels/normalPosObj");
    self.tenResultPanel = self.transform:Find("resultPanel/Panels/tenResultPanel");
    self.resultLeft = self.transform:Find("resultPanel/Panels/tenResultPanel/resultLeft");
    self.resultRight = self.transform:Find("resultPanel/Panels/tenResultPanel/resultRight");
    self.onceResultPanel = self.transform:Find("resultPanel/Panels/onceResultPanel");
    self.onceItem = self.transform:Find("resultPanel/Panels/onceResultPanel/onceItem");
    self.imgOnceIcon = self.transform:Find("resultPanel/Panels/onceResultPanel/onceItem/imgOnceIcon"):GetComponent("Image");
    self.txtOnceNumber = self.transform:Find("resultPanel/Panels/onceResultPanel/onceItem/txtOnceNumber"):GetComponent("Text");
    self.btns_result = self.transform:Find("resultPanel/btns_result").gameObject;
    self.btnOnceMore = self.transform:Find("resultPanel/btns_result/btns/btnOnceMore").gameObject;
    self.txtOnceMoreGold = self.transform:Find("resultPanel/btns_result/btns/btnOnceMore/txtOnceMoreGold"):GetComponent("Text");
    self.btnSureClick = self.transform:Find("resultPanel/btns_result/btns/btnSureClick").gameObject;

end 

function LuckDrawViewUI:InitView(objUI)
    if null ~= objUI then
	    self.gameObject = objUI;
		self.transform = self.gameObject.transform;
        self:InitControl(); 
	end
	self:Init();
end

function LuckDrawViewUI:Init()
end