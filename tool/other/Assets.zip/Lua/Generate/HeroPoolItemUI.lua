--UI View Gen From GenUITools
--Please Don't Modify!

HeroPoolItemUI = class(HeroPoolItemUI)

function HeroPoolItemUI:InitControl()  
    self.icon = self.transform:Find("icon"):GetComponent("Image");
    self.name = self.transform:Find("name"):GetComponent("Text");
    self.mask = self.transform:Find("mask").gameObject;
    self.spot = self.transform:Find("spot").gameObject;

end 

function HeroPoolItemUI:InitView(objUI)
    if null ~= objUI then
	    self.gameObject = objUI;
		self.transform = self.gameObject.transform;
        self:InitControl(); 
	end
	self:Init();
end

function HeroPoolItemUI:Init()
end