--UI View Gen From GenUITools
--Please Don't Modify!

MatchViewUI = class(MatchViewUI)

function MatchViewUI:InitControl()  
    self.txtMatch = self.transform:Find("txtMatch"):GetComponent("Text");
    self.btnCancel = self.transform:Find("btnCancel").gameObject;

end 

function MatchViewUI:InitView(objUI)
    if null ~= objUI then
	    self.gameObject = objUI;
		self.transform = self.gameObject.transform;
        self:InitControl(); 
	end
	self:Init();
end

function MatchViewUI:Init()
end