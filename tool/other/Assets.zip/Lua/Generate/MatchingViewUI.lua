--UI View Gen From GenUITools
--Please Don't Modify!

MatchingViewUI = class(MatchingViewUI)

function MatchingViewUI:InitControl()  
    self.friendList = self.transform:Find("FriendList/ItemContent/Viewport/FriendList");
    self.matchingFriendItem = self.transform:Find("FriendList/ItemContent/Viewport/FriendList/MatchingFriendItem").gameObject;
    self.refuseTime = self.transform:Find("FriendList/ItemContent/Viewport/FriendList/MatchingFriendItem/States/RefuseState/RefuseTime"):GetComponent("Text");
    self.hadInvitedTime = self.transform:Find("FriendList/ItemContent/Viewport/FriendList/MatchingFriendItem/States/HadInvitedState/HadInvitedTime"):GetComponent("Text");
    self.friendBtn = self.transform:Find("FriendList/FriendBtn").gameObject;
    self.latelyBtn = self.transform:Find("FriendList/LatelyBtn").gameObject;
    self.readyToMatchBtn = self.transform:Find("FriendList/ReadyToMatchBtn").gameObject;
    self.cancelReadyBtn = self.transform:Find("FriendList/CancelReadyBtn").gameObject;
    self.objVoice = self.transform:Find("FriendList/objVoice").gameObject;
    self.inTeamList = self.transform:Find("InTeamList");
    self.backBtn = self.transform:Find("InTeamList/TopBar/BackBtn").gameObject;
    self.matchingPanel = self.transform:Find("MatchingPanel").gameObject;
    self.cancelMatchingBtn = self.transform:Find("MatchingPanel/CancelMatchingBtn").gameObject;
    self.timeText = self.transform:Find("MatchingPanel/CancelMatchingBtn/TimeText"):GetComponent("Text");
    self.readyPanel = self.transform:Find("ReadyCanvas/ReadyPanel").gameObject;
    self.titleText = self.transform:Find("ReadyCanvas/ReadyPanel/Panel/TitleIcon/TitleText"):GetComponent("Text");
    self.readyTimeText = self.transform:Find("ReadyCanvas/ReadyPanel/Panel/ReadyTimeText"):GetComponent("Text");
    self.playerList = self.transform:Find("ReadyCanvas/ReadyPanel/Panel/PlayerList");
    self.playerItem = self.transform:Find("ReadyCanvas/ReadyPanel/Panel/PlayerList/PlayerItem").gameObject;
    self.readyToPlayBtn = self.transform:Find("ReadyCanvas/ReadyPanel/Panel/ReadyToPlayBtn").gameObject;

end 

function MatchingViewUI:InitView(objUI)
    if null ~= objUI then
	    self.gameObject = objUI;
		self.transform = self.gameObject.transform;
        self:InitControl(); 
	end
	self:Init();
end

function MatchingViewUI:Init()
end