--UI View Gen From GenUITools
--Please Don't Modify!

TipType1ViewUI = class(TipType1ViewUI)

function TipType1ViewUI:InitControl()  
    self.mask = self.transform:Find("mask").gameObject;
    self.txtContent = self.transform:Find("txtContent"):GetComponent("Text");
    self.btnCancel = self.transform:Find("btns/btnCancel"):GetComponent("Button");
    self.btnConfirm = self.transform:Find("btns/btnConfirm"):GetComponent("Button");

end 

function TipType1ViewUI:InitView(objUI)
    if null ~= objUI then
	    self.gameObject = objUI;
		self.transform = self.gameObject.transform;
        self:InitControl(); 
	end
	self:Init();
end

function TipType1ViewUI:Init()
end