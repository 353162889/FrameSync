--UI View Gen From GenUITools
--Please Don't Modify!

MobaBattleInfoViewUI = class(MobaBattleInfoViewUI)

function MobaBattleInfoViewUI:InitControl()  
    self.mask = self.transform:Find("mask"):GetComponent("Image");
    self.mainContainer = self.transform:Find("mainContainer"):GetComponent("Image");
    self.baseInfoContainer = self.transform:Find("mainContainer/baseInfoContainer").gameObject;
    self.skillIconContainer = self.transform:Find("mainContainer/skillIconContainer").gameObject;
    self.playerInfoContainer = self.transform:Find("mainContainer/playerInfoContainer").gameObject;
    self.playerInfoItem = self.transform:Find("mainContainer/playerInfoContainer/playerInfoItem").gameObject;
    self.txt_myCampKillNum = self.transform:Find("mainContainer/myDataContainer/txt_myCampKillNum"):GetComponent("Text");
    self.txt_myCampSocre = self.transform:Find("mainContainer/myDataContainer/txt_myCampSocre"):GetComponent("Text");
    self.txt_enemyCampKillNum = self.transform:Find("mainContainer/enemyDataContainer/txt_enemyCampKillNum"):GetComponent("Text");
    self.txt_enemyCampSocre = self.transform:Find("mainContainer/enemyDataContainer/txt_enemyCampSocre"):GetComponent("Text");
    self.btn_showInfo = self.transform:Find("mainContainer/btn_showInfo").gameObject;
    self.btn_showSkill = self.transform:Find("mainContainer/btn_showSkill").gameObject;
    self.btn_back = self.transform:Find("btn_back").gameObject;
    self.img_gameResult = self.transform:Find("img_gameResult"):GetComponent("Image");
    self.lineConitaner = self.transform:Find("lineConitaner").gameObject;

end 

function MobaBattleInfoViewUI:InitView(objUI)
    if null ~= objUI then
	    self.gameObject = objUI;
		self.transform = self.gameObject.transform;
        self:InitControl(); 
	end
	self:Init();
end

function MobaBattleInfoViewUI:Init()
end