--UI View Gen From GenUITools
--Please Don't Modify!

ActiveSystemViewUIUI = class(ActiveSystemViewUIUI)

function ActiveSystemViewUIUI:InitControl()  
    self.signInBtn = self.transform:Find("SysBtns/SignInBtn"):GetComponent("Button");
    self.activitySignInPanel = self.transform:Find("SysPanels/ActivitySignInPanel").gameObject;
    self.content = self.transform:Find("SysPanels/ActivitySignInPanel/Scroll View/Viewport/Content");
    self.signInBtn = self.transform:Find("SysPanels/ActivitySignInPanel/SignInBtn"):GetComponent("Button");
    self.rewardIcon = self.transform:Find("SysPanels/ActivitySignInPanel/RewardIcon"):GetComponent("Image");
    self.rewardNumberText = self.transform:Find("SysPanels/ActivitySignInPanel/RewardNumberText"):GetComponent("Text");
    self.closeBtn = self.transform:Find("CloseBtn"):GetComponent("Button");
    self.titleText = self.transform:Find("TitleIcon/TitleText"):GetComponent("Text");

end 

function ActiveSystemViewUIUI:InitView(objUI)
    if null ~= objUI then
	    self.gameObject = objUI;
		self.transform = self.gameObject.transform;
        self:InitControl(); 
	end
	self:Init();
end

function ActiveSystemViewUIUI:Init()
end