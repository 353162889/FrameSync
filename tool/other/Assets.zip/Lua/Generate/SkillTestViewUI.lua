--UI View Gen From GenUITools
--Please Don't Modify!

SkillTestViewUI = class(SkillTestViewUI)

function SkillTestViewUI:InitControl()  
    self.operateBars = self.transform:Find("OperateBars").gameObject;
    self.moveJoystickPos = self.transform:Find("OperateBars/moveJoystickPos");
    self.normalSkillBtn = self.transform:Find("OperateBars/skill/normalSkillBtn").gameObject;
    self.normalSkillMask = self.transform:Find("OperateBars/skill/normalSkillBtn/normalSkillMask"):GetComponent("Image");
    self.skillBtn1 = self.transform:Find("OperateBars/skill/skillBtn1").gameObject;
    self.skillEnergy1 = self.transform:Find("OperateBars/skill/skillBtn1/skillEnergy1"):GetComponent("Image");
    self.imgSkillLeaveTime1 = self.transform:Find("OperateBars/skill/skillBtn1/imgSkillLeaveTime1"):GetComponent("Image");
    self.skillIcon1 = self.transform:Find("OperateBars/skill/skillBtn1/skillIcon1"):GetComponent("Image");
    self.txtSkillBg1 = self.transform:Find("OperateBars/skill/skillBtn1/txtSkillBg1").gameObject;
    self.txtEnergy1 = self.transform:Find("OperateBars/skill/skillBtn1/txtSkillBg1/txtEnergy1"):GetComponent("Text");
    self.skillMask1 = self.transform:Find("OperateBars/skill/skillBtn1/skillMask1"):GetComponent("Image");
    self.cdTime1 = self.transform:Find("OperateBars/skill/skillBtn1/skillMask1/CdTime1"):GetComponent("Text");
    self.skillBtn2 = self.transform:Find("OperateBars/skill/skillBtn2").gameObject;
    self.skillEnergy2 = self.transform:Find("OperateBars/skill/skillBtn2/skillEnergy2"):GetComponent("Image");
    self.imgSkillLeaveTime2 = self.transform:Find("OperateBars/skill/skillBtn2/imgSkillLeaveTime2"):GetComponent("Image");
    self.skillIcon2 = self.transform:Find("OperateBars/skill/skillBtn2/skillIcon2"):GetComponent("Image");
    self.txtSkillBg2 = self.transform:Find("OperateBars/skill/skillBtn2/txtSkillBg2").gameObject;
    self.txtEnergy2 = self.transform:Find("OperateBars/skill/skillBtn2/txtSkillBg2/txtEnergy2"):GetComponent("Text");
    self.skillMask2 = self.transform:Find("OperateBars/skill/skillBtn2/skillMask2"):GetComponent("Image");
    self.cdTime2 = self.transform:Find("OperateBars/skill/skillBtn2/skillMask2/CdTime2"):GetComponent("Text");
    self.skillBtn3 = self.transform:Find("OperateBars/skill/skillBtn3").gameObject;
    self.skillEnergy3 = self.transform:Find("OperateBars/skill/skillBtn3/skillEnergy3"):GetComponent("Image");
    self.imgSkillLeaveTime3 = self.transform:Find("OperateBars/skill/skillBtn3/imgSkillLeaveTime3"):GetComponent("Image");
    self.skillIcon3 = self.transform:Find("OperateBars/skill/skillBtn3/skillIcon3"):GetComponent("Image");
    self.txtSkillBg3 = self.transform:Find("OperateBars/skill/skillBtn3/txtSkillBg3").gameObject;
    self.txtEnergy3 = self.transform:Find("OperateBars/skill/skillBtn3/txtSkillBg3/txtEnergy3"):GetComponent("Text");
    self.skillMask3 = self.transform:Find("OperateBars/skill/skillBtn3/skillMask3"):GetComponent("Image");
    self.cdTime3 = self.transform:Find("OperateBars/skill/skillBtn3/skillMask3/CdTime3"):GetComponent("Text");
    self.lockBars = self.transform:Find("LockBars").gameObject;
    self.pingValue = self.transform:Find("SetOrFps_RightTop/pingValue"):GetComponent("Text");
    self.fpsValue = self.transform:Find("SetOrFps_RightTop/fpsValue"):GetComponent("Text");

end 

function SkillTestViewUI:InitView(objUI)
    if null ~= objUI then
	    self.gameObject = objUI;
		self.transform = self.gameObject.transform;
        self:InitControl(); 
	end
	self:Init();
end

function SkillTestViewUI:Init()
end