--UI View Gen From GenUITools
--Please Don't Modify!

BattleResultBornViewUI = class(BattleResultBornViewUI)

function BattleResultBornViewUI:InitControl()  
    self.boxEffect = self.transform:Find("boxEffect").gameObject;
    self.content = self.transform:Find("Content").gameObject;
    self.effect = self.transform:Find("Content/effect").gameObject;
    self.born1Grid = self.transform:Find("Content/born1/born1Grid").gameObject;
    self.imgAce = self.transform:Find("Content/iconBorn2/imgAce").gameObject;
    self.imgKd = self.transform:Find("Content/iconBorn2/imgKd").gameObject;
    self.imgMvp = self.transform:Find("Content/iconBorn2/imgMvp").gameObject;
    self.born2Grid = self.transform:Find("Content/born2/born2Grid").gameObject;
    self.btnBack = self.transform:Find("Content/btnBack"):GetComponent("Button");

end 

function BattleResultBornViewUI:InitView(objUI)
    if null ~= objUI then
	    self.gameObject = objUI;
		self.transform = self.gameObject.transform;
        self:InitControl(); 
	end
	self:Init();
end

function BattleResultBornViewUI:Init()
end