--UI View Gen From GenUITools
--Please Don't Modify!

StrengthenEquipViewUI = class(StrengthenEquipViewUI)

function StrengthenEquipViewUI:InitControl()  
    self.mask = self.transform:Find("Mask").gameObject;
    self.btn_left = self.transform:Find("MainContainer/HeroSwitchContainer/btn_left").gameObject;
    self.btn_right = self.transform:Find("MainContainer/HeroSwitchContainer/btn_right").gameObject;
    self.btn_switchShowStatus = self.transform:Find("MainContainer/HeroSwitchContainer/btn_switchShowStatus").gameObject;
    self.breakContainer = self.transform:Find("MainContainer/StrengthenEquipContainer/SingleEquipItem/breakContainer").gameObject;
    self.btn_break = self.transform:Find("MainContainer/StrengthenEquipContainer/SingleEquipItem/breakContainer/btn_break").gameObject;
    self.txt_breakDesc = self.transform:Find("MainContainer/StrengthenEquipContainer/SingleEquipItem/breakContainer/Image (2)/txt_breakDesc"):GetComponent("Text");
    self.btn_unlock = self.transform:Find("MainContainer/StrengthenEquipContainer/SingleEquipItem/btn_unlock").gameObject;
    self.btn_close = self.transform:Find("MainContainer/btn_close").gameObject;

end 

function StrengthenEquipViewUI:InitView(objUI)
    if null ~= objUI then
	    self.gameObject = objUI;
		self.transform = self.gameObject.transform;
        self:InitControl(); 
	end
	self:Init();
end

function StrengthenEquipViewUI:Init()
end