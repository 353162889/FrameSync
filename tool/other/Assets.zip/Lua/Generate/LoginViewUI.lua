--UI View Gen From GenUITools
--Please Don't Modify!

LoginViewUI = class(LoginViewUI)

function LoginViewUI:InitControl()  
    self.centerUp = self.transform:Find("CenterUp");
    self.loginBtn = self.transform:Find("CenterUp/loginBtn").gameObject;
    self.container = self.transform:Find("CenterUp/container").gameObject;
    self.userNameInput = self.transform:Find("CenterUp/container/UserName/userNameInput"):GetComponent("InputField");

end 

function LoginViewUI:InitView(objUI)
    if null ~= objUI then
	    self.gameObject = objUI;
		self.transform = self.gameObject.transform;
        self:InitControl(); 
	end
	self:Init();
end

function LoginViewUI:Init()
end