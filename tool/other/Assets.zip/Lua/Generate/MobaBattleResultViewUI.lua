--UI View Gen From GenUITools
--Please Don't Modify!

MobaBattleResultViewUI = class(MobaBattleResultViewUI)

function MobaBattleResultViewUI:InitControl()  
    self.selfInfo = self.transform:Find("selfInfo").gameObject;
    self.txtSelfKill = self.transform:Find("selfInfo/txtSelfKill"):GetComponent("Text");
    self.txtSelfDie = self.transform:Find("selfInfo/txtSelfDie"):GetComponent("Text");
    self.imgWin = self.transform:Find("selfInfo/Status/imgWin").gameObject;
    self.imgFail = self.transform:Find("selfInfo/Status/imgFail").gameObject;
    self.imgDeuce = self.transform:Find("selfInfo/Status/imgDeuce").gameObject;
    self.redParent = self.transform:Find("redParent");
    self.blueParent = self.transform:Find("blueParent");
    self.btnBack = self.transform:Find("BtnBack"):GetComponent("Button");
    self.startPosX = self.transform:Find("AnimPos/StartPosX");

end 

function MobaBattleResultViewUI:InitView(objUI)
    if null ~= objUI then
	    self.gameObject = objUI;
		self.transform = self.gameObject.transform;
        self:InitControl(); 
	end
	self:Init();
end

function MobaBattleResultViewUI:Init()
end