--UI View Gen From GenUITools
--Please Don't Modify!

TipType2ViewUI = class(TipType2ViewUI)

function TipType2ViewUI:InitControl()  
    self.mask = self.transform:Find("mask").gameObject;
    self.txtContent = self.transform:Find("txtContent"):GetComponent("Text");
    self.btnClose = self.transform:Find("btnClose"):GetComponent("Button");

end 

function TipType2ViewUI:InitView(objUI)
    if null ~= objUI then
	    self.gameObject = objUI;
		self.transform = self.gameObject.transform;
        self:InitControl(); 
	end
	self:Init();
end

function TipType2ViewUI:Init()
end