--UI View Gen From GenUITools
--Please Don't Modify!

FightBarViewUI = class(FightBarViewUI)

function FightBarViewUI:InitControl()  
    self.hPBars = self.transform:Find("HPBars").gameObject;
    self.bubbleBars = self.transform:Find("BubbleBars").gameObject;

end 

function FightBarViewUI:InitView(objUI)
    if null ~= objUI then
	    self.gameObject = objUI;
		self.transform = self.gameObject.transform;
        self:InitControl(); 
	end
	self:Init();
end

function FightBarViewUI:Init()
end