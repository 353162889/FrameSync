--UI View Gen From GenUITools
--Please Don't Modify!

MallViewUI = class(MallViewUI)

function MallViewUI:InitControl()  
    self.backLobbyBtn = self.transform:Find("BackLobbyBtn").gameObject;
    self.btnSliverPlus = self.transform:Find("bgIconSliver/btnSliverPlus").gameObject;
    self.txtSliver = self.transform:Find("bgIconSliver/txtSliver"):GetComponent("Text");
    self.btnGoldPlus = self.transform:Find("bgIconGold/btnGoldPlus").gameObject;
    self.txtGold = self.transform:Find("bgIconGold/txtGold"):GetComponent("Text");
    self.buyYueKaBtn = self.transform:Find("BuyYueKaBtn").gameObject;
    self.notBuyYueKaIcon = self.transform:Find("NotBuyYueKaIcon").gameObject;
    self.icon1 = self.transform:Find("RewardShow/RewardItem1/Icon1"):GetComponent("Image");
    self.numberText1 = self.transform:Find("RewardShow/RewardItem1/Icon1/numberText1"):GetComponent("Text");
    self.icon2 = self.transform:Find("RewardShow/RewardItem2/Icon2"):GetComponent("Image");
    self.numberText2 = self.transform:Find("RewardShow/RewardItem2/Icon2/numberText2"):GetComponent("Text");

end 

function MallViewUI:InitView(objUI)
    if null ~= objUI then
	    self.gameObject = objUI;
		self.transform = self.gameObject.transform;
        self:InitControl(); 
	end
	self:Init();
end

function MallViewUI:Init()
end