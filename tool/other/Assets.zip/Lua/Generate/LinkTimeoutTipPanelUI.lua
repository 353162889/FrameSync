--UI View Gen From GenUITools
--Please Don't Modify!

LinkTimeoutTipPanelUI = class(LinkTimeoutTipPanelUI)

function LinkTimeoutTipPanelUI:InitControl()  
    self.btnClose = self.transform:Find("centerView/btnClose").gameObject;
    self.titileInfo = self.transform:Find("centerView/titileInfo"):GetComponent("Text");

end 

function LinkTimeoutTipPanelUI:InitView(objUI)
    if null ~= objUI then
	    self.gameObject = objUI;
		self.transform = self.gameObject.transform;
        self:InitControl(); 
	end
	self:Init();
end

function LinkTimeoutTipPanelUI:Init()
end