--UI View Gen From GenUITools
--Please Don't Modify!

CommonTipPanelViewUI = class(CommonTipPanelViewUI)

function CommonTipPanelViewUI:InitControl()  
    self.titleText = self.transform:Find("centerView/titleText"):GetComponent("Text");
    self.descText = self.transform:Find("centerView/descText"):GetComponent("Text");
    self.okButton = self.transform:Find("centerView/okButton").gameObject;
    self.cancleButton = self.transform:Find("centerView/cancleButton").gameObject;
    self.okLoginButton = self.transform:Find("centerView/okLoginButton").gameObject;

end 

function CommonTipPanelViewUI:InitView(objUI)
    if null ~= objUI then
	    self.gameObject = objUI;
		self.transform = self.gameObject.transform;
        self:InitControl(); 
	end
	self:Init();
end

function CommonTipPanelViewUI:Init()
end